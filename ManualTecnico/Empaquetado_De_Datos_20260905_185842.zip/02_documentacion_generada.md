# Manual de Usuario - `ActiveTestSuite`

### 1. Resumen Ejecutivo

`ActiveTestSuite` es una extensión de `junit.framework.TestSuite` ubicada en el paquete `junit.extensions` diseñada para la ejecución concurrente de pruebas unitarias. Su propósito es ejecutar cada `Test` contenido en la suite en un hilo (`Thread`) separado de forma paralela y bloquear la ejecución principal hasta que todos los hilos hayan finalizado, permitiendo validar el comportamiento del sistema bajo condiciones de concurrencia.

### 2. Especificación de Funciones

#### 2.1 Constructores `ActiveTestSuite()`

Conjunto de constructores que inicializan la suite activa. Heredan el comportamiento de `TestSuite`.

**a) `ActiveTestSuite()`**

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | Constructor por defecto. Crea una suite vacía sin nombre. |

**b) `ActiveTestSuite(Class<? extends TestCase> theClass)`**

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `theClass` | `Class<? extends TestCase>` | Sí | Clase de tipo `TestCase` de la cual se extraerán automáticamente todos los métodos de prueba `test*` para poblar la suite. |

**c) `ActiveTestSuite(String name)`**

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `name` | `String` | Sí | Nombre asignado a la suite de pruebas. |

**d) `ActiveTestSuite(Class<? extends TestCase> theClass, String name)`**

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `theClass` | `Class<? extends TestCase>` | Sí | Clase de tipo `TestCase` a extraer. |
| `name` | `String` | Sí | Nombre asignado a la suite. |

**Valor de Retorno:** Instancia de `ActiveTestSuite`.
**Manejo de Errores:** No realiza manejo explícito. Delega la validación de parámetros a la clase padre `TestSuite`.

---

#### 2.2 `run(TestResult result)`

Método principal de ejecución de la suite. Sobrescribe `TestSuite.run()` para implementar la lógica de espera activa.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `result` | `TestResult` | Sí | Objeto colector donde se reportan los éxitos, fallos y errores de cada test. |

**Valor de Retorno:** `void`
**Manejo de Errores:** No lanza excepciones. No captura errores de los tests hijos; estos son reportados en el objeto `TestResult`.
**Comportamiento:**
1. Reinicia el contador volátil `fActiveTestDeathCount` a `0`.
2. Invoca a `super.run(result)`, lo que dispara `runTest()` para cada test de la suite.
3. Invoca a `waitUntilFinished()` para bloquear el hilo principal hasta que todos los hilos hijos terminen.

---

#### 2.3 `runTest(final Test test, final TestResult result)`

Sobrescribe `TestSuite.runTest()` para cambiar la ejecución secuencial por una ejecución concurrente. No ejecuta el test directamente, sino que lo delega a un nuevo hilo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `test` | `Test` | Sí | Caso de prueba individual a ejecutar. |
| `result` | `TestResult` | Sí | Colector de resultados compartido entre todos los hilos. |

**Valor de Retorno:** `void`
**Manejo de Errores:** No lanza ni captura excepciones directamente. La ejecución del test dentro del hilo está protegida por un bloque `try-finally` para garantizar la notificación de finalización incluso si `test.run()` falla.
**Comportamiento:** Crea una instancia de `Thread`, sobrescribe su método `run()` y ejecuta `t.start()` de forma inmediata.

---

#### 2.4 `run()` - Método Anidado / Local dentro de `runTest()`

Función anónima y local definida dentro de `runTest()` como `new Thread() { @Override public void run() { ... } }`. Es el *worker* que ejecuta cada test en paralelo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | No recibe parámetros. Captura por clausura las variables `final Test test` y `final TestResult result` del método padre. |

**Valor de Retorno:** `void`
**Manejo de Errores:** No propaga excepciones. Utiliza un bloque `try-finally` para asegurar que `ActiveTestSuite.this.runFinished()` se ejecute siempre, incluso si `test.run(result)` lanza una excepción o error de aserción.
**Comportamiento:**
1. `try`: Ejecuta `test.run(result)`.
2. `finally`: Invoca a `runFinished()` para incrementar el contador de hilos terminados y notificar al hilo en espera.

---

#### 2.5 `waitUntilFinished()`

Método de sincronización que bloquea el hilo principal hasta que todos los tests activos hayan reportado su finalización. Visibilidad de paquete (`package-private`) y sincronizado.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | No recibe parámetros. Opera sobre el estado interno `fActiveTestDeathCount` y `testCount()`. |

**Valor de Retorno:** `void`
**Manejo de Errores:** Captura `InterruptedException` lanzada por `wait()`. En caso de interrupción, realiza un `return` inmediato y sale del ciclo de espera, ignorando la excepción sin re-lanzarla ni restaurar el estado de interrupción. Utiliza un bucle `while (fActiveTestDeathCount < testCount())` para protegerse contra despertares espurios.
**Sincronización:** Declarado como `synchronized`. Utiliza `wait()` y es notificado por `runFinished()`.

---

#### 2.6 `runFinished()`

Método de callback invocado por cada hilo hijo al terminar su ejecución. Es el mecanismo de conteo y notificación.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | No recibe parámetros. |

**Valor de Retorno:** `void`
**Manejo de Errores:** No genera ni captura errores.
**Sincronización:** Declarado como `public synchronized`.
**Comportamiento:**
1. Incrementa de forma atómica `fActiveTestDeathCount++`.
2. Invoca a `notifyAll()` para despertar al hilo bloqueado en `waitUntilFinished()` y reevaluar la condición de finalización.

### 3. Ejemplo de Uso

Caso real: Ejecución concurrente de una clase de pruebas `MiTestCase` para detectar condiciones de carrera.

```java
import junit.extensions.ActiveTestSuite;
import junit.framework.Test;
import junit.framework.TestResult;
import junit.framework.TestSuite;

// 1. Crear la suite activa a partir de una clase TestCase
TestSuite suite = new ActiveTestSuite(MiTestCase.class, "Suite Concurrente");

// Alternativa: Creación manual
// TestSuite suite = new ActiveTestSuite("Suite Concurrente");
// suite.addTest(new MiTestCase("testMetodoSincronizado"));
// suite.addTest(new MiTestCase("testAccesoConcurrente"));

// 2. Crear el colector de resultados
TestResult result = new TestResult();

// 3. Ejecutar la suite. Cada test se lanzará en un Thread separado.
// El método run() se bloqueará hasta que todos los hilos finalicen.
suite.run(result);

// 4. Evaluar resultados
System.out.println("Tests ejecutados: " + result.runCount());
System.out.println("Fallos: " + result.failureCount());
System.out.println("Errores: " + result.errorCount());

if (result.wasSuccessful()) {
    System.out.println("Todos los tests concurrentes pasaron correctamente.");
}
```