# Documentación Técnica - `wrappers.py` (Flask `Request` / `Response`)

## 1. Resumen Ejecutivo

Este módulo extiende las clases base `Request` y `Response` de Werkzeug para integrarlas con el contexto de aplicación de Flask. La clase `Request` añade resolución de endpoints/blueprints, gestión de límites configurables (`MAX_CONTENT_LENGTH`, `MAX_FORM_MEMORY_SIZE`, `MAX_FORM_PARTS`) y manejo de errores JSON/form-data adaptado al modo `debug`. La clase `Response` personaliza el `mimetype` por defecto a `text/html` y expone la configuración `MAX_COOKIE_SIZE` de la aplicación.

## 2. Especificación de Funciones

### 2.1 Clase `Request` - Hereda de `werkzeug.wrappers.Request`

#### `Request.max_content_length` (property getter)

Obtiene el límite máximo de bytes que se leerán en la petición actual. Prioriza el valor por instancia (`_max_content_length`), luego la configuración de `current_app` y finalmente el valor por defecto de Werkzeug.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `max_content_length` | `int \| None` | Límite en bytes. `None` si no hay límite. |

**Manejo de Errores:** No lanza excepciones directamente. Si `current_app` no está disponible (fuera de contexto de aplicación), delega a `super().max_content_length`.

#### `Request.max_content_length` (setter)

Establece un límite específico para la petición actual, sobrescribiendo la configuración global.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |
| `value` | `int \| None` | Sí | Nuevo límite en bytes. `None` para deshabilitar el límite. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | No retorna valor. Asigna a `self._max_content_length`. |

**Manejo de Errores:** No lanza excepciones.

#### `Request.max_form_memory_size` (property getter)

Obtiene el tamaño máximo en bytes que puede tener un campo de formulario no-archivo en un cuerpo `multipart/form-data`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `max_form_memory_size` | `int \| None` | Límite en bytes. Por defecto `500_000` vía config `MAX_FORM_MEMORY_SIZE`. `None` si no hay límite. |

**Manejo de Errores:** Si `current_app` no existe, delega a `super().max_form_memory_size`.

#### `Request.max_form_memory_size` (setter)

Establece el límite de memoria para campos de formulario para esta petición específica.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |
| `value` | `int \| None` | Sí | Nuevo límite en bytes. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Asigna a `self._max_form_memory_size`. |

**Manejo de Errores:** No lanza excepciones.

#### `Request.max_form_parts` (property getter)

Obtiene el número máximo de campos permitidos en un cuerpo `multipart/form-data`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `max_form_parts` | `int \| None` | Número máximo de partes. Por defecto `1_000` vía config `MAX_FORM_PARTS`. `None` si no hay límite. |

**Manejo de Errores:** Si `current_app` no existe, delega a `super().max_form_parts`.

#### `Request.max_form_parts` (setter)

Establece el límite de número de partes para esta petición específica.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |
| `value` | `int \| None` | Sí | Nuevo límite de partes. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Asigna a `self._max_form_parts`. |

**Manejo de Errores:** No lanza excepciones.

#### `Request.endpoint` (property getter)

Retorna el endpoint que coincidió con la URL solicitada.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `endpoint` | `str \| None` | Nombre del endpoint (`url_rule.endpoint`) o `None` si el matcheo falló o no se ha realizado. |

**Manejo de Errores:** No lanza excepciones. Retorna `None` si `self.url_rule is None`.

#### `Request.blueprint` (property getter)

Retorna el nombre registrado del blueprint actual.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `blueprint` | `str \| None` | Nombre del blueprint (prefijo antes del último `.` en el endpoint) o `None` si no pertenece a un blueprint. |

**Manejo de Errores:** No lanza excepciones.

#### `Request.blueprints` (property getter)

Retorna la lista jerárquica de nombres de blueprints desde el actual hasta sus padres.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `blueprints` | `list[str]` | Lista de nombres obtenida vía `_split_blueprint_path`. Lista vacía si `blueprint is None`. |

**Manejo de Errores:** No lanza excepciones.

#### `Request._load_form_data()`

Sobrescribe el cargador de datos de formulario de Werkzeug. Carga los datos y, si la aplicación está en modo `debug`, el `mimetype` no es `multipart/form-data` y no hay archivos, reemplaza `self.files` con un `MultiDict` especial que genera errores de `enctype` más descriptivos.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | No retorna valor. Efecto secundario sobre `self.form` y `self.files`. |

**Manejo de Errores:** No lanza excepciones directamente. Delega la carga a `super()._load_form_data()` que puede lanzar `RequestEntityTooLarge` si se exceden los límites. Importa y ejecuta `attach_enctype_error_multidict(self)` solo bajo condiciones de debug.

#### `Request.on_json_loading_failed()`

Manejador invocado cuando falla el parsing de JSON. Intenta delegar a la implementación de Werkzeug y normaliza la excepción resultante.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Request` | Sí | Instancia de la petición. |
| `e` | `ValueError \| None` | Sí | Excepción original del fallo de decodificación JSON. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Any` | `t.Any` | Retorno de `super().on_json_loading_failed(e)` si no lanza `BadRequest`. En la práctica, este método siempre lanza una excepción. |

**Manejo de Errores:**
| Condición | Excepción Lanzada |
| :--- | :--- |
| `super().on_json_loading_failed(e)` lanza `BadRequest` y `current_app.debug is True` | Re-lanza la misma excepción `BadRequest` original (`raise` sin argumentos). |
| `super().on_json_loading_failed(e)` lanza `BadRequest` y `current_app` es `None` o `debug is False` | Lanza un nuevo `BadRequest()` genérico encadenado `from ebr` para ocultar detalles internos. |

### 2.2 Clase `Response` - Hereda de `werkzeug.wrappers.Response`

#### `Response.max_cookie_size` (property getter)

Vista de solo lectura de la clave de configuración `MAX_COOKIE_SIZE`. Sobrescribe el comportamiento de Werkzeug para leer el valor desde `current_app.config`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Response` | Sí | Instancia de la respuesta. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `max_cookie_size` | `int` | Tamaño máximo de cookie en bytes definido en `current_app.config["MAX_COOKIE_SIZE"]`. Si no hay contexto de aplicación, retorna `super().max_cookie_size` (valor por defecto de Werkzeug). |

**Manejo de Errores:** No lanza excepciones. Requiere que `current_app` esté disponible para leer la configuración; de lo contrario hace fallback silencioso.

## 3. Ejemplo de Uso

```python
from flask import Flask, request, jsonify, Response

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024  # 1 MB global
app.config["MAX_COOKIE_SIZE"] = 4093

@app.route("/api/data", methods=["POST"])
def handle_data():
    # 1. Sobrescribir límite solo para esta vista
    request.max_content_length = 2 * 1024 * 1024  # 2 MB para este endpoint

    # 2. Inspeccionar routing
    print(f"Endpoint: {request.endpoint}")      # -> "handle_data"
    print(f"Blueprint: {request.blueprint}")    # -> None (no blueprint)
    print(f"Blueprints: {request.blueprints}")  # -> []

    # 3. Manejo de JSON - on_json_loading_failed() se invoca automáticamente
    # si el JSON es inválido. En debug lanzará BadRequest detallado,
    # en producción un BadRequest genérico.
    try:
        data = request.get_json(force=True)
    except Exception as e:
        return jsonify(error="JSON inválido"), 400

    # 4. Usar Response y verificar max_cookie_size
    resp = Response("OK", mimetype="text/html")
    print(f"Max cookie size: {resp.max_cookie_size}") # -> 4093

    resp.set_cookie("session", "valor_muy_largo...", max_size=resp.max_cookie_size)
    return resp

# Ejemplo con Blueprints anidados
from flask import Blueprint
api_bp = Blueprint("api", __name__)
v1_bp = Blueprint("v1", __name__)

@v1_bp.route("/users")
def users():
    # request.blueprint -> "api.v1"
    # request.blueprints -> ["api", "api.v1"]
    # request.endpoint -> "api.v1.users"
    return jsonify(blueprint=request.blueprint, blueprints=request.blueprints)

api_bp.register_blueprint(v1_bp, url_prefix="/v1")
app.register_blueprint(api_bp, url_prefix="/api")

if __name__ == "__main__":
    app.run(debug=True)
```