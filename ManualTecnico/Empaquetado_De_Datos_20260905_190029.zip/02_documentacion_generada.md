# Manual de Usuario (Alto Nivel) - `flask/globals.py`

## 1. Resumen Ejecutivo

Este módulo gestiona el acceso global al estado contextual de Flask mediante `ContextVar` y `LocalProxy`. Expone los proxies `app_ctx`, `current_app`, `g`, `request` y `session` que resuelven dinámicamente al contexto de aplicación o de petición activo, permitiendo acceder al estado sin pasar objetos explícitamente entre funciones. Incluye además un mecanismo de compatibilidad para el atributo deprecado `request_ctx`.

## 2. Especificación de Funciones

El análisis estático del código fuente detecta **2 funciones/métodos** definidos explícitamente. No existen funciones anidadas, callbacks ni workers adicionales.

### 2.1. `ProxyMixin._get_current_object()`

Método de protocolo definido dentro del bloque `if t.TYPE_CHECKING` para tipado estático. Define la interfaz que deben exponer todos los proxies (`FlaskProxy`, `AppContextProxy`, etc.).

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `ProxyMixin[T]` | Sí | Instancia del proxy. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `objeto actual` | `T` (covariante) | Retorna el objeto real subyacente al que apunta el `LocalProxy` (ej. instancia de `Flask`, `Request`, `SessionMixin`). |

| Manejo de Errores | Condición |
| :--- | :--- |
| No lanza errores directamente | Es un método de protocolo (`t.Protocol`) solo para type checkers; no tiene implementación en tiempo de ejecución. En tiempo de ejecución, `LocalProxy` lanza `RuntimeError` con mensaje `_no_app_msg` o `_no_req_msg` si se invoca fuera de contexto. |

> **Clases asociadas que heredan este método (solo para tipado):** `FlaskProxy`, `AppContextProxy`, `_AppCtxGlobalsProxy`, `RequestProxy`, `SessionMixinProxy`. No contienen lógica adicional ni métodos propios; existen únicamente para informar a los verificadores de tipos que el proxy se comporta como el tipo proxied + `_get_current_object`.

### 2.2. `__getattr__(name)`

Función a nivel de módulo que implementa [PEP 562](https://peps.python.org/pep-0562/) para interceptar accesos a atributos no encontrados en el módulo. Gestiona la compatibilidad hacia atrás del atributo deprecado `request_ctx`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `name` | `str` | Sí | Nombre del atributo solicitado al módulo `flask.globals`. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `app_ctx` | `AppContextProxy` (`LocalProxy[AppContext]`) | Retorna el proxy `app_ctx` únicamente cuando `name == "request_ctx"`. |

| Manejo de Errores / Comportamiento | Condición | Descripción |
| :--- | :--- | :--- |
| `DeprecationWarning` | `name == "request_ctx"` | Emite advertencia: `"'request_ctx' has merged with 'app_ctx', and will be removed in Flask 4.0. Use 'app_ctx' instead."` con `stacklevel=2`. La ejecución continúa y retorna `app_ctx`. |
| `AttributeError` | `name != "request_ctx"` | Lanza `AttributeError(name)` para cualquier otro atributo no definido en el módulo. |

**Variables de contexto expuestas por el módulo (no son funciones, pero son la API principal):**

*   `_cv_app: ContextVar[AppContext]`: Variable de contexto que almacena el `AppContext` actual.
*   `app_ctx: AppContextProxy`: Proxy a `_cv_app`. Error `RuntimeError(_no_app_msg)` si se usa fuera de contexto de aplicación.
*   `current_app: FlaskProxy`: Proxy a `_cv_app.app`. Error `RuntimeError(_no_app_msg)` si se usa fuera de contexto de aplicación.
*   `g: _AppCtxGlobalsProxy`: Proxy a `_cv_app.g`. Error `RuntimeError(_no_app_msg)` si se usa fuera de contexto de aplicación.
*   `request: RequestProxy`: Proxy a `_cv_app.request`. Error `RuntimeError(_no_req_msg)` si se usa fuera de contexto de petición.
*   `session: SessionMixinProxy`: Proxy a `_cv_app.session`. Error `RuntimeError(_no_req_msg)` si se usa fuera de contexto de petición.

## 3. Ejemplo de Uso

```python
from flask import Flask, g, current_app, request, session

app = Flask(__name__)
app.secret_key = 'clave-secreta'

@app.route('/perfil')
def perfil():
    # Acceso a proxies dentro de un contexto de petición activo
    print(f"App actual: {current_app.name}")
    print(f"Ruta solicitada: {request.path}")
    print(f"Usuario en g: {g.get('usuario', 'anonimo')}")
    session['visitas'] = session.get('visitas', 0) + 1
    return f"Hola {g.usuario}"

# 1. Uso dentro de contexto de aplicación (sin petición HTTP)
with app.app_context():
    print(current_app.config['SECRET_KEY'])
    g.usuario = "admin"  # Almacén temporal por contexto
    # Acceder a request aquí lanzaría RuntimeError: Working outside of request context.

# 2. Uso dentro de contexto de petición simulado (testing)
with app.test_request_context('/perfil?lang=es', method='GET'):
    g.usuario = "test_user"
    print(request.args.get('lang')) # -> 'es'
    print(session) # Sesión vacía pero accesible

# 3. Compatibilidad con atributo deprecado (emite DeprecationWarning)
import flask.globals
import warnings
warnings.simplefilter('always', DeprecationWarning)
ctx = flask.globals.request_ctx # Warning: 'request_ctx' has merged with 'app_ctx'
assert ctx is flask.globals.app_ctx

# 4. Fuera de contexto -> Error
try:
    print(current_app.name)
except RuntimeError as e:
    print(e) # Working outside of application context...
```