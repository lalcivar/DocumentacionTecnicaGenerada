# Docstrings de funciones - `junit.extensions.ActiveTestSuite`

## 1. Resumen Ejecutivo

`ActiveTestSuite` es una extensión de `junit.framework.TestSuite` que permite la ejecución concurrente de casos de prueba. Cada `Test` agregado a la suite se ejecuta en un hilo (`Thread`) independiente, mientras que el hilo principal se bloquea hasta que todos los hilos trabajadores han finalizado mediante un mecanismo de conteo y `wait()/notifyAll()`. Está diseñada para pruebas activas y asíncronas donde se requiere paralelismo.

## 2. Especificación de Funciones

Clase: `public class ActiveTestSuite extends TestSuite`
Atributo interno: `private volatile int fActiveTestDeathCount` - Contador volátil de hilos/test finalizados.

---

### `ActiveTestSuite()`

Constructor por defecto.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| - | - | - | No recibe parámetros. Inicializa una suite vacía. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| `ActiveTestSuite` | `ActiveTestSuite` | Nueva instancia vacía. |

**Manejo de Errores:** No lanza excepciones. Delega al constructor `TestSuite()`.

---

### `ActiveTestSuite(Class<? extends TestCase> theClass)`

Constructor que crea una suite a partir de una clase de TestCase.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `theClass` | `Class<? extends TestCase>` | Sí | Clase que extiende de `TestCase` de la cual se extraerán automáticamente los métodos `test*` como casos de prueba. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| `ActiveTestSuite` | `ActiveTestSuite` | Nueva instancia poblada con los tests de `theClass`. |

**Manejo de Errores:** No captura excepciones propias. Propaga excepciones si `theClass` es nula o no es válida según `super(theClass)`.

---

### `ActiveTestSuite(String name)`

Constructor que crea una suite vacía con un nombre identificador.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `name` | `String` | Sí | Nombre descriptivo de la suite. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| `ActiveTestSuite` | `ActiveTestSuite` | Nueva instancia nombrada. |

**Manejo de Errores:** No lanza excepciones controladas.

---

### `ActiveTestSuite(Class<? extends TestCase> theClass, String name)`

Constructor que crea una suite a partir de una clase y con un nombre específico.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `theClass` | `Class<? extends TestCase>` | Sí | Clase fuente de los casos de prueba. |
| `name` | `String` | Sí | Nombre asignado a la suite. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| `ActiveTestSuite` | `ActiveTestSuite` | Nueva instancia nombrada y poblada. |

**Manejo de Errores:** Propaga errores de `super(theClass, name)` si los argumentos son inválidos.

---

### `run(TestResult result)`

Sobrescribe `TestSuite.run()`. Inicia la ejecución concurrente de todos los tests y bloquea hasta su finalización.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `result` | `TestResult` | Sí | Objeto colector donde se reportan éxitos, fallos y errores de cada test. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| - | `void` | No retorna valor. |

**Manejo de Errores:** No lanza excepciones. Reinicia `fActiveTestDeathCount` a `0`, delega a `super.run(result)` para despachar cada test vía `runTest()` y luego invoca `waitUntilFinished()` para esperar.

---

### `runTest(final Test test, final TestResult result)`

Sobrescribe `TestSuite.runTest()`. Despacha un test individual en un nuevo hilo.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `test` | `Test` | Sí | Caso de prueba a ejecutar. |
| `result` | `TestResult` | Sí | Colector de resultados compartido entre hilos. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| - | `void` | No retorna valor. Crea e inicia el hilo de forma asíncrona. |

**Manejo de Errores:** No lanza excepciones. La ejecución del test dentro del hilo está protegida por `try-finally` para garantizar la notificación de finalización incluso si `test.run(result)` falla.

---

### `run()` - Método anidado / Worker de Hilo dentro de `runTest()`

Método anónimo `run()` de la clase interna `new Thread() { ... }` definida dentro de `runTest()`. Es el worker que ejecuta el test en paralelo.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| - | - | - | No recibe parámetros. Captura por clausura `test` y `result` del método padre `runTest()`. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| - | `void` | No retorna valor. |

**Comportamiento:** Invoca `test.run(result)` directamente (inlined por limitación de VA/Java en lugar de `ActiveTestSuite.super.runTest()`).
**Manejo de Errores:** Bloque `try-finally` garantiza que `ActiveTestSuite.this.runFinished()` se ejecute siempre, incluso si `test.run()` lanza una excepción o error.

---

### `waitUntilFinished()`

Método sincronizado que bloquea al hilo principal hasta que todos los tests activos terminen.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| - | - | - | No recibe parámetros. Usa `fActiveTestDeathCount` y `testCount()`. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| - | `void` | No retorna valor. |

**Manejo de Errores:** Bucle `while (fActiveTestDeathCount < testCount())` con `wait()`. Captura `InterruptedException` y hace `return` inmediato, ignorando la interrupción y abortando la espera sin re-lanzar la excepción.

---

### `runFinished()`

Método sincronizado invocado por cada hilo worker al finalizar. Incrementa el contador y notifica al hilo en espera.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| - | - | - | No recibe parámetros. |

| Valor de Retorno | Tipo | Descripción |
|---|---|---|
| - | `void` | No retorna valor. |

**Comportamiento:** Incrementa `fActiveTestDeathCount++` y ejecuta `notifyAll()` para despertar a `waitUntilFinished()`.
**Manejo de Errores:** No lanza excepciones. Es `public synchronized` para garantizar visibilidad y atomicidad del contador volátil.

## 3. Ejemplo de Uso

```java
import junit.extensions.ActiveTestSuite;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestResult;

// Clase de prueba de ejemplo
public class MiTestCase extends TestCase {
    public MiTestCase(String name) {
        super(name);
    }
    
    public void testOperacionLarga1() throws InterruptedException {
        Thread.sleep(500);
        assertTrue(true);
    }

    public void testOperacionLarga2() throws InterruptedException {
        Thread.sleep(500);
        assertEquals(2, 1 + 1);
    }
}

// Ejecución concurrente con ActiveTestSuite
public class EjemploActiveSuite {
    public static void main(String[] args) {
        // Crea una suite activa a partir de una clase TestCase
        // Todos los métodos test* se ejecutarán en hilos paralelos
        Test suite = new ActiveTestSuite(MiTestCase.class);
        
        TestResult result = new TestResult();
        
        // run() bloqueará hasta que todos los hilos terminen
        suite.run(result);
        
        System.out.println("Tests ejecutados: " + result.runCount());
        System.out.println("Fallos: " + result.failureCount());
        System.out.println("Errores: " + result.errorCount());
        System.out.println("¿Fue exitoso?: " + result.wasSuccessful());
    }
}
```