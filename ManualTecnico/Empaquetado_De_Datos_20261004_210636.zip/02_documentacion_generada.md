# Documentación Técnica - Generador de Documentación con LLMs

## 1. Resumen Ejecutivo

La aplicación `AplicacionDocumentador` es una interfaz gráfica de escritorio desarrollada con `customtkinter` que automatiza la generación de documentación técnica a partir de código fuente Python/Java utilizando LLMs vía OpenRouter. Integra un flujo completo de auditoría de alucinaciones, evaluación de métricas NLP (BLEU, ROUGE, BERTScore) y exportación de artefactos (MD, PDF, ZIP) con sincronización automática a GitHub.

El sistema opera de forma asíncrona mediante hilos y multiprocesamiento para evitar bloqueos de la UI, gestionando estados, temporización y cancelación de procesos de generación y evaluación.

## 2. Especificación de Funciones

### 2.1 Funciones de Nivel Superior

#### ` _trabajador_bertscore_proceso()`
Se ejecuta BERTScore en un proceso aislado en segundo plano para evitar bloqueos de memoria en Windows.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `referencia` | `str` | Sí | Texto de referencia (Ground Truth) humano. |
| `generada` | `str` | Sí | Texto generado por el LLM a evaluar. |
| `queue` | `multiprocessing.Queue` | Sí | Cola para retornar los resultados al proceso padre. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | No retorna valor directo. Inserta en `queue` una tupla `(p_val, r_val, f1_val, error)` con precisión, recall y F1 en escala 0-100. |

**Manejo de Errores:**
- Valida textos vacíos con `strip()` y retorna `(0.0, 0.0, 0.0, "Texto de referencia o generado vacío.")`.
- Bloque `try/except` global que captura cualquier excepción y retorna `(0.0, 0.0, 0.0, str(e))`.
- Configura `TOKENIZERS_PARALLELISM`, `HF_HUB_DISABLE_SYMLINKS_WARNING` y `torch.set_num_threads(1)` para estabilidad.

---

### 2.2 Métodos de la Clase `AplicacionDocumentador`

#### `AplicacionDocumentador.__init__()`
Constructor de la ventana principal. Inicializa la UI, variables de estado y controles.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Inicializa atributos `ground_truth_extraido`, `contenido_codigo`, `hilo_generacion`, `proceso_bertscore_ref`, `cancelar_solicitado`. |

**Manejo de Errores:** No posee manejo explícito; depende de `ctk.CTk` y variables de entorno `OPENROUTER_API_KEY`.

#### `AplicacionDocumentador.cargar_archivo()`
Abre una ventana para elegir un archivo de código y separa el Ground Truth.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Actualiza `self.contenido_codigo`, `self.ground_truth_extraido`, `self.txt_codigo` y `self.lbl_archivo_cargado`. |

**Manejo de Errores:**
- `try/except` alrededor de `procesar_archivo_codigo(ruta_archivo)`. En caso de excepción, hace fallback leyendo el archivo con `open(..., encoding="utf-8")` y vacía `ground_truth_extraido`.

#### `AplicacionDocumentador.generar_documentacion()`
Valida entradas, configura estado de UI y lanza el hilo de generación.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Inicia `threading.Thread` hacia `_solicitar_api_thread`. |

**Manejo de Errores:**
- Valida `API_KEY` -> `messagebox.showerror`.
- Valida `modelo_id` vacío -> `messagebox.showwarning`.
- Valida `tipo_doc` vacío o placeholder -> `messagebox.showwarning`.
- Valida `codigo` vacío -> `messagebox.showwarning`.
- `try/except` global que muestra `messagebox.showerror` y llama a `_restablecer_botones_ui()`.

#### `AplicacionDocumentador._animar_interfaz()`
Mueve la barra de progreso y actualiza el reloj en tiempo real.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Actualiza `self.progress_bar` y `self.lbl_tiempo` cada 80ms vía `self.after`. |

**Manejo de Errores:** Verifica `getattr(self, 'generando', False)` antes de animar; invierte dirección al llegar a 0.0 o 1.0.

#### `AplicacionDocumentador._solicitar_api_thread()`
Ejecuta la petición HTTP a OpenRouter en segundo plano con puntos de cancelación.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `codigo` | `str` | Sí | Código fuente a documentar. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Delega actualización a `_actualizar_exito` o `_actualizar_error` vía `self.after(0, ...)`. |

**Manejo de Errores:**
- Verifica `self.cancelar_solicitado` antes y después de `requests.post`.
- Si `response.status_code != 200`, construye `msg_err` y llama a `_actualizar_error`.
- `try/except` que ignora errores si hubo cancelación, de lo contrario llama a `_actualizar_error(str(e))`.

#### `AplicacionDocumentador._actualizar_exito()`
Detiene la animación y vuelca los datos finales en la UI.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `resultado` | `str` | Sí | Contenido Markdown retornado por el LLM. |
| `tiempo_total` | `float` | Sí | Tiempo transcurrido en segundos. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Escribe en `self.txt_resultado` (deshabilitado tras escritura), actualiza `lbl_estado`, `lbl_tiempo` y `progress_bar`. |

**Manejo de Errores:** Convierte `resultado` a `str` si es `None`; llama a `_restablecer_botones_ui()`.

#### `AplicacionDocumentador._actualizar_error()`
Detiene la animación y muestra el mensaje de falla.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `mensaje_error` | `str` | Sí | Mensaje de error de la API. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Resetea `progress_bar`, actualiza `lbl_estado` y muestra `messagebox.showerror`. |

**Manejo de Errores:** Llama a `_restablecer_botones_ui()` para restaurar controles.

#### `AplicacionDocumentador.exportar_md()`
Guarda la documentación generada en un archivo Markdown (.md).

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Crea archivo `.md` vía `filedialog.asksaveasfilename`. |

**Manejo de Errores:**
- Valida contenido vacío -> `messagebox.showwarning`.
- `try/except` en `open/write` -> `messagebox.showerror`.

#### `AplicacionDocumentador.exportar_pdf()`
Genera un archivo PDF válido con el contenido de la documentación.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Crea PDF con `reportlab.pdfgen.canvas` y `letter`. |

**Manejo de Errores:**
- Valida contenido vacío -> `messagebox.showwarning`.
- Control de paginación (`if y < 50: pdf.showPage()`).
- `try/except` -> `messagebox.showerror`.

#### `AplicacionDocumentador.exportar_zip_analisis()`
Exporta código, documentación y métricas en un ZIP comprimido y sincroniza con GitHub.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Genera ZIP con `zipfile.ZIP_DEFLATED` y llama a `subir_zip_a_github`. |

**Manejo de Errores:**
- Valida `codigo` o `documentacion` vacíos -> `messagebox.showwarning`.
- `try/except` global -> `messagebox.showerror`.
- Maneja `filepath` vacío (cancelación de diálogo) con `return`.
- Gestiona retorno de `subir_zip_a_github` con `messagebox.showinfo` o `showwarning`.

#### `AplicacionDocumentador.salir_del_sistema()`
Muestra un mensaje de confirmación y cierra la aplicación.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Ejecuta `self.destroy()` si `messagebox.askyesno` retorna `True`. |

**Manejo de Errores:** No aplica.

#### `AplicacionDocumentador.centrar_ventana()`
Calcula el centro de la pantalla y ubica la ventana allí.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ventana_target` | `ctk.CTk \| ctk.CTkToplevel \| int \| None` | No | Ventana a centrar. Si es `None` o `int`, centra `self`. Default `None`. |
| `ancho` | `int` | No | Ancho de la ventana. Default `1100`. |
| `alto` | `int` | No | Alto de la ventana. Default `680`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Aplica `win.geometry(f"{ancho}x{alto}+{x}+{y}")`. |

**Manejo de Errores:** Maneja sobrecarga de firma antigua `centrar_ventana(1100, 680)` detectando `isinstance(ventana_target, int)`.

#### `AplicacionDocumentador._extraer_funciones_codigo()`
Combina extensión de archivo + AST Python + Regex Java estricto.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `codigo` | `str` | Sí | Código fuente a analizar. |
| `ruta_archivo` | `str \| None` | No | Ruta opcional para inferir lenguaje por extensión. Default `None`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `funciones` | `set[str]` | Conjunto de nombres de funciones/métodos detectados. |
| `lenguaje_detectado` | `str` | `Python`, `Java` o `Desconocido/General`. |

**Manejo de Errores:**
- Retorna `set(), "Desconocido/General"` si `codigo` vacío.
- `try/except SyntaxError` en `ast.parse`.
- Filtra palabras reservadas Java (`if`, `for`, `while`, etc.).

#### `AplicacionDocumentador.auditar_estructura_codigo()`
Compara las funciones del código fuente con la documentación generada.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Invoca `_mostrar_reporte_auditoria` con métricas de cobertura. |

**Manejo de Errores:**
- Valida `codigo` o `documentacion` vacíos -> `messagebox.showwarning`.
- Si `funciones_reales` vacío -> `messagebox.showinfo`.

#### `AplicacionDocumentador._mostrar_reporte_auditoria()`
Abre una ventana emergente estructurada con los resultados del análisis.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `lenguaje` | `str` | Sí | Lenguaje detectado. |
| `totales` | `set[str]` | Sí | Total de funciones detectadas. |
| `documentadas` | `set[str]` | Sí | Funciones encontradas en la documentación. |
| `olvidadas` | `set[str]` | Sí | Funciones no documentadas. |
| `alucinaciones` | `set[str]` | Sí | Funciones mencionadas como `` `fn()` `` que no existen en el código. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Crea `CTkToplevel` modal con `CTkTextbox` de solo lectura y botón Volver. |

**Manejo de Errores:** No aplica; calcula `cobertura = len(documentadas)/len(totales)*100`.

#### `AplicacionDocumentador.abrir_ventana_evaluacion_nlp()`
Abre una ventana modal para ingresar la documentación esperada y calcular métricas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Crea `CTkToplevel` de 700x680 con cronómetro independiente y delega cálculo a hilos. |

**Manejo de Errores:**
- Valida `doc_generada` vacía -> `messagebox.showwarning`.
- Delega validación de referencia vacía a función anidada `ejecutar_calculo_metricas`.

#### `AplicacionDocumentador._calcular_bleu()`
Calcula el BLEU Score con suavizado de frecuencia.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `referencia` | `str` | Sí | Texto de referencia. |
| `generada` | `str` | Sí | Texto generado. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `bleu` | `float` | Score BLEU en escala 0-100 usando `SmoothingFunction().method1`. |

**Manejo de Errores:** No posee `try/except`; depende de `nltk.translate.bleu_score`.

#### `AplicacionDocumentador._calcular_rouge()`
Calcula ROUGE-1, ROUGE-2 y ROUGE-L.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `referencia` | `str` | Sí | Texto de referencia. |
| `generada` | `str` | Sí | Texto generado. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `rouge_1` | `float` | F1-Score ROUGE-1 * 100. |
| `rouge_2` | `float` | F1-Score ROUGE-2 * 100. |
| `rouge_l` | `float` | F1-Score ROUGE-L * 100. |

**Manejo de Errores:** Usa `rouge_scorer.RougeScorer` con `use_stemmer=True`.

#### `AplicacionDocumentador._calcular_bertscore()`
Ejecuta BERTScore de manera segura evitando bloqueos de memoria en Windows.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `referencia` | `str` | Sí | Texto de referencia. |
| `generada` | `str` | Sí | Texto generado. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `p_val` | `float` | Precisión BERTScore 0-100. |
| `r_val` | `float` | Recall BERTScore 0-100. |
| `f1_val` | `float` | F1 BERTScore 0-100. |

**Manejo de Errores:**
- Usa `multiprocessing.Process` + `Queue` con `join(timeout=300)`. Si sigue vivo, hace `terminate()` y retorna `0.0, 0.0, 0.0`.
- Si `queue.empty()` o `error` no es `None`, retorna ceros y loguea en consola.
- `try/except` global retorna ceros.

#### `AplicacionDocumentador._obtener_ground_truth_actual()`
Extrae el Ground Truth directamente del texto visible en la caja `txt_codigo`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `ground_truth` | `str` | Docstrings Python, Javadoc Java o comentarios `#`/`//` concatenados con `\n\n`. Retorna `""` si no hay código. |

**Manejo de Errores:**
- `try/except` en `ast.parse` y `ast.get_docstring`.
- Fallback a regex `r'/\*\*([\s\S]*?)\*/'` para Javadoc y a filtrado de líneas con `#` o `//`.

#### `AplicacionDocumentador.subir_zip_a_github()`
Sube automáticamente el paquete ZIP a una carpeta dentro de GitHub.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |
| `filepath_local` | `str` | Sí | Ruta local del ZIP a subir. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `exito` | `bool` | `True` si status 200/201, `False` en caso contrario. |
| `mensaje` | `str` | Mensaje de éxito con ruta o detalle de error. |

**Manejo de Errores:**
- `try/except` global retorna `(False, str(e))`.
- Lee `GITHUB_TOKEN` de entorno, codifica en `base64`, usa `requests.put` con `timeout=30` y headers `Authorization: Bearer` y `User-Agent: LLMs-DocApp`.

#### `AplicacionDocumentador.cancelar_proceso()`
Detiene la ejecución activa y restablece los controles de la interfaz.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Setea `self.cancelar_solicitado = True` y llama a `_restablecer_botones_ui()`. |

**Manejo de Errores:** Actualiza `lbl_estado` a "Proceso cancelado por el usuario." color naranja.

#### `AplicacionDocumentador._restablecer_botones_ui()`
Garantiza la restauración segura de la UI en el hilo principal de Tkinter.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `AplicacionDocumentador` | Sí | Instancia de la clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Ejecuta función anidada `_aplicar()` vía `self.after(0, ...)`. |

**Manejo de Errores:** Verifica `hasattr(self, 'progress_bar')` antes de `set(1.0)`.

---

### 2.3 Funciones Anidadas / Locales

#### `abrir_ventana_evaluacion_nlp._actualizar_cronometro_modal()`
Actualiza el tiempo transcurrido en el label local de la ventana modal. Definida dentro de `abrir_ventana_evaluacion_nlp()`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | Usa closure: `calculando_metricas`, `tiempo_inicio_metricas`, `win_eval`, `lbl_tiempo_metricas`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Actualiza `lbl_tiempo_metricas` cada 100ms vía `win_eval.after`. |

**Manejo de Errores:** Verifica `win_eval.winfo_exists()` y `calculando_metricas`.

#### `abrir_ventana_evaluacion_nlp.ejecutar_calculo_metricas()`
Realiza los cálculos pesados BLEU, ROUGE y BERTScore en segundo plano. Definida dentro de `abrir_ventana_evaluacion_nlp()`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | Usa closure: `txt_referencia`, `doc_generada`, `txt_reporte_nlp`, `lbl_estado_metricas`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Guarda `self.ultimas_metricas_nlp` y actualiza `txt_reporte_nlp` vía `win_eval.after(0, ...)`. |

**Manejo de Errores:**
- Valida `doc_ref` vacío -> `messagebox.showwarning` y `_finalizar_ui_metricas`.
- `try/except` global que muestra error en `txt_reporte_nlp` y `messagebox.showerror`.

#### `ejecutar_calculo_metricas.mostrar_warn()` 
Función local dentro de `ejecutar_calculo_metricas()` para advertir referencia vacía.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | - |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Muestra `messagebox.showwarning` y llama a `_finalizar_ui_metricas`. |

#### `ejecutar_calculo_metricas.iniciar_texto_ui()`
Función local dentro de `ejecutar_calculo_metricas()` que inicializa UI de cálculo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | - |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Limpia `txt_reporte_nlp` y setea `lbl_estado_metricas` a "⏳ Calculando...". |

#### `ejecutar_calculo_metricas.finalizar_exito()`
Función local dentro de `ejecutar_calculo_metricas()` que vuelca el reporte exitoso.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | Usa closure `reporte`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Inserta reporte formateado en `txt_reporte_nlp` y actualiza estado a "✅ Completado". |

#### `ejecutar_calculo_metricas.finalizar_error()`
Función local dentro de `ejecutar_calculo_metricas()` que muestra error de métricas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `err_msg` | `str` | Sí | Mensaje de excepción capturado. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Escribe error en `txt_reporte_nlp` y muestra `messagebox.showerror`. |

#### `abrir_ventana_evaluacion_nlp._finalizar_ui_metricas()`
Restaura los botones y fija el tiempo final de la ventana modal.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | Usa `nonlocal calculando_metricas` y `tiempo_inicio_metricas`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Habilita `btn_procesar`, deshabilita `btn_cancelar_metricas`, actualiza `lbl_tiempo_metricas`. |

**Manejo de Errores:** Verifica `win_eval.winfo_exists()` y distingue cancelación vs. completado vía `self.cancelar_solicitado`.

#### `abrir_ventana_evaluacion_nlp._worker_calcular_metricas()`
Worker invocado por el hilo secundario de métricas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | - |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Llama a `ejecutar_calculo_metricas()` y garantiza `win_eval.after(0, _finalizar_ui_metricas)` en `finally`. |

**Manejo de Errores:** `try/except` que loguea `print(f"⚠️ Error durante el cálculo: {e}")`.

#### `abrir_ventana_evaluacion_nlp.iniciar_evaluacion_hilo()`
Inicia la tarea asíncrona y la animación del tiempo de métricas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | Usa `nonlocal calculando_metricas`, `tiempo_inicio_metricas`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Lanza `threading.Thread(target=_worker_calcular_metricas, daemon=True)` y llama a `_actualizar_cronometro_modal()`. |

**Manejo de Errores:** Resetea `self.cancelar_solicitado = False` y deshabilita botones.

#### `abrir_ventana_evaluacion_nlp.cancelar_evaluacion_metricas()`
Cancela el proceso activo de métricas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | - |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Setea `self.cancelar_solicitado = True` y termina `self.proceso_bertscore_ref` si está vivo. |

**Manejo de Errores:** Verifica `hasattr` y `is_alive()` antes de `terminate()`.

#### `AplicacionDocumentador._restablecer_botones_ui._aplicar()`
Función local dentro de `_restablecer_botones_ui()` que aplica restauración en MainThread.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | Usa closure `self`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Setea `self.generando=False`, `progress_bar.set(1.0)`, habilita `btn_generar`/`btn_salir`, deshabilita `btn_cancelar` y resetea combos a placeholders. |

## 3. Ejemplo de Uso

```python
import os
from dotenv import load_dotenv

# 1. Configurar API Key en .env
# OPENROUTER_API_KEY=sk-or-v1-xxx
# GITHUB_TOKEN=ghp_xxx
# HF_TOKEN=hf_xxx
load_dotenv()

# 2. Ejecutar la aplicación principal
if __name__ == "__main__":
    app = AplicacionDocumentador()
    app.mainloop()

# 3. Flujo de usuario dentro de la UI:
# a) Seleccionar modelo: "Google - Gemini" y tipo: "Docstrings de funciones"
# b) Cargar archivo: btn_cargar -> selecciona ejemplo.py (con docstrings como Ground Truth)
# c) Generar: btn_generar -> espera respuesta OpenRouter (barra animada + cronómetro)
# d) Auditar: btn_auditar -> verifica cobertura estructural y alucinaciones
# e) Evaluar métricas: btn_evaluar_nlp -> ingresa Ground Truth y calcula BLEU/ROUGE/BERTScore
# f) Exportar: btn_export_tesis -> genera Empaquetado_De_Datos_YYYYMMDD_HHMMSS.zip con:
#    - 01_codigo_fuente.py
#    - 02_documentacion_generada.md
#    - 03_metricas_experimento.json
#    - 04_reporte_metricas_nlp.txt
#    y sincroniza automáticamente a GitHub en ManualTecnico/

# 4. Uso programático de métricas (sin UI):
from multiprocessing import Queue

# Calcular BLEU/ROUGE/BERTScore directamente
# app = AplicacionDocumentador()
# bleu = app._calcular_bleu("referencia humana", "texto generado por LLM")
# rouge1, rouge2, rougel = app._calcular_rouge("referencia humana", "texto generado")
# bert_p, bert_r, bert_f1 = app._calcular_bertscore("referencia humana", "texto generado")
```