# Documentación Técnica - Módulo `config`

## 1. Resumen Ejecutivo

Este código implementa el sistema de configuración de Flask, basado en las clases `Config` y `ConfigAttribute`. `Config` extiende `dict` para almacenar la configuración de la aplicación y proporciona múltiples métodos para cargarla desde archivos Python, objetos, mapeos, ficheros genéricos y variables de entorno. `ConfigAttribute` es un descriptor que delega el acceso a atributos de la instancia `App` hacia su diccionario de configuración `app.config`.

## 2. Especificación de Funciones

### 2.1 Clase `ConfigAttribute`

Descriptor genérico `t.Generic[T]` que redirige el acceso a un atributo hacia `App.config`.

#### `ConfigAttribute.__init__()`

Inicializa el descriptor con el nombre de la clave de configuración y un convertidor opcional.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `name` | `str` | Sí | Nombre de la clave en `app.config` a la que se delega el atributo. Se asigna a `self.__name__`. |
| `get_converter` | `t.Callable[[t.Any], T] \| None` | No | Función opcional para convertir el valor obtenido de la configuración antes de retornarlo. Por defecto `None`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `None` | Constructor, no retorna valor. |

**Manejo de Errores:** No lanza errores propios. Propaga excepciones si los tipos son inválidos.

---

#### `ConfigAttribute.__get__()`

Implementa el protocolo descriptor para la lectura del atributo. Posee dos sobrecargas tipadas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `App \| None` | Sí | Instancia de la aplicación. Si es `None`, se accede desde la clase. |
| `owner` | `type[App] \| None` | No | Clase propietaria del descriptor. Por defecto `None`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `te.Self` | Si `obj is None`, retorna la propia instancia del descriptor `self`. |
| `T` | Si `obj` es una instancia de `App`, retorna `obj.config[self.__name__]` opcionalmente convertido por `get_converter`. |

**Manejo de Errores:**
* Lanza `KeyError` si `self.__name__` no existe en `obj.config`.
* Propaga cualquier excepción lanzada por `get_converter` al convertir el valor.

---

#### `ConfigAttribute.__set__()`

Implementa el protocolo descriptor para la escritura del atributo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `App` | Sí | Instancia de la aplicación donde se establecerá el valor. |
| `value` | `t.Any` | Sí | Valor a asignar en `obj.config[self.__name__]`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `None` | No retorna valor. Realiza asignación directa en el diccionario de configuración. |

**Manejo de Errores:** No lanza errores propios. Propaga excepciones si `obj.config` no es asignable.

### 2.2 Clase `Config`

Clase que hereda de `dict` y gestiona la carga y acceso a la configuración de la aplicación.

#### `Config.__init__()`

Inicializa el diccionario de configuración.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `root_path` | `str \| os.PathLike[str]` | Sí | Ruta base respecto a la cual se resuelven los archivos de configuración relativos. Normalmente `Flask.root_path`. |
| `defaults` | `dict[str, t.Any] \| None` | No | Diccionario opcional de valores por defecto para poblar la configuración inicial. Por defecto `None`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `None` | Constructor. |

**Manejo de Errores:** No lanza errores propios.

---

#### `Config.from_envvar()`

Carga configuración desde un archivo cuya ruta está definida en una variable de entorno.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `variable_name` | `str` | Sí | Nombre de la variable de entorno que contiene la ruta al archivo de configuración. |
| `silent` | `bool` | No | Si es `True`, no lanza error si la variable no existe o el archivo no se encuentra. Por defecto `False`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `bool` | `True` si el archivo fue cargado exitosamente. `False` si `silent=True` y la variable no está definida o el archivo no existe. |

**Manejo de Errores:**
* Lanza `RuntimeError` si la variable de entorno no está definida y `silent` es `False`.
* Propaga `OSError` con mensaje modificado `Unable to load configuration file (...)` si `from_pyfile` falla por errores distintos a archivo no encontrado.

---

#### `Config.from_prefixed_env()`

Carga variables de entorno que comienzan con un prefijo determinado y las inserta en la configuración, soportando conversión de tipos y diccionarios anidados.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `prefix` | `str` | No | Prefijo a filtrar. Solo se cargan variables que empiezan por `{prefix}_`. Por defecto `"FLASK"`. |
| `loads` | `t.Callable[[str], t.Any]` | No | Función para deserializar el valor string. Por defecto `json.loads`. Si falla, el valor se mantiene como `str`. Es argumento solo por keyword (`*`). |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `bool` | Siempre retorna `True`. |

**Manejo de Errores:** No lanza errores. Captura silenciosamente cualquier `Exception` lanzada por `loads` y conserva el valor original como cadena. Soporta claves anidadas separadas por `__` creando diccionarios intermedios si no existen.

---

#### `Config.from_pyfile()`

Actualiza la configuración desde un archivo Python ejecutando su contenido.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| os.PathLike[str]` | Sí | Ruta del archivo. Puede ser absoluta o relativa a `self.root_path`. |
| `silent` | `bool` | No | Si es `True`, ignora silenciosamente si el archivo no existe o es un directorio. Por defecto `False`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `bool` | `True` si el archivo fue cargado y procesado correctamente. `False` si `silent=True` y ocurre `OSError` con `errno` en `(ENOENT, EISDIR, ENOTDIR)`. |

**Manejo de Errores:**
* Lanza `OSError` con `strerror` modificado a `Unable to load configuration file (...)` si el archivo no puede abrirse y `silent` es `False` o el `errno` no es uno de los silenciables.
* Propaga errores de sintaxis o ejecución del `exec(compile(...))`.

---

#### `Config.from_object()`

Carga en la configuración solo los atributos en mayúsculas de un objeto o módulo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `object \| str` | Sí | Objeto de configuración o string con la ruta de importación (ej. `'myapp.config'`). Si es `str`, se resuelve con `werkzeug.utils.import_string`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `None` | No retorna valor. Actualiza `self` in-place. |

**Manejo de Errores:**
* Lanza `ImportError` / `ImportStringError` si `obj` es un string y la importación falla.
* No filtra errores de `getattr`; ignora claves que no son `isupper()`.

---

#### `Config.from_file()`

Carga configuración desde un archivo arbitrario usando una función `load` personalizable.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| os.PathLike[str]` | Sí | Ruta al archivo de datos, absoluta o relativa a `root_path`. |
| `load` | `t.Callable[[t.IO[t.Any]], t.Mapping[str, t.Any]]` | Sí | Callable que recibe un handle de archivo y retorna un `Mapping` con los datos. Ej: `json.load`, `tomllib.load`. |
| `silent` | `bool` | No | Si es `True`, ignora si el archivo no existe. Por defecto `False`. |
| `text` | `bool` | No | Si es `True` abre el archivo en modo texto `"r"`, si es `False` en binario `"rb"`. Por defecto `True`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `bool` | `True` si el archivo fue cargado y aplicado vía `from_mapping`. `False` si `silent=True` y ocurre `OSError` con `errno` en `(ENOENT, EISDIR)`. |

**Manejo de Errores:**
* Lanza `OSError` con `strerror` modificado si el archivo no puede abrirse y no aplica la condición de `silent`.
* Propaga cualquier excepción lanzada por la función `load`.

---

#### `Config.from_mapping()`

Actualiza la configuración desde un mapeo o kwargs, ignorando claves que no están en mayúsculas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `mapping` | `t.Mapping[str, t.Any] \| None` | No | Mapeo con valores de configuración. Por defecto `None`. |
| `**kwargs` | `t.Any` | No | Pares clave-valor adicionales. Tienen precedencia sobre `mapping`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `bool` | Siempre retorna `True`. |

**Manejo de Errores:** No lanza errores. Filtra silenciosamente cualquier clave donde `key.isupper()` sea `False`.

---

#### `Config.get_namespace()`

Retorna un sub-diccionario con las opciones que coinciden con un prefijo/namespace.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `namespace` | `str` | Sí | Prefijo a filtrar (ej. `'IMAGE_STORE_'`). |
| `lowercase` | `bool` | No | Si es `True`, convierte las claves resultantes a minúsculas. Por defecto `True`. |
| `trim_namespace` | `bool` | No | Si es `True`, elimina el prefijo de las claves resultantes. Por defecto `True`. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `dict[str, t.Any]` | Diccionario filtrado y transformado según `lowercase` y `trim_namespace`. |

**Manejo de Errores:** No lanza errores. Retorna diccionario vacío `{}` si ninguna clave coincide.

---

#### `Config.__repr__()`

Representación oficial del objeto para depuración.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Config` | Sí | Instancia actual. |

| Valor de Retorno | Descripción |
| :--- | :--- |
| `str` | Cadena con formato `<Config {dict}>`, donde `{dict}` es la representación del diccionario subyacente. |

**Manejo de Errores:** No lanza errores.

## 3. Ejemplo de Uso

```python
import json
import os
from flask import Flask

# 1. Inicialización y carga desde objeto
app = Flask(__name__)

class DefaultConfig:
    DEBUG = False
    SECRET_KEY = 'dev-key'
    IMAGE_STORE_TYPE = 'fs'
    IMAGE_STORE_PATH = '/var/app/images'
    lowercase_key = 'este valor será ignorado'

app.config.from_object(DefaultConfig)
app.config.from_mapping(API_TIMEOUT=30, DEBUG=True) # Solo claves en mayúsculas

# 2. Carga desde archivo Python
# app.config.from_pyfile('config.cfg', silent=False)

# 3. Carga desde variable de entorno
# os.environ['MYAPP_SETTINGS'] = '/path/to/prod.cfg'
# app.config.from_envvar('MYAPP_SETTINGS')

# 4. Carga desde variables de entorno con prefijo y JSON
os.environ['FLASK_CACHE__REDIS__HOST'] = '"localhost"'
os.environ['FLASK_CACHE__REDIS__PORT'] = '6379'
app.config.from_prefixed_env(prefix="FLASK", loads=json.loads)
# Resultado: app.config['CACHE'] == {'REDIS': {'HOST': 'localhost', 'PORT': 6379}}

# 5. Carga desde archivo JSON genérico
# app.config.from_file("config.json", load=json.load, text=True)

# 6. Uso de get_namespace para extraer configuración por prefijo
image_store_config = app.config.get_namespace('IMAGE_STORE_')
print(image_store_config)
# {'type': 'fs', 'path': '/var/app/images'}

# 7. Uso de ConfigAttribute como descriptor en la App
# class MyApp(Flask):
#     debug = ConfigAttribute('DEBUG', get_converter=bool)
# app.debug # -> delega a app.config['DEBUG']
```
