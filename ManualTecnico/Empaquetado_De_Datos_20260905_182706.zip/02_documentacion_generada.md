# Documentación Técnica - `Flask` (flask/app.py)

## 1. Resumen Ejecutivo

El código define la clase central `Flask`, que extiende `sansio.app.App` e implementa la aplicación WSGI principal del framework. Actúa como registro central para rutas, vistas, configuración, sesiones, plantillas Jinja y manejo del ciclo de vida de la petición (contextos, dispatch, manejo de errores y teardown). Incluye además dos decoradores de compatibilidad `remove_ctx`/`add_ctx` y la utilidad `_make_timedelta` para normalizar la configuración de tiempos.

## 2. Especificación de Funciones

### 2.1 Funciones de Módulo

#### `_make_timedelta()`
Convierte un valor entero (segundos) a `timedelta` o lo retorna sin cambios si ya es `timedelta`/`None`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `value` | `timedelta \| int \| None` | Sí | Valor a normalizar. `int` se interpreta como segundos. |

**Retorno:** `timedelta | None` - El `timedelta` original, uno nuevo creado desde segundos, o `None`.

**Manejo de Errores:** No lanza excepciones propias. Retorna directamente si `value` es `None` o `timedelta`.

---

#### `remove_ctx()`
Decorador de compatibilidad para subclases que aún usan la firma antigua sin `ctx`. Elimina el primer argumento `AppContext` si está presente antes de delegar al método original.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Función/método a envolver. |

**Retorno:** `F` - Función envuelta con `functools.update_wrapper`.

**Manejo de Errores:** No lanza errores propios; propaga los de `f`.

##### `remove_ctx.wrapper()`
Función anidada/local dentro de `remove_ctx`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `Any` | No | Argumentos posicionales; si `args[0]` es `AppContext` se descarta. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

**Retorno:** `Any` - Retorno de `f(self, *args, **kwargs)`.

---

#### `add_ctx()`
Decorador inverso a `remove_ctx`. Inyecta el `AppContext` actual (`app_ctx._get_current_object()`) como primer argumento si el método base es invocado sin él vía `super()`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método base de `Flask` a envolver. |

**Retorno:** `F` - Función envuelta.

##### `add_ctx.wrapper()`
Función anidada/local dentro de `add_ctx`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `Any` | No | Si está vacío o `args[0]` no es `AppContext`, se antepone el contexto actual. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

**Retorno:** `Any` - Retorno de `f(self, *args, **kwargs)`.

---

### 2.2 Clase `Flask`

#### `Flask.__init_subclass__()`
Hook de metaclase que detecta métodos sobreescritos en subclases con firma antigua (sin `ctx: AppContext`) y emite `DeprecationWarning` envolviéndolos con `remove_ctx`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `cls` | `type` | Sí | Subclase de `Flask` que se está definiendo. |
| `**kwargs` | `Any` | No | Argumentos adicionales de definición de clase. |

**Retorno:** `None`

**Manejo de Errores:**
- Emite `DeprecationWarning` si alguno de los 12 métodos (`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`) no declara `ctx` como segundo parámetro o anotación `AppContext`.
- No interrumpe la ejecución; reasigna el método envuelto con `setattr`.

#### `Flask.__init__()`
Inicializa la aplicación, configura `self.cli` (`click.AppGroup`) y registra la ruta estática si `has_static_folder` es verdadero.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `import_name` | `str` | Sí | Nombre del paquete/módulo de importación. |
| `static_url_path` | `str \| None` | No | Ruta URL para archivos estáticos. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta de archivos estáticos. Por defecto `"static"`. |
| `static_host` | `str \| None` | No | Host para la ruta estática. Requerido si `host_matching=True`. |
| `host_matching` | `bool` | No | Activa `url_map.host_matching`. Por defecto `False`. |
| `subdomain_matching` | `bool` | No | Activa matching por subdominio. Por defecto `False`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta de plantillas. Por defecto `"templates"`. |
| `instance_path` | `str \| None` | No | Ruta alternativa de instancia. |
| `instance_relative_config` | `bool` | No | Si `True`, config relativa a `instance_path`. |
| `root_path` | `str \| None` | No | Raíz de archivos de la app. |

**Retorno:** `None`

**Manejo de Errores:**
- `AssertionError` si `bool(static_host) != host_matching`.

##### `Flask.__init__.<lambda>()`
Callback anónimo registrado como `view_func` para la ruta `static`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kw` | `Any` | No | Debe contener `filename: str`. |

**Retorno:** `Response` - Resultado de `self.send_static_file(**kw)` vía `weakref`.

#### `Flask.get_send_file_max_age()`
Determina el valor `max_age` para caché usado por `send_file`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str \| None` | No | Nombre del archivo (no usado en la implementación base, pero permite override). |

**Retorno:** `int \| None` - Segundos de caché o `None` para usar peticiones condicionales.

**Manejo de Errores:** No lanza; convierte `timedelta` a `int` vía `total_seconds()`.

#### `Flask.send_static_file()`
View function que sirve archivos desde `static_folder`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str` | Sí | Ruta relativa dentro de `static_folder`. |

**Retorno:** `Response` - Respuesta generada por `send_from_directory`.

**Manejo de Errores:**
- `RuntimeError` si `has_static_folder` es `False`.

#### `Flask.open_resource()`
Abre un archivo relativo a `root_path` solo en modo lectura.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta relativa a `root_path`. |
| `mode` | `str` | No | Modo de apertura. Solo `"r"`, `"rt"`, `"rb"`. Por defecto `"rb"`. |
| `encoding` | `str \| None` | No | Codificación para modo texto. |

**Retorno:** `IO[AnyStr]` - Handle de archivo abierto.

**Manejo de Errores:**
- `ValueError` si `mode` no es uno de los permitidos.
- `FileNotFoundError` / `OSError` si el recurso no existe.

#### `Flask.open_instance_resource()`
Abre un archivo relativo a `instance_path`, permitiendo lectura y escritura.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta relativa a `instance_path`. |
| `mode` | `str` | No | Cualquier modo válido de `open()`. Por defecto `"rb"`. |
| `encoding` | `str \| None` | No | Codificación para modo texto. Por defecto `"utf-8"`. |

**Retorno:** `IO[AnyStr]`

**Manejo de Errores:** Propaga `OSError`/`FileNotFoundError` de `open()`.

#### `Flask.create_jinja_environment()`
Crea y configura el `Environment` de Jinja2.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| (ninguno) | - | - | Usa `self.jinja_options`, `self.config["TEMPLATES_AUTO_RELOAD"]` y `self.debug`. |

**Retorno:** `Environment` - Entorno con globales `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g` y política `json.dumps_function`.

**Manejo de Errores:** No lanza errores propios.

#### `Flask.create_url_adapter()`
Crea un `MapAdapter` para construir/resolver URLs.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request \| None` | No | Si se provee, hace `bind_to_environ`; si es `None`, hace `bind` con `SERVER_NAME`. |

**Retorno:** `MapAdapter \| None` - `None` si no hay `request` ni `SERVER_NAME` configurado.

**Manejo de Errores:** No lanza; ajusta `trusted_hosts` y `host` desde `request.environ`.

#### `Flask.raise_routing_exception()`
Intercepta excepciones de enrutamiento en modo debug para evitar pérdida de datos de formulario en redirects.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request` | Sí | Request que contiene `routing_exception`. |

**Retorno:** `NoReturn` - Siempre lanza.

**Manejo de Errores:**
- Lanza `request.routing_exception` original si no es `RequestRedirect`, si `debug=False`, si el código es `307`/`308` o si `method` es `GET`/`HEAD`/`OPTIONS`.
- Lanza `FormDataRoutingRedirect` en caso contrario.

#### `Flask.update_template_context()`
Inyecta variables de contexto (processors) al diccionario de plantillas.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto de aplicación (determina blueprints activos). |
| `context` | `dict[str, Any]` | Sí | Diccionario que se actualiza in-place. |

**Retorno:** `None`

**Manejo de Errores:** No lanza; respeta valores originales de `context` re-aplicándolos al final.

#### `Flask.make_shell_context()`
Ejecuta todos los `shell_context_processors` registrados.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| (ninguno) | - | - | - |

**Retorno:** `dict[str, Any]` - Diccionario con `{"app": self, "g": g}` más lo aportado por procesadores.

#### `Flask.run()`
Ejecuta el servidor de desarrollo Werkzeug.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `host` | `str \| None` | No | Hostname. Por defecto `127.0.0.1` o `SERVER_NAME`. |
| `port` | `int \| None` | No | Puerto. Por defecto `5000` o puerto de `SERVER_NAME`. |
| `debug` | `bool \| None` | No | Sobrescribe `self.debug`. |
| `load_dotenv` | `bool` | No | Carga `.env`/`.flaskenv`. Por defecto `True`. |
| `**options` | `Any` | No | Opciones para `werkzeug.serving.run_simple` (`use_reloader`, `use_debugger`, `threaded`, etc.). |

**Retorno:** `None`

**Manejo de Errores:**
- Si `FLASK_RUN_FROM_CLI=="true"` ignora la llamada y muestra advertencia con `click.secho`.
- Resetea `self._got_first_request = False` en bloque `finally`.

#### `Flask.test_client()`
Crea un cliente de pruebas WSGI.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `use_cookies` | `bool` | No | Si mantiene cookies. Por defecto `True`. |
| `**kwargs` | `Any` | No | Argumentos para `test_client_class`. |

**Retorno:** `FlaskClient`

#### `Flask.test_cli_runner()`
Crea un runner para probar comandos CLI.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kwargs` | `Any` | No | Argumentos para `test_cli_runner_class`. |

**Retorno:** `FlaskCliRunner`

#### `Flask.handle_http_exception()`
Gestiona `HTTPException` invocando handlers registrados.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `e` | `HTTPException` | Sí | Excepción HTTP. |

**Retorno:** `HTTPException \| ResponseReturnValue`

**Manejo de Errores:** Retorna `e` sin cambios si `e.code is None` o si es `RoutingException` o si no hay handler.

#### `Flask.handle_user_exception()`
Punto de entrada para cualquier excepción de usuario; delega a `handle_http_exception` si corresponde.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `e` | `Exception` | Sí | Excepción capturada. |

**Retorno:** `HTTPException \| ResponseReturnValue`

**Manejo de Errores:**
- Si `e` es `BadRequestKeyError` y `debug` o `TRAP_BAD_REQUEST_ERRORS` es `True`, activa `e.show_exception = True`.
- Si no hay handler, hace `raise` (re-lanza la excepción original).

#### `Flask.handle_exception()`
Maneja excepciones no capturadas generando un `500 InternalServerError`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `e` | `Exception` | Sí | Excepción no manejada. |

**Retorno:** `Response` - Respuesta finalizada vía `finalize_request`.

**Manejo de Errores:**
- Envía señal `got_request_exception`.
- Si `PROPAGATE_EXCEPTIONS` (o `testing`/`debug` cuando es `None`) es `True`, re-lanza `e`.
- Loguea con `log_exception` y busca handler para `500`.

#### `Flask.log_exception()`
Registra la excepción en `self.logger`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con `request.path` y `request.method`. |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí | Info de `sys.exc_info()`. |

**Retorno:** `None`

#### `Flask.dispatch_request()`
Hace el matching de URL y despacha a la view function.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con `request`. |

**Retorno:** `ResponseReturnValue` - Valor crudo de la vista.

**Manejo de Errores:**
- Llama a `raise_routing_exception` si `req.routing_exception` existe.
- Retorna `make_default_options_response` si `provide_automatic_options` y `method=="OPTIONS"`.

#### `Flask.full_dispatch_request()`
Orquesta `preprocess_request` → `dispatch_request` → `finalize_request` con manejo de excepciones y señales.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |

**Retorno:** `Response`

**Manejo de Errores:**
- Emite `DeprecationWarning` si `should_ignore_error` está definido y es la primera petición.
- Captura `Exception` y delega a `handle_user_exception`.
- Envía señal `request_started`.

#### `Flask.finalize_request()`
Convierte el valor de retorno en `Response` y ejecuta post-procesamiento.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `rv` | `ResponseReturnValue \| HTTPException` | Sí | Valor de la vista o excepción. |
| `from_error_handler` | `bool` | No | Si `True`, loguea errores de finalización en lugar de propagarlos. Por defecto `False`. |

**Retorno:** `Response`

**Manejo de Errores:**
- Si `process_response` o `request_finished` fallan y `from_error_handler=False`, propaga la excepción.
- Si `from_error_handler=True`, loguea con `logger.exception` y retorna la respuesta parcial.

#### `Flask.make_default_options_response()`
Genera respuesta automática para `OPTIONS`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con `url_adapter`. |

**Retorno:** `Response` - Con header `Allow` poblado desde `url_adapter.allowed_methods()`.

#### `Flask.ensure_sync()`
Garantiza que una función sea síncrona para workers WSGI.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `Callable[..., Any]` | Sí | Función a verificar. |

**Retorno:** `Callable[..., Any]` - La misma función si es síncrona, o envuelta vía `async_to_sync` si es corrutina.

#### `Flask.async_to_sync()`
Convierte una corrutina en función síncrona usando `asgiref`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `Callable[..., Coroutine[Any, Any, Any]]` | Sí | Función `async def`. |

**Retorno:** `Callable[..., Any]`

**Manejo de Errores:**
- `RuntimeError` si `asgiref` no está instalado (`pip install Flask[async]`).

#### `Flask.url_for()`
Construye una URL para un endpoint.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `endpoint` | `str` | Sí | Nombre del endpoint (prefijo `"."` indica blueprint actual). |
| `_anchor` | `str \| None` | No | Fragmento `#anchor`. |
| `_method` | `str \| None` | No | Método HTTP para el build. |
| `_scheme` | `str \| None` | No | Esquema (`http`/`https`). |
| `_external` | `bool \| None` | No | Fuerza URL externa/interna. |
| `**values` | `Any` | No | Variables de la regla URL y query string. |

**Retorno:** `str` - URL construida.

**Manejo de Errores:**
- `RuntimeError` si no hay request/app context y `SERVER_NAME` no está configurado.
- `ValueError` si `_scheme` se especifica con `_external=False`.
- `BuildError` (manejado vía `handle_url_build_error`) si el endpoint no existe o faltan valores.

#### `Flask.make_response()`
Normaliza el retorno de una vista a instancia de `response_class`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `rv` | `ResponseReturnValue` | Sí | Puede ser `str`, `bytes`, `dict`, `list`, `tuple`, `Response`, `Iterator`, `WSGI callable`. |

**Retorno:** `Response`

**Manejo de Errores:**
- `TypeError` si `rv is None`, si la tupla no tiene 2 o 3 elementos, o si el tipo no es convertible.
- Propaga `TypeError` con contexto si `force_type` falla.

#### `Flask.preprocess_request()`
Ejecuta `url_value_preprocessors` y `before_request_funcs`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |

**Retorno:** `ResponseReturnValue \| None` - Valor no-`None` corta el dispatch y se usa como respuesta.

#### `Flask.process_response()`
Aplica `after_request` y guarda la sesión.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `response` | `Response` | Sí | Respuesta a procesar. |

**Retorno:** `Response` - Respuesta modificada.

#### `Flask.do_teardown_request()`
Ejecuta teardown de request y envía señal `request_tearing_down`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `exc` | `BaseException \| None` | No | Excepción no manejada del dispatch. |

**Retorno:** `None`

**Manejo de Errores:** Colecta errores de todos los callbacks con `_CollectErrors` y los lanza agregados al final (`raise_any`).

#### `Flask.do_teardown_appcontext()`
Ejecuta teardown de appcontext y envía señal `appcontext_tearing_down`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `exc` | `BaseException \| None` | No | Excepción activa del contexto. |

**Retorno:** `None`

**Manejo de Errores:** Igual que `do_teardown_request`, usa `_CollectErrors`.

#### `Flask.app_context()`
Crea un `AppContext` sin request.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| (ninguno) | - | - | - |

**Retorno:** `AppContext`

#### `Flask.request_context()`
Crea un `AppContext` desde un `environ` WSGI.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Diccionario WSGI. |

**Retorno:** `AppContext` - Vía `AppContext.from_environ`.

#### `Flask.test_request_context()`
Crea un `AppContext` de prueba usando `EnvironBuilder`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `*args` | `Any` | No | Argumentos posicionales para `EnvironBuilder`. |
| `**kwargs` | `Any` | No | `path`, `base_url`, `subdomain`, `url_scheme`, `data`, `json`, `content_type`, etc. |

**Retorno:** `AppContext`

#### `Flask.wsgi_app()`
Aplicación WSGI real; gestiona push/pop de contexto y dispatch.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callable WSGI. |

**Retorno:** `Iterable[bytes]` - Iterable de la respuesta.

**Manejo de Errores:**
- Captura `Exception` y delega a `handle_exception`.
- Re-lanza `BaseException` no-`Exception` tras guardar `error`.
- Respeta `werkzeug.debug.preserve_context` y `should_ignore_error` (deprecated) antes de `ctx.pop(error)`.

#### `Flask.__call__()`
Entry-point WSGI que delega a `wsgi_app` (permite envolver middleware).

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callable WSGI. |

**Retorno:** `Iterable[bytes]`

## 3. Ejemplo de Uso

```python
from flask import Flask, request, jsonify, url_for

app = Flask(__name__)
app.config["SERVER_NAME"] = "example.com"

@app.route("/hello/<name>", methods=["GET"])
def hello(name):
    return jsonify(message=f"Hola, {name}!")

@app.before_request
def log_request():
    print(f"{request.method} {request.path}")

# Generación de URL fuera de request (requiere SERVER_NAME)
with app.app_context():
    print(app.url_for("hello", name="Mundo", _external=True))
    # https://example.com/hello/Mundo

# Cliente de pruebas sin levantar servidor
app.testing = True
with app.test_client() as client:
    rv = client.get("/hello/Flask")
    assert rv.status_code == 200
    assert rv.get_json() == {"message": "Hola, Flask!"}

# Contexto de request manual para tests unitarios
with app.test_request_context("/hello/Test?lang=es"):
    assert request.args["lang"] == "es"
    assert url_for("hello", name="Test") == "/hello/Test"

# Servir archivo estático y recurso interno
# with app.open_resource("schema.sql") as f:
#     print(f.read())

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
```