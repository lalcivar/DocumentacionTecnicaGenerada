# Documentación de APIs - `flask.globals`

## 1. Resumen Ejecutivo

El módulo `flask.globals` define los proxies globales sensibles al contexto de Flask que permiten acceder al estado de la aplicación y de la petición sin pasar objetos explícitamente. Gestiona dos contextos aislados mediante `ContextVar` (`_cv_app`) y expone a través de `werkzeug.local.LocalProxy` los objetos `app_ctx`, `current_app`, `g`, `request` y `session`. Incluye además compatibilidad tipada para type checkers y un hook de compatibilidad `__getattr__` para la deprecación de `request_ctx`.

## 2. Especificación de Funciones

El análisis estático del código fuente detecta **2 métodos/funciones** definibles en tiempo de ejecución y tipado. No existen funciones anidadas, callbacks ni workers adicionales.

### 2.1 `ProxyMixin._get_current_object()`

Método de protocolo definido exclusivamente para tipado estático dentro del bloque `if t.TYPE_CHECKING:`.

> No tiene impacto en tiempo de ejecución. Informa a los type checkers que los proxies se comportan como el tipo proxificado.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `ProxyMixin[T]` | Sí | Instancia del proxy. Parámetro implícito. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `objeto actual` | `T` (covariant) | Retorna la instancia real subyacente a la que apunta el `LocalProxy` (ej. `Flask`, `Request`, `AppContext`). |

**Manejo de Errores:**
*   En tiempo de ejecución, la implementación real es provista por `werkzeug.local.LocalProxy`. Si se invoca fuera de un contexto válido, lanza `RuntimeError` con el mensaje `unbound_message` correspondiente (`_no_app_msg` o `_no_req_msg`).
*   En tiempo de tipado no lanza errores; es una definición `Protocol` con cuerpo `...`.

**Definiciones relacionadas que heredan este método (sin implementación adicional):**
*   `FlaskProxy(ProxyMixin[Flask], Flask)`
*   `AppContextProxy(ProxyMixin[AppContext], AppContext)`
*   `_AppCtxGlobalsProxy(ProxyMixin[_AppCtxGlobals], _AppCtxGlobals)`
*   `RequestProxy(ProxyMixin[Request], Request)`
*   `SessionMixinProxy(ProxyMixin[SessionMixin], SessionMixin)`

Todas se definen como `...` (pass) y heredan únicamente `_get_current_object()` para fines de tipado.

### 2.2 `__getattr__()`

Hook a nivel de módulo definido según [PEP 562](https://peps.python.org/pep-0562/) para interceptar accesos a atributos no encontrados en el módulo. Implementa la capa de compatibilidad y deprecación para `request_ctx`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `name` | `str` | Sí | Nombre del atributo solicitado al módulo `flask.globals` que no fue encontrado por la búsqueda normal. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `app_ctx` | `t.Any` / `AppContextProxy` | Si `name == "request_ctx"`, retorna el proxy global `app_ctx`. Es el único caso de retorno exitoso. |

**Manejo de Errores y Efectos Secundarios:**

| Condición | Tipo de Error / Advertencia | Mensaje / Comportamiento |
| :--- | :--- | :--- |
| `name == "request_ctx"` | `DeprecationWarning` | Emite `warnings.warn()` con el mensaje: `"'request_ctx' has merged with 'app_ctx', and will be removed in Flask 4.0. Use 'app_ctx' instead."` con `stacklevel=2`. No interrumpe la ejecución; retorna `app_ctx`. |
| `name != "request_ctx"` | `AttributeError` | Lanza `AttributeError(name)` para cualquier otro atributo no existente, cumpliendo el contrato de `__getattr__` a nivel de módulo. |

**Dependencias internas:**
*   Importa `warnings` localmente dentro de la función.
*   Retorna la variable global `app_ctx: AppContextProxy = LocalProxy(_cv_app, unbound_message=_no_app_msg)`.

> **Nota sobre proxies globales (no son funciones pero son parte de la API pública del módulo):**
> *   `_cv_app: ContextVar[AppContext] = ContextVar("flask.app_ctx")` - Almacén aislado por contexto.
> *   `app_ctx`, `current_app`, `g` - Lanzan `RuntimeError(_no_app_msg)` si se acceden fuera de un application context.
> *   `request`, `session` - Lanzan `RuntimeError(_no_req_msg)` si se acceden fuera de un request context.

## 3. Ejemplo de Uso

```python
from flask import Flask, g, current_app, request, session, app_ctx

app = Flask(__name__)
app.secret_key = 'secret-key'

# 1. Uso de proxies de application context
with app.app_context():
    # current_app apunta a 'app'
    print(current_app.name)  # -> "__main__"
    
    # g es un namespace para almacenar datos durante el contexto
    g.usuario_actual = "admin"
    print(g.usuario_actual)

    # app_ctx es el contexto de aplicación actual
    print(app_ctx.g.usuario_actual) # -> "admin"

# 2. Uso de proxies de request context
with app.test_request_context('/?name=Flask', method='GET'):
    # request y session solo son válidos dentro de un request context
    print(request.path)   # -> "/"
    print(request.args.get('name')) # -> "Flask"
    session['user_id'] = 123

# 3. Uso del hook __getattr__ para compatibilidad deprecada
import flask.globals
import warnings

warnings.simplefilter("always", DeprecationWarning)

# Acceso deprecado: emite DeprecationWarning y retorna app_ctx
with app.app_context():
    ctx_deprecado = flask.globals.request_ctx  # DeprecationWarning
    assert ctx_deprecado is flask.globals.app_ctx  # True

# Acceso a atributo inexistente: lanza AttributeError
try:
    flask.globals.atributo_inexistente
except AttributeError as e:
    print(f"Atributo no encontrado: {e}")

# Acceso fuera de contexto: lanza RuntimeError
try:
    print(current_app.name)
except RuntimeError as e:
    print(e) # -> Working outside of application context...
```