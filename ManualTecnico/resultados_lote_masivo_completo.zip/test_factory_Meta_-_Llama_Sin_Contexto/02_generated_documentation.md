### Documentación Técnica - Módulo de Pruebas de Aplicación Flask

**Archivo:** `test_factory.py` / `test_app.py`
**Tipo:** Suite de Pruebas Unitarias
**Framework:** Flask + Pytest
**Lenguaje:** Python 3.x

#### 1. Descripción General

Este archivo contiene la suite de pruebas automatizadas para verificar el correcto funcionamiento del **Application Factory** de Flask `create_app`. Su objetivo es validar dos aspectos críticos de la aplicación:

1.  La correcta creación e inicialización de la instancia de la aplicación.
2.  La correcta configuración del modo `testing` y el funcionamiento de los endpoints básicos.

No contiene lógica de negocio, únicamente aserciones para garantizar la calidad y estabilidad de la aplicación antes de su despliegue. Sigue la convención de `pytest` donde toda función que inicia con `test_` es detectada como un caso de prueba.

#### 2. Dependencias

| Dependencia | Descripción |
| :--- | :--- |
| `flaskr.create_app` | Application Factory. Función encargada de crear y configurar la instancia de la aplicación Flask. Es el Sistema Bajo Prueba (SUT). |
| `pytest` | Framework de testing utilizado para la ejecución y aserción de las pruebas. |
| `client` | Fixture de `pytest` definido en `conftest.py`. Proporciona un cliente de pruebas de Flask `FlaskClient` que permite simular peticiones HTTP sin necesidad de levantar un servidor. |

#### 3. Componentes Principales

El archivo está compuesto por dos casos de prueba independientes:

##### 3.1. `test_config()`

Valida el comportamiento del factory `create_app` respecto a su configuración.

**Lógica:**
```python
assert not create_app().testing
```
Verifica que, por defecto, la aplicación se crea con el modo `testing` desactivado `False`.

```python
assert create_app({"TESTING": True}).testing
```
Verifica que el factory acepta correctamente un diccionario de configuración de prueba y activa el modo `testing` a `True` cuando se le pasa `{"TESTING": True}`. Esto asegura que la inyección de configuraciones para el entorno de pruebas funciona correctamente.

**Tipo de prueba:** Prueba unitaria de configuración.

##### 3.2. `test_hello(client)`

Valida la capa de enrutamiento y respuesta HTTP de la aplicación.

**Firma:** `def test_hello(client):`
Recibe como parámetro el fixture `client`, que representa un cliente HTTP simulado.

**Lógica:**
```python
response = client.get("/hello")
assert response.data == b"Hello, World!"
```
1.  Realiza una petición `GET` simulada al endpoint `/hello`.
2.  Verifica que el cuerpo de la respuesta `response.data` sea exactamente `b"Hello, World!"` en formato bytes.

Esta prueba confirma que la aplicación se inicializa correctamente, registra sus rutas y es capaz de responder a peticiones HTTP.

**Tipo de prueba:** Prueba de integración ligera / funcional.

#### 4. Ejecución

Para ejecutar esta suite de pruebas, se utiliza el siguiente comando en la raíz del proyecto:

```bash
pytest -v
```
o
```bash
python -m pytest
```

**Resultado esperado:** `2 passed` si la configuración del factory y el endpoint `/hello` funcionan según lo especificado.

#### 5. Conclusión

Este archivo es fundamental para el ciclo de Integración Continua (CI). Garantiza que cualquier cambio futuro en el `create_app` o en el sistema de configuración no rompa la inicialización de la aplicación ni sus rutas base, sirviendo como una red de seguridad para el desarrollo.