# Documentación Técnica: `flask/app.py`

---

## 1. Resumen ejecutivo

Este módulo define la clase **`Flask`**, la implementación concreta y síncrona (WSGI) del objeto central de aplicación del framework Flask, que hereda de `App` (capa *sans-io*). Aglutina el ciclo de vida completo de una petición: creación del contexto, enrutamiento, despacho de vistas, manejo de errores HTTP/usuario, post-procesado de respuesta, *teardown* de contextos y exposición del callable WSGI (`wsgi_app()` / `__call__()`).

Adicionalmente, provee utilidades de infraestructura: construcción del entorno Jinja, generación de URLs (`url_for()`), servidor de desarrollo (`run()`), clientes de pruebas (`test_client()`, `test_cli_runner()`) y un mecanismo de **retrocompatibilidad por decoradores** (`remove_ctx()` / `add_ctx()`) que detecta subclases con firmas antiguas (sin el parámetro `ctx: AppContext`) y las adapta emitiendo `DeprecationWarning`.

---

## 2. Elementos de nivel módulo (constantes y TypeVars)

| Nombre | Tipo | Descripción |
|---|---|---|
| `T_shell_context_processor` | `TypeVar` (bound `ft.ShellContextProcessorCallable`) | Tipado genérico para decoradores de procesadores de contexto de shell. |
| `T_teardown` | `TypeVar` (bound `ft.TeardownCallable`) | Tipado genérico para callbacks de *teardown*. |
| `T_template_filter` | `TypeVar` (bound `ft.TemplateFilterCallable`) | Tipado genérico para filtros Jinja. |
| `T_template_global` | `TypeVar` (bound `ft.TemplateGlobalCallable`) | Tipado genérico para globales Jinja. |
| `T_template_test` | `TypeVar` (bound `ft.TemplateTestCallable`) | Tipado genérico para tests Jinja. |
| `F` | `TypeVar` (bound `Callable[..., Any]`) | Tipado genérico usado por los decoradores `remove_ctx()` y `add_ctx()`. |

---

## 3. Especificación de funciones de nivel módulo

### 3.1 `_make_timedelta()`

Normaliza un valor numérico de segundos a un objeto `timedelta`. Función auxiliar privada (idempotente frente a valores ya normalizados o nulos).

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    """Convierte un entero de segundos en un timedelta.

    Args:
        value: Valor a normalizar. Si ya es timedelta o None se devuelve tal cual.

    Returns:
        timedelta | None: El valor normalizado.
    """
```

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `value` | `timedelta \| int \| None` | Sí | Segundos a convertir, o valor ya normalizado. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `timedelta \| None` | `None` si la entrada es `None`; la misma instancia si ya es `timedelta`; en otro caso `timedelta(seconds=value)`. |

**Raises:** No lanza excepciones propias.

---

### 3.2 `remove_ctx()`

Decorador de compatibilidad. Envuelve un método **sobrescrito por el usuario** que mantiene la firma antigua (sin `ctx`) para que, cuando el core de Flask lo invoque con el nuevo argumento `AppContext` en primera posición, dicho argumento sea descartado antes de delegar.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método con firma legada a envolver. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `F` | El wrapper, con metadatos copiados mediante `functools.update_wrapper`. |

**Raises:** No lanza excepciones propias (propaga las de `f`).

#### 3.2.1 `wrapper()` (función anidada en `remove_ctx()`)

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de aplicación. |
| `*args` | `t.Any` | No | Argumentos posicionales; si `args[0]` es instancia de `AppContext`, se elimina. |
| `**kwargs` | `t.Any` | No | Argumentos nominales reenviados sin cambios. |

**Retorno:** `t.Any` — resultado de `f(self, *args, **kwargs)`.

---

### 3.3 `add_ctx()`

Decorador de compatibilidad inverso. Envuelve el **método base de `Flask`** de modo que, si una subclase legada llama a `super().metodo_base(...)` sin el argumento `ctx`, este se inyecte automáticamente obteniéndolo del contexto activo (`app_ctx._get_current_object()`).

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método base de `Flask` a envolver. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `F` | El wrapper, con metadatos copiados mediante `functools.update_wrapper`. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | Indirecta: al resolver `app_ctx._get_current_object()` sin contexto de aplicación activo. |

#### 3.3.1 `wrapper()` (función anidada en `add_ctx()`)

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de aplicación. |
| `*args` | `t.Any` | No | Si está vacío o `args[0]` no es `AppContext`, se prepone el contexto actual. |
| `**kwargs` | `t.Any` | No | Argumentos nominales reenviados sin cambios. |

**Retorno:** `t.Any` — resultado de `f(self, *args, **kwargs)`.

---

## 4. Clase `Flask`

Implementa una aplicación WSGI y actúa como registro central de funciones de vista, reglas de URL, configuración de plantillas, comandos CLI, manejadores de error y señales.

### 4.1 Atributos de clase

| Atributo | Tipo | Valor por defecto | Descripción |
|---|---|---|---|
| `default_config` | `ImmutableDict` | Ver código | Configuración base (`DEBUG`, `SECRET_KEY`, `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, `TRUSTED_HOSTS`, `PROVIDE_AUTOMATIC_OPTIONS`, etc.). |
| `request_class` | `type[Request]` | `Request` | Clase empleada para objetos de petición. |
| `response_class` | `type[Response]` | `Response` | Clase empleada para objetos de respuesta. |
| `session_interface` | `SessionInterface` | `SecureCookieSessionInterface()` | Interfaz de sesión en uso. |

### 4.2 Parámetros del constructor (resumen)

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `import_name` | `str` | Sí | — | Nombre del módulo/paquete de la aplicación. |
| `static_url_path` | `str \| None` | No | `None` | Ruta web para archivos estáticos. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | `"static"` | Carpeta de archivos estáticos. |
| `static_host` | `str \| None` | No | `None` | Host para la ruta estática (obligatorio con `host_matching=True`). |
| `host_matching` | `bool` | No | `False` | Activa `url_map.host_matching`. |
| `subdomain_matching` | `bool` | No | `False` | Considera el subdominio relativo a `SERVER_NAME`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | `"templates"` | Carpeta de plantillas. |
| `instance_path` | `str \| None` | No | `None` | Ruta alternativa de la carpeta *instance*. |
| `instance_relative_config` | `bool` | No | `False` | Resuelve rutas de configuración relativas a `instance_path`. |
| `root_path` | `str \| None` | No | `None` | Raíz de archivos de la aplicación (detección manual). |

---

## 5. Especificación de métodos

### 5.1 `__init_subclass__()`

Hook ejecutado al definir una subclase de `Flask`. Inspecciona un conjunto cerrado de métodos del ciclo de vida (`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`). Si alguno fue sobrescrito **sin** el nuevo segundo parámetro `ctx: AppContext` (validado por nombre, anotación en cadena terminada en `AppContext`, o subclase real de `AppContext`), emite `DeprecationWarning` y re-parchea: el método de la subclase con `remove_ctx()` y el método base de `Flask` con `add_ctx()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `cls` | `type[Flask]` | Sí (implícito) | Subclase recién creada. |
| `**kwargs` | `t.Any` | No | Argumentos de palabra clave de creación de clase. |

**Retorno:** `None`.

**Raises**

| Excepción / Aviso | Condición |
|---|---|
| `DeprecationWarning` (warning, no excepción) | Método sobrescrito con firma legada sin `ctx`. |

> **Efecto colateral documentado:** modifica atributos de `cls` y de `Flask` mediante `setattr`.

---

### 5.2 `__init__()`

Inicializa la aplicación: delega en `App.__init__`, crea el grupo CLI (`cli.AppGroup()`), asigna `self.cli.name = self.name` y, si existe carpeta estática, registra la regla de URL `"{static_url_path}/<path:filename>"` con endpoint `"static"` usando una `weakref.ref` de la app para evitar ciclos de referencia.

**Parámetros:** ver tabla §4.2.

**Retorno:** `None`.

**Raises**

| Excepción | Condición |
|---|---|
| `AssertionError` | `bool(static_host) != host_matching` ("Invalid static_host/host_matching combination"). |

#### 5.2.1 Función de vista anónima `lambda **kw: self_ref().send_static_file(**kw)`

Callback local registrado como `view_func` del endpoint `static`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kw` | `t.Any` | No | Variables de la regla (típicamente `filename`), reenviadas a `send_static_file()`. |

**Retorno:** `Response`.

---

### 5.3 `get_send_file_max_age()`

Determina el valor `max_age` de caché para un archivo, leyendo `SEND_FILE_MAX_AGE_DEFAULT` de la configuración.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str \| None` | Sí | Nombre del archivo servido (no se usa en la implementación por defecto). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `int \| None` | `None` (peticiones condicionales), o segundos; si la config es `timedelta`, devuelve `int(value.total_seconds())`. |

**Raises:** No lanza excepciones propias.

---

### 5.4 `send_static_file()`

Función de vista que sirve archivos desde `static_folder` a través de `send_from_directory()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str` | Sí | Ruta del archivo relativa a `static_folder`. |

**Retorno:** `Response` — respuesta de archivo con `max_age` calculado por `get_send_file_max_age()`.

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | `static_folder` no está configurado. |
| `NotFound` (indirecta, vía `send_from_directory`) | El archivo no existe. |

---

### 5.5 `open_resource()`

Abre, **solo en modo lectura**, un recurso relativo a `root_path`.

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `resource` | `str` | Sí | — | Ruta relativa a `root_path`. |
| `mode` | `str` | No | `"rb"` | Modo de apertura; válidos: `"r"`, `"rt"`, `"rb"`. |
| `encoding` | `str \| None` | No | `None` | Codificación en modo texto (ignorada en binario). |

**Retorno:** `t.IO[t.AnyStr]` — manejador de archivo abierto.

**Raises**

| Excepción | Condición |
|---|---|
| `ValueError` | `mode` no pertenece a `{"r", "rt", "rb"}`. |
| `OSError` / `FileNotFoundError` | Error del sistema de archivos al abrir la ruta. |

---

### 5.6 `open_instance_resource()`

Abre un recurso relativo a `instance_path`. A diferencia de `open_resource()`, admite modos de escritura.

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `resource` | `str` | Sí | — | Ruta relativa a `instance_path`. |
| `mode` | `str` | No | `"rb"` | Cualquier modo válido de `open()`. |
| `encoding` | `str \| None` | No | `"utf-8"` | Codificación en modo texto (ignorada si `"b" in mode`). |

**Retorno:** `t.IO[t.AnyStr]`.

**Raises**

| Excepción | Condición |
|---|---|
| `OSError` / `FileNotFoundError` | Error del sistema de archivos. |
| `ValueError` | Modo inválido (propagada por `open()`). |

---

### 5.7 `create_jinja_environment()`

Construye el entorno Jinja a partir de `jinja_options`, fijando `autoescape` (`select_jinja_autoescape`) y `auto_reload` (según `TEMPLATES_AUTO_RELOAD` o `debug`). Registra los globales `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g` y la política `json.dumps_function`.

**Parámetros:** ninguno (además de `self`).

**Retorno:** `Environment` — entorno Jinja configurado.

**Raises:** No lanza excepciones propias.

---

### 5.8 `create_url_adapter()`

Crea el `MapAdapter` para la petición dada o, en su defecto, para un contexto de aplicación.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request \| None` | Sí | Petición a vincular; `None` para enlazar fuera de petición. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `MapAdapter \| None` | Adaptador vinculado al `environ` (si hay petición) o a `SERVER_NAME`; `None` si no hay petición ni `SERVER_NAME`. |

**Comportamiento relevante**

- Aplica `TRUSTED_HOSTS` a `request.trusted_hosts` y recalcula `request.host` con `get_host()`.
- Con `url_map.host_matching` activo, omite `server_name`.
- Sin `subdomain_matching`, fuerza el subdominio a `url_map.default_subdomain or ""`.

**Raises**

| Excepción | Condición |
|---|---|
| `SecurityError` (indirecta, vía `get_host`) | El host de la petición no figura en `trusted_hosts`. |

---

### 5.9 `raise_routing_exception()`

Método interno (`:meta private:`) que relanza la excepción de enrutamiento. En modo debug, sustituye redirecciones que descartarían el cuerpo por un error explicativo.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request` | Sí | Petición con `routing_exception` establecida. |

**Retorno:** `t.NoReturn` — siempre lanza.

**Raises**

| Excepción | Condición |
|---|---|
| `request.routing_exception` | Fuera de debug, o códigos 307/308, o método en `{GET, HEAD, OPTIONS}`, o excepción no `RequestRedirect`. |
| `FormDataRoutingRedirect` | En debug, redirección con método/cuerpo susceptible de pérdida de datos. |

---

### 5.10 `update_template_context()`

Inyecta en el diccionario de contexto de plantilla las variables comunes y el resultado de los *context processors* de la app y de los blueprints implicados. Los valores originales (`orig_ctx`) se re-aplican al final para conservar precedencia.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo; si `ctx.has_request`, se añaden los blueprints en orden inverso. |
| `context` | `dict[str, t.Any]` | Sí | Contexto a actualizar **in place**. |

**Retorno:** `None`.

**Raises:** propaga las excepciones de los *context processors*.

---

### 5.11 `make_shell_context()`

Construye el contexto del shell interactivo, partiendo de `{"app": self, "g": g}` y aplicando todos los `shell_context_processors`.

**Parámetros:** ninguno.

**Retorno:** `dict[str, t.Any]` — espacio de nombres del shell.

**Raises:** propaga las excepciones de los procesadores registrados.

---

### 5.12 `run()`

Arranca el servidor de desarrollo de Werkzeug. No apto para producción.

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `host` | `str \| None` | No | `None` | Host de escucha; resuelto desde `SERVER_NAME` o `127.0.0.1`. |
| `port` | `int \| None` | No | `None` | Puerto; resuelto desde `SERVER_NAME` o `5000`. |
| `debug` | `bool \| None` | No | `None` | Fuerza el modo debug (precede a cualquier otra fuente). |
| `load_dotenv` | `bool` | No | `True` | Carga `.env` / `.flaskenv` y ajusta el directorio de trabajo. |
| `**options` | `t.Any` | No | — | Reenviados a `werkzeug.serving.run_simple` (`use_reloader`, `use_debugger`, `threaded` tienen valores por defecto). |

**Retorno:** `None`.

**Comportamiento relevante**

- Si `FLASK_RUN_FROM_CLI == "true"`, la llamada se ignora (con mensaje en rojo si no se está bajo el *reloader*).
- `FLASK_DEBUG` sobrescribe `self.debug` tras cargar dotenv.
- En el `finally`, restablece `self._got_first_request = False`.

**Raises**

| Excepción | Condición |
|---|---|
| `OSError` (indirecta) | Puerto ocupado o dirección no disponible al llamar `run_simple`. |

---

### 5.13 `test_client()`

Crea un cliente de pruebas de la clase `test_client_class` o, si es `None`, `flask.testing.FlaskClient`.

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `use_cookies` | `bool` | No | `True` | Habilita el soporte de cookies entre peticiones. |
| `**kwargs` | `t.Any` | No | — | Reenviados al constructor de `test_client_class`. |

**Retorno:** `FlaskClient`.

**Raises:** No lanza excepciones propias.

---

### 5.14 `test_cli_runner()`

Crea un runner para probar comandos CLI, de la clase `test_cli_runner_class` o `flask.testing.FlaskCliRunner`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kwargs` | `t.Any` | No | Reenviados al constructor del runner. |

**Retorno:** `FlaskCliRunner`.

**Raises:** No lanza excepciones propias.

---

### 5.15 `handle_http_exception()`

Resuelve una `HTTPException` invocando el manejador de error registrado (búsqueda por código y MRO sobre `ctx.request.blueprints`).

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo de la petición. |
| `e` | `HTTPException` | Sí | Excepción HTTP a manejar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `HTTPException \| ft.ResponseReturnValue` | La propia excepción si `e.code is None`, si es `RoutingException` o si no hay manejador; en otro caso, el valor devuelto por el manejador. |

**Raises:** propaga las excepciones lanzadas por el manejador de error.

---

### 5.16 `handle_user_exception()`

Punto central de manejo de excepciones de usuario: deriva `HTTPException` a `handle_http_exception()` (salvo *trap*), activa `show_exception` en `BadRequestKeyError` bajo debug/`TRAP_BAD_REQUEST_ERRORS` y busca un manejador específico.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo de la petición. |
| `e` | `Exception` | Sí | Excepción capturada durante el despacho. |

**Retorno:** `HTTPException | ft.ResponseReturnValue` — respuesta o excepción HTTP resultante.

**Raises**

| Excepción | Condición |
|---|---|
| Excepción original (`raise` desnudo) | No existe manejador registrado para `e`. |

---

### 5.17 `handle_exception()`

Maneja excepciones sin manejador asociado produciendo un `500 InternalServerError`. Emite siempre la señal `got_request_exception`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción no manejada. |

**Retorno:** `Response` — resultado de `finalize_request(ctx, server_error, from_error_handler=True)`.

**Raises**

| Excepción | Condición |
|---|---|
| Excepción original / `e` | `PROPAGATE_EXCEPTIONS` es verdadero (o `testing`/`debug` activos). |

> El manejador de `InternalServerError`, si existe, recibe siempre la instancia `InternalServerError` con `original_exception` establecido.

---

### 5.18 `log_exception()`

Registra la excepción en `self.logger` con nivel `error`, incluyendo ruta y método de la petición.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (fuente de `request.path` y `request.method`). |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí | Tripleta de información de excepción. |

**Retorno:** `None`.

**Raises:** No lanza excepciones propias.

---

### 5.19 `dispatch_request()`

Realiza el despacho: valida la excepción de enrutamiento, atiende automáticamente `OPTIONS` si la regla lo permite y, en caso contrario, invoca la función de vista del endpoint con `view_args`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo con `request`, `url_rule` y `view_args`. |

**Retorno:** `ft.ResponseReturnValue` — valor bruto de la vista (no necesariamente un `Response`).

**Raises**

| Excepción | Condición |
|---|---|
| `HTTPException` / `RoutingException` / `FormDataRoutingRedirect` | Vía `raise_routing_exception()` cuando `request.routing_exception` no es `None`. |
| Cualquier excepción de la vista | Propagada al llamador (`full_dispatch_request()`). |

---

### 5.20 `full_dispatch_request()`

Orquesta el ciclo completo: emite `request_started`, ejecuta `preprocess_request()`, despacha, captura excepciones con `handle_user_exception()` y finaliza con `finalize_request()`. Marca `self._got_first_request = True` y advierte si `should_ignore_error` está definido (API en deprecación).

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo de la petición. |

**Retorno:** `Response`.

**Raises**

| Excepción / Aviso | Condición |
|---|---|
| `DeprecationWarning` (warning) | `should_ignore_error` definido antes de la primera petición. |
| Excepciones propagadas | Desde `handle_user_exception()` o `finalize_request()`. |

---

### 5.21 `finalize_request()`

Convierte el valor de retorno en `Response` (`make_response()`), ejecuta `process_response()` y emite `request_finished`. En modo seguro (`from_error_handler=True`) registra y suprime los fallos del post-procesado.

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `ctx` | `AppContext` | Sí | — | Contexto activo. |
| `rv` | `ft.ResponseReturnValue \| HTTPException` | Sí | — | Valor de retorno de la vista o manejador. |
| `from_error_handler` | `bool` | No | `False` | Activa el modo tolerante a fallos. |

**Retorno:** `Response`.

**Raises**

| Excepción | Condición |
|---|---|
| Cualquier excepción del post-procesado | Solo si `from_error_handler` es `False`. |
| `TypeError` | Vía `make_response()` con un valor de retorno inválido. |

---

### 5.22 `make_default_options_response()`

Genera la respuesta `OPTIONS` por defecto, poblando el encabezado `Allow` con los métodos permitidos por el adaptador de URL.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (usa `ctx.url_adapter.allowed_methods()`). |

**Retorno:** `Response` — instancia de `response_class` con `allow` actualizado.

**Raises**

| Excepción | Condición |
|---|---|
| `AttributeError` | `ctx.url_adapter` es `None` (escenario no esperado en flujo normal). |

---

### 5.23 `ensure_sync()`

Garantiza que un callable sea síncrono para *workers* WSGI: devuelve las funciones `def` sin cambios y envuelve las `async def` mediante `async_to_sync()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `t.Callable[..., t.Any]` | Sí | Vista o callback a normalizar. |

**Retorno:** `t.Callable[..., t.Any]` — callable invocable de forma síncrona.

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | Indirecta, vía `async_to_sync()` si `asgiref` no está instalado. |

---

### 5.24 `async_to_sync()`

Convierte una función corrutina en un callable síncrono usando `asgiref.sync.async_to_sync`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `t.Callable[..., t.Coroutine[t.Any, t.Any, t.Any]]` | Sí | Función `async def` a adaptar. |

**Retorno:** `t.Callable[..., t.Any]` — versión síncrona del callable.

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | `asgiref` no disponible (`ImportError` traducido): instalar Flask con el extra `async`. |

---

### 5.25 `url_for()`

Construye la URL de un endpoint. Resuelve el adaptador desde el contexto activo o creándolo con `create_url_adapter(None)`; soporta endpoints relativos al blueprint (prefijo `.`), inyección de `url_defaults` y *fallback* a `handle_url_build_error()`.

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `endpoint` | `str` | Sí | — | Nombre del endpoint (posicional-o-nominal tras `/`). Si empieza por `.`, es relativo al blueprint actual. |
| `_anchor` | `str \| None` | No (keyword-only) | `None` | Fragmento `#anchor`, escapado con `urllib.parse.quote`. |
| `_method` | `str \| None` | No (keyword-only) | `None` | Método HTTP asociado a la regla. |
| `_scheme` | `str \| None` | No (keyword-only) | `None` | Esquema para URLs externas. |
| `_external` | `bool \| None` | No (keyword-only) | `None` | Fuerza URL externa/interna. Por defecto `True` fuera de petición. |
| `**values` | `t.Any` | No | — | Valores de las partes variables; claves desconocidas pasan a query string. |

**Retorno:** `str` — la URL generada (o el valor de `handle_url_build_error()` en caso de fallo recuperable).

**Raises**

| Excepción | Condición |
|---|---|
| `ValueError` | Se indica `_scheme` con `_external` falso. |
| `RuntimeError` | Sin petición activa y sin `SERVER_NAME` configurado (adaptador `None`). |
| `BuildError` | Propagada desde `handle_url_build_error()` si este no devuelve una cadena. |

---

### 5.26 `make_response()`

Normaliza el valor de retorno de una vista a una instancia de `response_class`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `rv` | `ft.ResponseReturnValue` | Sí | `str`, `bytes`, `dict`, `list`, generador/iterador, `tuple` de 2 o 3 elementos, `Response`, otra `BaseResponse` o callable WSGI. |

**Retorno:** `Response` — respuesta final, con `status` y `headers` aplicados/extendidos.

**Raises**

| Excepción | Condición |
|---|---|
| `TypeError` | Tupla con longitud distinta de 2 o 3. |
| `TypeError` | `rv is None` (la vista no devolvió nada). |
| `TypeError` | Tipo de retorno no soportado, o fallo de `response_class.force_type` al coercer un callable/`BaseResponse`. |

---

### 5.27 `preprocess_request()`

Ejecuta `url_value_preprocessors` y después `before_request_funcs` de la app y blueprints (de más específico a más general). Si algún `before_request` devuelve un valor no `None`, corta el flujo y ese valor se trata como retorno de vista.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo de la petición. |

**Retorno:** `ft.ResponseReturnValue | None` — valor de corto-circuito o `None`.

**Raises:** propaga las excepciones de los preprocesadores y de `before_request`.

---

### 5.28 `process_response()`

Aplica los callbacks `ctx._after_request_functions` y los `after_request_funcs` (blueprints primero, app al final, en orden inverso de registro) y guarda la sesión si no es nula.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (fuente de la sesión y callbacks diferidos). |
| `response` | `Response` | Sí | Respuesta a post-procesar. |

**Retorno:** `Response` — la misma instancia o una nueva, siempre de tipo `response_class`.

**Raises:** propaga las excepciones de los `after_request` y de `save_session`.

---

### 5.29 `do_teardown_request()`

Invoca todos los `teardown_request` (blueprints y app, en orden inverso) y emite `request_tearing_down`. Desde 3.2 **todos** los callbacks se ejecutan, acumulando errores en `_CollectErrors`.

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `ctx` | `AppContext` | Sí | — | Contexto de la petición que se está cerrando. |
| `exc` | `BaseException \| None` | No | `None` | Excepción no manejada, pasada a cada callback. |

**Retorno:** `None`.

**Raises**

| Excepción | Condición |
|---|---|
| Errores agrupados por `collect_errors.raise_any("Errors during request teardown")` | Uno o más callbacks/receptores de señal fallaron. |

---

### 5.30 `do_teardown_appcontext()`

Invoca todos los `teardown_appcontext_funcs` (orden inverso) y emite `appcontext_tearing_down`, acumulando errores con `_CollectErrors`.

| Nombre | Tipo | Requerido | Defecto | Descripción |
|---|---|---|---|---|
| `ctx` | `AppContext` | Sí | — | Contexto de aplicación que se está cerrando. |
| `exc` | `BaseException \| None` | No | `None` | Excepción no manejada durante la vida del contexto. |

**Retorno:** `None`.

**Raises**

| Excepción | Condición |
|---|---|
| Errores agrupados por `collect_errors.raise_any("Errors during app teardown")` | Uno o más callbacks/receptores de señal fallaron. |

---

### 5.31 `app_context()`

Crea un `AppContext` vacío (sin petición) para usar como gestor de contexto.

**Parámetros:** ninguno.

**Retorno:** `AppContext` — contexto que, al empujarse, habilita `current_app` y `g`.

**Raises:** No lanza excepciones propias.

---

### 5.32 `request_context()`

Crea un `AppContext` con información de petición a partir de un entorno WSGI (`AppContext.from_environ`). Uso interno; para pruebas, emplear `test_request_context()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI válido. |

**Retorno:** `AppContext`.

**Raises:** propaga errores de construcción del contexto/petición.

---

### 5.33 `test_request_context()`

Construye un `AppContext` con petición sintética usando `flask.testing.EnvironBuilder`; cierra el builder en un bloque `finally`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `*args` | `t.Any` | No | Posicionales para `EnvironBuilder` (p. ej. `path`). |
| `**kwargs` | `t.Any` | No | Nominales para `EnvironBuilder` (`base_url`, `subdomain`, `url_scheme`, `data`, `json`, etc.). |

**Retorno:** `AppContext` — contexto listo para `with`.

**Raises:** propaga los errores de validación de `EnvironBuilder` (p. ej. `ValueError` por combinaciones inválidas de argumentos).

---

### 5.34 `wsgi_app()`

Implementación real de la aplicación WSGI. Empuja el contexto, despacha, maneja excepciones con `handle_exception()`, preserva el contexto para el depurador de Werkzeug si procede, filtra errores mediante `should_ignore_error` y hace `ctx.pop(error)` en el `finally`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI de la petición. |
| `start_response` | `StartResponse` | Sí | Callable WSGI para iniciar la respuesta. |

**Retorno:** `cabc.Iterable[bytes]` — iterable del cuerpo de la respuesta.

**Raises**

| Excepción | Condición |
|---|---|
| `BaseException` (relanzada) | Excepciones que no derivan de `Exception` (cláusula `except:` desnuda) o re-propagadas por `handle_exception()` con `PROPAGATE_EXCEPTIONS`. |
| Errores de *teardown* | Propagados desde `ctx.pop(error)`. |

> **Punto de extensión:** sustituible por middleware — `app.wsgi_app = MyMiddleware(app.wsgi_app)`.

---

### 5.35 `__call__()`

Hace que la instancia `Flask` sea invocable como aplicación WSGI; delega íntegramente en `wsgi_app()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callable de inicio de respuesta. |

**Retorno:** `cabc.Iterable[bytes]`.

**Raises:** las mismas que `wsgi_app()`.

---

## 6. Ejemplo de uso

```python
"""Caso de uso integral de flask.app.Flask: rutas, contextos, errores y pruebas."""

from __future__ import annotations

import typing as t

from werkzeug.exceptions import HTTPException

from flask import Flask
from flask.ctx import AppContext


# --- 1. Creación de la aplicación --------------------------------------------
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config.update(
    SECRET_KEY="dev-only-key",
    SERVER_NAME="example.com",
    APPLICATION_ROOT="/",
    PREFERRED_URL_SCHEME="https",
    SEND_FILE_MAX_AGE_DEFAULT=3600,
)


# --- 2. Vistas ----------------------------------------------------------------
@app.route("/")
def index() -> dict[str, str]:
    # make_response() convierte el dict en una respuesta JSON.
    return {"status": "ok"}


@app.route("/users/<int:user_id>")
def show_user(user_id: int) -> tuple[str, int, dict[str, str]]:
    # Tupla (body, status, headers) soportada por make_response().
    return f"user {user_id}", 200, {"X-Served-By": "flask"}


@app.route("/files/<path:filename>")
def download(filename: str):
    # Reutiliza send_static_file() y get_send_file_max_age() de la app.
    return app.send_static_file(filename)


# --- 3. Hooks del ciclo de vida ----------------------------------------------
@app.before_request
def _audit():
    # preprocess_request() ejecuta este callback; devolver None continúa el flujo.
    return None


@app.teardown_appcontext
def _close_resources(exc: BaseException | None) -> None:
    # Invocado por do_teardown_appcontext() al hacer pop del contexto.
    app.logger.debug("teardown appcontext, exc=%r", exc)


@app.errorhandler(HTTPException)
def _on_http_error(error: HTTPException):
    # Consumido por handle_http_exception() vía handle_user_exception().
    return {"error": error.name, "code": error.code}, error.code or 500


# --- 4. Uso de contextos y url_for() -----------------------------------------
with app.app_context():                     # -> app_context()
    print(app.url_for("show_user", user_id=7, _external=True))
    print(app.make_shell_context().keys())  # -> make_shell_context()

with app.test_request_context("/?q=flask"): # -> test_request_context()
    ctx: AppContext = t.cast(AppContext, None)  # solo ilustrativo
    print(app.url_for("index"))             # URL relativa dentro de petición


# --- 5. Lectura de recursos ---------------------------------------------------
with app.open_resource("schema.sql", mode="r", encoding="utf-8") as fh:
    schema_sql = fh.read()

with app.open_instance_resource("cache.bin", mode="wb") as fh:
    fh.write(b"\x00")


# --- 6. Pruebas ---------------------------------------------------------------
app.testing = True
client = app.test_client()                  # -> test_client()
response = client.get("/users/7", base_url="https://example.com")
assert response.status_code == 200
assert response.headers["X-Served-By"] == "flask"

runner = app.test_cli_runner()              # -> test_cli_runner()
result = runner.invoke(args=["routes"])
print(result.output)


# --- 7. Middleware sobre wsgi_app() y arranque -------------------------------
class RequestIdMiddleware:
    def __init__(self, wsgi_app):
        self.wsgi_app = wsgi_app

    def __call__(self, environ, start_response):
        environ["app.request_id"] = "req-001"
        return self.wsgi_app(environ, start_response)


app.wsgi_app = RequestIdMiddleware(app.wsgi_app)

if __name__ == "__main__":
    # run() ignora la llamada si se ejecuta desde el comando `flask`.
    app.run(host="127.0.0.1", port=5000, debug=True, use_reloader=False)
```

### 6.1 Ejemplo de subclase con firma nueva (evita `DeprecationWarning`)

```python
from flask import Flask
from flask.ctx import AppContext
from flask.typing import ResponseReturnValue


class TracedFlask(Flask):
    """Subclase alineada con la firma moderna: `ctx: AppContext` primero.

    Si se omitiera `ctx`, `__init_subclass__()` emitiría DeprecationWarning y
    aplicaría `remove_ctx()` / `add_ctx()` automáticamente.
    """

    def dispatch_request(self, ctx: AppContext) -> ResponseReturnValue:
        self.logger.info("dispatch %s", ctx.request.path)
        return super().dispatch_request(ctx)

    def log_exception(self, ctx: AppContext, exc_info) -> None:
        self.logger.error("fallo en %s", ctx.request.path, exc_info=exc_info)
```