# Documentación Técnica: Módulo `flask/app.py`

---

## 1. Resumen ejecutivo

Este módulo define la clase `Flask`, la implementación concreta y **síncrona (WSGI)** del objeto central de aplicación de Flask, que hereda de la clase base agnóstica al transporte `App` (`flask.sansio.app`). Su responsabilidad es orquestar el ciclo de vida completo de una petición HTTP: creación del contexto de aplicación/petición, despacho a la vista, pre/post-procesamiento, conversión del valor de retorno a un objeto `Response`, manejo de excepciones y ejecución de los *teardown handlers*.

Adicionalmente, el módulo provee utilidades de compatibilidad (`remove_ctx()`, `add_ctx()`) que permiten detectar en tiempo de definición de subclases los métodos sobrescritos con la firma antigua (sin el parámetro `ctx: AppContext`), emitiendo un `DeprecationWarning` y adaptando automáticamente la llamada. También expone la integración con el CLI de Click, el servidor de desarrollo (`run()`), el cliente de pruebas (`test_client()`) y la generación de URLs (`url_for()`).

---

## 2. Especificación de funciones y métodos

### 2.1 Constantes y variables de tipo del módulo

| Nombre | Tipo | Descripción |
|---|---|---|
| `T_shell_context_processor` | `TypeVar` | Acotado a `ft.ShellContextProcessorCallable`. |
| `T_teardown` | `TypeVar` | Acotado a `ft.TeardownCallable`. |
| `T_template_filter` | `TypeVar` | Acotado a `ft.TemplateFilterCallable`. |
| `T_template_global` | `TypeVar` | Acotado a `ft.TemplateGlobalCallable`. |
| `T_template_test` | `TypeVar` | Acotado a `ft.TemplateTestCallable`. |
| `F` | `TypeVar` | Acotado a `t.Callable[..., t.Any]`. Usado por los decoradores `remove_ctx()` / `add_ctx()`. |

---

### 2.2 Funciones a nivel de módulo

#### `_make_timedelta()`

```
_make_timedelta(value: timedelta | int | None) -> timedelta | None
```

Normaliza un valor de configuración temporal a un objeto `timedelta`. Función auxiliar privada: si el valor es `None` o ya es un `timedelta`, se devuelve sin cambios; si es un entero, se interpreta como segundos.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `value` | `timedelta \| int \| None` | Sí | Valor a normalizar. Un `int` se interpreta como segundos. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `timedelta \| None` | `None` si la entrada es `None`; en otro caso un `timedelta`. |

**Raises**

| Excepción | Condición |
|---|---|
| `TypeError` | Propagada por `timedelta(seconds=value)` si `value` no es un numérico válido. |

---

#### `remove_ctx()`

```
remove_ctx(f: F) -> F
```

Decorador de compatibilidad retroactiva. Envuelve un método **sobrescrito por el usuario** que conserva la firma antigua (sin `ctx`). Si la llamada incluye un `AppContext` como primer argumento posicional, éste es descartado antes de delegar en `f`. Preserva los metadatos mediante `update_wrapper`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método con la firma legada a envolver. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `F` | Función `wrapper` con los metadatos de `f` copiados. |

**Raises**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones propias; propaga las de `f`. |

##### Función anidada `wrapper()` (dentro de `remove_ctx()`)

```
wrapper(self: Flask, *args: t.Any, **kwargs: t.Any) -> t.Any
```

Elimina el primer argumento posicional cuando es una instancia de `AppContext` y reenvía el resto a `f`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación (método ligado). |
| `*args` | `t.Any` | No | Argumentos posicionales; `args[0]` se descarta si es `AppContext`. |
| `**kwargs` | `t.Any` | No | Argumentos por nombre reenviados íntegramente. |

**Retorno:** `t.Any` — el valor devuelto por `f(self, *args, **kwargs)`.

---

#### `add_ctx()`

```
add_ctx(f: F) -> F
```

Decorador de compatibilidad retroactiva complementario a `remove_ctx()`. Envuelve el **método base de `Flask`** para que, cuando una subclase legada invoque `super().metodo(...)` sin el argumento `ctx`, se inyecte automáticamente el contexto de aplicación activo (`app_ctx._get_current_object()`).

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método base de `Flask` con la firma nueva (`ctx` como primer parámetro). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `F` | Función `wrapper` con los metadatos de `f` copiados. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | Propagada por `app_ctx._get_current_object()` si no hay un contexto de aplicación activo. |

##### Función anidada `wrapper()` (dentro de `add_ctx()`)

```
wrapper(self: Flask, *args: t.Any, **kwargs: t.Any) -> t.Any
```

Inserta el `AppContext` activo como primer argumento posicional si no está presente.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `t.Any` | No | Si está vacío o `args[0]` no es `AppContext`, se prepone el contexto activo. |
| `**kwargs` | `t.Any` | No | Argumentos por nombre reenviados íntegramente. |

**Retorno:** `t.Any` — el valor devuelto por `f(self, *args, **kwargs)`.

---

### 2.3 Clase `Flask`

Implementa una aplicación WSGI y actúa como registro central de vistas, reglas de URL, configuración de plantillas y comandos CLI.

#### Atributos de clase

| Atributo | Tipo | Valor por defecto | Descripción |
|---|---|---|---|
| `default_config` | `ImmutableDict` | Ver código | Configuración base (`DEBUG`, `SECRET_KEY`, `MAX_CONTENT_LENGTH`, cookies de sesión, etc.). |
| `request_class` | `type[Request]` | `flask.Request` | Clase usada para objetos de petición. |
| `response_class` | `type[Response]` | `flask.Response` | Clase usada para objetos de respuesta. |
| `session_interface` | `SessionInterface` | `SecureCookieSessionInterface()` | Interfaz de sesión empleada. |

---

#### `__init_subclass__()`

```
__init_subclass__(cls, **kwargs: t.Any) -> None
```

Hook de creación de subclases. Inspecciona los métodos cuya firma fue migrada para recibir `ctx: AppContext` como primer parámetro (`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`). Para cada método sobrescrito, valida mediante `inspect.signature` que el segundo parámetro se llame `ctx` o esté anotado como `AppContext` (anotación como clase o como cadena). Si no cumple, emite un `DeprecationWarning` y reasigna el método de la subclase con `remove_ctx()` y el método base de `Flask` con `add_ctx()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `cls` | `type[Flask]` | Sí (implícito) | Subclase en construcción. |
| `**kwargs` | `t.Any` | No | Argumentos de clase adicionales (no utilizados directamente). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Modifica `cls` y `Flask` como efecto colateral. |

**Raises**

| Excepción | Condición |
|---|---|
| `DeprecationWarning` *(warning, no excepción)* | Firma legada detectada en un método sobrescrito. |
| `TypeError` / `ValueError` | Propagadas por `inspect.signature()` sobre objetos no inspeccionables. |

---

#### `__init__()`

```
__init__(import_name, static_url_path=None, static_folder="static", static_host=None,
         host_matching=False, subdomain_matching=False, template_folder="templates",
         instance_path=None, instance_relative_config=False, root_path=None)
```

Inicializa la aplicación delegando en `App.__init__`, crea el grupo de comandos Click (`self.cli = cli.AppGroup()`), asigna su nombre y, si hay carpeta estática configurada, registra la regla de URL `"{static_url_path}/<path:filename>"` con endpoint `"static"`. El `view_func` se construye como una lambda que usa una `weakref.ref` a la app para evitar ciclos de referencia.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `import_name` | `str` | Sí | Nombre del paquete/módulo de la aplicación. |
| `static_url_path` | `str \| None` | No | Ruta web para archivos estáticos. Por defecto, el nombre de `static_folder`. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta de archivos estáticos (`"static"`). |
| `static_host` | `str \| None` | No | Host para la ruta estática. Obligatorio con `host_matching=True`. |
| `host_matching` | `bool` | No | Activa `url_map.host_matching` (`False`). |
| `subdomain_matching` | `bool` | No | Considera el subdominio relativo a `SERVER_NAME` (`False`). |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta de plantillas (`"templates"`). |
| `instance_path` | `str \| None` | No | Ruta alternativa de la carpeta *instance*. |
| `instance_relative_config` | `bool` | No | Resuelve rutas de configuración relativas a `instance_path`. |
| `root_path` | `str \| None` | No | Raíz de los archivos de la aplicación. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Constructor. |

**Raises**

| Excepción | Condición |
|---|---|
| `AssertionError` | `bool(static_host) != host_matching` (combinación inválida de `static_host`/`host_matching`). |
| `ValueError` | Propagada por `App.__init__` ante un `import_name`/`instance_path` inválido. |

##### Callback local (lambda) del `view_func` estático

```
lambda **kw: self_ref().send_static_file(**kw)
```

Función anónima registrada como vista del endpoint `"static"`. Desreferencia el `weakref` a la aplicación y delega en `send_static_file()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kw` | `t.Any` | Sí | Variables de la regla; en la práctica `filename`. |

**Retorno:** `Response` — resultado de `send_static_file()`.

---

#### `get_send_file_max_age()`

```
get_send_file_max_age(filename: str | None) -> int | None
```

Determina el valor `max_age` de caché para un archivo servido por `send_file`, a partir de `SEND_FILE_MAX_AGE_DEFAULT`. Convierte `timedelta` a segundos enteros.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str \| None` | Sí | Ruta del archivo (puede ignorarse en la implementación por defecto). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `int \| None` | Segundos de caché, o `None` para usar peticiones condicionales. |

**Raises**

| Excepción | Condición |
|---|---|
| `KeyError` | Si la clave `SEND_FILE_MAX_AGE_DEFAULT` no existe en `self.config`. |

---

#### `send_static_file()`

```
send_static_file(filename: str) -> Response
```

Vista utilizada para servir archivos desde `static_folder`. Calcula `max_age` mediante `get_send_file_max_age()` y delega en `send_from_directory()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str` | Sí | Ruta relativa del archivo dentro de `static_folder`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta con el archivo estático. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | `static_folder` no está configurado. |
| `NotFound` (`werkzeug.exceptions`) | Propagada por `send_from_directory()` si el archivo no existe. |

---

#### `open_resource()`

```
open_resource(resource: str, mode: str = "rb", encoding: str | None = None) -> t.IO[t.AnyStr]
```

Abre un archivo de recurso relativo a `root_path` **solo para lectura**.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta relativa a `root_path`. |
| `mode` | `str` | No | Modo de apertura; válidos: `"r"`, `"rt"`, `"rb"` (`"rb"`). |
| `encoding` | `str \| None` | No | Codificación en modo texto; ignorada en binario. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.IO[t.AnyStr]` | Objeto archivo abierto. |

**Raises**

| Excepción | Condición |
|---|---|
| `ValueError` | `mode` no pertenece a `{"r", "rt", "rb"}`. |
| `OSError` / `FileNotFoundError` | El archivo no existe o no es accesible. |

---

#### `open_instance_resource()`

```
open_instance_resource(resource: str, mode: str = "rb", encoding: str | None = "utf-8") -> t.IO[t.AnyStr]
```

Abre un archivo relativo a `instance_path`. A diferencia de `open_resource()`, admite modos de escritura.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta relativa a `instance_path`. |
| `mode` | `str` | No | Cualquier modo válido de `open()` (`"rb"`). |
| `encoding` | `str \| None` | No | Codificación en modo texto (`"utf-8"`). Ignorada si `"b"` está en `mode`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.IO[t.AnyStr]` | Objeto archivo abierto. |

**Raises**

| Excepción | Condición |
|---|---|
| `OSError` / `FileNotFoundError` | Error de E/S al abrir el archivo. |
| `ValueError` | `mode` no válido para `open()`. |

---

#### `create_jinja_environment()`

```
create_jinja_environment() -> Environment
```

Construye el entorno Jinja a partir de `jinja_options`, estableciendo `autoescape` y `auto_reload` (según `TEMPLATES_AUTO_RELOAD` o `debug`), e inyectando los globales de Flask (`url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g`) y la política `json.dumps_function`.

**Parámetros:** ninguno (solo `self`).

**Retorno**

| Tipo | Descripción |
|---|---|
| `Environment` | Entorno Jinja configurado. |

**Raises**

| Excepción | Condición |
|---|---|
| `KeyError` | Falta la clave `TEMPLATES_AUTO_RELOAD` en la configuración. |

---

#### `create_url_adapter()`

```
create_url_adapter(request: Request | None) -> MapAdapter | None
```

Crea un `MapAdapter` para la petición dada. Con petición: aplica `TRUSTED_HOSTS`, recalcula `request.host` con `get_host()` y enlaza el mapa al entorno WSGI (omitiendo `server_name` si `host_matching`, o forzando el subdominio por defecto si `subdomain_matching` está desactivado). Sin petición: enlaza usando `SERVER_NAME`, `APPLICATION_ROOT` y `PREFERRED_URL_SCHEME`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request \| None` | Sí | Petición activa, o `None` para un adaptador de contexto de aplicación. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `MapAdapter \| None` | Adaptador, o `None` si no hay petición ni `SERVER_NAME`. |

**Raises**

| Excepción | Condición |
|---|---|
| `werkzeug.exceptions.SecurityError` | Propagada por `get_host()` si el host no es de confianza. |

---

#### `raise_routing_exception()`

```
raise_routing_exception(request: Request) -> t.NoReturn
```

Relanza la excepción de enrutamiento asociada a la petición. En modo *debug*, si se trata de un `RequestRedirect` con código distinto de 307/308 y un método que descartaría el cuerpo, la sustituye por `FormDataRoutingRedirect`. Marcado como `:internal:`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request` | Sí | Petición cuyo `routing_exception` se relanza. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.NoReturn` | Nunca retorna; siempre lanza. |

**Raises**

| Excepción | Condición |
|---|---|
| `request.routing_exception` (`HTTPException` / `RoutingException`) | Caso general (no debug, 307/308, o método seguro). |
| `FormDataRoutingRedirect` | En debug, redirección que descartaría datos de formulario. |

---

#### `update_template_context()`

```
update_template_context(ctx: AppContext, context: dict[str, t.Any]) -> None
```

Inyecta en el contexto de plantilla las variables de los *context processors* registrados para la app y para los blueprints de la petición (en orden inverso). Los valores originales pasados a `render_template` se reaplican al final para que tengan precedencia.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo; si `ctx.has_request`, se incluyen los blueprints. |
| `context` | `dict[str, t.Any]` | Sí | Diccionario de contexto modificado *in place*. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Modificación *in place* de `context`. |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` | Cualquier error propagado desde un *context processor*. |

---

#### `make_shell_context()`

```
make_shell_context() -> dict[str, t.Any]
```

Construye el espacio de nombres para el shell interactivo (`flask shell`), con `app` y `g`, actualizado por todos los `shell_context_processors`.

**Parámetros:** ninguno.

**Retorno**

| Tipo | Descripción |
|---|---|
| `dict[str, t.Any]` | Diccionario de variables del shell. |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` | Propagada desde un *shell context processor*. |

---

#### `run()`

```
run(host: str | None = None, port: int | None = None, debug: bool | None = None,
    load_dotenv: bool = True, **options: t.Any) -> None
```

Arranca el servidor de desarrollo de Werkzeug (`run_simple`). **No apto para producción.** Si la variable de entorno `FLASK_RUN_FROM_CLI` es `"true"`, la llamada se ignora (mostrando un aviso si no se ejecuta desde el reloader). Carga `.env`/`.flaskenv`, resuelve host y puerto desde `SERVER_NAME` cuando no se indican, aplica valores por defecto a `use_reloader`, `use_debugger` y `threaded`, y restablece `_got_first_request` al finalizar.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `host` | `str \| None` | No | Host de escucha. Por defecto `SERVER_NAME` o `"127.0.0.1"`. |
| `port` | `int \| None` | No | Puerto. Por defecto el de `SERVER_NAME` o `5000`. |
| `debug` | `bool \| None` | No | Activa/desactiva el modo debug; prevalece sobre otras fuentes. |
| `load_dotenv` | `bool` | No | Carga los archivos `.env`/`.flaskenv` más próximos (`True`). |
| `**options` | `t.Any` | No | Opciones reenviadas a `werkzeug.serving.run_simple`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Retorna al detenerse el servidor o inmediatamente si se ignora la llamada. |

**Raises**

| Excepción | Condición |
|---|---|
| `OSError` | Puerto en uso o dirección no disponible (desde `run_simple`). |
| `ValueError` | `port` no convertible a entero. |
| `KeyboardInterrupt` | Interrupción manual del servidor. |

---

#### `test_client()`

```
test_client(use_cookies: bool = True, **kwargs: t.Any) -> FlaskClient
```

Crea un cliente de pruebas usando `test_client_class` o, si es `None`, `flask.testing.FlaskClient`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `use_cookies` | `bool` | No | Mantiene cookies entre peticiones (`True`). |
| `**kwargs` | `t.Any` | No | Argumentos adicionales para el constructor de `test_client_class`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `FlaskClient` | Cliente de pruebas, usable como gestor de contexto (`with`). |

**Raises**

| Excepción | Condición |
|---|---|
| `TypeError` | `**kwargs` incompatibles con el constructor de la clase cliente. |

---

#### `test_cli_runner()`

```
test_cli_runner(**kwargs: t.Any) -> FlaskCliRunner
```

Crea un *runner* para probar comandos CLI, usando `test_cli_runner_class` o `flask.testing.FlaskCliRunner`. La app se pasa como primer argumento.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kwargs` | `t.Any` | No | Argumentos adicionales para el constructor del runner. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `FlaskCliRunner` | Runner de pruebas CLI. |

**Raises**

| Excepción | Condición |
|---|---|
| `TypeError` | `**kwargs` incompatibles con el constructor del runner. |

---

#### `handle_http_exception()`

```
handle_http_exception(ctx: AppContext, e: HTTPException) -> HTTPException | ft.ResponseReturnValue
```

Resuelve una `HTTPException` invocando el manejador de error registrado (buscado por código y MRO, considerando los blueprints de la petición). Devuelve la excepción sin tocar si `e.code is None` (excepciones proxy) o si es una `RoutingException`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (aporta `ctx.request.blueprints`). |
| `e` | `HTTPException` | Sí | Excepción HTTP a manejar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `HTTPException \| ft.ResponseReturnValue` | La propia excepción, o el valor devuelto por el manejador. |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` | Propagada desde el manejador de error invocado. |

---

#### `handle_user_exception()`

```
handle_user_exception(ctx: AppContext, e: Exception) -> HTTPException | ft.ResponseReturnValue
```

Punto de entrada para excepciones producidas durante el despacho. Activa `show_exception` en `BadRequestKeyError` cuando `debug` o `TRAP_BAD_REQUEST_ERRORS`; delega en `handle_http_exception()` para `HTTPException` no "trapeadas"; si no hay manejador registrado, relanza con el traceback original.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción a manejar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `HTTPException \| ft.ResponseReturnValue` | Valor de respuesta o excepción HTTP. |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` (bare `raise`) | No existe manejador registrado para `e`. |

---

#### `handle_exception()`

```
handle_exception(ctx: AppContext, e: Exception) -> Response
```

Maneja excepciones no gestionadas (o lanzadas desde un manejador), produciendo siempre un `500 InternalServerError`. Emite la señal `got_request_exception`. Si `PROPAGATE_EXCEPTIONS` (o `testing`/`debug`) está activo, relanza. En caso contrario registra la excepción con `log_exception()`, busca un manejador para `InternalServerError` (al que siempre se le pasa la instancia de `InternalServerError`, con `original_exception` establecido) y finaliza la petición en modo seguro.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción no manejada. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta 500 finalizada (`from_error_handler=True`). |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` (`e` o re-raise) | `PROPAGATE_EXCEPTIONS` activo (incluye `testing`/`debug`). |

---

#### `log_exception()`

```
log_exception(ctx: AppContext, exc_info: tuple[type, BaseException, TracebackType] | tuple[None, None, None]) -> None
```

Registra la excepción como `error` en `self.logger`, incluyendo ruta y método de la petición.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (usa `ctx.request.path` y `.method`). |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí | Información de excepción al estilo `sys.exc_info()`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Efecto colateral de logging. |

**Raises**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones propias. |

---

#### `dispatch_request()`

```
dispatch_request(ctx: AppContext) -> ft.ResponseReturnValue
```

Realiza el despacho: si hay `routing_exception`, delega en `raise_routing_exception()`; si la regla declara `provide_automatic_options` y el método es `OPTIONS`, devuelve `make_default_options_response()`; en otro caso invoca la función de vista del endpoint con `view_args`, envuelta por `ensure_sync()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con la petición ya emparejada. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `ft.ResponseReturnValue` | Valor crudo devuelto por la vista (no necesariamente `Response`). |

**Raises**

| Excepción | Condición |
|---|---|
| `HTTPException` / `RoutingException` | Vía `raise_routing_exception()`. |
| `KeyError` | El endpoint no está registrado en `view_functions`. |
| `Exception` | Propagada desde la función de vista. |

---

#### `full_dispatch_request()`

```
full_dispatch_request(ctx: AppContext) -> Response
```

Envuelve el despacho con pre/post-procesamiento y captura de errores. Emite un `DeprecationWarning` si `should_ignore_error` está definido y es la primera petición; marca `_got_first_request`; envía la señal `request_started`; ejecuta `preprocess_request()` y, si retorna `None`, `dispatch_request()`; captura `Exception` con `handle_user_exception()`; finaliza con `finalize_request()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo de la petición. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta final ya post-procesada. |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` | Si `handle_user_exception()` relanza (sin manejador registrado). |
| `DeprecationWarning` *(warning)* | Uso de `should_ignore_error`. |

---

#### `finalize_request()`

```
finalize_request(ctx: AppContext, rv: ft.ResponseReturnValue | HTTPException,
                 from_error_handler: bool = False) -> Response
```

Convierte el valor de retorno en `Response` con `make_response()`, aplica `process_response()` y emite `request_finished`. En modo seguro (`from_error_handler=True`), los fallos durante el post-procesado se registran en el log y se ignoran. Marcado como `:internal:`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `rv` | `ft.ResponseReturnValue \| HTTPException` | Sí | Valor de retorno de la vista o manejador de error. |
| `from_error_handler` | `bool` | No | Habilita el modo seguro de finalización (`False`). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta final. |

**Raises**

| Excepción | Condición |
|---|---|
| `TypeError` | Desde `make_response()` ante un valor de retorno inválido. |
| `Exception` | Fallo en `process_response()`/señal cuando `from_error_handler=False`. |

---

#### `make_default_options_response()`

```
make_default_options_response(ctx: AppContext) -> Response
```

Genera la respuesta automática para `OPTIONS`, poblando la cabecera `Allow` con `ctx.url_adapter.allowed_methods()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con `url_adapter` disponible. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Instancia de `response_class` con `Allow` establecido. |

**Raises**

| Excepción | Condición |
|---|---|
| `AttributeError` | `ctx.url_adapter` es `None`. |

---

#### `ensure_sync()`

```
ensure_sync(func: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]
```

Garantiza que el callable sea ejecutable de forma síncrona por un worker WSGI. Las funciones `def` se devuelven sin cambios; las `async def` se envuelven con `async_to_sync()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `t.Callable[..., t.Any]` | Sí | Vista, manejador o callback a normalizar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.Callable[..., t.Any]` | Callable síncrono equivalente. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | Vía `async_to_sync()` si `asgiref` no está instalado. |

---

#### `async_to_sync()`

```
async_to_sync(func: t.Callable[..., t.Coroutine[t.Any, t.Any, t.Any]]) -> t.Callable[..., t.Any]
```

Devuelve una versión síncrona de una función corrutina, utilizando `asgiref.sync.async_to_sync`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `t.Callable[..., t.Coroutine[...]]` | Sí | Función corrutina a convertir. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.Callable[..., t.Any]` | Callable síncrono que ejecuta y espera la corrutina. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | `asgiref` no disponible (instalar `flask[async]`). |

---

#### `url_for()`

```
url_for(/, endpoint: str, *, _anchor=None, _method=None, _scheme=None, _external=None, **values) -> str
```

Construye la URL de un endpoint. Si hay contexto con petición activa, resuelve endpoints relativos (`.endpoint` → `blueprint.endpoint`) y genera URLs internas por defecto; fuera de petición usa el `url_adapter` del contexto o crea uno con `create_url_adapter(None)` y genera URLs externas por defecto. Aplica `inject_url_defaults()` antes de construir y delega en `handle_url_build_error()` cuando falla la construcción. El ancla se codifica con `urllib.parse.quote`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `endpoint` | `str` | Sí | Nombre del endpoint (posicional-only). Si empieza por `.`, es relativo al blueprint actual. |
| `_anchor` | `str \| None` | No | Fragmento `#anchor` a añadir. |
| `_method` | `str \| None` | No | Método HTTP asociado a la regla. |
| `_scheme` | `str \| None` | No | Esquema a usar en URLs externas. |
| `_external` | `bool \| None` | No | Fuerza URL externa (`True`) o interna (`False`). |
| `**values` | `t.Any` | No | Valores de las partes variables; las claves desconocidas se añaden como query string. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `str` | URL generada (o el valor devuelto por `handle_url_build_error()`). |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | Fuera de petición sin `SERVER_NAME` configurado (adaptador `None`). |
| `ValueError` | Se indica `_scheme` con `_external=False`. |
| `BuildError` | Construcción fallida y `handle_url_build_error()` no devuelve una cadena. |

---

#### `make_response()`

```
make_response(rv: ft.ResponseReturnValue) -> Response
```

Normaliza el valor de retorno de una vista a una instancia de `response_class`. Desempaqueta tuplas de 3 (`body, status, headers`) o de 2 (discriminando *status* vs *headers*); convierte `str`/`bytes`/`bytearray`/iteradores en cuerpo de respuesta; serializa `dict`/`list` a JSON; coacciona otras `BaseResponse` o callables WSGI vía `force_type`; aplica `status` y extiende `headers`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `rv` | `ft.ResponseReturnValue` | Sí | Valor devuelto por la vista (`str`, `bytes`, `dict`, `list`, generador/iterador, tupla, `Response`, callable WSGI). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Instancia de `response_class`. |

**Raises**

| Excepción | Condición |
|---|---|
| `TypeError` | Tupla con longitud distinta de 2 o 3. |
| `TypeError` | `rv` es `None` (la vista no retornó nada). |
| `TypeError` | Tipo de retorno no soportado, o fallo de `force_type` al coaccionar la respuesta. |

---

#### `preprocess_request()`

```
preprocess_request(ctx: AppContext) -> ft.ResponseReturnValue | None
```

Ejecuta los `url_value_preprocessors` y después los `before_request_funcs` de la app y de los blueprints implicados (en orden inverso). Si algún `before_request` devuelve un valor distinto de `None`, se interrumpe el procesamiento y ese valor se trata como retorno de la vista.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo de la petición. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `ft.ResponseReturnValue \| None` | Valor de respuesta anticipada, o `None` para continuar el despacho. |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` | Propagada desde un preprocesador o un `before_request`. |

---

#### `process_response()`

```
process_response(ctx: AppContext, response: Response) -> Response
```

Aplica los callbacks `after_request` (primero los registrados en el contexto `ctx._after_request_functions`, luego los de blueprints y app en orden inverso de registro) y guarda la sesión mediante `session_interface.save_session()` si no es una sesión nula.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `response` | `Response` | Sí | Respuesta a post-procesar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta modificada (debe ser instancia de `response_class`). |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` | Propagada desde un `after_request` o desde `save_session()`. |

---

#### `do_teardown_request()`

```
do_teardown_request(ctx: AppContext, exc: BaseException | None = None) -> None
```

Ejecuta todos los `teardown_request` (app y blueprints, en orden inverso) y emite la señal `request_tearing_down`. Los errores se acumulan mediante `_CollectErrors` para que **todos** los callbacks se ejecuten, y se relanzan agrupados al final.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto que está siendo descartado. |
| `exc` | `BaseException \| None` | No | Excepción no manejada durante el despacho; se pasa a cada callback. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | — |

**Raises**

| Excepción | Condición |
|---|---|
| `BaseException` / grupo de excepciones | `collect_errors.raise_any("Errors during request teardown")` con errores acumulados. |

---

#### `do_teardown_appcontext()`

```
do_teardown_appcontext(ctx: AppContext, exc: BaseException | None = None) -> None
```

Ejecuta los `teardown_appcontext` (en orden inverso) y emite `appcontext_tearing_down`, acumulando errores con `_CollectErrors`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto de aplicación que se está descartando. |
| `exc` | `BaseException \| None` | No | Excepción no manejada mientras el contexto estaba activo. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | — |

**Raises**

| Excepción | Condición |
|---|---|
| `BaseException` / grupo de excepciones | `collect_errors.raise_any("Errors during app teardown")`. |

---

#### `app_context()`

```
app_context() -> AppContext
```

Crea un `AppContext` sin información de petición. Al hacer *push*, `current_app` y `g` quedan disponibles.

**Parámetros:** ninguno.

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto usable como bloque `with`. |

**Raises**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones propias. |

---

#### `request_context()`

```
request_context(environ: WSGIEnvironment) -> AppContext
```

Crea un `AppContext` con información de petición a partir de un entorno WSGI (`AppContext.from_environ`). No destinado a uso directo en código de aplicación (preferir `test_request_context()`).

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI válido. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto con `request` y `session` disponibles tras el *push*. |

**Raises**

| Excepción | Condición |
|---|---|
| `KeyError` / `ValueError` | Entorno WSGI incompleto o inválido. |

---

#### `test_request_context()`

```
test_request_context(*args: t.Any, **kwargs: t.Any) -> AppContext
```

Construye un entorno WSGI mediante `flask.testing.EnvironBuilder` (cerrándolo siempre en `finally`) y devuelve el contexto de petición correspondiente. Acepta los mismos argumentos que `werkzeug.test.EnvironBuilder`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `path` | `str` | No | Ruta URL solicitada. |
| `base_url` | `str` | No | URL base; derivada de `PREFERRED_URL_SCHEME`, `subdomain`, `SERVER_NAME` y `APPLICATION_ROOT` si se omite. |
| `subdomain` | `str` | No | Subdominio a prefijar a `SERVER_NAME`. |
| `url_scheme` | `str` | No | Esquema alternativo a `PREFERRED_URL_SCHEME`. |
| `data` | `str \| bytes \| dict` | No | Cuerpo de la petición o datos de formulario. |
| `json` | `t.Any` | No | Objeto serializado como JSON; fija `content_type` a `application/json`. |
| `*args` | `t.Any` | No | Otros posicionales para `EnvironBuilder`. |
| `**kwargs` | `t.Any` | No | Otros por nombre para `EnvironBuilder`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto de petición de prueba, usable como `with`. |

**Raises**

| Excepción | Condición |
|---|---|
| `TypeError` / `ValueError` | Argumentos inválidos para `EnvironBuilder`. |

---

#### `wsgi_app()`

```
wsgi_app(environ: WSGIEnvironment, start_response: StartResponse) -> cabc.Iterable[bytes]
```

Implementación real de la aplicación WSGI, separada de `__call__` para permitir envolver middlewares sin perder la referencia al objeto app. Crea y hace *push* del contexto de petición, despacha con `full_dispatch_request()`, convierte excepciones con `handle_exception()`, preserva el contexto para el depurador de Werkzeug si procede, aplica `should_ignore_error` y hace *pop* del contexto en `finally`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI de la petición. |
| `start_response` | `StartResponse` | Sí | Callable WSGI para iniciar la respuesta. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `cabc.Iterable[bytes]` | Iterable del cuerpo de la respuesta. |

**Raises**

| Excepción | Condición |
|---|---|
| `BaseException` | Las excepciones que no derivan de `Exception` (p. ej. `SystemExit`, `KeyboardInterrupt`) se relanzan. |
| `Exception` | Relanzada por `handle_exception()` cuando `PROPAGATE_EXCEPTIONS` está activo. |
| `BaseException` / grupo | Desde los *teardown* ejecutados en `ctx.pop(error)`. |

---

#### `__call__()`

```
__call__(environ: WSGIEnvironment, start_response: StartResponse) -> cabc.Iterable[bytes]
```

Hace que la instancia de `Flask` sea invocable como aplicación WSGI. Delega directamente en `wsgi_app()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callable WSGI de inicio de respuesta. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `cabc.Iterable[bytes]` | Iterable del cuerpo de la respuesta. |

**Raises**

| Excepción | Condición |
|---|---|
| Igual que `wsgi_app()` | Toda excepción se propaga tal cual. |

---

## 3. Ejemplo de uso

```python
"""Caso de uso real: aplicación con subclase personalizada de Flask,
manejo de errores, hooks de ciclo de vida y pruebas."""

from __future__ import annotations

import typing as t
from datetime import timedelta

from flask import Flask, jsonify, render_template_string
from flask.ctx import AppContext
from werkzeug.exceptions import HTTPException


class AuditedFlask(Flask):
    """Subclase que usa la firma NUEVA (con `ctx: AppContext`).

    Al declararse con `ctx` como primer parámetro, `__init_subclass__()`
    NO emite DeprecationWarning ni aplica `remove_ctx()` / `add_ctx()`.
    """

    def preprocess_request(self, ctx: AppContext) -> t.Any:
        ctx.g.audit_path = ctx.request.path
        return super().preprocess_request(ctx)

    def log_exception(self, ctx: AppContext, exc_info) -> None:
        self.logger.error("AUDIT fallo en %s", ctx.request.full_path, exc_info=exc_info)
        super().log_exception(ctx, exc_info)


app = AuditedFlask(__name__, static_folder="static", template_folder="templates")
app.config.update(
    SECRET_KEY="dev-only-key",
    PERMANENT_SESSION_LIFETIME=timedelta(days=7),
    SERVER_NAME="localhost:5000",
    SEND_FILE_MAX_AGE_DEFAULT=3600,
)


# --- Vistas -----------------------------------------------------------------
@app.route("/")
def index() -> str:
    # `make_response()` convierte el str en Response con cuerpo UTF-8.
    return render_template_string("Hola desde {{ config['SERVER_NAME'] }}")


@app.route("/api/users/<int:user_id>")
def get_user(user_id: int):
    # Una tupla (body, status) es desempaquetada por `make_response()`.
    return jsonify(id=user_id, name="Ada"), 200


@app.route("/async-demo")
async def async_demo() -> dict[str, bool]:
    # `ensure_sync()` -> `async_to_sync()` (requiere flask[async]).
    return {"async": True}


# --- Ciclo de vida ----------------------------------------------------------
@app.after_request
def add_header(response):
    response.headers["X-App"] = app.name
    return response


@app.teardown_request
def close_resources(exc: BaseException | None) -> None:
    # Ejecutado por `do_teardown_request()`; los errores se acumulan.
    if exc is not None:
        app.logger.warning("Petición terminó con error: %r", exc)


@app.errorhandler(HTTPException)
def handle_http(e: HTTPException):
    # Invocado desde `handle_http_exception()`.
    return jsonify(error=e.name, code=e.code), e.code or 500


@app.shell_context_processor
def shell_ctx() -> dict[str, t.Any]:
    # Consumido por `make_shell_context()`.
    return {"timedelta": timedelta}


# --- Uso de la API documentada ---------------------------------------------
def main() -> None:
    # 1) URLs fuera de petición: requiere SERVER_NAME (ver `url_for()`).
    with app.app_context():
        print(app.url_for("get_user", user_id=7, _anchor="perfil"))
        print(app.get_send_file_max_age("logo.png"))  # -> 3600

    # 2) Contexto de petición simulado (`test_request_context()`).
    with app.test_request_context("/?debug=1", method="GET"):
        from flask import request
        assert request.args["debug"] == "1"

    # 3) Lectura de recursos (`open_resource()` / `open_instance_resource()`).
    try:
        with app.open_resource("schema.sql", mode="r", encoding="utf-8") as fh:
            schema = fh.read()
    except FileNotFoundError:
        schema = ""

    # 4) Cliente de pruebas (`test_client()`).
    app.testing = True
    with app.test_client() as client:
        rv = client.get("/api/users/42")
        assert rv.status_code == 200 and rv.json["id"] == 42
        assert client.get("/no-existe").status_code == 404

    # 5) Runner CLI (`test_cli_runner()`).
    runner = app.test_cli_runner()
    result = runner.invoke(args=["routes"])
    print(result.output)

    # 6) Middleware WSGI sobre `wsgi_app` (la app sigue siendo invocable
    #    vía `__call__()` -> `wsgi_app()`).
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)

    # 7) Servidor de desarrollo (`run()`), nunca en producción.
    app.run(host="127.0.0.1", port=5000, debug=True, use_reloader=False)


if __name__ == "__main__":
    main()
```