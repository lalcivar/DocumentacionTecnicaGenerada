# Documentación Técnica — Módulo `flask/app.py` (clase `Flask`)

---

## 1. Resumen ejecutivo

Este módulo define la clase `Flask`, la implementación síncrona (WSGI) del objeto central de la aplicación Flask, que hereda de `App` (capa "sansio"). Concentra el ciclo de vida completo de una petición: creación de contextos (`AppContext`), construcción del adaptador de URLs, despacho de rutas, conversión de valores de retorno a objetos `Response`, manejo de excepciones HTTP/usuario, procesamiento posterior y teardown de contextos.

Adicionalmente provee utilidades de infraestructura: servidor de desarrollo (`run()`), clientes de prueba (`test_client()`, `test_cli_runner()`), acceso a recursos del paquete e instancia, entorno Jinja y generación de URLs (`url_for()`). El módulo incorpora dos decoradores internos (`remove_ctx()` y `add_ctx()`) que, junto con `__init_subclass__()`, implementan una capa de compatibilidad retroactiva para subclases que aún usan las firmas de métodos previas a la introducción del parámetro `ctx: AppContext`.

---

## 2. Especificación de funciones y métodos

### 2.1. Símbolos de tipado a nivel de módulo

| Símbolo | Tipo | Vinculación (`bound`) | Propósito |
|---|---|---|---|
| `T_shell_context_processor` | `TypeVar` | `ft.ShellContextProcessorCallable` | Preservar tipos en decoradores de contexto de shell. |
| `T_teardown` | `TypeVar` | `ft.TeardownCallable` | Preservar tipos en decoradores de teardown. |
| `T_template_filter` | `TypeVar` | `ft.TemplateFilterCallable` | Preservar tipos en filtros de plantilla. |
| `T_template_global` | `TypeVar` | `ft.TemplateGlobalCallable` | Preservar tipos en globales de plantilla. |
| `T_template_test` | `TypeVar` | `ft.TemplateTestCallable` | Preservar tipos en tests de plantilla. |
| `F` | `TypeVar` | `t.Callable[..., t.Any]` | Tipo genérico de función usado por `remove_ctx()` y `add_ctx()`. |

---

### 2.2. Funciones a nivel de módulo

#### `_make_timedelta()`

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None
```

Normaliza un valor de configuración temporal a un objeto `timedelta`. Función auxiliar privada: si el valor ya es un `timedelta` o es `None` se devuelve sin cambios; si es un entero se interpreta como segundos.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `value` | `timedelta \| int \| None` | Sí | Valor a normalizar. Un `int` se interpreta como segundos. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `timedelta \| None` | `None` si la entrada fue `None`; en caso contrario, el `timedelta` equivalente. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `TypeError` | Propagada desde `timedelta(seconds=value)` si `value` no es `None`, `timedelta` ni un valor numérico aceptado. |

---

#### `remove_ctx()`

```python
def remove_ctx(f: F) -> F
```

Decorador de compatibilidad. Envuelve un método sobrescrito por el usuario que **aún usa la firma antigua** (sin `ctx`), de modo que si el llamador le pasa un `AppContext` como primer argumento posicional, éste se descarte antes de invocar al método original. Los metadatos se copian con `update_wrapper`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método con firma legacy a envolver. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `F` | Función envolvente (`wrapper`) con los metadatos de `f`. |

**Excepciones**: ninguna propia; propaga lo que lance `f`.

##### Función anidada `wrapper()` (dentro de `remove_ctx()`)

```python
def wrapper(self: Flask, *args: t.Any, **kwargs: t.Any) -> t.Any
```

Elimina `args[0]` cuando es una instancia de `AppContext` y delega en `f(self, *args, **kwargs)`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación (método vinculado manualmente). |
| `*args` | `t.Any` | No | Argumentos posicionales; el primero se descarta si es `AppContext`. |
| `**kwargs` | `t.Any` | No | Argumentos por palabra clave reenviados sin cambios. |

| Retorno | Descripción |
|---|---|
| `t.Any` | Valor devuelto por `f`. |

---

#### `add_ctx()`

```python
def add_ctx(f: F) -> F
```

Decorador de compatibilidad complementario a `remove_ctx()`. Envuelve el método **base** de `Flask` (firma nueva, con `ctx`) para que pueda ser invocado mediante `super().metodo(...)` desde una subclase legacy que no envía el contexto: en ese caso inyecta el `AppContext` activo como primer argumento.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método base de `Flask` con firma `(self, ctx, ...)`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `F` | Función envolvente (`wrapper`) con los metadatos de `f`. |

##### Función anidada `wrapper()` (dentro de `add_ctx()`)

```python
def wrapper(self: Flask, *args: t.Any, **kwargs: t.Any) -> t.Any
```

Si no hay argumentos posicionales, o el primero no es un `AppContext`, obtiene el contexto activo mediante `app_ctx._get_current_object()` y lo coloca como primer argumento.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `t.Any` | No | Argumentos posicionales; se prefija el contexto activo si falta. |
| `**kwargs` | `t.Any` | No | Argumentos por palabra clave reenviados sin cambios. |

| Retorno | Descripción |
|---|---|
| `t.Any` | Valor devuelto por `f`. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `RuntimeError` | Propagada por `app_ctx._get_current_object()` cuando no hay contexto de aplicación activo. |

---

### 2.3. Clase `Flask(App)`

Implementa una aplicación WSGI y actúa como registro central de vistas, reglas de URL, configuración de plantillas, CLI y manejadores de error.

#### Atributos de clase

| Atributo | Tipo | Valor por defecto | Descripción |
|---|---|---|---|
| `default_config` | `ImmutableDict` | Diccionario con 28 claves (`DEBUG`, `SECRET_KEY`, `PERMANENT_SESSION_LIFETIME`, `MAX_CONTENT_LENGTH`, `SESSION_COOKIE_*`, `TRUSTED_HOSTS`, `PROVIDE_AUTOMATIC_OPTIONS`, etc.) | Configuración base inmutable copiada a `app.config`. |
| `request_class` | `type[Request]` | `Request` | Clase usada para objetos de petición. |
| `response_class` | `type[Response]` | `Response` | Clase usada para objetos de respuesta. |
| `session_interface` | `SessionInterface` | `SecureCookieSessionInterface()` | Interfaz de sesión empleada por la aplicación. |

---

#### `__init_subclass__()`

```python
def __init_subclass__(cls, **kwargs: t.Any) -> None
```

Hook de creación de subclases que implementa la detección de firmas obsoletas. Recorre el conjunto de métodos del ciclo de petición (`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`) y, para cada uno sobrescrito en la subclase, inspecciona su segundo parámetro con `inspect.signature`.

Se considera firma válida (nueva) cuando el segundo parámetro:
- no tiene anotación y se llama `ctx`, o
- tiene anotación en forma de cadena cuyo último segmento tras `.` es `AppContext`, o
- tiene anotación de clase que es subclase de `AppContext`.

En caso contrario emite un `DeprecationWarning` y aplica el parcheo doble: el método de la subclase se envuelve con `remove_ctx()` y el método base de `Flask` con `add_ctx()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `cls` | `type` | Sí (implícito) | Subclase recién definida. |
| `**kwargs` | `t.Any` | No | Argumentos de clase adicionales, reenviados por el protocolo de subclases. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Opera por efecto lateral (`setattr` sobre `cls` y sobre `Flask`). |

**Advertencias emitidas**

| Categoría | Condición |
|---|---|
| `DeprecationWarning` | Un método sobrescrito no acepta `ctx: AppContext` como primer parámetro tras `self`. |

---

#### `__init__()`

```python
def __init__(
    self,
    import_name: str,
    static_url_path: str | None = None,
    static_folder: str | os.PathLike[str] | None = "static",
    static_host: str | None = None,
    host_matching: bool = False,
    subdomain_matching: bool = False,
    template_folder: str | os.PathLike[str] | None = "templates",
    instance_path: str | None = None,
    instance_relative_config: bool = False,
    root_path: str | None = None,
)
```

Inicializa la aplicación delegando en `App.__init__`, crea el grupo de comandos Click (`self.cli = cli.AppGroup()`), le asigna el nombre de la app y, si existe carpeta estática configurada, registra la regla de URL `"<static_url_path>/<path:filename>"` con endpoint `"static"`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `import_name` | `str` | Sí | Nombre del paquete/módulo de la aplicación; base para resolver recursos. |
| `static_url_path` | `str \| None` | No | Ruta web para archivos estáticos. Por defecto, el nombre de `static_folder`. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta de archivos estáticos (relativa a `root_path` o absoluta). Defecto `"static"`. |
| `static_host` | `str \| None` | No | Host para la ruta estática. Obligatorio si `host_matching=True` con `static_folder`. |
| `host_matching` | `bool` | No | Activa `url_map.host_matching`. Defecto `False`. |
| `subdomain_matching` | `bool` | No | Considera el subdominio relativo a `SERVER_NAME` al enrutar. Defecto `False`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta de plantillas. Defecto `"templates"`. |
| `instance_path` | `str \| None` | No | Ruta alternativa de la carpeta de instancia. |
| `instance_relative_config` | `bool` | No | Si `True`, las rutas relativas de configuración se resuelven contra `instance_path`. |
| `root_path` | `str \| None` | No | Raíz de los archivos de la aplicación; sólo se fija manualmente si no puede autodetectarse. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `AssertionError` | `bool(static_host) != host_matching` cuando existe carpeta estática ("Invalid static_host/host_matching combination"). |

**Callback anónimo (lambda) de la ruta estática**

```python
view_func=lambda **kw: self_ref().send_static_file(**kw)
```

Función de vista registrada para el endpoint `"static"`. Utiliza `self_ref = weakref.ref(self)` para evitar un ciclo de referencias entre la app y la vista; al invocarse desreferencia el weakref y delega en `send_static_file()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kw` | `t.Any` | No | Variables de ruta capturadas por la regla (en la práctica, `filename`). |

| Retorno | Descripción |
|---|---|
| `Response` | Respuesta producida por `send_static_file()`. |

---

#### `get_send_file_max_age()`

```python
def get_send_file_max_age(self, filename: str | None) -> int | None
```

Determina el valor de caché `max_age` (en segundos) que usará `send_file()` cuando no se especifique explícitamente. Lee `SEND_FILE_MAX_AGE_DEFAULT` de la configuración; si es `timedelta` lo convierte a segundos enteros.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str \| None` | Sí | Ruta del archivo a servir. Puede ser `None`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `int \| None` | Segundos de caché, o `None` para que el navegador use peticiones condicionales. |

---

#### `send_static_file()`

```python
def send_static_file(self, filename: str) -> Response
```

Función de vista que sirve archivos desde `static_folder` mediante `send_from_directory()`, aplicando el `max_age` calculado por `get_send_file_max_age()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str` | Sí | Ruta del archivo relativa a `static_folder`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta con el archivo solicitado. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `RuntimeError` | `static_folder` no está configurado. |
| `NotFound` (`werkzeug.exceptions`) | Propagada por `send_from_directory()` si el archivo no existe. |

---

#### `open_resource()`

```python
def open_resource(self, resource: str, mode: str = "rb", encoding: str | None = None) -> t.IO[t.AnyStr]
```

Abre, **sólo para lectura**, un archivo relativo a `root_path`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta del recurso relativa a `root_path`. |
| `mode` | `str` | No | Modo de apertura; sólo `"r"`, `"rt"` o `"rb"`. Defecto `"rb"`. |
| `encoding` | `str \| None` | No | Codificación en modo texto; ignorada en modo binario. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.IO[t.AnyStr]` | Manejador de archivo abierto. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `ValueError` | `mode` no pertenece a `{"r", "rt", "rb"}`. |
| `OSError` / `FileNotFoundError` | Propagada por `open()` si la ruta no es accesible. |

---

#### `open_instance_resource()`

```python
def open_instance_resource(self, resource: str, mode: str = "rb", encoding: str | None = "utf-8") -> t.IO[t.AnyStr]
```

Abre un archivo relativo a `instance_path`. A diferencia de `open_resource()`, admite modos de escritura.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta del recurso relativa a `instance_path`. |
| `mode` | `str` | No | Cualquier modo válido de `open()`. Defecto `"rb"`. |
| `encoding` | `str \| None` | No | Codificación en modo texto (ignorada si `"b"` está en `mode`). Defecto `"utf-8"`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.IO[t.AnyStr]` | Manejador de archivo abierto. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `OSError` / `FileNotFoundError` | Propagada por `open()`. |

---

#### `create_jinja_environment()`

```python
def create_jinja_environment(self) -> Environment
```

Construye el entorno Jinja a partir de `jinja_options`, estableciendo `autoescape` (`select_jinja_autoescape`) y `auto_reload` (según `TEMPLATES_AUTO_RELOAD` o `debug`). Registra los globales `url_for`, `get_flashed_messages`, `config`, `request`, `session` y `g`, y fija la política `json.dumps_function`.

**Parámetros**: ninguno (además de `self`).

**Retorno**

| Tipo | Descripción |
|---|---|
| `Environment` | Entorno Jinja configurado para la aplicación. |

---

#### `create_url_adapter()`

```python
def create_url_adapter(self, request: Request | None) -> MapAdapter | None
```

Crea el adaptador de URLs. Con petición, aplica `TRUSTED_HOSTS`, recalcula `request.host` con `get_host()` y vincula el mapa al entorno WSGI (anulando `server_name` cuando hay `host_matching`, o forzando el subdominio por defecto cuando `subdomain_matching` está desactivado). Sin petición, vincula usando `SERVER_NAME`, `APPLICATION_ROOT` y `PREFERRED_URL_SCHEME`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request \| None` | Sí | Petición para la que se crea el adaptador, o `None` para contexto de aplicación. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `MapAdapter \| None` | Adaptador vinculado, o `None` si no hay petición ni `SERVER_NAME` configurado. |

---

#### `raise_routing_exception()`

```python
def raise_routing_exception(self, request: Request) -> t.NoReturn
```

Relanza la excepción de enrutamiento almacenada en la petición. En modo depuración, si se trata de un redireccionamiento que descartaría el cuerpo (código distinto de 307/308 y método no seguro), la sustituye por `FormDataRoutingRedirect`. Marcado como `:meta private:` / `:internal:`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request` | Sí | Petición cuyo `routing_exception` se relanza. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.NoReturn` | Nunca retorna: siempre lanza. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `request.routing_exception` (`RoutingException`/`HTTPException`) | Caso general (producción, redirecciones 307/308, métodos `GET`/`HEAD`/`OPTIONS`). |
| `FormDataRoutingRedirect` | Modo depuración con `RequestRedirect` que descartaría datos de formulario. |

---

#### `update_template_context()`

```python
def update_template_context(self, ctx: AppContext, context: dict[str, t.Any]) -> None
```

Inyecta en el contexto de plantilla las variables aportadas por los `template_context_processors` de la aplicación y de los blueprints implicados (en orden inverso). Los valores originales (`orig_ctx`) se reaplican al final para que tengan prioridad sobre los procesadores.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo; si tiene petición, se añaden los blueprints de la misma. |
| `context` | `dict[str, t.Any]` | Sí | Diccionario de contexto modificado **in place**. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Modifica `context` por efecto lateral. |

---

#### `make_shell_context()`

```python
def make_shell_context(self) -> dict[str, t.Any]
```

Construye el espacio de nombres del shell interactivo, partiendo de `{"app": self, "g": g}` y ejecutando todos los `shell_context_processors` registrados.

**Retorno**

| Tipo | Descripción |
|---|---|
| `dict[str, t.Any]` | Diccionario de variables disponibles en el shell. |

---

#### `run()`

```python
def run(
    self,
    host: str | None = None,
    port: int | None = None,
    debug: bool | None = None,
    load_dotenv: bool = True,
    **options: t.Any,
) -> None
```

Arranca el servidor de desarrollo de Werkzeug (`run_simple`). No apto para producción. Si la variable de entorno `FLASK_RUN_FROM_CLI` es `"true"`, la llamada se ignora (mostrando un aviso con `click.secho` si no se está ejecutando desde el recargador). Carga archivos `.env`/`.flaskenv` cuando corresponde, resuelve host/puerto desde `SERVER_NAME` y fija por defecto `use_reloader`, `use_debugger` y `threaded`. En el bloque `finally` restablece `self._got_first_request = False`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `host` | `str \| None` | No | Host de escucha. Defecto: host de `SERVER_NAME` o `"127.0.0.1"`. |
| `port` | `int \| None` | No | Puerto. Defecto: puerto de `SERVER_NAME` o `5000`. |
| `debug` | `bool \| None` | No | Activa/desactiva el modo depuración; tiene prioridad sobre otras fuentes. |
| `load_dotenv` | `bool` | No | Carga `.env` y `.flaskenv`. Defecto `True`. |
| `**options` | `t.Any` | No | Opciones reenviadas a `werkzeug.serving.run_simple`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Bloquea hasta que el servidor finaliza, o retorna de inmediato si la llamada se ignora. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `OSError` | Propagada por `run_simple` (p. ej. puerto ocupado). |
| `ValueError` | Propagada por `int(port)` si `port` no es convertible. |

---

#### `test_client()`

```python
def test_client(self, use_cookies: bool = True, **kwargs: t.Any) -> FlaskClient
```

Crea un cliente de pruebas, usando `test_client_class` si está definido o `flask.testing.FlaskClient` en caso contrario. Soporta uso como gestor de contexto (`with`) para diferir el cierre del contexto.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `use_cookies` | `bool` | No | Mantiene cookies entre peticiones. Defecto `True`. |
| `**kwargs` | `t.Any` | No | Argumentos adicionales para el constructor de `test_client_class`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `FlaskClient` | Cliente de pruebas enlazado a la app y a `response_class`. |

---

#### `test_cli_runner()`

```python
def test_cli_runner(self, **kwargs: t.Any) -> FlaskCliRunner
```

Crea un runner para probar comandos CLI, usando `test_cli_runner_class` o `flask.testing.FlaskCliRunner`. La app se pasa como primer argumento.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kwargs` | `t.Any` | No | Argumentos adicionales para el constructor del runner. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `FlaskCliRunner` | Runner CLI de pruebas. |

---

#### `handle_http_exception()`

```python
def handle_http_exception(self, ctx: AppContext, e: HTTPException) -> HTTPException | ft.ResponseReturnValue
```

Gestiona excepciones HTTP. Devuelve la excepción sin modificar si `e.code is None` (excepciones proxy) o si es una `RoutingException`. En otro caso busca un manejador con `_find_error_handler()` según los blueprints de la petición y lo ejecuta mediante `ensure_sync()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (aporta `ctx.request.blueprints`). |
| `e` | `HTTPException` | Sí | Excepción HTTP a manejar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `HTTPException \| ft.ResponseReturnValue` | La propia excepción (si no hay manejador) o el valor retornado por el manejador. |

---

#### `handle_user_exception()`

```python
def handle_user_exception(self, ctx: AppContext, e: Exception) -> HTTPException | ft.ResponseReturnValue
```

Punto de entrada para excepciones producidas durante el despacho. Activa `show_exception` en `BadRequestKeyError` cuando `debug` o `TRAP_BAD_REQUEST_ERRORS` están activos; delega en `handle_http_exception()` para `HTTPException` no "atrapadas"; en otro caso busca un manejador registrado y, si no existe, relanza la excepción activa con `raise` desnudo.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción a manejar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `HTTPException \| ft.ResponseReturnValue` | Valor de respuesta generado por el manejador o la excepción HTTP resultante. |

**Excepciones**

| Excepción | Condición |
|---|---|
| Excepción original (re-lanzada con `raise`) | No existe manejador de error aplicable. |
| `RuntimeError` | `raise` desnudo invocado sin excepción activa en el contexto. |

---

#### `handle_exception()`

```python
def handle_exception(self, ctx: AppContext, e: Exception) -> Response
```

Maneja excepciones no cubiertas por manejadores (o lanzadas desde ellos), produciendo siempre un 500. Emite la señal `got_request_exception`; si `PROPAGATE_EXCEPTIONS` (o, por defecto, `testing`/`debug`) está activo, re-lanza. En caso contrario registra el error con `log_exception()`, construye `InternalServerError(original_exception=e)`, aplica el manejador de 500 si existe y finaliza con `finalize_request(..., from_error_handler=True)`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción no manejada. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta 500 finalizada (o la generada por el manejador registrado). |

**Excepciones**

| Excepción | Condición |
|---|---|
| Excepción activa (`raise`) | `PROPAGATE_EXCEPTIONS` efectivo y `sys.exc_info()[1] is e`. |
| `e` | `PROPAGATE_EXCEPTIONS` efectivo sin excepción activa coincidente. |

---

#### `log_exception()`

```python
def log_exception(
    self,
    ctx: AppContext,
    exc_info: tuple[type, BaseException, TracebackType] | tuple[None, None, None],
) -> None
```

Registra la excepción como `error` en `self.logger`, incluyendo ruta y método de la petición.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo; aporta `ctx.request.path` y `ctx.request.method`. |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí | Triple de información de excepción al estilo `sys.exc_info()`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | — |

---

#### `dispatch_request()`

```python
def dispatch_request(self, ctx: AppContext) -> ft.ResponseReturnValue
```

Realiza el despacho: si hay `routing_exception` llama a `raise_routing_exception()`; si la regla declara `provide_automatic_options` y el método es `OPTIONS`, devuelve `make_default_options_response()`; en otro caso invoca la función de vista asociada al endpoint con `**view_args`, envuelta por `ensure_sync()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con la petición ya enlazada. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `ft.ResponseReturnValue` | Valor crudo devuelto por la vista (no necesariamente un `Response`). |

**Excepciones**

| Excepción | Condición |
|---|---|
| `HTTPException` / `RoutingException` / `FormDataRoutingRedirect` | Propagadas desde `raise_routing_exception()`. |
| Cualquier excepción de la vista | Propagada al llamador (`full_dispatch_request()`). |

---

#### `full_dispatch_request()`

```python
def full_dispatch_request(self, ctx: AppContext) -> Response
```

Orquesta el ciclo completo: advierte si `should_ignore_error` está definido (obsoleto), marca `_got_first_request`, emite `request_started`, ejecuta `preprocess_request()` y, si no cortocircuita, `dispatch_request()`. Captura `Exception` delegando en `handle_user_exception()` y siempre finaliza con `finalize_request()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo de la petición. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta final ya postprocesada. |

**Advertencias / Excepciones**

| Tipo | Condición |
|---|---|
| `DeprecationWarning` | `should_ignore_error` definido en la primera petición. |
| Excepciones no gestionadas | Re-lanzadas por `handle_user_exception()` o `finalize_request()`. |

---

#### `finalize_request()`

```python
def finalize_request(
    self,
    ctx: AppContext,
    rv: ft.ResponseReturnValue | HTTPException,
    from_error_handler: bool = False,
) -> Response
```

Convierte el valor de retorno en `Response` con `make_response()`, aplica `process_response()` y emite `request_finished`. En modo seguro (`from_error_handler=True`) los fallos de postprocesado se registran con `logger.exception` y se ignoran. Marcado `:internal:`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `rv` | `ft.ResponseReturnValue \| HTTPException` | Sí | Valor devuelto por la vista o manejador de error. |
| `from_error_handler` | `bool` | No | Activa el modo tolerante a fallos. Defecto `False`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta finalizada. |

**Excepciones**

| Excepción | Condición |
|---|---|
| Cualquier `Exception` del postprocesado | Se re-lanza si `from_error_handler` es `False`. |
| `TypeError` | Propagada por `make_response()` ante valores de retorno inválidos. |

---

#### `make_default_options_response()`

```python
def make_default_options_response(self, ctx: AppContext) -> Response
```

Construye la respuesta automática a `OPTIONS` consultando `ctx.url_adapter.allowed_methods()` y poblando la cabecera `Allow`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con `url_adapter` disponible. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Instancia de `response_class` con `Allow` establecido. |

---

#### `ensure_sync()`

```python
def ensure_sync(self, func: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]
```

Garantiza que el callable sea ejecutable de forma síncrona por un worker WSGI: las funciones `async def` (detectadas con `iscoroutinefunction`) se envuelven con `async_to_sync()`; las demás se devuelven intactas.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `t.Callable[..., t.Any]` | Sí | Vista, manejador o callback a normalizar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.Callable[..., t.Any]` | Callable síncrono equivalente. |

---

#### `async_to_sync()`

```python
def async_to_sync(self, func: t.Callable[..., t.Coroutine[t.Any, t.Any, t.Any]]) -> t.Callable[..., t.Any]
```

Convierte una función corrutina en una función síncrona utilizando `asgiref.sync.async_to_sync`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `t.Callable[..., t.Coroutine[t.Any, t.Any, t.Any]]` | Sí | Función `async def` a envolver. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.Callable[..., t.Any]` | Wrapper síncrono que ejecuta y espera la corrutina. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `RuntimeError` | `asgiref` no está instalado (requiere el extra `flask[async]`). |

---

#### `url_for()`

```python
def url_for(
    self,
    /,
    endpoint: str,
    *,
    _anchor: str | None = None,
    _method: str | None = None,
    _scheme: str | None = None,
    _external: bool | None = None,
    **values: t.Any,
) -> str
```

Genera la URL de un endpoint. Si hay contexto de petición activo, resuelve endpoints relativos (`.endpoint`) contra el blueprint actual y genera URLs internas salvo que se indique `_scheme`; fuera de petición genera URLs externas por defecto usando el adaptador del contexto de app o uno creado con `create_url_adapter(None)`. Aplica `inject_url_defaults()`, construye con `url_adapter.build()` y añade el ancla citada con `urllib.parse.quote`. Los fallos de construcción se derivan a `handle_url_build_error()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `endpoint` | `str` | Sí | Nombre del endpoint; si empieza por `.` se resuelve relativo al blueprint actual. |
| `_anchor` | `str \| None` | No | Fragmento `#anchor` a añadir. |
| `_method` | `str \| None` | No | Método HTTP para seleccionar la regla. |
| `_scheme` | `str \| None` | No | Esquema a usar en URLs externas. Requiere `_external` verdadero. |
| `_external` | `bool \| None` | No | Fuerza URL externa (`True`) o interna (`False`). Defecto según contexto. |
| `**values` | `t.Any` | No | Valores para las partes variables; las claves desconocidas pasan a query string. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `str` | URL generada (o el valor devuelto por `handle_url_build_error()`). |

**Excepciones**

| Excepción | Condición |
|---|---|
| `RuntimeError` | No hay adaptador de URL disponible (fuera de petición y sin `SERVER_NAME`). |
| `ValueError` | Se indicó `_scheme` con `_external` falso. |
| `BuildError` | Propagada desde `handle_url_build_error()` si éste no devuelve una cadena. |

---

#### `make_response()`

```python
def make_response(self, rv: ft.ResponseReturnValue) -> Response
```

Normaliza el valor de retorno de una vista a una instancia de `response_class`. Desempaqueta tuplas de 2 o 3 elementos (`(body, status, headers)`, `(body, status)`, `(body, headers)`), convierte `str`/`bytes`/`bytearray`/iteradores en respuestas (incluidas respuestas por streaming), `dict`/`list` en JSON vía `self.json.response()`, y coacciona otras `Response` o callables WSGI con `response_class.force_type()`. Finalmente aplica `status` (como `status` o `status_code`) y extiende cabeceras.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `rv` | `ft.ResponseReturnValue` | Sí | Valor de retorno de la vista. No puede ser `None`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Instancia de `response_class` lista para enviar. |

**Excepciones**

| Excepción | Condición |
|---|---|
| `TypeError` | Tupla con longitud distinta de 2 o 3. |
| `TypeError` | `rv` es `None` (la vista no retornó nada). |
| `TypeError` | `force_type()` falla, o el tipo de `rv` no es soportado. |

---

#### `preprocess_request()`

```python
def preprocess_request(self, ctx: AppContext) -> ft.ResponseReturnValue | None
```

Ejecuta los `url_value_preprocessors` y después los `before_request_funcs` de la app y de los blueprints implicados (en orden inverso de anidamiento). Si algún `before_request` devuelve un valor no `None`, se interrumpe el preprocesado y ese valor se trata como retorno de la vista.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo de la petición. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `ft.ResponseReturnValue \| None` | Valor de cortocircuito o `None` para continuar con el despacho. |

---

#### `process_response()`

```python
def process_response(self, ctx: AppContext, response: Response) -> Response
```

Aplica los callbacks `ctx._after_request_functions` y los `after_request_funcs` de blueprints y app (en orden inverso de registro), y persiste la sesión mediante `session_interface.save_session()` cuando no es una sesión nula.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `response` | `Response` | Sí | Respuesta a postprocesar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | La misma respuesta o una nueva instancia de `response_class`. |

---

#### `do_teardown_request()`

```python
def do_teardown_request(self, ctx: AppContext, exc: BaseException | None = None) -> None
```

Ejecuta todos los `teardown_request_funcs` (app y blueprints, en orden inverso) y emite `request_tearing_down`. Usa `_CollectErrors` como gestor de contexto para invocar **todos** los callbacks aunque alguno falle, y finalmente propaga los errores acumulados con `raise_any("Errors during request teardown")`. Invocado por `AppContext.pop`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto que se está desmontando. |
| `exc` | `BaseException \| None` | No | Excepción no manejada durante el despacho; se pasa a cada callback. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | — |

**Excepciones**

| Excepción | Condición |
|---|---|
| Error(es) agregados por `_CollectErrors.raise_any()` | Uno o más callbacks de teardown o receptores de la señal fallaron. |

---

#### `do_teardown_appcontext()`

```python
def do_teardown_appcontext(self, ctx: AppContext, exc: BaseException | None = None) -> None
```

Ejecuta todos los `teardown_appcontext_funcs` en orden inverso y emite `appcontext_tearing_down`, agregando errores con `_CollectErrors` y propagándolos con `raise_any("Errors during app teardown")`. Invocado por `AppContext.pop`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto de aplicación que se desmonta. |
| `exc` | `BaseException \| None` | No | Excepción no manejada mientras el contexto estuvo activo. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | — |

**Excepciones**

| Excepción | Condición |
|---|---|
| Error(es) agregados por `_CollectErrors.raise_any()` | Fallos en callbacks de teardown o receptores de la señal. |

---

#### `app_context()`

```python
def app_context(self) -> AppContext
```

Crea un `AppContext`. Al hacer `push`, `current_app` y `g` quedan disponibles. Pensado para uso como bloque `with` fuera del ciclo de petición (inicialización, tareas, pruebas).

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto de aplicación no empujado. |

---

#### `request_context()`

```python
def request_context(self, environ: WSGIEnvironment) -> AppContext
```

Crea un `AppContext` con información de petición a partir de un entorno WSGI, usando `AppContext.from_environ()`. No destinado a uso directo en código de usuario (preferir `test_request_context()`).

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI válido. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto con petición asociada. |

---

#### `test_request_context()`

```python
def test_request_context(self, *args: t.Any, **kwargs: t.Any) -> AppContext
```

Crea un contexto de petición sintético usando `flask.testing.EnvironBuilder`. Obtiene el entorno con `get_environ()`, cierra el builder en `finally` y delega en `request_context()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `*args` | `t.Any` | No | Argumentos posicionales para `EnvironBuilder` (p. ej. `path`). |
| `**kwargs` | `t.Any` | No | Argumentos por palabra clave: `base_url`, `subdomain`, `url_scheme`, `data`, `json`, etc. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto de petición listo para `push()` o uso con `with`. |

---

#### `wsgi_app()`

```python
def wsgi_app(self, environ: WSGIEnvironment, start_response: StartResponse) -> cabc.Iterable[bytes]
```

Implementación real de la aplicación WSGI, separada de `__call__()` para permitir envolverla con middlewares (`app.wsgi_app = MyMiddleware(app.wsgi_app)`). Crea y empuja el contexto, ejecuta `full_dispatch_request()`, deriva excepciones a `handle_exception()`, preserva el contexto para el depurador de Werkzeug si procede, aplica `should_ignore_error` y siempre ejecuta `ctx.pop(error)`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI de la petición. |
| `start_response` | `StartResponse` | Sí | Callable WSGI para iniciar la respuesta. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `cabc.Iterable[bytes]` | Iterable del cuerpo de la respuesta. |

**Excepciones**

| Excepción | Condición |
|---|---|
| Excepción re-lanzada por `handle_exception()` | `PROPAGATE_EXCEPTIONS` activo (depuración/testing). |
| `BaseException` (p. ej. `SystemExit`, `KeyboardInterrupt`) | Capturada por el `except:` desnudo únicamente para registrarla en `error` y re-lanzada. |

---

#### `__call__()`

```python
def __call__(self, environ: WSGIEnvironment, start_response: StartResponse) -> cabc.Iterable[bytes]
```

Hace que la instancia `Flask` sea directamente invocable como aplicación WSGI; delega íntegramente en `wsgi_app()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callable WSGI de inicio de respuesta. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `cabc.Iterable[bytes]` | Resultado de `wsgi_app(environ, start_response)`. |

---

## 3. Ejemplo de uso

```python
"""Caso de uso integral: creación de la app, rutas, manejo de errores,
contextos, pruebas y arranque del servidor de desarrollo."""

from __future__ import annotations

import typing as t
from datetime import timedelta

from werkzeug.exceptions import NotFound

from flask import Flask, g, request

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config.update(
    SECRET_KEY="dev-only",
    SERVER_NAME="localhost:5000",          # necesario para url_for() fuera de petición
    PERMANENT_SESSION_LIFETIME=timedelta(days=7),
)


# --- Rutas -------------------------------------------------------------------
@app.route("/")
def index() -> str:
    # make_response() convertirá este str en Response con cuerpo UTF-8.
    return "Hola"


@app.route("/api/items/<int:item_id>")
def get_item(item_id: int) -> tuple[dict[str, t.Any], int]:
    # Tupla (body, status): el dict se serializa como JSON.
    return {"id": item_id, "path": request.path}, 200


@app.route("/assets/<path:filename>")
def assets(filename: str):
    # Uso explícito de send_static_file() y get_send_file_max_age().
    app.logger.info("max_age=%s", app.get_send_file_max_age(filename))
    return app.send_static_file(filename)


# --- Ciclo de petición -------------------------------------------------------
@app.before_request
def load_user() -> None:
    g.user = request.headers.get("X-User", "anonymous")


@app.after_request
def add_header(response):
    response.headers["X-App"] = app.name
    return response


@app.teardown_appcontext
def close_resources(exc: BaseException | None) -> None:
    # Invocado por do_teardown_appcontext() al hacer pop del contexto.
    app.logger.debug("teardown appcontext, exc=%r", exc)


@app.errorhandler(NotFound)
def handle_404(e: NotFound):
    # Alcanzado vía handle_user_exception() -> handle_http_exception().
    return {"error": "not found"}, 404


# --- Shell y recursos --------------------------------------------------------
@app.shell_context_processor
def shell_ctx() -> dict[str, t.Any]:
    return {"NotFound": NotFound}


def bootstrap_schema() -> None:
    """Lee un recurso del paquete con open_resource() dentro de app_context()."""
    with app.app_context():
        with app.open_resource("schema.sql", mode="r", encoding="utf-8") as f:
            app.logger.info("schema cargado (%d bytes)", len(f.read()))

        # url_for() fuera de petición: URL externa gracias a SERVER_NAME.
        app.logger.info(app.url_for("get_item", item_id=7, _anchor="top"))

    # Contexto de aplicación disponible en el shell: app.make_shell_context()
    app.logger.info(sorted(app.make_shell_context()))


def run_checks() -> None:
    """Pruebas con test_client(), test_request_context() y test_cli_runner()."""
    app.testing = True

    with app.test_client() as client:
        assert client.get("/").data == b"Hola"
        assert client.get("/api/items/42").get_json()["id"] == 42
        assert client.get("/no-existe").status_code == 404

    # Contexto de petición sintético, sin despachar la petición completa.
    with app.test_request_context("/api/items/1?debug=1", method="GET"):
        assert request.args["debug"] == "1"
        assert app.url_for("index") == "/"

    runner = app.test_cli_runner()
    assert runner.invoke(args=["routes"]).exit_code == 0


# --- Middleware WSGI sobre wsgi_app() ---------------------------------------
class TimingMiddleware:
    def __init__(self, wsgi_app):
        self.wsgi_app = wsgi_app

    def __call__(self, environ, start_response):
        return self.wsgi_app(environ, start_response)


# Se envuelve wsgi_app(), no la app, para conservar la referencia al objeto.
app.wsgi_app = TimingMiddleware(app.wsgi_app)


if __name__ == "__main__":
    bootstrap_schema()
    run_checks()
    # run() queda ignorado si se ejecuta vía 'flask run' (FLASK_RUN_FROM_CLI).
    app.run(host="127.0.0.1", port=5000, debug=True, use_reloader=False)
```