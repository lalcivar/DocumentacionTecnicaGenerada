# Documentación Técnica — Módulo `flask/app.py`

---

## 1. Resumen ejecutivo

Este módulo define la clase `Flask`, la implementación concreta y *síncrona* (WSGI) del framework Flask, que hereda de la clase base agnóstica al transporte `App` (`flask.sansio.app.App`). Su responsabilidad es orquestar el ciclo de vida completo de una petición HTTP: creación del contexto de aplicación/petición, despacho a la vista, manejo de excepciones, post-procesamiento de la respuesta y teardown de contextos.

Adicionalmente, el módulo expone utilidades internas de compatibilidad (`remove_ctx()`, `add_ctx()`, `_make_timedelta()`) empleadas por el mecanismo de deprecación introducido en `Flask.__init_subclass__()`, el cual detecta subclases que sobrescriben métodos del ciclo de vida con la firma antigua (sin el parámetro `ctx: AppContext`) y las adapta automáticamente emitiendo un `DeprecationWarning`.

---

## 2. Especificación de funciones y métodos

### 2.0 Símbolos de módulo (TypeVars)

| Símbolo | Tipo | `bound` | Propósito |
|---|---|---|---|
| `T_shell_context_processor` | `TypeVar` | `ft.ShellContextProcessorCallable` | Tipado de decoradores de procesadores de contexto de shell. |
| `T_teardown` | `TypeVar` | `ft.TeardownCallable` | Tipado de decoradores de teardown. |
| `T_template_filter` | `TypeVar` | `ft.TemplateFilterCallable` | Tipado de filtros Jinja. |
| `T_template_global` | `TypeVar` | `ft.TemplateGlobalCallable` | Tipado de globales Jinja. |
| `T_template_test` | `TypeVar` | `ft.TemplateTestCallable` | Tipado de tests Jinja. |
| `F` | `TypeVar` | `Callable[..., Any]` | Tipo genérico de función usado por `remove_ctx()` / `add_ctx()`. |

---

### 2.1 Funciones a nivel de módulo

#### `_make_timedelta()`

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None
```

Normaliza un valor de configuración temporal a un objeto `timedelta`. Si el valor ya es un `timedelta` o es `None`, se devuelve sin alteración; si es un entero, se interpreta como segundos.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `value` | `timedelta \| int \| None` | Sí | Valor a normalizar. Un `int` se interpreta como segundos. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `timedelta \| None` | `None` si la entrada fue `None`; en caso contrario, el `timedelta` equivalente. |

**Raises**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones explícitas. |

---

#### `remove_ctx()`

```python
def remove_ctx(f: F) -> F
```

Decorador de compatibilidad retroactiva. Envuelve un método sobrescrito por el usuario que mantiene la **firma antigua** (sin `ctx`). Si el primer argumento posicional recibido es una instancia de `AppContext`, lo descarta antes de invocar la función original. Preserva los metadatos mediante `functools.update_wrapper`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método con firma legada a envolver. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `F` | Función `wrapper` con los metadatos de `f` copiados. |

**Raises**

| Excepción | Condición |
|---|---|
| — | Propaga cualquier excepción lanzada por `f`. |

##### Función anidada: `remove_ctx.wrapper()`

```python
def wrapper(self: Flask, *args: t.Any, **kwargs: t.Any) -> t.Any
```

Closure que realiza el filtrado del argumento `ctx`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación (método vinculado). |
| `*args` | `Any` | No | Argumentos posicionales. Si `args[0]` es un `AppContext`, se elimina. |
| `**kwargs` | `Any` | No | Argumentos por palabra clave, reenviados tal cual. |

**Retorno:** `Any` — el valor devuelto por `f(self, *args, **kwargs)`.

---

#### `add_ctx()`

```python
def add_ctx(f: F) -> F
```

Decorador inverso a `remove_ctx()`. Se aplica al método **base** de `Flask` para que, cuando una subclase con firma legada invoque `super().metodo_base(...)` sin `ctx`, se inyecte automáticamente el contexto de aplicación activo (`app_ctx._get_current_object()`) como primer argumento posicional.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método base de `Flask` que espera `ctx` como primer parámetro. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `F` | Función `wrapper` con los metadatos de `f` copiados. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | Indirectamente, si `app_ctx._get_current_object()` se evalúa sin contexto de aplicación activo. |

##### Función anidada: `add_ctx.wrapper()`

```python
def wrapper(self: Flask, *args: t.Any, **kwargs: t.Any) -> t.Any
```

Closure que inyecta el `AppContext` activo.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `Any` | No | Si está vacío o `args[0]` no es `AppContext`, se prepone el contexto actual. |
| `**kwargs` | `Any` | No | Argumentos por palabra clave, reenviados tal cual. |

**Retorno:** `Any` — el valor devuelto por `f(self, *args, **kwargs)`.

---

### 2.2 Clase `Flask`

Implementa la aplicación WSGI y actúa como registro central de vistas, reglas de URL, configuración de plantillas e interfaz de sesión.

#### Atributos de clase

| Atributo | Tipo | Valor por defecto | Descripción |
|---|---|---|---|
| `default_config` | `ImmutableDict` | *(ver código)* | Configuración base inmutable (`DEBUG`, `SECRET_KEY`, `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, etc.). |
| `request_class` | `type[Request]` | `Request` | Clase usada para objetos de petición. |
| `response_class` | `type[Response]` | `Response` | Clase usada para objetos de respuesta. |
| `session_interface` | `SessionInterface` | `SecureCookieSessionInterface()` | Interfaz de gestión de sesiones. |

---

#### `__init_subclass__()`

```python
def __init_subclass__(cls, **kwargs: t.Any) -> None
```

Hook de creación de subclases. Inspecciona un conjunto fijo de métodos del ciclo de vida (`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`). Para cada método sobrescrito, valida mediante `inspect.signature` que el segundo parámetro se llame `ctx` o esté anotado como `AppContext` (anotación en texto o clase). Si la validación falla, emite un `DeprecationWarning` y aplica `remove_ctx()` al método de la subclase y `add_ctx()` al método base de `Flask`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `cls` | `type[Flask]` | Sí (implícito) | Subclase en construcción. |
| `**kwargs` | `Any` | No | Argumentos de clase adicionales (aceptados y no utilizados). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Modifica la subclase y la clase `Flask` por efecto lateral (`setattr`). |

**Raises / Warns**

| Excepción / Aviso | Condición |
|---|---|
| `DeprecationWarning` | Un método sobrescrito conserva la firma antigua sin `ctx: AppContext`. |

---

#### `__init__()`

```python
def __init__(
    self,
    import_name: str,
    static_url_path: str | None = None,
    static_folder: str | os.PathLike[str] | None = "static",
    static_host: str | None = None,
    host_matching: bool = False,
    subdomain_matching: bool = False,
    template_folder: str | os.PathLike[str] | None = "templates",
    instance_path: str | None = None,
    instance_relative_config: bool = False,
    root_path: str | None = None,
)
```

Construye la instancia. Delega en `App.__init__`, crea el grupo de comandos Click (`self.cli = cli.AppGroup()`), le asigna el nombre de la app y, si existe carpeta estática configurada, registra la ruta `"<static_url_path>/<path:filename>"` con endpoint `"static"` usando una referencia débil (`weakref.ref`) para evitar ciclos de referencia.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `import_name` | `str` | Sí | Nombre del paquete/módulo de la aplicación. |
| `static_url_path` | `str \| None` | No | Ruta web para los archivos estáticos. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta de archivos estáticos (`"static"` por defecto). |
| `static_host` | `str \| None` | No | Host de la ruta estática; obligatorio con `host_matching=True`. |
| `host_matching` | `bool` | No | Activa `url_map.host_matching`. |
| `subdomain_matching` | `bool` | No | Considera el subdominio relativo a `SERVER_NAME`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta de plantillas Jinja. |
| `instance_path` | `str \| None` | No | Ruta alternativa a la carpeta *instance*. |
| `instance_relative_config` | `bool` | No | Resuelve la configuración relativa a `instance_path`. |
| `root_path` | `str \| None` | No | Raíz de los archivos de la aplicación. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Constructor. |

**Raises**

| Excepción | Condición |
|---|---|
| `AssertionError` | `bool(static_host) != host_matching` cuando hay carpeta estática (`"Invalid static_host/host_matching combination"`). |

##### Callback anónimo (`lambda`) del endpoint `static`

```python
view_func=lambda **kw: self_ref().send_static_file(**kw)
```

Función de vista registrada para el endpoint `"static"`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kw` | `Any` | Sí (`filename`) | Variables de la regla de URL; se reenvían a `send_static_file()`. |

**Retorno:** `Response` — resultado de `send_static_file()` sobre la app desreferenciada desde el `weakref`.

---

#### `get_send_file_max_age()`

```python
def get_send_file_max_age(self, filename: str | None) -> int | None
```

Determina el valor de caché `max_age` (en segundos) para un archivo, leyendo `SEND_FILE_MAX_AGE_DEFAULT` de la configuración. Convierte `timedelta` a segundos enteros.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str \| None` | Sí | Ruta del archivo evaluado (no usada en la implementación por defecto). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `int \| None` | Segundos de caché, o `None` para habilitar peticiones condicionales. |

**Raises:** ninguna.

---

#### `send_static_file()`

```python
def send_static_file(self, filename: str) -> Response
```

Vista que sirve archivos desde `static_folder`, aplicando `get_send_file_max_age()` y delegando en `send_from_directory()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str` | Sí | Ruta relativa del archivo dentro de `static_folder`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta con el archivo solicitado. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | `static_folder` no está configurado. |
| `NotFound` (vía `send_from_directory`) | El archivo no existe. |

---

#### `open_resource()`

```python
def open_resource(self, resource: str, mode: str = "rb", encoding: str | None = None) -> t.IO[t.AnyStr]
```

Abre, **solo en lectura**, un recurso relativo a `root_path`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta relativa a `root_path`. |
| `mode` | `str` | No | Modo de apertura; válidos: `"r"`, `"rt"`, `"rb"`. |
| `encoding` | `str \| None` | No | Codificación en modo texto; ignorada en binario. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.IO[t.AnyStr]` | Objeto fichero abierto. |

**Raises**

| Excepción | Condición |
|---|---|
| `ValueError` | `mode` no pertenece a `{"r", "rt", "rb"}`. |
| `OSError` / `FileNotFoundError` | El recurso no puede abrirse. |

---

#### `open_instance_resource()`

```python
def open_instance_resource(self, resource: str, mode: str = "rb", encoding: str | None = "utf-8") -> t.IO[t.AnyStr]
```

Abre un recurso relativo a `instance_path`. A diferencia de `open_resource()`, admite modos de escritura.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta relativa a `instance_path`. |
| `mode` | `str` | No | Cualquier modo válido de `open()`. |
| `encoding` | `str \| None` | No | Codificación en modo texto; ignorada si `"b"` está en `mode`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.IO[t.AnyStr]` | Objeto fichero abierto. |

**Raises**

| Excepción | Condición |
|---|---|
| `OSError` / `FileNotFoundError` | Error de E/S al abrir la ruta. |

---

#### `create_jinja_environment()`

```python
def create_jinja_environment(self) -> Environment
```

Construye el entorno Jinja a partir de `jinja_options`, estableciendo `autoescape` (`select_jinja_autoescape`) y `auto_reload` (según `TEMPLATES_AUTO_RELOAD` o `debug`). Registra los globales `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g` y la política `json.dumps_function`.

**Parámetros:** ninguno (además de `self`).

**Retorno**

| Tipo | Descripción |
|---|---|
| `Environment` | Entorno Jinja configurado. |

**Raises:** ninguna explícita.

---

#### `create_url_adapter()`

```python
def create_url_adapter(self, request: Request | None) -> MapAdapter | None
```

Crea un `MapAdapter` para la petición dada, o para el contexto de aplicación cuando `request is None`. Aplica `TRUSTED_HOSTS`, recalcula `request.host` con `get_host()` y ajusta `server_name`/`subdomain` según `host_matching` y `subdomain_matching`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request \| None` | Sí | Petición a la que vincular el adaptador; `None` para enlazar fuera de petición. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `MapAdapter \| None` | Adaptador vinculado, o `None` si no hay petición ni `SERVER_NAME` configurado. |

**Raises**

| Excepción | Condición |
|---|---|
| `BadRequest` (vía `get_host`) | El host de la petición no está en `trusted_hosts`. |

---

#### `raise_routing_exception()`

```python
def raise_routing_exception(self, request: Request) -> t.NoReturn
```

Método interno (`:meta private:`). Relanza `request.routing_exception`. En modo depuración, si se trata de un `RequestRedirect` con código distinto de 307/308 y el método HTTP no es seguro, lo sustituye por `FormDataRoutingRedirect` para advertir de la pérdida del cuerpo.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request` | Sí | Petición con `routing_exception` establecida. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `t.NoReturn` | Nunca retorna; siempre lanza. |

**Raises**

| Excepción | Condición |
|---|---|
| `request.routing_exception` | Caso general (no debug, redirecciones 307/308, métodos `GET`/`HEAD`/`OPTIONS`). |
| `FormDataRoutingRedirect` | Modo debug con redirección de ruta que descartaría el cuerpo. |

---

#### `update_template_context()`

```python
def update_template_context(self, ctx: AppContext, context: dict[str, t.Any]) -> None
```

Inyecta variables comunes y el resultado de los *context processors* registrados (de la app y de los blueprints de la petición) en el diccionario de contexto de plantilla. Los valores originales se reaplican al final para que tengan precedencia.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo; si `ctx.has_request`, se recorren los blueprints. |
| `context` | `dict[str, Any]` | Sí | Diccionario de contexto modificado *in place*. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Mutación in place de `context`. |

**Raises:** propaga excepciones de los procesadores de contexto.

---

#### `make_shell_context()`

```python
def make_shell_context(self) -> dict[str, t.Any]
```

Construye el espacio de nombres para el shell interactivo (`flask shell`), partiendo de `{"app": self, "g": g}` y aplicando todos los `shell_context_processors`.

**Retorno**

| Tipo | Descripción |
|---|---|
| `dict[str, Any]` | Namespace del shell. |

**Raises:** propaga excepciones de los procesadores.

---

#### `run()`

```python
def run(
    self,
    host: str | None = None,
    port: int | None = None,
    debug: bool | None = None,
    load_dotenv: bool = True,
    **options: t.Any,
) -> None
```

Arranca el servidor de desarrollo de Werkzeug (`run_simple`). **No apto para producción.** Si se detecta `FLASK_RUN_FROM_CLI == "true"`, la llamada se ignora (con aviso en consola si no se está en el recargador). Carga `.env`/`.flaskenv`, resuelve host/puerto desde `SERVER_NAME` y establece valores por defecto de `use_reloader`, `use_debugger` y `threaded`. En el `finally`, restablece `self._got_first_request = False`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `host` | `str \| None` | No | Interfaz de escucha. Por defecto `SERVER_NAME` o `"127.0.0.1"`. |
| `port` | `int \| None` | No | Puerto. Por defecto el de `SERVER_NAME` o `5000`. |
| `debug` | `bool \| None` | No | Fuerza modo depuración (prioridad máxima). |
| `load_dotenv` | `bool` | No | Carga los ficheros `.env` y `.flaskenv` más cercanos. |
| `**options` | `Any` | No | Opciones reenviadas a `werkzeug.serving.run_simple`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `None` | Retorna al detenerse el servidor, o inmediatamente si la llamada se ignora. |

**Raises**

| Excepción | Condición |
|---|---|
| `OSError` | Puerto ocupado o host inválido (desde `run_simple`). |
| `ValueError` | `port` no convertible a `int`. |

---

#### `test_client()`

```python
def test_client(self, use_cookies: bool = True, **kwargs: t.Any) -> FlaskClient
```

Crea un cliente de pruebas. Usa `test_client_class` si está definida; en caso contrario importa `flask.testing.FlaskClient`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `use_cookies` | `bool` | No | Mantiene cookies entre peticiones. |
| `**kwargs` | `Any` | No | Argumentos adicionales para el constructor de `test_client_class`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `FlaskClient` | Cliente de pruebas, usable como gestor de contexto. |

**Raises:** propaga errores del constructor de la clase cliente.

---

#### `test_cli_runner()`

```python
def test_cli_runner(self, **kwargs: t.Any) -> FlaskCliRunner
```

Crea un *runner* para probar comandos CLI, instanciando `test_cli_runner_class` (por defecto `flask.testing.FlaskCliRunner`) con la app como primer argumento.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kwargs` | `Any` | No | Argumentos adicionales para el constructor del runner. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `FlaskCliRunner` | Runner de pruebas CLI. |

**Raises:** propaga errores del constructor.

---

#### `handle_http_exception()`

```python
def handle_http_exception(self, ctx: AppContext, e: HTTPException) -> HTTPException | ft.ResponseReturnValue
```

Gestiona una `HTTPException`. Devuelve la excepción sin cambios si `e.code is None` (excepciones proxy) o si es una `RoutingException`. En otro caso busca un handler por código y MRO (`_find_error_handler`) considerando los blueprints de la petición.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (aporta `ctx.request.blueprints`). |
| `e` | `HTTPException` | Sí | Excepción HTTP a tratar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `HTTPException \| ft.ResponseReturnValue` | La excepción original o el valor devuelto por el handler. |

**Raises:** propaga excepciones lanzadas por el handler registrado.

---

#### `handle_user_exception()`

```python
def handle_user_exception(self, ctx: AppContext, e: Exception) -> HTTPException | ft.ResponseReturnValue
```

Punto central de manejo de excepciones de usuario. Activa `show_exception` en `BadRequestKeyError` bajo `debug`/`TRAP_BAD_REQUEST_ERRORS`, delega en `handle_http_exception()` para `HTTPException` no interceptadas, y busca un handler específico. Si no existe handler, re-lanza la excepción en curso con su traceback original (`raise` desnudo).

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción a manejar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `HTTPException \| ft.ResponseReturnValue` | Valor de respuesta o excepción HTTP a convertir. |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` (la original) | No hay handler registrado para `e`. |
| `RuntimeError` | `raise` desnudo invocado fuera de un contexto de excepción activo. |

---

#### `handle_exception()`

```python
def handle_exception(self, ctx: AppContext, e: Exception) -> Response
```

Maneja excepciones no capturadas, produciendo siempre un **500**. Emite la señal `got_request_exception`. Si `PROPAGATE_EXCEPTIONS` (o `testing`/`debug`) está activo, re-lanza; en caso contrario registra el error con `log_exception()`, construye un `InternalServerError(original_exception=e)`, aplica el handler de 500 si existe y finaliza la petición en modo seguro.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción no manejada. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta 500 finalizada (`finalize_request(..., from_error_handler=True)`). |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` (la original o `e`) | `PROPAGATE_EXCEPTIONS` evaluado como verdadero. |

---

#### `log_exception()`

```python
def log_exception(
    self,
    ctx: AppContext,
    exc_info: tuple[type, BaseException, TracebackType] | tuple[None, None, None],
) -> None
```

Registra la excepción con nivel `ERROR` en `self.logger`, incluyendo ruta y método de la petición.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo; aporta `ctx.request.path` y `.method`. |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí | Tupla al estilo `sys.exc_info()`. |

**Retorno:** `None`.

**Raises:** ninguna.

---

#### `dispatch_request()`

```python
def dispatch_request(self, ctx: AppContext) -> ft.ResponseReturnValue
```

Realiza el despacho: si hay `routing_exception` llama a `raise_routing_exception()`; si la regla provee `provide_automatic_options` y el método es `OPTIONS`, devuelve `make_default_options_response()`; en otro caso invoca la vista del endpoint con `view_args` a través de `ensure_sync()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con la petición ya emparejada. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `ft.ResponseReturnValue` | Valor bruto devuelto por la vista (no necesariamente un `Response`). |

**Raises**

| Excepción | Condición |
|---|---|
| `HTTPException` / `RoutingException` | Fallo de enrutamiento (vía `raise_routing_exception()`). |
| `Exception` | Cualquier error propagado desde la función de vista. |

---

#### `full_dispatch_request()`

```python
def full_dispatch_request(self, ctx: AppContext) -> Response
```

Envoltura completa del despacho: advierte si `should_ignore_error` está definido (deprecado), marca `_got_first_request`, emite `request_started`, ejecuta `preprocess_request()` y, si no hay cortocircuito, `dispatch_request()`. Captura cualquier `Exception` y la deriva a `handle_user_exception()`. Finaliza con `finalize_request()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto de la petición en curso. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta final totalmente procesada. |

**Raises / Warns**

| Excepción / Aviso | Condición |
|---|---|
| `DeprecationWarning` | `should_ignore_error` definido en la primera petición. |
| `Exception` | Propagada desde `handle_user_exception()` o `finalize_request()`. |

---

#### `finalize_request()`

```python
def finalize_request(
    self,
    ctx: AppContext,
    rv: ft.ResponseReturnValue | HTTPException,
    from_error_handler: bool = False,
) -> Response
```

Convierte el valor de retorno en `Response` (`make_response()`), aplica `process_response()` y emite `request_finished`. Método interno.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `rv` | `ft.ResponseReturnValue \| HTTPException` | Sí | Valor devuelto por la vista o handler de error. |
| `from_error_handler` | `bool` | No | Modo seguro: registra y suprime fallos del post-procesado. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta final. |

**Raises**

| Excepción | Condición |
|---|---|
| `Exception` | Error en `process_response()`/`request_finished` con `from_error_handler=False`. |
| `TypeError` | `rv` no es un tipo de respuesta válido (desde `make_response()`). |

---

#### `make_default_options_response()`

```python
def make_default_options_response(self, ctx: AppContext) -> Response
```

Genera la respuesta automática a `OPTIONS`, poblando la cabecera `Allow` con `ctx.url_adapter.allowed_methods()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con `url_adapter` disponible. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Instancia vacía de `response_class` con `Allow` establecida. |

**Raises**

| Excepción | Condición |
|---|---|
| `AttributeError` | `ctx.url_adapter` es `None`. |

---

#### `ensure_sync()`

```python
def ensure_sync(self, func: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]
```

Garantiza que el *callable* sea ejecutable de forma síncrona por un worker WSGI: las corrutinas se envuelven con `async_to_sync()`, el resto se devuelve intacto.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `Callable[..., Any]` | Sí | Vista, handler o callback a normalizar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Callable[..., Any]` | Función síncrona equivalente. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | Indirectamente desde `async_to_sync()` si falta el extra `async`. |

---

#### `async_to_sync()`

```python
def async_to_sync(self, func: t.Callable[..., t.Coroutine[t.Any, t.Any, t.Any]]) -> t.Callable[..., t.Any]
```

Adapta una función corrutina a una función síncrona utilizando `asgiref.sync.async_to_sync`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `Callable[..., Coroutine[Any, Any, Any]]` | Sí | Función `async def` a adaptar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Callable[..., Any]` | Wrapper síncrono que ejecuta la corrutina y espera el resultado. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | `asgiref` no instalado (`ImportError` reconvertido). |

---

#### `url_for()`

```python
def url_for(
    self,
    /,
    endpoint: str,
    *,
    _anchor: str | None = None,
    _method: str | None = None,
    _scheme: str | None = None,
    _external: bool | None = None,
    **values: t.Any,
) -> str
```

Construye la URL de un endpoint. Resuelve endpoints relativos (`".vista"`) contra el blueprint actual, determina el carácter externo/interno de la URL según el contexto, aplica `inject_url_defaults()` y delega en `MapAdapter.build()`. Los fallos de construcción se derivan a `handle_url_build_error()`. El ancla se escapa con `urllib.parse.quote`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `endpoint` | `str` | Sí | Nombre del endpoint; si empieza por `.` es relativo al blueprint activo. |
| `_anchor` | `str \| None` | No | Fragmento `#anchor` a añadir. |
| `_method` | `str \| None` | No | Método HTTP para desambiguar reglas. |
| `_scheme` | `str \| None` | No | Esquema a usar en URLs externas. |
| `_external` | `bool \| None` | No | Fuerza URL absoluta (`True`) o relativa (`False`). |
| `**values` | `Any` | No | Valores de las partes variables; las claves desconocidas pasan a query string. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `str` | URL generada, o el valor devuelto por `handle_url_build_error()`. |

**Raises**

| Excepción | Condición |
|---|---|
| `RuntimeError` | No hay adaptador de URL disponible (fuera de petición y sin `SERVER_NAME`). |
| `ValueError` | Se indicó `_scheme` con `_external=False`. |
| `BuildError` | Fallo de construcción no resuelto por `handle_url_build_error()`. |

---

#### `make_response()`

```python
def make_response(self, rv: ft.ResponseReturnValue) -> Response
```

Normaliza el valor de retorno de una vista a una instancia de `response_class`. Desempaqueta tuplas de 2 o 3 elementos, convierte `str`/`bytes`/iteradores en cuerpo de respuesta, `dict`/`list` en JSON, coacciona otras `Response` o *callables* WSGI mediante `force_type()`, y finalmente aplica `status` y `headers`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `rv` | `ft.ResponseReturnValue` | Sí | Valor devuelto por la vista: `str`, `bytes`, `dict`, `list`, generador/iterador, tupla, `Response` o callable WSGI. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Instancia de `response_class` lista para servirse. |

**Raises**

| Excepción | Condición |
|---|---|
| `TypeError` | Tupla con longitud distinta de 2 o 3; `rv is None`; tipo de retorno no soportado; fallo de `force_type()`. |

---

#### `preprocess_request()`

```python
def preprocess_request(self, ctx: AppContext) -> ft.ResponseReturnValue | None
```

Ejecuta `url_value_preprocessors` y después `before_request_funcs` para la app y los blueprints (en orden inverso de anidamiento). Si algún `before_request` devuelve un valor no `None`, éste cortocircuita el despacho.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto de la petición. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `ft.ResponseReturnValue \| None` | Valor de respuesta anticipado, o `None` para continuar el despacho. |

**Raises:** propaga excepciones de los preprocesadores y handlers `before_request`.

---

#### `process_response()`

```python
def process_response(self, ctx: AppContext, response: Response) -> Response
```

Aplica los callbacks `ctx._after_request_functions` y los `after_request_funcs` de blueprints y app (en orden inverso de registro), y guarda la sesión mediante `session_interface.save_session()` si no es una sesión nula.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `response` | `Response` | Sí | Respuesta a modificar. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Response` | Respuesta resultante (misma instancia o una nueva). |

**Raises:** propaga excepciones de los callbacks `after_request` o del guardado de sesión.

---

#### `do_teardown_request()`

```python
def do_teardown_request(self, ctx: AppContext, exc: BaseException | None = None) -> None
```

Ejecuta todos los `teardown_request` (app y blueprints, en orden inverso) y emite `request_tearing_down`. Usa `_CollectErrors` para invocar **todos** los callbacks, acumulando los fallos y relanzándolos agrupados al final. Invocado por `AppContext.pop()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto que está siendo liberado. |
| `exc` | `BaseException \| None` | No | Excepción no manejada durante el despacho; se pasa a cada callback. |

**Retorno:** `None`.

**Raises**

| Excepción | Condición |
|---|---|
| Excepción agregada (`collect_errors.raise_any`) | Uno o más callbacks de teardown fallaron (`"Errors during request teardown"`). |

---

#### `do_teardown_appcontext()`

```python
def do_teardown_appcontext(self, ctx: AppContext, exc: BaseException | None = None) -> None
```

Ejecuta los `teardown_appcontext_funcs` en orden inverso y emite `appcontext_tearing_down`, acumulando errores con `_CollectErrors`. Invocado por `AppContext.pop()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto de aplicación a liberar. |
| `exc` | `BaseException \| None` | No | Excepción no manejada mientras el contexto estuvo activo. |

**Retorno:** `None`.

**Raises**

| Excepción | Condición |
|---|---|
| Excepción agregada (`collect_errors.raise_any`) | Fallos en los callbacks (`"Errors during app teardown"`). |

---

#### `app_context()`

```python
def app_context(self) -> AppContext
```

Crea un `AppContext` sin información de petición. Al empujarlo, `current_app` y `g` quedan disponibles.

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto usable como bloque `with`. |

**Raises:** ninguna.

---

#### `request_context()`

```python
def request_context(self, environ: WSGIEnvironment) -> AppContext
```

Crea un `AppContext` con información de petición a partir de un entorno WSGI (`AppContext.from_environ`). No recomendado en código de usuario; emplear `test_request_context()`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Diccionario de entorno WSGI. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto con `request`, `session` y `g` disponibles al empujarse. |

**Raises:** propaga errores de validación del entorno.

---

#### `test_request_context()`

```python
def test_request_context(self, *args: t.Any, **kwargs: t.Any) -> AppContext
```

Construye un entorno WSGI sintético con `flask.testing.EnvironBuilder` (cerrándolo en el `finally`) y devuelve el contexto de petición asociado.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `path` (vía `*args`/`**kwargs`) | `str` | No | Ruta solicitada. |
| `base_url` | `str` | No | URL base; derivada de `PREFERRED_URL_SCHEME`, `SERVER_NAME` y `APPLICATION_ROOT` si se omite. |
| `subdomain` | `str` | No | Subdominio a antepuesto a `SERVER_NAME`. |
| `url_scheme` | `str` | No | Esquema alternativo a `PREFERRED_URL_SCHEME`. |
| `data` | `str \| bytes \| dict` | No | Cuerpo de la petición o datos de formulario. |
| `json` | `Any` | No | Objeto serializado como JSON; fija `content_type`. |
| `*args` | `Any` | No | Argumentos posicionales para `EnvironBuilder`. |
| `**kwargs` | `Any` | No | Argumentos por palabra clave para `EnvironBuilder`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `AppContext` | Contexto de petición sintético, usable como `with`. |

**Raises:** propaga errores de `EnvironBuilder` (p. ej. `TypeError` por argumentos inválidos).

---

#### `wsgi_app()`

```python
def wsgi_app(self, environ: WSGIEnvironment, start_response: StartResponse) -> cabc.Iterable[bytes]
```

Implementación real de la aplicación WSGI. Crea y empuja el contexto, ejecuta `full_dispatch_request()`, deriva excepciones a `handle_exception()` y garantiza en el bloque `finally` la preservación del contexto para el depurador (`werkzeug.debug.preserve_context`), el filtrado opcional vía `should_ignore_error` y el `ctx.pop(error)`.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI de la petición. |
| `start_response` | `StartResponse` | Sí | Callable WSGI para iniciar la respuesta. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `cabc.Iterable[bytes]` | Iterable con el cuerpo de la respuesta. |

**Raises**

| Excepción | Condición |
|---|---|
| `BaseException` | Excepciones no derivadas de `Exception` (p. ej. `SystemExit`) se re-lanzan tras registrarse en `error`. |
| `Exception` | Si `PROPAGATE_EXCEPTIONS` está activo en `handle_exception()`, o si falla el teardown en `ctx.pop()`. |

---

#### `__call__()`

```python
def __call__(self, environ: WSGIEnvironment, start_response: StartResponse) -> cabc.Iterable[bytes]
```

Hace que la instancia `Flask` sea invocable como aplicación WSGI; delega íntegramente en `wsgi_app()` para permitir el envoltorio con middlewares.

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callable WSGI de inicio de respuesta. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `cabc.Iterable[bytes]` | Cuerpo de la respuesta. |

**Raises:** las mismas que `wsgi_app()`.

---

## 3. Ejemplo de uso

```python
"""Caso de uso integral: aplicación, vistas sync/async, manejo de errores,
contextos manuales, pruebas y personalización mediante subclase."""

from __future__ import annotations

import typing as t

from flask import Flask, g, request
from flask.ctx import AppContext
from werkzeug.exceptions import HTTPException

# ---------------------------------------------------------------------------
# 1. Subclase con la firma moderna (recibe `ctx: AppContext`).
#    Si se omitiera `ctx`, `Flask.__init_subclass__()` emitiría un
#    DeprecationWarning y aplicaría `remove_ctx()` / `add_ctx()`.
# ---------------------------------------------------------------------------
class AuditedFlask(Flask):
    def log_exception(self, ctx: AppContext, exc_info) -> None:
        self.logger.error("[AUDIT] fallo en %s", ctx.request.path, exc_info=exc_info)
        super().log_exception(ctx, exc_info)

    def process_response(self, ctx: AppContext, response):
        response = super().process_response(ctx, response)
        response.headers["X-App-Name"] = self.name
        return response


app = AuditedFlask(__name__, static_folder="static", template_folder="templates")
app.config.update(SERVER_NAME="localhost:5000", SEND_FILE_MAX_AGE_DEFAULT=3600)


# ---------------------------------------------------------------------------
# 2. Vistas: retorno simple, tupla (body, status, headers) y vista async.
# ---------------------------------------------------------------------------
@app.route("/")
def index() -> str:
    # `url_for()` del objeto app, equivalente a flask.url_for
    return f"Estáticos en: {app.url_for('static', filename='app.css')}"


@app.route("/api/items")
def items() -> tuple[dict[str, t.Any], int, dict[str, str]]:
    # make_response() convertirá el dict a JSON y extenderá las cabeceras.
    return {"items": [1, 2, 3]}, 201, {"X-Total-Count": "3"}


@app.route("/async")
async def async_view() -> str:
    # ensure_sync() -> async_to_sync() requiere el extra: pip install "flask[async]"
    return "respuesta asíncrona"


@app.errorhandler(HTTPException)
def on_http_error(e: HTTPException):
    return {"error": e.name, "code": e.code}, e.code or 500


@app.teardown_request
def close_resources(exc: BaseException | None) -> None:
    # Invocado por do_teardown_request(); todos los callbacks se ejecutan
    # incluso si alguno falla (errores agregados por _CollectErrors).
    g.pop("db", None)


@app.shell_context_processor
def shell_ctx() -> dict[str, t.Any]:
    return {"Flask": Flask}


# ---------------------------------------------------------------------------
# 3. Contextos manuales.
# ---------------------------------------------------------------------------
with app.app_context():
    # URL externa fuera de petición (requiere SERVER_NAME).
    print(app.url_for("items", _external=True, page=2))
    print(sorted(app.make_shell_context()))          # make_shell_context()
    print(app.get_send_file_max_age("app.css"))      # get_send_file_max_age()

with app.test_request_context("/api/items?page=2", method="GET"):
    print(request.args["page"])
    ctx_vars: dict[str, t.Any] = {"title": "Demo"}
    # update_template_context() requiere el AppContext explícito.
    from flask.globals import app_ctx
    app.update_template_context(app_ctx._get_current_object(), ctx_vars)
    print(sorted(ctx_vars))

# Lectura de recursos relativos a root_path / instance_path.
try:
    with app.open_resource("schema.sql", mode="r", encoding="utf-8") as fh:
        schema = fh.read()
except FileNotFoundError:
    schema = ""

# ---------------------------------------------------------------------------
# 4. Pruebas: cliente HTTP y runner CLI.
# ---------------------------------------------------------------------------
app.testing = True
with app.test_client() as client:
    rv = client.get("/api/items")
    assert rv.status_code == 201
    assert rv.headers["X-App-Name"] == app.name  # añadido en process_response()

runner = app.test_cli_runner()
result = runner.invoke(args=["routes"])
print(result.output)

# ---------------------------------------------------------------------------
# 5. Middleware sobre wsgi_app() y arranque del servidor de desarrollo.
# ---------------------------------------------------------------------------
from werkzeug.middleware.proxy_fix import ProxyFix

app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)  # type: ignore[assignment]

if __name__ == "__main__":
    # run() se ignora automáticamente si se ejecuta desde `flask run`.
    app.run(host="127.0.0.1", port=5000, debug=True, use_reloader=False)
```