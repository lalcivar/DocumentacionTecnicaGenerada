Claro, aquí tienes la documentación técnica exhaustiva para la clase `DefaultLauncherTests`, siguiendo la estructura y restricciones solicitadas.

***

## Documentación Técnica: `DefaultLauncherTests`

### 1. Resumen Ejecutivo

La clase `DefaultLauncherTests` es una suite de pruebas exhaustiva diseñada para verificar el comportamiento de `DefaultLauncher`, el componente central de ejecución de JUnit Platform. Su propósito es asegurar la correcta implementación de los ciclos de vida de descubrimiento y ejecución de pruebas, incluyendo el manejo de múltiples `TestEngine`, la aplicación de filtros, la notificación a `listeners`, el manejo de errores y la gestión de la configuración. Esta clase garantiza la robustez y fiabilidad del lanzador de pruebas en una amplia gama de escenarios.

### 2. Especificación de Métodos y Constructores

A continuación se detallan todos los constructores y métodos de la clase `DefaultLauncherTests`.

#### Constructor

##### `DefaultLauncherTests()`
Constructor por defecto de la clase de pruebas.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` (implícita) |
| **Parámetros** | Ninguno. |
| **Retorno** | Instancia de `DefaultLauncherTests`. |
| **Excepciones** | Ninguna. |

---
#### Métodos de Prueba y Auxiliares

##### `constructLauncherWithoutAnyEngines()`
Verifica que se lance una `JUnitException` al intentar descubrir pruebas con un `Launcher` creado sin ningún `TestEngine`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`
Comprueba que se lance una `JUnitException` si se intenta construir un `Launcher` con múltiples `TestEngine` que tienen el mismo ID.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`
Asegura que el descubrimiento de pruebas con un `TestEngine` que no contiene tests produce un `TestPlan` con un único nodo raíz (el descriptor del motor).

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
Verifica que el `Launcher` maneja correctamente el caso en que un `TestEngine` devuelve `null` durante la fase de descubrimiento, reportando un fallo.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)`**: Sobrescribe el método para devolver siempre `null`, simulando un fallo en el descubrimiento.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `discoveryRequest` (`EngineDiscoveryRequest`), `uniqueId` (`UniqueId`) |
| **Retorno** | `null` |
| **Excepciones** | Ninguna. |

##### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`
Prueba parametrizada que asegura que si un `TestEngine` lanza un `Error` o `RuntimeException` durante el descubrimiento, se crea un descriptor de error y la ejecución posterior de ese descriptor falla.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `@param throwableClass` (`Class<? extends Throwable>`, Requerido): La clase de la excepción a lanzar. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)`**: Sobrescribe el método para lanzar una instancia de la clase `throwableClass` proporcionada, simulando un error crítico durante el descubrimiento.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `discoveryRequest` (`EngineDiscoveryRequest`), `uniqueId` (`UniqueId`) |
| **Retorno** | `TestDescriptor` |
| **Excepciones** | Lanza una instancia de `throwableClass`. |

##### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`
Método auxiliar privado para verificar que un `TestEngine` ha fallado correctamente durante la fase de descubrimiento y que el `LauncherDiscoveryListener` ha sido notificado en el orden correcto.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `private` |
| **Parámetros** | `@param testEngine` (`TestEngine`, Requerido): El motor de pruebas que se espera que falle.<br>`@param inOrder` (`InOrder`, Requerido): Verificador de orden de Mockito para las llamadas al listener.<br>`@param discoveryListener` (`LauncherDiscoveryListener`, Requerido): El listener mockeado cuyas interacciones se verifican. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si las verificaciones fallan. |

##### `reportsEngineExecutionFailuresWithoutPriorEvents()`
Verifica que si un `TestEngine` lanza una excepción durante la ejecución (sin haber notificado eventos previos), el fallo se reporta correctamente al `TestExecutionListener`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`execute(ExecutionRequest request)`**: Sobrescribe el método para lanzar inmediatamente una `RuntimeException`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `request` (`ExecutionRequest`) |
| **Retorno** | `void` |
| **Excepciones** | `RuntimeException` |

##### `reportsEngineExecutionFailuresForSkippedEngine()`
Verifica que si un `TestEngine` reporta un evento de "saltado" (`executionSkipped`) y luego lanza una excepción, el fallo de ejecución se reporta correctamente.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`execute(ExecutionRequest request)`**: Notifica que la ejecución fue saltada y luego lanza una `RuntimeException`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `request` (`ExecutionRequest`) |
| **Retorno** | `void` |
| **Excepciones** | `RuntimeException` |

##### `reportsEngineExecutionFailuresForStartedEngine()`
Verifica que si un `TestEngine` reporta un evento de "iniciado" (`executionStarted`) y luego lanza una excepción, el fallo de ejecución se reporta correctamente.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`execute(ExecutionRequest request)`**: Notifica el inicio de la ejecución y luego lanza una `RuntimeException`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `request` (`ExecutionRequest`) |
| **Retorno** | `void` |
| **Excepciones** | `RuntimeException` |

##### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`
Verifica que si un `TestEngine` reporta una finalización exitosa (`executionFinished`) y luego lanza una excepción, el fallo de ejecución se reporta correctamente.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`execute(ExecutionRequest request)`**: Notifica el inicio y fin exitoso de la ejecución, y luego lanza una `RuntimeException`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `request` (`ExecutionRequest`) |
| **Retorno** | `void` |
| **Excepciones** | `RuntimeException` |

##### `reportsEngineExecutionFailuresForFailedFinishedEngine()`
Verifica que si un `TestEngine` reporta una finalización fallida y luego lanza otra excepción, la excepción final contiene la original como suprimida.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`execute(ExecutionRequest request)`**: Notifica una finalización fallida y luego lanza una nueva `RuntimeException`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `request` (`ExecutionRequest`) |
| **Retorno** | `void` |
| **Excepciones** | `RuntimeException` |

##### `reportsSkippedEngines()`
Asegura que cuando un `TestEngine` reporta que su ejecución fue saltada, el `TestExecutionListener` es notificado correctamente sin llamadas a `executionStarted` o `executionFinished`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`execute(ExecutionRequest request)`**: Notifica que la ejecución del motor fue saltada.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `request` (`ExecutionRequest`) |
| **Retorno** | `void` |
| **Excepciones** | Ninguna. |

##### `reportsFinishedEngines()`
Asegura que cuando un `TestEngine` completa su ejecución normalmente, los eventos `executionStarted` y `executionFinished` son reportados al `TestExecutionListener`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`execute(ExecutionRequest request)`**: Notifica el inicio y fin de la ejecución del motor.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `request` (`ExecutionRequest`) |
| **Retorno** | `void` |
| **Excepciones** | Ninguna. |

##### `discoverTestPlanForSingleEngine()`
Verifica que el descubrimiento de pruebas para un único `TestEngine` con múltiples tests genera un `TestPlan` con la estructura correcta.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `discoverTestPlanForMultipleEngines()`
Verifica que el descubrimiento de pruebas para múltiples `TestEngine` genera un `TestPlan` que contiene los nodos raíz de cada motor.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `launcherAppliesPostDiscoveryFilters()`
Asegura que los `PostDiscoveryFilter` se aplican correctamente después de la fase de descubrimiento, filtrando el `TestPlan` resultante.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`
Verifica que si no se proporcionan parámetros de configuración, el `Launcher` pasa un conjunto de parámetros vacío al `ExecutionRequest` del motor.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`
Verifica que los parámetros de configuración proporcionados al `Launcher` se pasan correctamente al `ExecutionRequest` del motor.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`
Asegura que, en ausencia de parámetros de configuración explícitos, el `Launcher` recurre a las propiedades del sistema (`System.properties`).

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `withAdditionalListener()`
Verifica que un `TestExecutionListener` adicional, como `SummaryGeneratingListener`, se registra y se invoca correctamente durante la ejecución.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
Verifica que el `TestPlan` se "poda" (prunes) correctamente, eliminando contenedores vacíos después de aplicar los `PostDiscoveryFilter`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineSpy`**
    *   **`discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)`**: Crea una jerarquía de descriptores (motor -> contenedor -> test) para la prueba.
*   **Clase Anónima: `TestDescriptorStub`**
    *   **`getType()`**: Devuelve `Type.CONTAINER` para simular un descriptor de tipo contenedor.

##### `reportsDynamicTestDescriptorsCorrectly()`
Asegura que los tests registrados dinámicamente durante la ejecución son reportados correctamente a los `TestExecutionListener`, incluyendo su registro y ciclo de vida de ejecución.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineSpy`**
    *   **`discover(...)`**: Descubre un descriptor inicial de tipo `CONTAINER_AND_TEST`.
    *   **`execute(...)`**: Durante la ejecución, registra dinámicamente un nuevo descriptor de test hijo y notifica su ciclo de vida completo.
*   **Clase Anónima: `TestDescriptorStub`**
    *   **`getType()`**: Devuelve `Type.CONTAINER_AND_TEST`.

##### `launcherCanExecuteTestPlanExactlyOnce()`
Verifica que un `TestPlan` solo puede ser ejecutado una vez. Un segundo intento de ejecución debe lanzar una `JUnitException`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`
Asegura que un `TestEngine` de terceros que utiliza el prefijo de ID reservado "junit-" emite una advertencia de `DiscoveryIssue` y lanza una `DiscoveryIssueException`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `thirdPartyEngineClaimingToBeJupiterResultsInException()`
Verifica que un `TestEngine` de terceros no puede usar el ID reservado "junit-jupiter".

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `thirdPartyEngineClaimingToBeVintageResultsInException()`
Verifica que un `TestEngine` de terceros no puede usar el ID reservado "junit-vintage".

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `assertImposter(String id)`
Método auxiliar privado para verificar que un motor "impostor" que usa un ID reservado provoca una `JUnitException`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `private` |
| **Parámetros** | `@param id` (`String`, Requerido): El ID reservado que se va a probar. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`
Verifica que en modo "dry run" (`DRY_RUN_PROPERTY_NAME`), los tests se reportan como "saltados" (`skipped`) en lugar de ejecutarse, pero los contenedores se reportan como iniciados y finalizados.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `notifiesDiscoveryListenersOfProcessedSelectors()`
Asegura que todos los `LauncherDiscoveryListener` registrados (en la configuración, en el lanzador y en la solicitud) son notificados cuando un selector es procesado por un motor.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Itera sobre los selectores y notifica al listener de descubrimiento que cada uno ha sido procesado.

##### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)`
Verifica que si un motor encuentra un `DiscoveryIssue` crítico (ERROR), la ejecución del motor falla con una `DiscoveryIssueException`. Los issues no críticos (WARNING) se registran en el log.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `@param listener` (`LogRecordListener`, Requerido): Listener para capturar los registros de log generados. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `ERROR` y otro de `WARNING`.
*   **Clase Anónima: `EngineDescriptor`**
    *   **`getTags()`**: Devuelve un conjunto de tags para el descriptor.

##### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)`
Asegura que los `DiscoveryIssue` no críticos (INFO) se registran en el log durante una ejecución normal y exitosa.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `@param listener` (`LogRecordListener`, Requerido): Listener para capturar los registros de log. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `INFO`.
    *   **`execute(...)`**: Realiza una ejecución exitosa.

##### `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)`
Verifica que si el descubrimiento de un motor falla con una excepción, todos los `DiscoveryIssue` (críticos y no críticos) emitidos antes del fallo se registran en el log.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `@param listener` (`LogRecordListener`, Requerido): Listener para capturar los registros de log. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Emite issues de `ERROR` e `INFO` y luego lanza una `RuntimeException`.

##### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)`
Verifica que los `DiscoveryIssue` no críticos se registran en el log incluso si la fase de ejecución del motor falla posteriormente.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `@param listener` (`LogRecordListener`, Requerido): Listener para capturar los registros de log. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `INFO`.
    *   **`execute(...)`**: Lanza una `RuntimeException`.

##### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`
Asegura que la ejecución del motor falla si un `UniqueIdSelector` que apunta a ese motor no puede ser resuelto.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`
Verifica que un `UniqueIdSelector` que no puede ser resuelto es ignorado si no pertenece al motor que se está ejecutando.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `reportsEngineExecutionFailureForSelectorResolutionFailure()`
Verifica que la ejecución del motor falla si la resolución de un selector falla con una excepción.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `allowsConfiguringCriticalDiscoveryIssueSeverity()`
Asegura que la severidad mínima para que un `DiscoveryIssue` sea considerado crítico puede ser configurada a través de parámetros de configuración.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `INFO`.

##### `failsIfCriticalSeverityIsConfiguredIncorrectly()`
Verifica que se lanza una `JUnitException` si se configura un valor inválido para la severidad crítica de `DiscoveryIssue`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `INFO`.
    *   **`execute(...)`**: Realiza una ejecución exitosa.

##### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`
Verifica que si se configura que los fallos por `DiscoveryIssue` ocurran en la fase de "discovery", se lanza una `DiscoveryIssueException` durante la llamada a `discover()`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `ERROR`.

##### `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)`
Prueba parametrizada que asegura que los `DiscoveryIssue` no críticos se registran en el log solo una vez, independientemente de si el fallo se configura para la fase de descubrimiento o ejecución.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | `@param phase` (`String`, Requerido): La fase configurada para el fallo ("discovery" o "execution").<br>`@param listener` (`LogRecordListener`, Requerido): Listener para capturar los registros de log. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `WARNING`.
    *   **`execute(...)`**: Realiza una ejecución exitosa.

##### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`
Verifica que se lanza una `JUnitException` si se proporciona un valor inválido para el parámetro de configuración de la fase de fallo por `DiscoveryIssue`.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

##### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`
Asegura que si se solicita la cancelación antes de la ejecución, los tests hijos del descriptor del motor se marcan como "saltados" (`skipped`) y el motor se marca como "abortado" (`aborted`).

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `public` |
| **Parámetros** | Ninguno. |
| **Retorno** | `void` |
| **Excepciones** | Lanza una excepción de aserción si el comportamiento esperado no se cumple. |

*   **Clase Anónima: `TestEngineStub`**
    *   **`discover(...)`**: Crea una jerarquía de descriptores (motor -> contenedor -> test).

##### `execute(TestEngine engine)`
Método auxiliar estático y privado que ejecuta un `TestEngine` con configuración por defecto.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `private static` |
| **Parámetros** | `@param engine` (`TestEngine`, Requerido): El motor a ejecutar. |
| **Retorno** | `@return ReportedData`: Un registro con los datos capturados de la ejecución. |
| **Excepciones** | Ninguna. |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)`
Método auxiliar estático y privado que ejecuta un `TestEngine`, permitiendo personalizar la solicitud de descubrimiento.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `private static` |
| **Parámetros** | `@param engine` (`TestEngine`, Requerido): El motor a ejecutar.<br>`@param discoveryConfigurer` (`UnaryOperator<...>`, Requerido): Una función para configurar el `LauncherDiscoveryRequestBuilder`. |
| **Retorno** | `@return ReportedData`: Un registro con los datos capturados de la ejecución. |
| **Excepciones** | Ninguna. |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)`
Método auxiliar estático y privado que ejecuta un `TestEngine`, permitiendo personalizar tanto la solicitud de descubrimiento como la de ejecución.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `private static` |
| **Parámetros** | `@param engine` (`TestEngine`, Requerido): El motor a ejecutar.<br>`@param discoveryConfigurer` (`UnaryOperator<...>`, Requerido): Una función para configurar el `LauncherDiscoveryRequestBuilder`.<br>`@param executionConfigurer` (`UnaryOperator<...>`, Requerido): Una función para configurar el `LauncherExecutionRequestBuilder`. |
| **Retorno** | `@return ReportedData`: Un registro con los datos capturados de la ejecución. |
| **Excepciones** | Ninguna. |

##### `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)`
Método auxiliar estático y privado para encontrar el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con un nivel de severidad específico.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `private static` |
| **Parámetros** | `@param listener` (`LogRecordListener`, Requerido): El listener que contiene los registros.<br>`@param level` (`Level`, Requerido): El nivel de log a buscar. |
| **Retorno** | `@return LogRecord`: El primer registro de log encontrado. |
| **Excepciones** | `@throws NoSuchElementException`: Si no se encuentra ningún registro con el nivel especificado. |

---
#### Clases Internas

##### `record ReportedData`
Un `record` privado para encapsular los resultados de una ejecución de prueba para facilitar las aserciones.

| Atributo | Descripción |
| :--- | :--- |
| **Visibilidad** | `private` |
| **Componentes** | `testPlan` (`TestPlan`): El plan de pruebas ejecutado.<br>`testIdentifier` (`TestIdentifier`): El identificador del test raíz ejecutado.<br>`testExecutionResult` (`TestExecutionResult`): El resultado de la ejecución del test raíz.<br>`startTime` (`Instant`): El momento de inicio de la ejecución.<br>`finishTime` (`Instant`): El momento de finalización de la ejecución. |

### 3. Ejemplo de Uso

Dado que `DefaultLauncherTests` es una clase de prueba, su "uso" consiste en ejecutarla a través de un framework de testing como JUnit 5. Sin embargo, el código contiene excelentes ejemplos de cómo usar el `DefaultLauncher`, que es la clase bajo prueba. El siguiente bloque de código, adaptado de `discoverTestPlanForSingleEngine()`, ilustra un caso de uso básico del `DefaultLauncher` para descubrir y analizar un plan de pruebas.

```java
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.engine.support.hierarchical.DemoHierarchicalTestEngine;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.Launcher;

import static org.junit.platform.commons.util.CollectionUtils.getOnlyElement;

public class LauncherUsageExample {

    public static void main(String[] args) {
        // 1. Crear un motor de pruebas de demostración y añadirle tests.
        var engine = new DemoHierarchicalTestEngine("my-demo-engine");
        engine.addTest("firstTest", () -> System.out.println("Executing first test!"));
        engine.addTest("secondTest", () -> System.out.println("Executing second test!"));

        // 2. Crear una instancia del Launcher con el motor de pruebas.
        Launcher launcher = LauncherFactory.create(
            LauncherFactory.createLauncherConfigBuilderWithDisabledServiceLoading()
                .addTestEngines(engine)
                .build()
        );

        // 3. Construir una solicitud de descubrimiento para un paquete específico.
        var discoveryRequest = LauncherDiscoveryRequestBuilder.request()
                .selectors(DiscoverySelectors.selectPackage("com.example.tests"))
                .build();

        // 4. Descubrir el plan de pruebas.
        TestPlan testPlan = launcher.discover(discoveryRequest);

        // 5. Analizar el plan de pruebas resultante.
        System.out.println("Test plan discovery finished.");
        System.out.println("Number of roots: " + testPlan.getRoots().size());
        
        var rootIdentifier = getOnlyElement(testPlan.getRoots());
        System.out.println("Root ID: " + rootIdentifier.getUniqueId());
        System.out.println("Number of children for root: " + testPlan.getChildren(rootIdentifier).size());

        // Opcional: Ejecutar el plan de pruebas (no mostrado aquí).
        // launcher.execute(testPlan);
    }
}
```