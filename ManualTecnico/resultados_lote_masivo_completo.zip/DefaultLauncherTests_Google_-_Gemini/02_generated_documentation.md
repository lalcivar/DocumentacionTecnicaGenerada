Claro, aquí tienes la documentación técnica exhaustiva para la clase `DefaultLauncherTests`, elaborada por un Arquitecto de Software Senior en Java.

### Resumen ejecutivo

La clase `DefaultLauncherTests` es una suite de pruebas exhaustiva para la implementación `DefaultLauncher` del JUnit Platform. Su propósito es verificar el comportamiento correcto del lanzador en una amplia gama de escenarios, incluyendo el descubrimiento de pruebas, la ejecución, el manejo de filtros, la notificación a listeners, la gestión de errores y la configuración de parámetros. Esta clase es fundamental para garantizar la estabilidad y fiabilidad del núcleo del lanzador de JUnit 5.

### Especificación de métodos y constructores

A continuación se detallan todos los métodos, constructores y clases internas de `DefaultLauncherTests`.

---

#### **DefaultLauncherTests()**
Constructor por defecto de la clase de pruebas.

| Atributo | Descripción |
|---|---|
| **@return** | Una nueva instancia de `DefaultLauncherTests`. |

---

#### **constructLauncherWithoutAnyEngines()**
Verifica que un intento de descubrir pruebas con un `Launcher` creado sin ningún `TestEngine` resulta en una `JUnitException`, ya que se requiere al menos un motor de pruebas para operar.

| Atributo | Descripción |
|---|---|
| **@throws** | `JUnitException` - Se espera que se lance esta excepción. |

---

#### **constructLauncherWithMultipleTestEnginesWithDuplicateIds()**
Asegura que la creación de un `Launcher` con múltiples `TestEngine` que comparten el mismo ID provoca una `JUnitException` para prevenir ambigüedades.

| Atributo | Descripción |
|---|---|
| **@throws** | `JUnitException` - Se espera que se lance esta excepción. |

---

#### **discoverEmptyTestPlanWithEngineWithoutAnyTests()**
Comprueba que al descubrir pruebas con un motor que no encuentra ningún test, se genera un `TestPlan` válido que contiene únicamente el nodo raíz del motor.

---

#### **discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()**
Prueba el manejo de un caso anómalo donde un `TestEngine` devuelve `null` de su método `discover`. Se espera que el `Launcher` maneje esto como un fallo en la fase de descubrimiento para ese motor.

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)`**: Sobrescritura del método `discover` que retorna `null` intencionadamente para simular un motor de pruebas defectuoso.
  - **@param** `discoveryRequest` (EngineDiscoveryRequest): La solicitud de descubrimiento.
  - **@param** `uniqueId` (UniqueId): El ID único para el descriptor raíz.
  - **@return** `null`.

---

#### **discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)**
Prueba parametrizada que verifica que si un `TestEngine` lanza un `Error` o `RuntimeException` durante la fase de descubrimiento, el `Launcher` lo captura, lo reporta como un fallo y permite que la ejecución posterior del plan de pruebas refleje este error.

| Atributo | Descripción |
|---|---|
| **@param** `throwableClass` (Class<? extends Throwable>, requerido): La clase del `Throwable` (Error o RuntimeException) que se lanzará durante la simulación del descubrimiento. |
| **@throws** `Exception` - Potencialmente lanzada por la reflexión usada en el test. |

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)`**: Sobrescritura que utiliza reflexión para instanciar y lanzar una excepción del tipo `throwableClass`, simulando un fallo catastrófico en el motor.
  - **@param** `discoveryRequest` (EngineDiscoveryRequest): La solicitud de descubrimiento.
  - **@param** `uniqueId` (UniqueId): El ID único para el descriptor raíz.
  - **@return** `null` (aunque nunca se alcanza debido a la excepción).

---

#### **assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)**
Método de ayuda privado para verificar que un motor de pruebas ha fallado durante la fase de descubrimiento y que el `LauncherDiscoveryListener` ha sido notificado correctamente.

| Atributo | Descripción |
|---|---|
| **@param** `testEngine` (TestEngine, requerido): El motor de pruebas que se espera que falle. |
| **@param** `inOrder` (InOrder, requerido): Un verificador de orden de Mockito para asegurar la secuencia de llamadas. |
| **@param** `discoveryListener` (LauncherDiscoveryListener, requerido): El listener (mock) cuyas interacciones se verifican. |

---

#### **reportsEngineExecutionFailuresWithoutPriorEvents()**
Verifica que si un `TestEngine` lanza una excepción inmediatamente en su método `execute`, el `Launcher` reporta un fallo de ejecución para el motor, asociando la excepción original como la causa.

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.execute(ExecutionRequest request)`**: Sobrescritura que lanza incondicionalmente una `RuntimeException`.

---

#### **reportsEngineExecutionFailuresForSkippedEngine()**
Asegura que si un `TestEngine` primero reporta que su ejecución ha sido omitida (`executionSkipped`) y luego lanza una excepción, el `Launcher` prioriza el reporte del fallo de ejecución.

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.execute(ExecutionRequest request)`**: Sobrescritura que notifica un `executionSkipped` y luego lanza una `RuntimeException`.

---

#### **reportsEngineExecutionFailuresForStartedEngine()**
Comprueba que si un `TestEngine` reporta el inicio de su ejecución (`executionStarted`) y luego lanza una excepción, el `Launcher` reporta correctamente el fallo de ejecución.

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.execute(ExecutionRequest request)`**: Sobrescritura que notifica un `executionStarted` y luego lanza una `RuntimeException`.

---

#### **reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()**
Verifica que si un `TestEngine` reporta una finalización exitosa (`executionFinished` con éxito) pero luego lanza una excepción, el `Launcher` captura y reporta esta excepción como un fallo de ejecución del motor.

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.execute(ExecutionRequest request)`**: Sobrescritura que notifica un `executionStarted`, un `executionFinished` exitoso y luego lanza una `RuntimeException`.

---

#### **reportsEngineExecutionFailuresForFailedFinishedEngine()**
Prueba que si un `TestEngine` reporta una finalización fallida (`executionFinished` con fallo) y además lanza una excepción, el `Launcher` reporta un fallo de ejecución que incluye la excepción lanzada como causa principal y el fallo original como una excepción suprimida.

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.execute(ExecutionRequest request)`**: Sobrescritura que notifica un `executionStarted`, un `executionFinished` fallido y luego lanza otra `RuntimeException`.

---

#### **reportsSkippedEngines()**
Verifica que cuando un `TestEngine` omite su ejecución a través del listener, el `TestExecutionListener` del `Launcher` es notificado correctamente con el evento `executionSkipped`.

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.execute(ExecutionRequest request)`**: Sobrescritura que únicamente notifica que la ejecución del motor ha sido omitida.

---

#### **reportsFinishedEngines()**
Comprueba el flujo normal de ejecución donde un `TestEngine` inicia y finaliza con éxito, asegurando que el `TestExecutionListener` recibe los eventos `executionStarted` y `executionFinished` correspondientes.

##### Métodos de Clases Anónimas Internas
- **`TestEngineStub.execute(ExecutionRequest request)`**: Sobrescritura que simula un ciclo de vida de ejecución normal y exitoso.

---

#### **discoverTestPlanForSingleEngine()**
Prueba la capacidad del `Launcher` para descubrir un plan de pruebas a partir de un único motor que contiene múltiples tests.

---

#### **discoverTestPlanForMultipleEngines()**
Verifica que el `Launcher` puede agregar y descubrir pruebas de múltiples motores de prueba en una sola operación de descubrimiento, generando un `TestPlan` que contiene raíces de ambos motores.

---

#### **launcherAppliesPostDiscoveryFilters()**
Asegura que los `PostDiscoveryFilter` proporcionados en la solicitud de descubrimiento se aplican correctamente, filtrando el `TestPlan` después de que los motores hayan descubierto los tests.

---

#### **withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()**
Verifica que si no se proporcionan parámetros de configuración, el `Launcher` pasa un objeto de parámetros de configuración vacío a la `ExecutionRequest` del motor.

---

#### **withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()**
Comprueba que los parámetros de configuración proporcionados en la solicitud se propagan correctamente a la `ExecutionRequest` que recibe el `TestEngine`.

---

#### **withoutConfigurationParameters_LookupFallsBackToSystemProperty()**
Verifica que, en ausencia de parámetros de configuración explícitos, el `Launcher` recurre a las propiedades del sistema (`System.getProperty`) como fuente de configuración.

---

#### **withAdditionalListener()**
Prueba que un `TestExecutionListener` adicional, como `SummaryGeneratingListener`, puede ser registrado y recibe notificaciones durante la ejecución de las pruebas.

---

#### **prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()**
Verifica que el `Launcher` "poda" el árbol de descriptores de prueba después de aplicar los filtros post-descubrimiento. Si un filtro excluye a todos los hijos de un contenedor, el contenedor debe quedar vacío en el `TestPlan` final.

##### Métodos de Clases Anónimas Internas
- **`TestEngineSpy.discover(...)`**: Sobrescritura que crea una jerarquía de descriptores (motor -> contenedor -> test) para la prueba de filtrado.
- **`TestDescriptorStub.getType()`**: Sobrescritura que devuelve `Type.CONTAINER` para marcar un descriptor como contenedor.

---

#### **reportsDynamicTestDescriptorsCorrectly()**
Prueba el ciclo de vida completo de los tests dinámicos. Asegura que cuando un motor registra un test dinámicamente durante la ejecución, el `Launcher` actualiza el `TestPlan` y notifica a los listeners sobre el nuevo `TestIdentifier` y sus eventos de ejecución.

##### Métodos de Clases Anónimas Internas
- **`TestEngineSpy.discover(...)`**: Configura un descriptor inicial que actuará como padre del test dinámico.
- **`TestEngineSpy.execute(...)`**: Simula la ejecución, donde registra dinámicamente un nuevo descriptor de prueba y notifica su ciclo de vida (registrado, iniciado, finalizado).

---

#### **launcherCanExecuteTestPlanExactlyOnce()**
Asegura que un objeto `TestPlan` solo puede ser ejecutado una vez. Un segundo intento de ejecutar el mismo plan debe lanzar una `PreconditionViolationException`.

---

#### **thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()**
Verifica que si un motor de pruebas de terceros utiliza el prefijo de ID reservado "junit-", el `Launcher` emite una `DiscoveryIssue` de advertencia y lanza una `DiscoveryIssueException`.

---

#### **thirdPartyEngineClaimingToBeJupiterResultsInException()**
Prueba que un motor de terceros no puede usar el ID "junit-jupiter", que está reservado. Intentarlo debe resultar en una `JUnitException`.

---

#### **thirdPartyEngineClaimingToBeVintageResultsInException()**
Prueba que un motor de terceros no puede usar el ID "junit-vintage", que está reservado. Intentarlo debe resultar en una `JUnitException`.

---

#### **assertImposter(String id)**
Método de ayuda privado para probar que el uso de un ID de motor reservado por parte de un motor de terceros impostor lanza una `JUnitException`.

| Atributo | Descripción |
|---|---|
| **@param** `id` (String, requerido): El ID reservado que se va a probar. |

---

#### **dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()**
Verifica el comportamiento del modo "dry run". En este modo, los tests deben ser reportados como "omitidos" (`skipped`) en lugar de ser ejecutados, pero los contenedores deben seguir su ciclo de vida normal de `started`/`finished`.

---

#### **notifiesDiscoveryListenersOfProcessedSelectors()**
Asegura que todos los `LauncherDiscoveryListener` registrados (a nivel de configuración, lanzador y solicitud) son notificados cuando un `DiscoverySelector` es procesado por un motor.

---

#### **reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)**
Prueba que si un motor encuentra un `DiscoveryIssue` crítico (severidad `ERROR`), la ejecución del motor falla con una `DiscoveryIssueException`. Los issues no críticos (como `WARNING`) se registran en el log.

| Atributo | Descripción |
|---|---|
| **@param** `listener` (LogRecordListener, requerido): Un listener para capturar los registros de log generados durante la prueba. |

---

#### **logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)**
Verifica que los `DiscoveryIssue` no críticos (como `INFO`) encontrados durante el descubrimiento se registran en el log, pero no impiden que la ejecución de las pruebas proceda normalmente.

| Atributo | Descripción |
|---|---|
| **@param** `listener` (LogRecordListener, requerido): Un listener para capturar los registros de log. |

---

#### **logsAllIssuesForDiscoveryFailure(LogRecordListener listener)**
Prueba que si el descubrimiento de un motor falla con una excepción, todos los `DiscoveryIssue` encontrados hasta ese momento (críticos y no críticos) se registran en el log.

| Atributo | Descripción |
|---|---|
| **@param** `listener` (LogRecordListener, requerido): Un listener para capturar los registros de log. |

---

#### **logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)**
Asegura que los `DiscoveryIssue` no críticos se registran en el log incluso si la fase de ejecución del motor falla posteriormente por otra razón.

| Atributo | Descripción |
|---|---|
| **@param** `listener` (LogRecordListener, requerido): Un listener para capturar los registros de log. |

---

#### **reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()**
Verifica que si se proporciona un `UniqueIdSelector` que apunta a un motor específico, pero ese motor no puede resolverlo, se genera un `DiscoveryIssue` crítico que causa un fallo en la ejecución.

---

#### **ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()**
Comprueba que un motor ignora un `UniqueIdSelector` que no le pertenece (es decir, el prefijo del ID no coincide con el ID del motor), y la ejecución procede con éxito.

---

#### **reportsEngineExecutionFailureForSelectorResolutionFailure()**
Prueba que si un motor lanza una excepción al intentar resolver un selector, se genera un `DiscoveryIssue` crítico que causa un fallo en la ejecución.

---

#### **allowsConfiguringCriticalDiscoveryIssueSeverity()**
Verifica que la severidad mínima para que un `DiscoveryIssue` sea considerado crítico puede ser configurada mediante un parámetro. En este caso, se configura `INFO` como crítico, causando un fallo.

---

#### **failsIfCriticalSeverityIsConfiguredIncorrectly()**
Asegura que si se proporciona un valor inválido para el parámetro de configuración de severidad crítica, el `Launcher` lanza una `JUnitException`.

---

#### **failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()**
Prueba que el `Launcher` puede ser configurado para fallar inmediatamente durante la fase de descubrimiento si se encuentra un `DiscoveryIssue` crítico, en lugar de esperar a la fase de ejecución.

---

#### **logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)**
Verifica que los `DiscoveryIssue` no críticos se registran en el log solo una vez, independientemente de si la fase de fallo está configurada como "discovery" o "execution".

| Atributo | Descripción |
|---|---|
| **@param** `phase` (String, requerido): La fase de fallo configurada ("discovery" o "execution"). |
| **@param** `listener` (LogRecordListener, requerido): Un listener para capturar los registros de log. |

---

#### **failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()**
Asegura que si se proporciona un valor inválido para el parámetro de configuración de la fase de fallo, el `Launcher` lanza una `JUnitException`.

---

#### **reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()**
Prueba que si se solicita la cancelación de la ejecución antes de que comience, los tests y contenedores dentro del plan se marcan como omitidos (`skipped`) con el motivo "Execution cancelled".

---

#### **execute(TestEngine engine)**
Método de ayuda estático y privado que simplifica la ejecución de un `TestPlan` para un motor dado con configuración por defecto.

| Atributo | Descripción |
|---|---|
| **@param** `engine` (TestEngine, requerido): El motor de pruebas a ejecutar. |
| **@return** (`ReportedData`): Un objeto que encapsula los resultados de la ejecución para su posterior aserción. |

---

#### **execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)**
Sobrecarga del método `execute` que permite personalizar la solicitud de descubrimiento.

| Atributo | Descripción |
|---|---|
| **@param** `engine` (TestEngine, requerido): El motor de pruebas a ejecutar. |
| **@param** `discoveryConfigurer` (UnaryOperator, requerido): Una función para configurar el `LauncherDiscoveryRequestBuilder`. |
| **@return** (`ReportedData`): Un objeto que encapsula los resultados de la ejecución. |

---

#### **execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)**
Sobrecarga completa del método `execute` que permite personalizar tanto la solicitud de descubrimiento como la de ejecución.

| Atributo | Descripción |
|---|---|
| **@param** `engine` (TestEngine, requerido): El motor de pruebas a ejecutar. |
| **@param** `discoveryConfigurer` (UnaryOperator, requerido): Una función para configurar el `LauncherDiscoveryRequestBuilder`. |
| **@param** `executionConfigurer` (UnaryOperator, requerido): Una función para configurar el `LauncherExecutionRequestBuilder`. |
| **@return** (`ReportedData`): Un objeto que encapsula los resultados de la ejecución. |

---

#### **findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)**
Método de ayuda estático y privado para buscar el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con un nivel de log específico.

| Atributo | Descripción |
|---|---|
| **@param** `listener` (LogRecordListener, requerido): El listener que ha capturado los logs. |
| **@param** `level` (Level, requerido): El nivel de log a buscar. |
| **@return** (`LogRecord`): El primer registro de log encontrado. |
| **@throws** `NoSuchElementException` - Si no se encuentra ningún registro con el nivel especificado. |

---

#### **ReportedData(TestPlan testPlan, TestIdentifier testIdentifier, TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)**
Constructor del `record` privado `ReportedData`, utilizado para agrupar los artefactos clave de una ejecución de prueba para facilitar las aserciones.

| Atributo | Descripción |
|---|---|
| **@param** `testPlan` (TestPlan, requerido): El plan de pruebas que fue ejecutado. |
| **@param** `testIdentifier` (TestIdentifier, requerido): El identificador del nodo raíz (motor) que fue ejecutado. |
| **@param** `testExecutionResult` (TestExecutionResult, requerido): El resultado de la ejecución del nodo raíz. |
| **@param** `startTime` (Instant, requerido): El momento en que comenzó la ejecución. |
| **@param** `finishTime` (Instant, requerido): El momento en que finalizó la ejecución. |

---

### Ejemplo de uso

Dado que `DefaultLauncherTests` es una clase de prueba, no está diseñada para ser utilizada directamente en una aplicación. Sin embargo, su contenido demuestra cómo usar el `DefaultLauncher`, que es el componente bajo prueba. El siguiente ejemplo ilustra el patrón de uso fundamental del JUnit Platform Launcher API, similar a lo que se prueba en esta clase.

```java
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners.TestExecutionSummary;

// Clase de ejemplo con un test (requiere dependencia de JUnit Jupiter API)
class MySampleTest {
    @org.junit.jupiter.api.Test
    void sampleTest() {
        System.out.println("Executing sample test!");
        assert 1 + 1 == 2;
    }
}

public class LauncherExample {

    public static void main(String[] args) {
        // 1. Crear el Launcher. LauncherFactory encontrará los TestEngines
        // disponibles en el classpath (ej. junit-jupiter-engine).
        Launcher launcher = LauncherFactory.create();

        // 2. Crear un listener para recopilar el resumen de la ejecución.
        SummaryGeneratingListener listener = new SummaryGeneratingListener();
        launcher.registerTestExecutionListeners(listener);

        // 3. Construir una solicitud de descubrimiento para encontrar tests.
        // Aquí, le pedimos que encuentre tests en la clase MySampleTest.
        LauncherDiscoveryRequest discoveryRequest = LauncherDiscoveryRequestBuilder.request()
                .selectors(
                    DiscoverySelectors.selectClass(MySampleTest.class)
                )
                .build();

        // 4. Descubrir los tests según la solicitud.
        // El TestPlan es una descripción inmutable de los tests que se ejecutarán.
        TestPlan testPlan = launcher.discover(discoveryRequest);

        // 5. Ejecutar el TestPlan.
        System.out.println("Starting test execution...");
        launcher.execute(testPlan);
        System.out.println("Test execution finished.");

        // 6. Obtener y mostrar el resumen de la ejecución.
        TestExecutionSummary summary = listener.getSummary();
        System.out.println("\n--- Test Execution Summary ---");
        System.out.println("Tests found: " + summary.getTestsFoundCount());
        System.out.println("Tests succeeded: " + summary.getTestsSucceededCount());
        System.out.println("Tests failed: " + summary.getTestsFailedCount());
        summary.printFailuresTo(new java.io.PrintWriter(System.out));
    }
}
```