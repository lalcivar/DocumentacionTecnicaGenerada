Claro, aquí tienes la documentación técnica para la clase `DefaultLauncherTests`.

---

### Documentación Técnica: Clase `DefaultLauncherTests`

#### Descripción General

La clase `DefaultLauncherTests` es una suite de pruebas exhaustiva para la clase `DefaultLauncher` dentro del framework JUnit Platform. La clase `DefaultLauncher` es la implementación por defecto de la interfaz `Launcher`, que actúa como el punto de entrada principal para descubrir y ejecutar pruebas en la plataforma JUnit.

El propósito de esta clase de prueba es verificar el correcto funcionamiento del `DefaultLauncher` en una amplia variedad de escenarios, asegurando su robustez, fiabilidad y conformidad con las especificaciones de la plataforma. Para lograrlo, utiliza intensivamente técnicas de testing como el uso de *mocks* (con la librería Mockito) y *stubs* de `TestEngine` (motores de prueba simulados). Esto permite aislar el comportamiento del lanzador y simular diversas condiciones, incluyendo casos de éxito, fallos controlados y escenarios límite.

En resumen, esta clase no es parte de la API pública para los usuarios finales de JUnit, sino una pieza fundamental del conjunto de pruebas internas que garantiza la calidad y el comportamiento esperado del corazón de JUnit Platform.

---

#### Métodos Principales (o Grupos de Pruebas)

Dado que `DefaultLauncherTests` es una clase de prueba, sus "métodos principales" son los propios casos de prueba (métodos anotados con `@Test`, `@ParameterizedTest`, etc.). Estos se pueden agrupar por la funcionalidad del `DefaultLauncher` que verifican:

##### 1. Pruebas de Configuración y Ciclo de Vida del Launcher
Estos métodos validan la correcta inicialización y las restricciones del `DefaultLauncher`.
*   **`constructLauncherWithoutAnyEngines()`**: Asegura que se lance una excepción si se intenta crear un `Launcher` sin ningún `TestEngine` disponible, ya que no tendría capacidad para descubrir o ejecutar pruebas.
*   **`constructLauncherWithMultipleTestEnginesWithDuplicateIds()`**: Verifica que el sistema detecte y prohíba la configuración de múltiples motores de prueba que compartan el mismo ID, para evitar ambigüedades.
*   **`launcherCanExecuteTestPlanExactlyOnce()`**: Comprueba una regla fundamental del ciclo de vida: un `TestPlan` (plan de ejecución) generado por el `Launcher` solo puede ser ejecutado una única vez. Intentos posteriores deben fallar.

##### 2. Pruebas de la Fase de Descubrimiento (Discovery)
Este grupo de pruebas se centra en la capacidad del `Launcher` para encontrar pruebas según las solicitudes.
*   **`discoverTestPlanForSingleEngine()` y `discoverTestPlanForMultipleEngines()`**: Prueban que el `Launcher` puede delegar correctamente la tarea de descubrimiento a uno o varios `TestEngine` y consolidar los resultados en un único `TestPlan`.
*   **`launcherAppliesPostDiscoveryFilters()`**: Verifica que los filtros `PostDiscoveryFilter` se aplican correctamente después de que los motores han descubierto los tests, permitiendo podar el árbol de pruebas antes de la ejecución.
*   **`discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()`**: Simula un `TestEngine` que falla catastróficamente durante el descubrimiento y comprueba que el `Launcher` maneja el error de forma elegante, reportándolo como un fallo en el `TestPlan`.

##### 3. Pruebas de la Fase de Ejecución (Execution)
Estos métodos validan el comportamiento del `Launcher` cuando ejecuta un `TestPlan`.
*   **`dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`**: Prueba el modo "dry-run" (`-n`). En este modo, el `Launcher` debe reportar todos los tests que *serían* ejecutados como "saltados" (skipped), sin llegar a ejecutar su lógica interna.
*   **`reportsDynamicTestDescriptorsCorrectly()`**: Asegura que el `Launcher` maneja correctamente las pruebas dinámicas, que son aquellas que se registran durante la ejecución de otra prueba o contenedor.
*   **`reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`**: Verifica que si se solicita la cancelación de la ejecución, el `Launcher` detiene el proceso y reporta las pruebas pendientes como "abortadas" o "saltadas".

##### 4. Pruebas de Manejo de Errores y Reportes
Una parte crucial de la suite. Estos tests aseguran que el `Launcher` maneje y reporte adecuadamente los fallos.
*   **`reportsEngineExecutionFailures...()`**: Serie de pruebas que simulan un `TestEngine` que falla en diferentes momentos de la fase de ejecución (antes de empezar, durante, o incluso después de haber reportado éxito). Se comprueba que el `Launcher` captura estas excepciones y las reporta como un fallo de ejecución del motor.
*   **`reportsEngineExecutionFailureForCriticalDiscoveryIssues...()`**: Prueba el manejo de `DiscoveryIssue`, que son problemas no catastróficos reportados por un `TestEngine` durante el descubrimiento. Verifica que si un `DiscoveryIssue` es de severidad crítica (p. ej., `ERROR`), la ejecución de ese motor falla.
*   **`logsNonCriticalIssuesForRegularEngineExecution()`**: Comprueba que los `DiscoveryIssue` no críticos (p. ej., `WARNING` o `INFO`) no impiden la ejecución, sino que simplemente se registran en el log.

##### 5. Pruebas de Configuración y Parámetros
Este grupo valida que los parámetros de configuración se gestionan y aplican correctamente.
*   **`withConfigurationParameters...()`**: Asegura que los parámetros de configuración pasados en la solicitud de ejecución se entregan correctamente al `TestEngine` correspondiente.
*   **`allowsConfiguringCriticalDiscoveryIssueSeverity()`**: Verifica que se puede cambiar el umbral de severidad que se considera "crítico" para los `DiscoveryIssue` a través de un parámetro de configuración.
*   **`failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`**: Prueba el parámetro que permite configurar si un fallo por `DiscoveryIssue` crítico debe ocurrir en la fase de descubrimiento (impidiendo la creación del `TestPlan`) o en la de ejecución.