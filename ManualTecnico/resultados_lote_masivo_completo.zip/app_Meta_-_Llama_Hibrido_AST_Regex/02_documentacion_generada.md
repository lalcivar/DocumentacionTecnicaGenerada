# Documentación Técnica - Módulo `flask.app.Flask`

## 1. Resumen Ejecutivo

El módulo implementa la clase central `Flask` que extiende `sansio.app.App` y materializa una aplicación WSGI completa. Gestiona el ciclo de vida de la petición (contextos de aplicación y de petición, routing, dispatch, manejo de excepciones, hooks `before/after/teardown`), la configuración, el sistema de plantillas Jinja2, el servicio de archivos estáticos y la integración con CLI y testing. Las funciones auxiliares `_make_timedelta`, `remove_ctx` y `add_ctx` proveen compatibilidad y normalización para la evolución de firmas con `AppContext`.

## 2. Especificación de Funciones y Métodos

### 2.1 Funciones a Nivel de Módulo

#### ` _make_timedelta()`

Convierte un valor entero (segundos) o `timedelta` en `timedelta` normalizado.

**Docstring (Google Style):**
```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    """Normaliza un valor a timedelta.

    Args:
        value: Valor a convertir. Puede ser timedelta, int (segundos) o None.

    Returns:
        El mismo timedelta si ya lo es, un nuevo timedelta si es int,
        o None si la entrada es None.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `value` | `timedelta \| int \| None` | Sí | Valor a normalizar. `int` se interpreta como segundos. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `timedelta \| None` | `timedelta \| None` | Timedelta normalizado o `None`. |

| Excepciones | Condición |
|---|---|
| - | No lanza excepciones explícitas. |

---

#### `remove_ctx()`

Decorador de compatibilidad hacia atrás. Elimina el primer argumento `AppContext` si está presente antes de delegar a la implementación antigua.

**Docstring (Google Style):**
```python
def remove_ctx(f: F) -> F:
    """Envuelve una función para eliminar el argumento ctx.

    Args:
        f: Función objetivo con firma antigua (sin ctx).

    Returns:
        Wrapper que descarta AppContext si es el primer argumento posicional.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `Callable[..., Any]` | Sí | Función/método a envolver. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `F` | `Callable` | Wrapper con `update_wrapper` aplicado. |

##### `remove_ctx.wrapper()`

Función anidada/local generada por `remove_ctx`.

```python
def wrapper(self: Flask, *args: Any, **kwargs: Any) -> Any:
    """Wrapper interno de remove_ctx.

    Args:
        self: Instancia Flask.
        *args: Argumentos posicionales, posiblemente con AppContext en args[0].
        **kwargs: Argumentos nominales.

    Returns:
        Resultado de f(self, *args_filtrados, **kwargs).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia. |
| `*args` | `Any` | No | Argumentos; si `args[0]` es `AppContext` se descarta. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

---

#### `add_ctx()`

Decorador inverso a `remove_ctx`. Inyecta el `AppContext` actual si el método base lo requiere y no fue provisto.

**Docstring (Google Style):**
```python
def add_ctx(f: F) -> F:
    """Envuelve una función para inyectar AppContext.

    Args:
        f: Función objetivo con firma nueva (con ctx).

    Returns:
        Wrapper que antepone app_ctx._get_current_object() si es necesario.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `Callable[..., Any]` | Sí | Función con firma nueva. |

##### `add_ctx.wrapper()`

```python
def wrapper(self: Flask, *args: Any, **kwargs: Any) -> Any:
    """Wrapper interno de add_ctx.

    Args:
        self: Instancia Flask.
        *args: Argumentos posicionales.
        **kwargs: Argumentos nominales.

    Returns:
        Resultado de f(self, ctx, *args, **kwargs).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia. |
| `*args` | `Any` | No | Si está vacío o `args[0]` no es `AppContext`, se inyecta el contexto actual. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

---

### 2.2 Clase `Flask`

#### `Flask.__init_subclass__()`

Hook de metaclase que detecta overrides con firma antigua (sin `ctx: AppContext`) y aplica compatibilidad con `DeprecationWarning`.

```python
def __init_subclass__(cls, **kwargs: Any) -> None:
    """Intercepta subclases para compatibilidad de firmas.

    Args:
        **kwargs: Argumentos de clase.

    Raises:
        No lanza, emite DeprecationWarning si detecta firma obsoleta.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `cls` | `type` | Sí | Subclase de `Flask`. |
| `**kwargs` | `Any` | No | Argumentos adicionales de definición de clase. |

| `Raises` | Condición |
|---|---|
| `DeprecationWarning` (warning) | Método sobreescrito sin parámetro `ctx` o anotación `AppContext`. |

Métodos inspeccionados: `handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`.

---

#### `Flask.__init__()`

```python
def __init__(self, import_name: str, static_url_path: str | None = None, static_folder: str | os.PathLike[str] | None = "static", static_host: str | None = None, host_matching: bool = False, subdomain_matching: bool = False, template_folder: str | os.PathLike[str] | None = "templates", instance_path: str | None = None, instance_relative_config: bool = False, root_path: str | None = None) -> None:
    """Inicializa la aplicación Flask.

    Args:
        import_name: Nombre del paquete/módulo de importación.
        static_url_path: Ruta URL para archivos estáticos.
        static_folder: Carpeta de archivos estáticos.
        static_host: Host para la ruta estática (requiere host_matching=True).
        host_matching: Activa matching por host en url_map.
        subdomain_matching: Activa matching por subdominio.
        template_folder: Carpeta de plantillas.
        instance_path: Ruta alternativa de instancia.
        instance_relative_config: Si True, config relativa a instance_path.
        root_path: Ruta raíz manual.

    Raises:
        AssertionError: Si static_host/host_matching es combinación inválida.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `import_name` | `str` | Sí | Nombre de importación. |
| `static_url_path` | `str \| None` | No | Path URL estático. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Directorio estático, default `static`. |
| `static_host` | `str \| None` | No | Host estático. |
| `host_matching` | `bool` | No | Default `False`. |
| `subdomain_matching` | `bool` | No | Default `False`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Default `templates`. |
| `instance_path` | `str \| None` | No | Path instancia. |
| `instance_relative_config` | `bool` | No | Default `False`. |
| `root_path` | `str \| None` | No | Path raíz. |

**Función anidada:** `Flask.__init__.<locals>.<lambda>(**kw)` - callback `view_func` registrado para `endpoint="static"` que delega a `self_ref().send_static_file(**kw)` vía `weakref`.

---

#### `Flask.get_send_file_max_age()`

```python
def get_send_file_max_age(self, filename: str | None) -> int | None:
    """Determina max_age para send_file.

    Args:
        filename: Nombre del archivo o None.

    Returns:
        Segundos de caché o None para peticiones condicionales.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str \| None` | Sí | Nombre de archivo. |

| Retorno | Tipo |
|---|---|
| `int \| None` | Segundos o `None`. |

---

#### `Flask.send_static_file()`

```python
def send_static_file(self, filename: str) -> Response:
    """Sirve archivo desde static_folder.

    Args:
        filename: Ruta relativa dentro de static_folder.

    Returns:
        Response con el archivo.

    Raises:
        RuntimeError: Si has_static_folder es False.
        NotFound: Si el archivo no existe (vía send_from_directory).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str` | Sí | Archivo a servir. |

---

#### `Flask.open_resource()`

```python
def open_resource(self, resource: str, mode: str = "rb", encoding: str | None = None) -> IO[AnyStr]:
    """Abre recurso relativo a root_path solo lectura.

    Args:
        resource: Path relativo a root_path.
        mode: Modo, solo "r", "rt", "rb".
        encoding: Codificación si modo texto.

    Returns:
        Handle de archivo abierto.

    Raises:
        ValueError: Si mode no es de lectura.
        FileNotFoundError: Si no existe.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Recurso relativo. |
| `mode` | `str` | No | Default `rb`. |
| `encoding` | `str \| None` | No | Default `None`. |

---

#### `Flask.open_instance_resource()`

```python
def open_instance_resource(self, resource: str, mode: str = "rb", encoding: str | None = "utf-8") -> IO[AnyStr]:
    """Abre recurso relativo a instance_path (lectura/escritura).

    Args:
        resource: Path relativo a instance_path.
        mode: Modo de apertura.
        encoding: Codificación para modo texto.

    Returns:
        Handle de archivo.

    Raises:
        FileNotFoundError: Si no existe y modo lectura.
        OSError: Errores de IO.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Recurso relativo. |
| `mode` | `str` | No | Default `rb`. |
| `encoding` | `str \| None` | No | Default `utf-8`. |

---

#### `Flask.create_jinja_environment()`

```python
def create_jinja_environment(self) -> Environment:
    """Crea Environment Jinja2 configurado.

    Returns:
        Environment con globals (url_for, get_flashed_messages, config, request, session, g) y política json.dumps_function.
    """
```

---

#### `Flask.create_url_adapter()`

```python
def create_url_adapter(self, request: Request | None) -> MapAdapter | None:
    """Crea adaptador de URLs.

    Args:
        request: Request actual o None (contexto de app).

    Returns:
        MapAdapter vinculado o None si no hay SERVER_NAME fuera de request.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request \| None` | Sí | Request o `None`. |

---

#### `Flask.raise_routing_exception()`

```python
def raise_routing_exception(self, request: Request) -> NoReturn:
    """Intercepta excepciones de routing.

    Args:
        request: Request con routing_exception.

    Raises:
        RequestRedirect | FormDataRoutingRedirect | RoutingException: Siempre relanza.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request` | Sí | Request a inspeccionar. |

---

#### `Flask.update_template_context()`

```python
def update_template_context(self, ctx: AppContext, context: dict[str, Any]) -> None:
    """Inyecta variables de contexto en plantillas.

    Args:
        ctx: AppContext activo.
        context: Diccionario a actualizar in-place.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto de app. |
| `context` | `dict[str, Any]` | Sí | Contexto de plantilla. |

---

#### `Flask.make_shell_context()`

```python
def make_shell_context(self) -> dict[str, Any]:
    """Retorna contexto para shell interactivo.

    Returns:
        Dict con app, g y procesadores registrados.
    """
```

---

#### `Flask.run()`

```python
def run(self, host: str | None = None, port: int | None = None, debug: bool | None = None, load_dotenv: bool = True, **options: Any) -> None:
    """Ejecuta servidor de desarrollo Werkzeug.

    Args:
        host: Hostname, default 127.0.0.1 o SERVER_NAME.
        port: Puerto, default 5000 o SERVER_NAME.
        debug: Override de modo debug.
        load_dotenv: Carga .env/.flaskenv.
        **options: Opciones para werkzeug.serving.run_simple.

    Returns:
        None. No usar en producción.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `host` | `str \| None` | No | Host. |
| `port` | `int \| None` | No | Puerto. |
| `debug` | `bool \| None` | No | Flag debug. |
| `load_dotenv` | `bool` | No | Default `True`. |
| `**options` | `Any` | No | `use_reloader`, `use_debugger`, `threaded`, etc. |

---

#### `Flask.test_client()`

```python
def test_client(self, use_cookies: bool = True, **kwargs: Any) -> FlaskClient:
    """Crea cliente de pruebas.

    Args:
        use_cookies: Habilita cookies.
        **kwargs: Args para test_client_class.

    Returns:
        Instancia FlaskClient.
    """
```

---

#### `Flask.test_cli_runner()`

```python
def test_cli_runner(self, **kwargs: Any) -> FlaskCliRunner:
    """Crea runner CLI para tests.

    Args:
        **kwargs: Args para test_cli_runner_class.

    Returns:
        Instancia FlaskCliRunner.
    """
```

---

#### `Flask.handle_http_exception()`

```python
def handle_http_exception(self, ctx: AppContext, e: HTTPException) -> HTTPException | ResponseReturnValue:
    """Maneja HTTPException.

    Args:
        ctx: AppContext.
        e: Excepción HTTP.

    Returns:
        Respuesta del handler o la excepción original.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `HTTPException` | Sí | Excepción. |

---

#### `Flask.handle_user_exception()`

```python
def handle_user_exception(self, ctx: AppContext, e: Exception) -> HTTPException | ResponseReturnValue:
    """Maneja excepciones de usuario.

    Args:
        ctx: AppContext.
        e: Excepción.

    Returns:
        Valor de respuesta del handler.

    Raises:
        Exception: Si no hay handler registrado, relanza e.
    """
```

---

#### `Flask.handle_exception()`

```python
def handle_exception(self, ctx: AppContext, e: Exception) -> Response:
    """Maneja excepción no controlada (500).

    Args:
        ctx: AppContext.
        e: Excepción original.

    Returns:
        Response finalizada (500 o handler).

    Raises:
        Exception: Si PROPAGATE_EXCEPTIONS es True.
    """
```

---

#### `Flask.log_exception()`

```python
def log_exception(self, ctx: AppContext, exc_info: tuple[type, BaseException, TracebackType] | tuple[None, None, None]) -> None:
    """Loguea excepción.

    Args:
        ctx: AppContext.
        exc_info: Tupla exc_info de sys.exc_info().
    """
```

---

#### `Flask.dispatch_request()`

```python
def dispatch_request(self, ctx: AppContext) -> ResponseReturnValue:
    """Despacha request a view function.

    Args:
        ctx: AppContext.

    Returns:
        Valor de retorno de la vista.

    Raises:
        RequestRedirect | BuildError | KeyError: Errores de routing/vista.
    """
```

---

#### `Flask.full_dispatch_request()`

```python
def full_dispatch_request(self, ctx: AppContext) -> Response:
    """Despacho completo con pre/post-procesamiento.

    Args:
        ctx: AppContext.

    Returns:
        Response finalizada.
    """
```

---

#### `Flask.finalize_request()`

```python
def finalize_request(self, ctx: AppContext, rv: ResponseReturnValue | HTTPException, from_error_handler: bool = False) -> Response:
    """Convierte rv a Response y aplica post-procesamiento.

    Args:
        ctx: AppContext.
        rv: Valor de vista o excepción.
        from_error_handler: Si True, suprime errores en finalización.

    Returns:
        Response procesada.

    Raises:
        Exception: Si falla process_response y from_error_handler es False.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto. |
| `rv` | `ResponseReturnValue \| HTTPException` | Sí | Valor a convertir. |
| `from_error_handler` | `bool` | No | Default `False`. |

---

#### `Flask.make_default_options_response()`

```python
def make_default_options_response(self, ctx: AppContext) -> Response:
    """Crea respuesta OPTIONS por defecto.

    Args:
        ctx: AppContext.

    Returns:
        Response con header Allow.
    """
```

---

#### `Flask.ensure_sync()`

```python
def ensure_sync(self, func: Callable[..., Any]) -> Callable[..., Any]:
    """Asegura ejecución síncrona.

    Args:
        func: Función sync o async.

    Returns:
        Función síncrona (wrapping si era coroutine).
    """
```

---

#### `Flask.async_to_sync()`

```python
def async_to_sync(self, func: Callable[..., Coroutine[Any, Any, Any]]) -> Callable[..., Any]:
    """Convierte coroutine a sync vía asgiref.

    Args:
        func: Función async.

    Returns:
        Función síncrona.

    Raises:
        RuntimeError: Si asgiref no está instalado.
    """
```

---

#### `Flask.url_for()`

```python
def url_for(self, /, endpoint: str, *, _anchor: str | None = None, _method: str | None = None, _scheme: str | None = None, _external: bool | None = None, **values: Any) -> str:
    """Genera URL para endpoint.

    Args:
        endpoint: Nombre del endpoint, con soporte "." relativo a blueprint.
        _anchor: Ancla #anchor.
        _method: Método para selección de regla.
        _scheme: Esquema si _external True.
        _external: Fuerza URL externa/interna.
        **values: Valores para variables de URL y querystring.

    Returns:
        URL generada.

    Raises:
        RuntimeError: Sin request y sin SERVER_NAME.
        ValueError: _scheme con _external=False.
        BuildError: Si handle_url_build_error no resuelve.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `endpoint` | `str` | Sí | Endpoint. |
| `_anchor` | `str \| None` | No | Ancla. |
| `_method` | `str \| None` | No | Método. |
| `_scheme` | `str \| None` | No | Esquema. |
| `_external` | `bool \| None` | No | Externa. |
| `**values` | `Any` | No | Variables URL. |

---

#### `Flask.make_response()`

```python
def make_response(self, rv: ResponseReturnValue) -> Response:
    """Convierte valor de vista a Response.

    Args:
        rv: str, bytes, dict, list, tuple, Response, WSGI callable, iterator.

    Returns:
        Instancia response_class.

    Raises:
        TypeError: Si rv es None o tupla inválida o tipo no soportado.
    """
```

---

#### `Flask.preprocess_request()`

```python
def preprocess_request(self, ctx: AppContext) -> ResponseReturnValue | None:
    """Ejecuta url_value_preprocessors y before_request.

    Args:
        ctx: AppContext.

    Returns:
        Valor de respuesta si un before_request lo retorna, None si continúa.
    """
```

---

#### `Flask.process_response()`

```python
def process_response(self, ctx: AppContext, response: Response) -> Response:
    """Aplica after_request y guarda sesión.

    Args:
        ctx: AppContext.
        response: Response a procesar.

    Returns:
        Response modificada.
    """
```

---

#### `Flask.do_teardown_request()`

```python
def do_teardown_request(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta teardown_request y señal request_tearing_down.

    Args:
        ctx: AppContext.
        exc: Excepción no manejada o None.

    Raises:
        ExceptionGroup | Exception: Errores agregados vía _CollectErrors.
    """
```

---

#### `Flask.do_teardown_appcontext()`

```python
def do_teardown_appcontext(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta teardown_appcontext y señal appcontext_tearing_down.

    Args:
        ctx: AppContext.
        exc: Excepción o None.

    Raises:
        ExceptionGroup | Exception: Errores agregados.
    """
```

---

#### `Flask.app_context()`

```python
def app_context(self) -> AppContext:
    """Crea AppContext.

    Returns:
        AppContext sin pushear.
    """
```

---

#### `Flask.request_context()`

```python
def request_context(self, environ: WSGIEnvironment) -> AppContext:
    """Crea AppContext desde environ WSGI.

    Args:
        environ: Diccionario WSGI.

    Returns:
        AppContext con request.
    """
```

---

#### `Flask.test_request_context()`

```python
def test_request_context(self, *args: Any, **kwargs: Any) -> AppContext:
    """Crea AppContext de prueba vía EnvironBuilder.

    Args:
        *args: Args para EnvironBuilder.
        **kwargs: Kwargs para EnvironBuilder (path, base_url, subdomain, url_scheme, data, json, etc.).

    Returns:
        AppContext de prueba.
    """
```

---

#### `Flask.wsgi_app()`

```python
def wsgi_app(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
    """Aplicación WSGI real.

    Args:
        environ: Entorno WSGI.
        start_response: Callable start_response.

    Returns:
        Iterable de bytes de la respuesta.

    Raises:
        Exception: Relanza si ocurre fuera de handle_exception.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno. |
| `start_response` | `StartResponse` | Sí | Callback WSGI. |

---

#### `Flask.__call__()`

```python
def __call__(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
    """Entry-point WSGI. Delega a wsgi_app.

    Args:
        environ: Entorno WSGI.
        start_response: Callable.

    Returns:
        Iterable de bytes.
    """
```

## 3. Ejemplo de Uso

```python
from flask import Flask, request, jsonify, g

app = Flask(__name__)
app.config.update(
    SERVER_NAME="example.com",
    SECRET_KEY="dev-key",
    SEND_FILE_MAX_AGE_DEFAULT=3600
)

@app.before_request
def before():
    g.start = "preprocess"

@app.route("/hello/<name>", methods=["GET"])
def hello(name: str):
    # Usa url_for, make_response y context processors
    return jsonify(message=f"Hola {name}", via=g.start)

@app.route("/static-test")
def static_test():
    # Demuestra open_resource y send_static_file
    with app.open_resource("static/data.txt", mode="r", encoding="utf-8") as f:
        content = f.read()
    return app.make_response((content, 200, {"Content-Type": "text/plain"}))

# Uso fuera de request: url_for y app_context
with app.app_context():
    url = app.url_for("hello", name="mundo", _external=True)
    print(url)  # https://example.com/hello/mundo

# Testing con test_client y test_request_context
with app.test_client() as client:
    rv = client.get("/hello/mundo")
    assert rv.status_code == 200
    assert rv.json["message"] == "Hola mundo"

with app.test_request_context("/hello/test?x=1"):
    assert request.args["x"] == "1"
    assert request.endpoint == "hello"

# WSGI y CLI runner
wsgi = app.wsgi_app  # Puede envolverse con middleware
runner = app.test_cli_runner()
# runner.invoke(args=["routes"])

if __name__ == "__main__":
    # No se ejecuta si FLASK_RUN_FROM_CLI=true
    app.run(host="127.0.0.1", port=5000, debug=True)
```
