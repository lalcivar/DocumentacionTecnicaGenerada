# Documentación Técnica - Módulo `Flask` (`flask/app.py`)

## 1. Resumen Ejecutivo

Este módulo implementa la clase central `Flask`, que extiende `sansio.app.App` para proporcionar una aplicación WSGI completa. Actúa como registro central para rutas, vistas, manejo de errores, contextos de aplicación/petición, gestión de sesiones, integración con Jinja2 y CLI de Click. El módulo también provee utilidades de compatibilidad para la migración de firmas con `AppContext` (`remove_ctx`, `add_ctx`) y helpers de configuración como `_make_timedelta`.

---

## 2. Especificación de Funciones y Métodos

### 2.1 Funciones a Nivel de Módulo

#### ` _make_timedelta()`

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    """Convierte un valor entero o timedelta a timedelta.

    Args:
        value: Valor a convertir. Si es None o timedelta se retorna
            sin cambios. Si es int se interpreta como segundos.

    Returns:
        Instancia de timedelta o None si la entrada fue None.

    Raises:
        TypeError: Si el valor no es None, int o timedelta (implícito por timedelta).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `value` | `timedelta \| int \| None` | Sí | Valor a normalizar a `timedelta`. Enteros se convierten a segundos. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `timedelta \| None` | `timedelta \| None` | `timedelta` normalizado o `None`. |

| Excepciones | Condición |
|---|---|
| - | No lanza excepciones explícitas. |

---

#### `remove_ctx()`

```python
def remove_ctx(f: F) -> F:
    """Decorador para compatibilidad con firmas antiguas sin `ctx`.

    Elimina el primer argumento si es una instancia de `AppContext`
    antes de delegar a la función original. Usado para envolver
    métodos sobreescritos en subclases que aún no adoptan la nueva firma.

    Args:
        f: Función a envolver (método de instancia de Flask).

    Returns:
        Función envuelta con `functools.update_wrapper` aplicado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Función/método original a envolver. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `F` | `Callable` | Wrapper que filtra `AppContext` de `args`. |

| Excepciones | Condición |
|---|---|
| - | No lanza. |

---

#### `add_ctx()`

```python
def add_ctx(f: F) -> F:
    """Decorador para inyectar `AppContext` en métodos base.

    Asegura que el primer argumento posicional sea el `AppContext`
    actual (`app_ctx._get_current_object()`). Si no hay argumentos
    o el primero no es `AppContext`, lo antepone.

    Args:
        f: Función base de `Flask` a envolver.

    Returns:
        Función envuelta que garantiza `ctx` como primer argumento.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método base de `Flask` que requiere `ctx`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `F` | `Callable` | Wrapper que inyecta `AppContext`. |

| Excepciones | Condición |
|---|---|
| - | No lanza. |

---

### 2.2 Funciones Anidadas / Locales

#### `remove_ctx.wrapper()`

```python
def wrapper(self: Flask, *args: t.Any, **kwargs: t.Any) -> t.Any:
    """Wrapper interno de `remove_ctx`.

    Args:
        self: Instancia de Flask.
        *args: Argumentos posicionales, posiblemente con `AppContext` al inicio.
        **kwargs: Argumentos nominales.

    Returns:
        Resultado de invocar `f` sin el `AppContext` inicial si existía.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `Any` | No | Argumentos posicionales. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `Any` | `Any` | Valor retornado por `f`. |

#### `add_ctx.wrapper()`

```python
def wrapper(self: Flask, *args: t.Any, **kwargs: t.Any) -> t.Any:
    """Wrapper interno de `add_ctx`.

    Args:
        self: Instancia de Flask.
        *args: Argumentos posicionales, sin garantía de contener `AppContext`.
        **kwargs: Argumentos nominales.

    Returns:
        Resultado de invocar `f` con `AppContext` actual inyectado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `Any` | No | Argumentos posicionales. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `Any` | `Any` | Valor retornado por `f`. |

---

### 2.3 Métodos de la Clase `Flask`

#### `Flask.__init_subclass__()`

```python
@classmethod
def __init_subclass__(cls, **kwargs: t.Any) -> None:
    """Detecta métodos sobreescritos con firma antigua y aplica compatibilidad.

    Inspecciona 12 métodos críticos (`handle_http_exception`, `handle_user_exception`,
    `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`,
    `finalize_request`, `make_default_options_response`, `preprocess_request`,
    `process_response`, `do_teardown_request`, `do_teardown_appcontext`).
    Si el segundo parámetro no es `ctx: AppContext`, emite `DeprecationWarning`
    y envuelve el método con `remove_ctx`/`add_ctx`.

    Args:
        **kwargs: Argumentos de creación de subclase.

    Returns:
        None

    Raises:
        DeprecationWarning: Vía `warnings.warn` si se detecta firma obsoleta.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `cls` | `type` | Sí | Subclase de `Flask` en creación. |
| `**kwargs` | `Any` | No | Argumentos adicionales de subclase. |

#### `Flask.__init__()`

```python
def __init__(
    self,
    import_name: str,
    static_url_path: str | None = None,
    static_folder: str | os.PathLike[str] | None = "static",
    static_host: str | None = None,
    host_matching: bool = False,
    subdomain_matching: bool = False,
    template_folder: str | os.PathLike[str] | None = "templates",
    instance_path: str | None = None,
    instance_relative_config: bool = False,
    root_path: str | None = None,
) -> None:
    """Inicializa la aplicación Flask y registra la ruta estática.

    Args:
        import_name: Nombre del paquete/módulo de la aplicación.
        static_url_path: Ruta URL para archivos estáticos.
        static_folder: Carpeta de archivos estáticos relativa a `root_path`.
        static_host: Host para la ruta estática (requerido si `host_matching=True`).
        host_matching: Habilita `url_map.host_matching`.
        subdomain_matching: Habilita matching por subdominio.
        template_folder: Carpeta de plantillas.
        instance_path: Ruta alternativa de instancia.
        instance_relative_config: Si True, config relativa a `instance_path`.
        root_path: Ruta raíz de archivos de la app.

    Returns:
        None

    Raises:
        AssertionError: Si `bool(static_host) != host_matching` cuando hay `static_folder`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `import_name` | `str` | Sí | Nombre de importación. |
| `static_url_path` | `str \| None` | No | Prefijo URL estático. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Directorio estático. Default `static`. |
| `static_host` | `str \| None` | No | Host estático. |
| `host_matching` | `bool` | No | Default `False`. |
| `subdomain_matching` | `bool` | No | Default `False`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Default `templates`. |
| `instance_path` | `str \| None` | No | Ruta instancia. |
| `instance_relative_config` | `bool` | No | Default `False`. |
| `root_path` | `str \| None` | No | Ruta raíz. |

#### `Flask.get_send_file_max_age()`

```python
def get_send_file_max_age(self, filename: str | None) -> int | None:
    """Determina el valor `max_age` para caché de `send_file`.

    Args:
        filename: Nombre del archivo solicitado.

    Returns:
        Segundos de caché como int, o None para usar peticiones condicionales.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str \| None` | Sí | Nombre del archivo. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `int \| None` | `int \| None` | Segundos o `None`. |

#### `Flask.send_static_file()`

```python
def send_static_file(self, filename: str) -> Response:
    """Sirve un archivo desde `static_folder`.

    Args:
        filename: Ruta relativa dentro de `static_folder`.

    Returns:
        Objeto `Response` con el archivo.

    Raises:
        RuntimeError: Si `has_static_folder` es False.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str` | Sí | Archivo a servir. |

#### `Flask.open_resource()`

```python
def open_resource(
    self, resource: str, mode: str = "rb", encoding: str | None = None
) -> t.IO[t.AnyStr]:
    """Abre un recurso relativo a `root_path` solo para lectura.

    Args:
        resource: Ruta relativa a `root_path`.
        mode: Modo de apertura. Solo `r`, `rt`, `rb`.
        encoding: Codificación para modo texto.

    Returns:
        Handle de archivo abierto.

    Raises:
        ValueError: Si `mode` no es `r`, `rt` o `rb`.
        FileNotFoundError: Si el recurso no existe.
        OSError: Errores de E/S.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `resource` | `str` | Sí | Ruta relativa. |
| `mode` | `str` | No | Default `rb`. |
| `encoding` | `str \| None` | No | Default `None`. |

#### `Flask.open_instance_resource()`

```python
def open_instance_resource(
    self, resource: str, mode: str = "rb", encoding: str | None = "utf-8"
) -> t.IO[t.AnyStr]:
    """Abre un recurso relativo a `instance_path` (lectura/escritura).

    Args:
        resource: Ruta relativa a `instance_path`.
        mode: Modo de apertura (cualquiera válido para `open`).
        encoding: Codificación para modo texto. Default `utf-8`.

    Returns:
        Handle de archivo abierto.

    Raises:
        FileNotFoundError: Si el recurso no existe en lectura.
        OSError: Errores de E/S.
    """
```

#### `Flask.create_jinja_environment()`

```python
def create_jinja_environment(self) -> Environment:
    """Crea el entorno Jinja2 configurado para la app.

    Returns:
        Entorno Jinja2 con globals (`url_for`, `get_flashed_messages`,
        `config`, `request`, `session`, `g`) y política `json.dumps_function`.
    """
```

#### `Flask.create_url_adapter()`

```python
def create_url_adapter(self, request: Request | None) -> MapAdapter | None:
    """Crea un adaptador de URLs para el request dado.

    Args:
        request: Request actual o None para contexto fuera de request.

    Returns:
        `MapAdapter` vinculado al environ o a `SERVER_NAME`, o None si no hay
        `SERVER_NAME` fuera de request.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request \| None` | Sí | Request actual. |

#### `Flask.raise_routing_exception()`

```python
def raise_routing_exception(self, request: Request) -> t.NoReturn:
    """Intercepta excepciones de ruteo en modo debug.

    Args:
        request: Request que contiene `routing_exception`.

    Returns:
        No retorna (NoReturn).

    Raises:
        RequestRedirect: Original si no aplica interceptación.
        FormDataRoutingRedirect: Si es redirect con body descartable en debug.
    """
```

#### `Flask.update_template_context()`

```python
def update_template_context(
    self, ctx: AppContext, context: dict[str, t.Any]
) -> None:
    """Actualiza el contexto de plantillas con procesadores registrados.

    Args:
        ctx: Contexto de aplicación activo.
        context: Diccionario de contexto a actualizar in-place.

    Returns:
        None
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto de app. |
| `context` | `dict[str, Any]` | Sí | Contexto a mutar. |

#### `Flask.make_shell_context()`

```python
def make_shell_context(self) -> dict[str, t.Any]:
    """Ejecuta procesadores de contexto shell.

    Returns:
        Diccionario con `app`, `g` y valores de `shell_context_processors`.
    """
```

#### `Flask.run()`

```python
def run(
    self,
    host: str | None = None,
    port: int | None = None,
    debug: bool | None = None,
    load_dotenv: bool = True,
    **options: t.Any,
) -> None:
    """Ejecuta servidor de desarrollo Werkzeug.

    Args:
        host: Hostname. Default `127.0.0.1` o `SERVER_NAME`.
        port: Puerto. Default `5000` o puerto de `SERVER_NAME`.
        debug: Habilita/deshabilita debug. Sobrescribe config.
        load_dotenv: Carga `.env` y `.flaskenv` si True.
        **options: Opciones para `werkzeug.serving.run_simple`.

    Returns:
        None
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `host` | `str \| None` | No | Host. |
| `port` | `int \| None` | No | Puerto. |
| `debug` | `bool \| None` | No | Flag debug. |
| `load_dotenv` | `bool` | No | Default `True`. |
| `**options` | `Any` | No | Opciones Werkzeug. |

#### `Flask.test_client()`

```python
def test_client(self, use_cookies: bool = True, **kwargs: t.Any) -> FlaskClient:
    """Crea un cliente de pruebas WSGI.

    Args:
        use_cookies: Si True habilita manejo de cookies.
        **kwargs: Argumentos para `test_client_class`.

    Returns:
        Instancia de `FlaskClient`.
    """
```

#### `Flask.test_cli_runner()`

```python
def test_cli_runner(self, **kwargs: t.Any) -> FlaskCliRunner:
    """Crea un runner CLI para pruebas.

    Args:
        **kwargs: Argumentos para `test_cli_runner_class`.

    Returns:
        Instancia de `FlaskCliRunner`.
    """
```

#### `Flask.handle_http_exception()`

```python
def handle_http_exception(
    self, ctx: AppContext, e: HTTPException
) -> HTTPException | ft.ResponseReturnValue:
    """Maneja una `HTTPException` vía handlers registrados.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción HTTP.

    Returns:
        Respuesta del handler o la excepción original si no hay handler.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `HTTPException` | Sí | Excepción. |

#### `Flask.handle_user_exception()`

```python
def handle_user_exception(
    self, ctx: AppContext, e: Exception
) -> HTTPException | ft.ResponseReturnValue:
    """Maneja excepciones de usuario, delegando a `handle_http_exception` si aplica.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción capturada.

    Returns:
        Valor de respuesta del handler.

    Raises:
        Exception: Re-lanza `e` si no hay handler registrado.
    """
```

#### `Flask.handle_exception()`

```python
def handle_exception(self, ctx: AppContext, e: Exception) -> Response:
    """Maneja excepciones no capturadas generando 500.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción no manejada.

    Returns:
        `Response` finalizada (500 o del handler de 500).

    Raises:
        Exception: Si `PROPAGATE_EXCEPTIONS` es True (testing/debug).
    """
```

#### `Flask.log_exception()`

```python
def log_exception(
    self,
    ctx: AppContext,
    exc_info: tuple[type, BaseException, TracebackType] | tuple[None, None, None],
) -> None:
    """Registra una excepción en `logger.error`.

    Args:
        ctx: Contexto de aplicación.
        exc_info: Tupla `sys.exc_info()`.

    Returns:
        None
    """
```

#### `Flask.dispatch_request()`

```python
def dispatch_request(self, ctx: AppContext) -> ft.ResponseReturnValue:
    """Despacha la petición a la view function correspondiente.

    Args:
        ctx: Contexto de aplicación con `request` poblado.

    Returns:
        Valor de retorno de la view (no necesariamente `Response`).

    Raises:
        RequestRedirect | BuildError: Vía `raise_routing_exception`.
        KeyError: Si `endpoint` no existe en `view_functions`.
    """
```

#### `Flask.full_dispatch_request()`

```python
def full_dispatch_request(self, ctx: AppContext) -> Response:
    """Despacho completo con pre/post-procesamiento y manejo de errores.

    Args:
        ctx: Contexto de aplicación.

    Returns:
        `Response` finalizada lista para WSGI.
    """
```

#### `Flask.finalize_request()`

```python
def finalize_request(
    self,
    ctx: AppContext,
    rv: ft.ResponseReturnValue | HTTPException,
    from_error_handler: bool = False,
) -> Response:
    """Convierte `rv` en `Response` y ejecuta post-procesamiento.

    Args:
        ctx: Contexto de aplicación.
        rv: Valor de retorno de view o excepción HTTP.
        from_error_handler: Si True, suprime errores en finalización y solo loguea.

    Returns:
        `Response` procesada.

    Raises:
        Exception: Si `process_response` falla y `from_error_handler` es False.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto. |
| `rv` | `ResponseReturnValue \| HTTPException` | Sí | Valor a convertir. |
| `from_error_handler` | `bool` | No | Default `False`. |

#### `Flask.make_default_options_response()`

```python
def make_default_options_response(self, ctx: AppContext) -> Response:
    """Crea respuesta por defecto para método OPTIONS.

    Args:
        ctx: Contexto con `url_adapter`.

    Returns:
        `Response` con header `Allow` poblado.
    """
```

#### `Flask.ensure_sync()`

```python
def ensure_sync(self, func: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Garantiza que la función sea síncrona para workers WSGI.

    Args:
        func: Función posiblemente `async def`.

    Returns:
        Función síncrona (original si ya lo era, o envuelta vía `async_to_sync`).
    """
```

#### `Flask.async_to_sync()`

```python
def async_to_sync(
    self, func: t.Callable[..., t.Coroutine[t.Any, t.Any, t.Any]]
) -> t.Callable[..., t.Any]:
    """Convierte una corrutina en función síncrona.

    Args:
        func: Función `async def`.

    Returns:
        Función síncrona que ejecuta la corrutina.

    Raises:
        RuntimeError: Si `asgiref` no está instalado.
    """
```

#### `Flask.url_for()`

```python
def url_for(
    self,
    /,
    endpoint: str,
    *,
    _anchor: str | None = None,
    _method: str | None = None,
    _scheme: str | None = None,
    _external: bool | None = None,
    **values: t.Any,
) -> str:
    """Genera URL para un endpoint.

    Args:
        endpoint: Nombre del endpoint (prefijo `.` para relativo a blueprint).
        _anchor: Ancla a añadir como `#anchor`.
        _method: Método HTTP para selección de regla.
        _scheme: Esquema (`http`, `https`) para URLs externas.
        _external: Si True fuerza URL externa; si False fuerza interna.
        **values: Valores para partes variables de la URL y query string.

    Returns:
        URL generada como string.

    Raises:
        RuntimeError: Si se llama fuera de request sin `SERVER_NAME`.
        ValueError: Si `_scheme` se especifica con `_external=False`.
        BuildError: Si no se puede construir la URL (delegado a `handle_url_build_error`).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `endpoint` | `str` | Sí | Endpoint. |
| `_anchor` | `str \| None` | No | Ancla. |
| `_method` | `str \| None` | No | Método. |
| `_scheme` | `str \| None` | No | Esquema. |
| `_external` | `bool \| None` | No | Externa/interna. |
| `**values` | `Any` | No | Variables de URL. |

#### `Flask.make_response()`

```python
def make_response(self, rv: ft.ResponseReturnValue) -> Response:
    """Convierte el valor de retorno de una view en `Response`.

    Args:
        rv: Valor de retorno. Tipos permitidos: `str`, `bytes`, `bytearray`,
            `dict`, `list`, `Iterator`, `tuple` (body,status,headers),
            `Response`, WSGI callable.

    Returns:
        Instancia de `response_class`.

    Raises:
        TypeError: Si `rv` es None, tupla de tamaño inválido o tipo no soportado.
    """
```

#### `Flask.preprocess_request()`

```python
def preprocess_request(self, ctx: AppContext) -> ft.ResponseReturnValue | None:
    """Ejecuta `url_value_preprocessors` y `before_request_funcs`.

    Args:
        ctx: Contexto de aplicación.

    Returns:
        Valor de respuesta si un `before_request` lo retorna, o None para continuar.
    """
```

#### `Flask.process_response()`

```python
def process_response(self, ctx: AppContext, response: Response) -> Response:
    """Aplica `after_request` y guarda sesión.

    Args:
        ctx: Contexto de aplicación.
        response: Respuesta a procesar.

    Returns:
        Respuesta modificada.
    """
```

#### `Flask.do_teardown_request()`

```python
def do_teardown_request(
    self, ctx: AppContext, exc: BaseException | None = None
) -> None:
    """Ejecuta funciones `teardown_request` y señal `request_tearing_down`.

    Args:
        ctx: Contexto de aplicación.
        exc: Excepción no manejada durante el despacho, o None.

    Returns:
        None

    Raises:
        Exception: Agregada vía `_CollectErrors.raise_any` si algún teardown falla.
    """
```

#### `Flask.do_teardown_appcontext()`

```python
def do_teardown_appcontext(
    self, ctx: AppContext, exc: BaseException | None = None
) -> None:
    """Ejecuta funciones `teardown_appcontext` y señal `appcontext_tearing_down`.

    Args:
        ctx: Contexto de aplicación.
        exc: Excepción activa durante el contexto, o None.

    Returns:
        None

    Raises:
        Exception: Agregada vía `_CollectErrors.raise_any` si algún teardown falla.
    """
```

#### `Flask.app_context()`

```python
def app_context(self) -> AppContext:
    """Crea un `AppContext` sin request.

    Returns:
        Nuevo `AppContext` asociado a `self`.
    """
```

#### `Flask.request_context()`

```python
def request_context(self, environ: WSGIEnvironment) -> AppContext:
    """Crea un `AppContext` con información de request desde environ WSGI.

    Args:
        environ: Diccionario WSGI `environ`.

    Returns:
        `AppContext` poblado con `Request`.
    """
```

#### `Flask.test_request_context()`

```python
def test_request_context(self, *args: t.Any, **kwargs: t.Any) -> AppContext:
    """Crea un `AppContext` de prueba vía `EnvironBuilder`.

    Args:
        *args: Argumentos posicionales para `EnvironBuilder`.
        **kwargs: Argumentos nominales para `EnvironBuilder` (`path`, `base_url`,
            `subdomain`, `url_scheme`, `data`, `json`, etc.).

    Returns:
        `AppContext` de prueba.
    """
```

#### `Flask.wsgi_app()`

```python
def wsgi_app(
    self, environ: WSGIEnvironment, start_response: StartResponse
) -> cabc.Iterable[bytes]:
    """Aplicación WSGI real. Gestiona ciclo de vida del contexto.

    Args:
        environ: Entorno WSGI.
        start_response: Callable WSGI `start_response(status, headers, exc_info)`.

    Returns:
        Iterable de bytes de la respuesta.

    Raises:
        Exception: Re-lanza excepciones no manejadas tras `handle_exception`.
    """
```

#### `Flask.__call__()`

```python
def __call__(
    self, environ: WSGIEnvironment, start_response: StartResponse
) -> cabc.Iterable[bytes]:
    """Entrada WSGI. Delega a `wsgi_app`.

    Args:
        environ: Entorno WSGI.
        start_response: Callable `start_response`.

    Returns:
        Iterable de bytes de la respuesta.
    """
```

---

## 3. Ejemplo de Uso

```python
from flask import Flask, request, jsonify, url_for

# 1. Creación de la aplicación
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SERVER_NAME"] = "example.com"
app.config["SECRET_KEY"] = "dev-secret"

# 2. Definición de rutas y uso de url_for
@app.route("/hello/<name>", methods=["GET"])
def hello(name: str):
    # url_for genera URLs internas/externas según contexto
    profile_url = url_for("hello", name=name, _external=False)
    return jsonify(message=f"Hola {name}", url=profile_url)

@app.route("/data", methods=["POST"])
def create_data():
    data = request.get_json()
    # make_response convierte dict/list/tupla automáticamente
    return {"received": data}, 201

# 3. Contextos manuales y recursos
with app.app_context():
    # open_resource lee relativo a root_path
    try:
        with app.open_resource("schema.sql", mode="r", encoding="utf-8") as f:
            schema = f.read()
    except FileNotFoundError:
        schema = "-- no schema --"

# 4. Testing con test_client y test_request_context
with app.test_client() as client:
    rv = client.get("/hello/Mundo")
    assert rv.status_code == 200
    assert rv.json["message"] == "Hola Mundo"

with app.test_request_context("/hello/Test?lang=es"):
    assert request.path == "/hello/Test"
    assert request.args["lang"] == "es"
    generated = url_for("hello", name="Test", _anchor="top")
    assert generated == "/hello/Test#top"

# 5. WSGI y ejecución
# app.wsgi_app puede envolverse con middleware:
# app.wsgi_app = MyMiddleware(app.wsgi_app)

if __name__ == "__main__":
    # run() ignora la llamada si FLASK_RUN_FROM_CLI=true
    app.run(host="127.0.0.1", port=5000, debug=True)
```
