# Documentación Técnica - Módulo `flask.app` (Clase `Flask`)

## 1. Resumen Ejecutivo

El módulo implementa la clase central `Flask`, que extiende `sansio.app.App` y constituye la aplicación WSGI principal del framework. Actúa como registro central para rutas, vistas, configuración, manejo de sesiones, contexto de aplicación/petición, sistema de plantillas Jinja2 y CLI. Gestiona el ciclo de vida completo de la petición: enrutamiento, despacho, manejo de excepciones, pre/post-procesamiento y generación de respuestas WSGI.

---

## 2. Especificación de Funciones y Métodos

### 2.1 Funciones a Nivel de Módulo

#### ` _make_timedelta()`

Convierte un valor entero (segundos) o `timedelta` en un objeto `timedelta` normalizado.

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    """Convierte un valor a timedelta.

    Args:
        value (timedelta | int | None): Valor a convertir. Si es int se
            interpreta como segundos. Si es None o timedelta se retorna tal cual.

    Returns:
        timedelta | None: Objeto timedelta resultante o None si la entrada es None.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `value` | `timedelta \| int \| None` | Sí | Valor a normalizar. `int` se convierte a segundos. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `timedelta \| None` | `timedelta \| None` | `timedelta` normalizado o `None`. |

| Excepciones | Condición |
| :--- | :--- |
| No lanza | - |

---

#### `remove_ctx()`

Decorador de compatibilidad. Elimina el primer argumento `AppContext` si está presente antes de delegar a la función original. Usado para soportar subclases con firma antigua sin `ctx`.

```python
def remove_ctx(f: F) -> F:
    """Envuelve una función eliminando el argumento ctx si es AppContext.

    Args:
        f (F): Función a envolver, típicamente un método de Flask con firma antigua.

    Returns:
        F: Función envuelta con `functools.update_wrapper` aplicado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `f` | `F` (`Callable[..., Any]`) | Sí | Función objetivo a envolver. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `F` | `Callable` | Wrapper que filtra `AppContext` de `*args`. |

| Excepciones | Condición |
| :--- | :--- |
| No lanza | - |

##### `remove_ctx.wrapper()`

Función anidada/local generada por `remove_ctx()`.

```python
def wrapper(self: Flask, *args: Any, **kwargs: Any) -> Any:
    """Wrapper interno de remove_ctx.

    Args:
        self (Flask): Instancia de la aplicación.
        *args (Any): Argumentos posicionales. Si args[0] es AppContext, se descarta.
        **kwargs (Any): Argumentos nominales.

    Returns:
        Any: Retorno de `f(self, *args_filtrados, **kwargs)`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Flask` | Sí | Instancia. |
| `*args` | `Any` | No | Argumentos posicionales. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Any` | `Any` | Resultado de la función original. |

---

#### `add_ctx()`

Decorador inverso a `remove_ctx`. Inyecta el `AppContext` actual (`app_ctx._get_current_object()`) como primer argumento si no está presente. Permite que el método base llame a `super()` sin `ctx` explícito.

```python
def add_ctx(f: F) -> F:
    """Envuelve una función inyectando el AppContext actual si falta.

    Args:
        f (F): Función a envolver, típicamente un método base de Flask.

    Returns:
        F: Función envuelta que asegura `ctx` como primer argumento.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `f` | `F` (`Callable[..., Any]`) | Sí | Función objetivo. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `F` | `Callable` | Wrapper que inyecta `AppContext`. |

| Excepciones | Condición |
| :--- | :--- |
| No lanza | - |

##### `add_ctx.wrapper()`

Función anidada/local generada por `add_ctx()`.

```python
def wrapper(self: Flask, *args: Any, **kwargs: Any) -> Any:
    """Wrapper interno de add_ctx.

    Args:
        self (Flask): Instancia de la aplicación.
        *args (Any): Argumentos posicionales. Si está vacío o args[0] no es AppContext, se antepone el contexto actual.
        **kwargs (Any): Argumentos nominales.

    Returns:
        Any: Retorno de `f(self, ctx, *args, **kwargs)`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Flask` | Sí | Instancia. |
| `*args` | `Any` | No | Argumentos posicionales. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Any` | `Any` | Resultado de la función original. |

---

### 2.2 Métodos de la Clase `Flask`

#### `Flask.__init_subclass__()`

Hook de metaclase que detecta métodos sobreescritos con firma antigua (sin `ctx: AppContext`) y aplica compatibilidad. Emite `DeprecationWarning` y envuelve métodos.

```python
@classmethod
def __init_subclass__(cls, **kwargs: Any) -> None:
    """Detecta firmas deprecadas y aplica wrappers de compatibilidad.

    Args:
        **kwargs (Any): Argumentos de clase.

    Returns:
        None:

    Raises:
        DeprecationWarning: Si un método sobreescrito no incluye `ctx: AppContext` como segundo parámetro.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `cls` | `type` | Sí | Subclase de `Flask` que se está definiendo. |
| `**kwargs` | `Any` | No | Argumentos adicionales de definición de clase. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | No retorna valor. |

| Excepciones | Condición |
| :--- | :--- |
| `DeprecationWarning` | Método sobreescrito sin parámetro `ctx` o anotación `AppContext`. |

#### `Flask.__init__()`

Constructor de la aplicación. Inicializa `App` base, configura `self.cli` (`click.AppGroup`) y registra la ruta estática si `has_static_folder` es `True`.

```python
def __init__(self, import_name: str, static_url_path: str | None = None, static_folder: str | os.PathLike[str] | None = "static", static_host: str | None = None, host_matching: bool = False, subdomain_matching: bool = False, template_folder: str | os.PathLike[str] | None = "templates", instance_path: str | None = None, instance_relative_config: bool = False, root_path: str | None = None) -> None:
    """Inicializa la aplicación Flask.

    Args:
        import_name (str): Nombre del paquete/módulo de importación.
        static_url_path (str | None): Ruta URL para archivos estáticos.
        static_folder (str | os.PathLike[str] | None): Carpeta de archivos estáticos.
        static_host (str | None): Host para la ruta estática (requerido si host_matching=True).
        host_matching (bool): Habilita matching por host en url_map.
        subdomain_matching (bool): Habilita matching por subdominio.
        template_folder (str | os.PathLike[str] | None): Carpeta de plantillas.
        instance_path (str | None): Ruta alternativa de instancia.
        instance_relative_config (bool): Si True, config relativa a instance_path.
        root_path (str | None): Ruta raíz de la aplicación.

    Returns:
        None:

    Raises:
        AssertionError: Si `static_host` y `host_matching` son inconsistentes.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `import_name` | `str` | Sí | Nombre de importación. |
| `static_url_path` | `str \| None` | No | Path URL estático. Default `None`. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta estática. Default `"static"`. |
| `static_host` | `str \| None` | No | Host estático. Default `None`. |
| `host_matching` | `bool` | No | Default `False`. |
| `subdomain_matching` | `bool` | No | Default `False`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Default `"templates"`. |
| `instance_path` | `str \| None` | No | Default `None`. |
| `instance_relative_config` | `bool` | No | Default `False`. |
| `root_path` | `str \| None` | No | Default `None`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | - |

| Excepciones | Condición |
| :--- | :--- |
| `AssertionError` | `bool(static_host) != host_matching` cuando `has_static_folder` es `True`. |

##### `Flask.__init__.<lambda>()`

Función anidada/local (callback) registrada como `view_func` para la ruta estática `"<static_url_path>/<path:filename>"`. Usa `weakref` para evitar ciclos de referencia.

```python
lambda **kw: self_ref().send_static_file(**kw)
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `**kw` | `Any` | Sí | Debe contener `filename: str`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Resultado de `send_static_file`. |

| Excepciones | Condición |
| :--- | :--- |
| `RuntimeError` | Si `static_folder` no está configurado. |

#### `Flask.get_send_file_max_age()`

Determina el valor `max_age` para caché de `send_file`.

```python
def get_send_file_max_age(self, filename: str | None) -> int | None:
    """Obtiene max_age para un archivo.

    Args:
        filename (str | None): Nombre del archivo.

    Returns:
        int | None: Segundos de caché o None para peticiones condicionales.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| None` | Sí | Nombre del archivo. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `int \| None` | `int \| None` | Segundos o `None`. |

#### `Flask.send_static_file()`

View function que sirve archivos desde `static_folder` vía `send_from_directory`.

```python
def send_static_file(self, filename: str) -> Response:
    """Sirve un archivo estático.

    Args:
        filename (str): Ruta relativa dentro de static_folder.

    Returns:
        Response: Respuesta con el archivo.

    Raises:
        RuntimeError: Si `has_static_folder` es False.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str` | Sí | Nombre del archivo. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Respuesta de archivo. |

| Excepciones | Condición |
| :--- | :--- |
| `RuntimeError` | `static_folder` no configurado. |

#### `Flask.open_resource()`

Abre un recurso relativo a `root_path` solo en modo lectura.

```python
def open_resource(self, resource: str, mode: str = "rb", encoding: str | None = None) -> IO[AnyStr]:
    """Abre un recurso del paquete.

    Args:
        resource (str): Ruta relativa a root_path.
        mode (str): Modo, solo "r", "rt", "rb". Defaults "rb".
        encoding (str | None): Codificación para modo texto.

    Returns:
        IO[AnyStr]: Handle del archivo.

    Raises:
        ValueError: Si mode no es de lectura.
        FileNotFoundError: Si el recurso no existe.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `resource` | `str` | Sí | Ruta relativa. |
| `mode` | `str` | No | Default `"rb"`. |
| `encoding` | `str \| None` | No | Default `None`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `IO[AnyStr]` | `IO` | Descriptor de archivo. |

| Excepciones | Condición |
| :--- | :--- |
| `ValueError` | `mode` no está en `{"r", "rt", "rb"}`. |

#### `Flask.open_instance_resource()`

Abre un recurso relativo a `instance_path`, permite lectura y escritura.

```python
def open_instance_resource(self, resource: str, mode: str = "rb", encoding: str | None = "utf-8") -> IO[AnyStr]:
    """Abre un recurso de la carpeta instance.

    Args:
        resource (str): Ruta relativa a instance_path.
        mode (str): Modo de apertura. Defaults "rb".
        encoding (str | None): Codificación para modo texto. Defaults "utf-8".

    Returns:
        IO[AnyStr]: Handle del archivo.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `resource` | `str` | Sí | Ruta relativa. |
| `mode` | `str` | No | Default `"rb"`. |
| `encoding` | `str \| None` | No | Default `"utf-8"`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `IO[AnyStr]` | `IO` | Descriptor de archivo. |

#### `Flask.create_jinja_environment()`

Crea y configura el `Environment` de Jinja2 con `jinja_options`, `autoescape`, `auto_reload` y globales de Flask.

```python
def create_jinja_environment(self) -> Environment:
    """Crea el entorno Jinja2.

    Returns:
        Environment: Entorno configurado con url_for, config, request, session, g.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | No recibe parámetros. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Environment` | `Environment` | Entorno Jinja2. |

#### `Flask.create_url_adapter()`

Crea un `MapAdapter` para construcción/matching de URLs.

```python
def create_url_adapter(self, request: Request | None) -> MapAdapter | None:
    """Crea adaptador de URLs.

    Args:
        request (Request | None): Request actual o None para contexto de app.

    Returns:
        MapAdapter | None: Adaptador o None si no hay SERVER_NAME fuera de request.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request` | `Request \| None` | Sí | Request o `None`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `MapAdapter \| None` | `MapAdapter \| None` | Adaptador vinculado. |

#### `Flask.raise_routing_exception()`

Intercepta `RequestRedirect` en modo debug para evitar pérdida de datos de formulario.

```python
def raise_routing_exception(self, request: Request) -> NoReturn:
    """Intercepta excepciones de enrutamiento.

    Args:
        request (Request): Request con routing_exception.

    Returns:
        NoReturn: Siempre lanza excepción.

    Raises:
        RequestRedirect | FormDataRoutingRedirect: Redirección original o de debug.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request` | `Request` | Sí | Request con `routing_exception`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `NoReturn` | - | No retorna, siempre lanza. |

| Excepciones | Condición |
| :--- | :--- |
| `RequestRedirect` | Fuera de debug o método seguro. |
| `FormDataRoutingRedirect` | En debug con método no seguro y código != 307/308. |

#### `Flask.update_template_context()`

Inyecta variables de contexto (request, session, g, config) y procesadores de contexto al diccionario de plantillas.

```python
def update_template_context(self, ctx: AppContext, context: dict[str, Any]) -> None:
    """Actualiza el contexto de plantilla.

    Args:
        ctx (AppContext): Contexto de aplicación (con o sin request).
        context (dict[str, Any]): Diccionario a actualizar in-place.

    Returns:
        None:
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `context` | `dict[str, Any]` | Sí | Diccionario de contexto. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Modifica `context` in-place. |

#### `Flask.make_shell_context()`

Ejecuta todos los `shell_context_processors` y retorna el contexto para `flask shell`.

```python
def make_shell_context(self) -> dict[str, Any]:
    """Genera contexto para shell interactivo.

    Returns:
        dict[str, Any]: Diccionario con `app`, `g` y valores de procesadores.
    """
```

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `dict[str, Any]` | `dict` | Contexto del shell. |

#### `Flask.run()`

Ejecuta el servidor de desarrollo Werkzeug (`run_simple`). Ignora la llamada si `FLASK_RUN_FROM_CLI=true`.

```python
def run(self, host: str | None = None, port: int | None = None, debug: bool | None = None, load_dotenv: bool = True, **options: Any) -> None:
    """Ejecuta servidor de desarrollo.

    Args:
        host (str | None): Hostname. Defaults 127.0.0.1 o SERVER_NAME.
        port (int | None): Puerto. Defaults 5000 o SERVER_NAME.
        debug (bool | None): Override de modo debug.
        load_dotenv (bool): Carga .env/.flaskenv. Defaults True.
        **options (Any): Opciones para werkzeug.serving.run_simple.

    Returns:
        None:
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `host` | `str \| None` | No | Default `None`. |
| `port` | `int \| None` | No | Default `None`. |
| `debug` | `bool \| None` | No | Default `None`. |
| `load_dotenv` | `bool` | No | Default `True`. |
| `**options` | `Any` | No | `use_reloader`, `use_debugger`, `threaded`, etc. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Bloquea hasta detener servidor. |

#### `Flask.test_client()`

Crea un cliente de pruebas `FlaskClient` para testing.

```python
def test_client(self, use_cookies: bool = True, **kwargs: Any) -> FlaskClient:
    """Crea cliente de test.

    Args:
        use_cookies (bool): Habilita manejo de cookies. Defaults True.
        **kwargs (Any): Argumentos para test_client_class.

    Returns:
        FlaskClient: Cliente de pruebas.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `use_cookies` | `bool` | No | Default `True`. |
| `**kwargs` | `Any` | No | Args para constructor del cliente. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `FlaskClient` | `FlaskClient` | Instancia cliente. |

#### `Flask.test_cli_runner()`

Crea un runner CLI `FlaskCliRunner` para probar comandos Click.

```python
def test_cli_runner(self, **kwargs: Any) -> FlaskCliRunner:
    """Crea runner CLI de test.

    Args:
        **kwargs (Any): Argumentos para test_cli_runner_class.

    Returns:
        FlaskCliRunner: Runner CLI.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `**kwargs` | `Any` | No | Args para constructor. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `FlaskCliRunner` | `FlaskCliRunner` | Instancia runner. |

#### `Flask.handle_http_exception()`

Maneja `HTTPException` buscando handler registrado por código/MRO o retornando la excepción.

```python
def handle_http_exception(self, ctx: AppContext, e: HTTPException) -> HTTPException | ResponseReturnValue:
    """Maneja excepción HTTP.

    Args:
        ctx (AppContext): Contexto actual.
        e (HTTPException): Excepción HTTP.

    Returns:
        HTTPException | ResponseReturnValue: Respuesta del handler o la excepción original.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `HTTPException` | Sí | Excepción. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `HTTPException \| ResponseReturnValue` | `HTTPException \| Any` | Handler result o `e`. |

#### `Flask.handle_user_exception()`

Punto central de manejo de excepciones de usuario. Delega `HTTPException` a `handle_http_exception` o busca handler genérico.

```python
def handle_user_exception(self, ctx: AppContext, e: Exception) -> HTTPException | ResponseReturnValue:
    """Maneja excepción de usuario.

    Args:
        ctx (AppContext): Contexto actual.
        e (Exception): Excepción capturada.

    Returns:
        HTTPException | ResponseReturnValue: Respuesta del handler.

    Raises:
        Exception: Si no hay handler registrado, re-lanza `e`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `Exception` | Sí | Excepción. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `HTTPException \| ResponseReturnValue` | `Any` | Respuesta del handler. |

| Excepciones | Condición |
| :--- | :--- |
| `Exception` | No hay handler encontrado (`raise` sin args). |
| `BadRequestKeyError` | Se marca `show_exception=True` si `debug` o `TRAP_BAD_REQUEST_ERRORS`. |

#### `Flask.handle_exception()`

Maneja excepciones no capturadas generando `500 InternalServerError`, logueando y enviando señal `got_request_exception`.

```python
def handle_exception(self, ctx: AppContext, e: Exception) -> Response:
    """Maneja excepción no controlada.

    Args:
        ctx (AppContext): Contexto actual.
        e (Exception): Excepción original.

    Returns:
        Response: Respuesta finalizada (500 o handler de 500).

    Raises:
        Exception: Si PROPAGATE_EXCEPTIONS es True, re-lanza `e`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `Exception` | Sí | Excepción. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Respuesta 500 finalizada. |

| Excepciones | Condición |
| :--- | :--- |
| `Exception` | Si `PROPAGATE_EXCEPTIONS` o `debug/testing` es `True`. |

#### `Flask.log_exception()`

Registra la excepción en `self.logger.error` con `exc_info`.

```python
def log_exception(self, ctx: AppContext, exc_info: tuple[type, BaseException, TracebackType] | tuple[None, None, None]) -> None:
    """Loguea excepción.

    Args:
        ctx (AppContext): Contexto con request.path y request.method.
        exc_info (tuple): Tupla exc_info de sys.exc_info().

    Returns:
        None:
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí | Info de excepción. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | - |

#### `Flask.dispatch_request()`

Realiza el matching de URL y despacha a la view function. Maneja `OPTIONS` automático.

```python
def dispatch_request(self, ctx: AppContext) -> ResponseReturnValue:
    """Despacha la petición a la vista.

    Args:
        ctx (AppContext): Contexto con request.

    Returns:
        ResponseReturnValue: Retorno de la vista.

    Raises:
        RequestRedirect | BuildError: Errores de enrutamiento.
        KeyError: Si endpoint no está en view_functions.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `ResponseReturnValue` | `Any` | Retorno de la vista. |

#### `Flask.full_dispatch_request()`

Orquesta el ciclo completo: `request_started`, `preprocess_request`, `dispatch_request`, `handle_user_exception`, `finalize_request`.

```python
def full_dispatch_request(self, ctx: AppContext) -> Response:
    """Despacho completo con pre/post-procesamiento.

    Args:
        ctx (AppContext): Contexto actual.

    Returns:
        Response: Respuesta finalizada.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Respuesta final. |

#### `Flask.finalize_request()`

Convierte `rv` en `Response` vía `make_response`, aplica `process_response` y envía `request_finished`.

```python
def finalize_request(self, ctx: AppContext, rv: ResponseReturnValue | HTTPException, from_error_handler: bool = False) -> Response:
    """Finaliza la petición.

    Args:
        ctx (AppContext): Contexto actual.
        rv (ResponseReturnValue | HTTPException): Valor de retorno de vista o excepción.
        from_error_handler (bool): Si True, suprime errores en post-procesamiento. Defaults False.

    Returns:
        Response: Respuesta procesada.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `rv` | `ResponseReturnValue \| HTTPException` | Sí | Valor a convertir. |
| `from_error_handler` | `bool` | No | Default `False`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Respuesta final. |

| Excepciones | Condición |
| :--- | :--- |
| `Exception` | Error en `process_response` si `from_error_handler=False`, se propaga. |

#### `Flask.make_default_options_response()`

Genera respuesta `OPTIONS` por defecto con header `Allow`.

```python
def make_default_options_response(self, ctx: AppContext) -> Response:
    """Crea respuesta OPTIONS por defecto.

    Args:
        ctx (AppContext): Contexto con url_adapter.

    Returns:
        Response: Respuesta con Allow.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Respuesta OPTIONS. |

#### `Flask.ensure_sync()`

Asegura que una función sea síncrona para workers WSGI. Si es `async def`, la envuelve con `async_to_sync`.

```python
def ensure_sync(self, func: Callable[..., Any]) -> Callable[..., Any]:
    """Asegura ejecución síncrona.

    Args:
        func (Callable[..., Any]): Función a verificar.

    Returns:
        Callable[..., Any]: Función original si es sync, o wrapper sync si es async.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `func` | `Callable[..., Any]` | Sí | Función. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Callable[..., Any]` | `Callable` | Función síncrona. |

#### `Flask.async_to_sync()`

Convierte una corrutina en función síncrona usando `asgiref.sync.async_to_sync`.

```python
def async_to_sync(self, func: Callable[..., Coroutine[Any, Any, Any]]) -> Callable[..., Any]:
    """Convierte async a sync.

    Args:
        func (Callable[..., Coroutine]): Función asíncrona.

    Returns:
        Callable[..., Any]: Función síncrona equivalente.

    Raises:
        RuntimeError: Si asgiref no está instalado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `func` | `Callable[..., Coroutine[Any, Any, Any]]` | Sí | Corrutina. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Callable[..., Any]` | `Callable` | Wrapper síncrono. |

| Excepciones | Condición |
| :--- | :--- |
| `RuntimeError` | `asgiref` no instalado. |

#### `Flask.url_for()`

Genera URL para un endpoint. Maneja contexto de request vs. app, blueprints relativos (`.`), `_external` y `_anchor`.

```python
def url_for(self, /, endpoint: str, *, _anchor: str | None = None, _method: str | None = None, _scheme: str | None = None, _external: bool | None = None, **values: Any) -> str:
    """Genera URL para endpoint.

    Args:
        endpoint (str): Nombre del endpoint. Si empieza con ".", es relativo al blueprint actual.
        _anchor (str | None): Ancla a añadir como #anchor.
        _method (str | None): Método HTTP para matching.
        _scheme (str | None): Esquema si es externa.
        _external (bool | None): Fuerza URL externa/interna. None auto-detecta.
        **values (Any): Valores para variables de URL y query string.

    Returns:
        str: URL generada.

    Raises:
        RuntimeError: Si no hay request/app context y falta SERVER_NAME.
        ValueError: Si _scheme se especifica con _external=False.
        BuildError: Si handle_url_build_error no retorna string.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `endpoint` | `str` | Sí | Endpoint (posicional-only). |
| `_anchor` | `str \| None` | No | Default `None`. |
| `_method` | `str \| None` | No | Default `None`. |
| `_scheme` | `str \| None` | No | Default `None`. |
| `_external` | `bool \| None` | No | Default `None`. |
| `**values` | `Any` | No | Variables de URL. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `str` | `str` | URL construida. |

| Excepciones | Condición |
| :--- | :--- |
| `RuntimeError` | Sin contexto y sin `SERVER_NAME`. |
| `ValueError` | `_scheme` con `_external=False`. |
| `BuildError` | Endpoint/valores inválidos y sin handler. |

#### `Flask.make_response()`

Convierte `rv` (str, bytes, dict, list, tuple, Response, WSGI callable, iterator) en `Response`.

```python
def make_response(self, rv: ResponseReturnValue) -> Response:
    """Convierte valor de vista en Response.

    Args:
        rv (ResponseReturnValue): Valor retornado por la vista.

    Returns:
        Response: Instancia de response_class.

    Raises:
        TypeError: Si rv es None, tupla inválida o tipo no soportado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `rv` | `ResponseReturnValue` | Sí | Valor de vista. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Respuesta normalizada. |

| Excepciones | Condición |
| :--- | :--- |
| `TypeError` | `rv is None`, tupla con len !=2/3, o tipo inválido. |

#### `Flask.preprocess_request()`

Ejecuta `url_value_preprocessors` y `before_request_funcs` (app + blueprint). Si un `before_request` retorna no-`None`, corta el despacho.

```python
def preprocess_request(self, ctx: AppContext) -> ResponseReturnValue | None:
    """Pre-procesa la petición.

    Args:
        ctx (AppContext): Contexto actual.

    Returns:
        ResponseReturnValue | None: Valor de before_request si intercepta, o None para continuar.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `ResponseReturnValue \| None` | `Any \| None` | Interceptación o `None`. |

#### `Flask.process_response()`

Aplica `after_request` (blueprint + app) en orden inverso y guarda la sesión.

```python
def process_response(self, ctx: AppContext, response: Response) -> Response:
    """Post-procesa la respuesta.

    Args:
        ctx (AppContext): Contexto actual.
        response (Response): Respuesta a procesar.

    Returns:
        Response: Respuesta modificada.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `response` | `Response` | Sí | Respuesta. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Respuesta procesada. |

#### `Flask.do_teardown_request()`

Ejecuta `teardown_request_funcs` y envía señal `request_tearing_down`. Acumula errores con `_CollectErrors`.

```python
def do_teardown_request(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta teardown de request.

    Args:
        ctx (AppContext): Contexto actual.
        exc (BaseException | None): Excepción no manejada. Defaults None.

    Returns:
        None:

    Raises:
        ExceptionGroup | Exception: Si algún teardown falla (via _CollectErrors).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc` | `BaseException \| None` | No | Default `None`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | - |

| Excepciones | Condición |
| :--- | :--- |
| `Exception` | Errores agregados durante teardown. |

#### `Flask.do_teardown_appcontext()`

Ejecuta `teardown_appcontext_funcs` y envía `appcontext_tearing_down`.

```python
def do_teardown_appcontext(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta teardown de appcontext.

    Args:
        ctx (AppContext): Contexto actual.
        exc (BaseException | None): Excepción no manejada. Defaults None.

    Returns:
        None:

    Raises:
        ExceptionGroup | Exception: Si algún teardown falla.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc` | `BaseException \| None` | No | Default `None`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | - |

#### `Flask.app_context()`

Crea un `AppContext` sin request.

```python
def app_context(self) -> AppContext:
    """Crea contexto de aplicación.

    Returns:
        AppContext: Contexto de app.
    """
```

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `AppContext` | `AppContext` | Contexto. |

#### `Flask.request_context()`

Crea `AppContext` desde un `WSGIEnvironment` dado.

```python
def request_context(self, environ: WSGIEnvironment) -> AppContext:
    """Crea contexto de request desde environ.

    Args:
        environ (WSGIEnvironment): Entorno WSGI.

    Returns:
        AppContext: Contexto con request.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `AppContext` | `AppContext` | Contexto. |

#### `Flask.test_request_context()`

Crea `AppContext` de prueba usando `EnvironBuilder` (Werkzeug) con defaults de `SERVER_NAME`, `APPLICATION_ROOT`, etc.

```python
def test_request_context(self, *args: Any, **kwargs: Any) -> AppContext:
    """Crea contexto de request de prueba.

    Args:
        *args (Any): Args para EnvironBuilder.
        **kwargs (Any): Kwargs para EnvironBuilder (path, base_url, subdomain, url_scheme, data, json, etc.).

    Returns:
        AppContext: Contexto de prueba.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `*args` | `Any` | No | Args para `EnvironBuilder`. |
| `**kwargs` | `Any` | No | Kwargs para `EnvironBuilder`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `AppContext` | `AppContext` | Contexto. |

#### `Flask.wsgi_app()`

Aplicación WSGI real. Hace `push` del contexto, llama `full_dispatch_request`, maneja excepciones y hace `pop`.

```python
def wsgi_app(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
    """Aplicación WSGI.

    Args:
        environ (WSGIEnvironment): Entorno WSGI.
        start_response (StartResponse): Callable de inicio de respuesta.

    Returns:
        Iterable[bytes]: Iterable de bytes de la respuesta.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `environ` | `WSGIEnvironment` | Sí | Entorno. |
| `start_response` | `StartResponse` | Sí | Callable WSGI. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Iterable[bytes]` | `Iterable[bytes]` | Cuerpo de respuesta. |

#### `Flask.__call__()`

Hace la instancia callable como WSGI app. Delega a `wsgi_app` para permitir middleware.

```python
def __call__(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
    """Invocación WSGI de la app.

    Args:
        environ (WSGIEnvironment): Entorno WSGI.
        start_response (StartResponse): Callable de inicio.

    Returns:
        Iterable[bytes]: Iterable de respuesta.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `environ` | `WSGIEnvironment` | Sí | Entorno. |
| `start_response` | `StartResponse` | Sí | Callable. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Iterable[bytes]` | `Iterable[bytes]` | Respuesta. |

---

## 3. Ejemplo de Uso

```python
from flask import Flask, request, jsonify, g

# 1. Creación de la aplicación
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SERVER_NAME"] = "example.com"
app.config["SECRET_KEY"] = "dev-key"

# 2. Registro de rutas y manejo de contexto
@app.route("/hello/<name>", methods=["GET"])
def hello(name: str):
    # Uso de make_response implícito: dict -> JSON
    return {"message": f"Hola, {name}!"}

@app.route("/data", methods=["POST"])
def create_data():
    # Uso de request context y g
    g.user = request.json.get("user")
    return jsonify(user=g.user), 201

@app.before_request
def before():
    # Intercepta si falta header
    if request.path == "/data" and not request.is_json:
        return jsonify(error="JSON requerido"), 400

@app.teardown_request
def teardown(exc):
    # Limpieza por request
    g.pop("user", None)

# 3. Generación de URLs fuera de request (requiere SERVER_NAME)
with app.app_context():
    url = app.url_for("hello", name="Mundo", _external=True)
    print(url)  # https://example.com/hello/Mundo

# 4. Testing con test_client y test_request_context
with app.test_client() as client:
    rv = client.get("/hello/Mundo")
    assert rv.status_code == 200
    assert rv.json["message"] == "Hola, Mundo!"

with app.test_request_context("/hello/Test", method="GET"):
    assert request.endpoint == "hello"
    assert request.view_args == {"name": "Test"}

# 5. Servidor de desarrollo (solo en guard main)
if __name__ == "__main__":
    # No usar en producción; usar gunicorn/uwsgi
    app.run(host="127.0.0.1", port=5000, debug=True)

# 6. Uso como WSGI callable con middleware
# from werkzeug.middleware.proxy_fix import ProxyFix
# app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1)
```
