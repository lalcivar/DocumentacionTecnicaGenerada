# Documentación Técnica - Módulo `flask.app` (Clase `Flask`)

### 1. Resumen Ejecutivo

El módulo implementa la clase central `Flask`, subclase de `sansio.app.App`, que constituye la aplicación WSGI principal del framework. Actúa como registro central para rutas, vistas, manejo de errores, contextos de aplicación/petición, gestión de sesiones, integración con Jinja2 y Werkzeug, y expone la interfaz WSGI (`wsgi_app` / `__call__`) para servidores de producción y desarrollo. Incluye utilidades de compatibilidad (`remove_ctx`, `add_ctx`, `_make_timedelta`) para la transición de firmas con `AppContext` hacia Flask 4.0.

### 2. Especificación de Funciones y Métodos

#### 2.1 Funciones a Nivel de Módulo

---

##### ` _make_timedelta()`

Convierte un valor entero (segundos) o `timedelta` en un objeto `timedelta` normalizado.

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    """Normaliza un valor de duración a timedelta.

    Args:
        value: Duración como timedelta, segundos en entero o None.

    Returns:
        Objeto timedelta si se proporciona valor, None si la entrada es None.

    Raises:
        TypeError: Si el valor no es timedelta, int o None (implícito por timedelta).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `value` | `timedelta \| int \| None` | Sí | Valor a convertir. Enteros se interpretan como segundos. |

| Retorno | Descripción |
| :--- | :--- |
| `timedelta \| None` | `timedelta` normalizado o `None`. |

| Excepción | Condición |
| :--- | :--- |
| - | No lanza excepciones explícitas. |

---

##### `remove_ctx()`

Decorador de compatibilidad. Elimina el primer argumento `ctx: AppContext` si está presente antes de delegar al método original con firma antigua.

```python
def remove_ctx(f: F) -> F:
    """Adapta un método con firma nueva (con ctx) a firma antigua (sin ctx).

    Args:
        f: Callable a envolver, cuya primera firma incluye AppContext.

    Returns:
        Callable envuelto que descarta AppContext si se pasa como primer argumento.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `f` | `F (bound Callable[..., Any])` | Sí | Función/método a adaptar. |

| Retorno | Descripción |
| :--- | :--- |
| `F` | Wrapper con `update_wrapper` aplicado. |

---

##### `add_ctx()`

Decorador inverso a `remove_ctx`. Inyecta el `AppContext` actual (`app_ctx._get_current_object()`) como primer argumento si no fue provisto, permitiendo que métodos base con firma nueva sean llamados desde subclases con firma antigua vía `super()`.

```python
def add_ctx(f: F) -> F:
    """Adapta un método con firma antigua para llamar a implementación con ctx.

    Args:
        f: Callable base que espera AppContext como primer argumento.

    Returns:
        Callable envuelto que inyecta AppContext automáticamente.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `f` | `F` | Sí | Función/método base que requiere `ctx`. |

| Retorno | Descripción |
| :--- | :--- |
| `F` | Wrapper que antepone `AppContext` actual. |

---

#### 2.2 Funciones Anidadas / Locales

##### `remove_ctx.wrapper()`

```python
def wrapper(self: Flask, *args: Any, **kwargs: Any) -> Any:
    """Wrapper interno de remove_ctx.

    Args:
        self: Instancia de Flask.
        *args: Argumentos posicionales. Si args[0] es AppContext, se descarta.
        **kwargs: Argumentos nominales.

    Returns:
        Resultado de f(self, *args_filtrados, **kwargs).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Flask` | Sí | Instancia receptora. |
| `*args` | `Any` | No | Argumentos variables, posible `AppContext` en posición 0. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

| Retorno | Descripción |
| :--- | :--- |
| `Any` | Valor de retorno de `f`. |

##### `add_ctx.wrapper()`

```python
def wrapper(self: Flask, *args: Any, **kwargs: Any) -> Any:
    """Wrapper interno de add_ctx.

    Args:
        self: Instancia de Flask.
        *args: Argumentos posicionales. Si está vacío o args[0] no es AppContext, se inyecta.
        **kwargs: Argumentos nominales.

    Returns:
        Resultado de f(self, ctx, *args, **kwargs).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Flask` | Sí | Instancia receptora. |
| `*args` | `Any` | No | Argumentos variables. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

| Retorno | Descripción |
| :--- | :--- |
| `Any` | Valor de retorno de `f`. |

##### `Flask.__init__.<lambda>()`

Función anónima registrada como `view_func` para la ruta estática `static`.

```python
lambda **kw: self_ref().send_static_file(**kw)
    """Callback para servir archivos estáticos vía weakref.

    Args:
        **kw: Debe contener 'filename: str'.

    Returns:
        Response: Respuesta con el archivo estático.

    Raises:
        RuntimeError: Si la referencia débil es None o static_folder no configurado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `**kw` | `Any` | Sí | `filename` del archivo solicitado. |

| Retorno | Descripción |
| :--- | :--- |
| `Response` | Respuesta generada por `send_static_file`. |

---

#### 2.3 Métodos de la Clase `Flask`

##### `Flask.__init_subclass__()`

Hook de metaclase que detecta subclases que sobrescriben métodos con firma antigua (sin `ctx`) y aplica envoltura de compatibilidad con advertencia de deprecación.

```python
@classmethod
def __init_subclass__(cls, **kwargs: Any) -> None:
    """Intercepta la creación de subclases para compatibilidad de firmas.

    Args:
        **kwargs: Argumentos de creación de clase.

    Returns:
        None

    Raises:
        DeprecationWarning: Emitido vía warnings.warn si se detecta firma antigua.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `cls` | `type` | Sí | Subclase en creación. |
| `**kwargs` | `Any` | No | Argumentos adicionales de clase. |

| Excepción | Condición |
| :--- | :--- |
| `DeprecationWarning` | Método sobrescrito sin parámetro `ctx: AppContext`. |

Métodos inspeccionados: `handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`.

---

##### `Flask.__init__()`

```python
def __init__(self, import_name: str, static_url_path: str | None = None, static_folder: str | os.PathLike[str] | None = "static", static_host: str | None = None, host_matching: bool = False, subdomain_matching: bool = False, template_folder: str | os.PathLike[str] | None = "templates", instance_path: str | None = None, instance_relative_config: bool = False, root_path: str | None = None) -> None:
    """Inicializa la aplicación Flask y registra la ruta estática si aplica.

    Args:
        import_name: Nombre del paquete/módulo de la aplicación.
        static_url_path: Ruta URL para archivos estáticos.
        static_folder: Carpeta física de archivos estáticos.
        static_host: Host para la ruta estática (requiere host_matching=True).
        host_matching: Habilita matching por host en url_map.
        subdomain_matching: Habilita matching por subdominio.
        template_folder: Carpeta de plantillas.
        instance_path: Ruta alternativa de instancia.
        instance_relative_config: Si True, config relativa a instance_path.
        root_path: Ruta raíz de la aplicación.

    Returns:
        None

    Raises:
        AssertionError: Si static_host/host_matching es combinación inválida.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `import_name` | `str` | Sí | Nombre de importación. |
| `static_url_path` | `str \| None` | No | URL base estática. Default `None`. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta estática. Default `"static"`. |
| `static_host` | `str \| None` | No | Host estático. |
| `host_matching` | `bool` | No | Default `False`. |
| `subdomain_matching` | `bool` | No | Default `False`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Default `"templates"`. |
| `instance_path` | `str \| None` | No | Default `None`. |
| `instance_relative_config` | `bool` | No | Default `False`. |
| `root_path` | `str \| None` | No | Default `None`. |

---

##### `Flask.get_send_file_max_age()`

```python
def get_send_file_max_age(self, filename: str | None) -> int | None:
    """Determina el max_age para cache de send_file.

    Args:
        filename: Nombre del archivo solicitado.

    Returns:
        Segundos de cache como int, o None para usar peticiones condicionales.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| None` | Sí | Ruta del archivo. |

| Retorno | Descripción |
| :--- | :--- |
| `int \| None` | Segundos o `None`. |

---

##### `Flask.send_static_file()`

```python
def send_static_file(self, filename: str) -> Response:
    """Sirve un archivo desde static_folder.

    Args:
        filename: Ruta relativa dentro de static_folder.

    Returns:
        Response con el archivo.

    Raises:
        RuntimeError: Si has_static_folder es False.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str` | Sí | Archivo a servir. |

| Excepción | Condición |
| :--- | :--- |
| `RuntimeError` | `static_folder` no configurado. |

---

##### `Flask.open_resource()`

```python
def open_resource(self, resource: str, mode: str = "rb", encoding: str | None = None) -> IO[AnyStr]:
    """Abre un recurso relativo a root_path solo en lectura.

    Args:
        resource: Ruta relativa a root_path.
        mode: Modo de apertura. Solo 'r', 'rt', 'rb'.
        encoding: Codificación para modo texto.

    Returns:
        Handle de archivo abierto.

    Raises:
        ValueError: Si mode no es de lectura.
        FileNotFoundError: Si el recurso no existe.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `resource` | `str` | Sí | Ruta relativa. |
| `mode` | `str` | No | Default `"rb"`. |
| `encoding` | `str \| None` | No | Default `None`. |

---

##### `Flask.open_instance_resource()`

```python
def open_instance_resource(self, resource: str, mode: str = "rb", encoding: str | None = "utf-8") -> IO[AnyStr]:
    """Abre un recurso relativo a instance_path (permite escritura).

    Args:
        resource: Ruta relativa a instance_path.
        mode: Modo de apertura (cualquiera válido para open).
        encoding: Codificación para modo texto. Default 'utf-8'.

    Returns:
        Handle de archivo abierto.

    Raises:
        FileNotFoundError: Si el archivo no existe en lectura.
        OSError: Errores de E/S.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `resource` | `str` | Sí | Ruta relativa. |
| `mode` | `str` | No | Default `"rb"`. |
| `encoding` | `str \| None` | No | Default `"utf-8"`. |

---

##### `Flask.create_jinja_environment()`

```python
def create_jinja_environment(self) -> Environment:
    """Crea y configura el entorno Jinja2.

    Returns:
        Environment configurado con globals (url_for, config, request, session, g) y política json.dumps_function.
    """
```

| Retorno | Descripción |
| :--- | :--- |
| `Environment` | Entorno Jinja listo. |

---

##### `Flask.create_url_adapter()`

```python
def create_url_adapter(self, request: Request | None) -> MapAdapter | None:
    """Crea un adaptador de URLs para el request dado o para contexto de app.

    Args:
        request: Request actual o None si se llama fuera de request.

    Returns:
        MapAdapter vinculado al environ o a SERVER_NAME, o None si no hay SERVER_NAME fuera de request.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request` | `Request \| None` | Sí | Request actual. |

---

##### `Flask.raise_routing_exception()`

```python
def raise_routing_exception(self, request: Request) -> NoReturn:
    """Intercepta excepciones de ruteo y las relanza o convierte.

    Args:
        request: Request que contiene routing_exception.

    Returns:
        NoReturn: Siempre lanza excepción.

    Raises:
        RequestRedirect | FormDataRoutingRedirect | RoutingException: Según modo debug y método.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request` | `Request` | Sí | Request con `routing_exception`. |

---

##### `Flask.update_template_context()`

```python
def update_template_context(self, ctx: AppContext, context: dict[str, Any]) -> None:
    """Inyecta variables de contexto de plantillas y procesadores.

    Args:
        ctx: Contexto de aplicación activo.
        context: Diccionario de contexto a actualizar in-place.

    Returns:
        None
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `context` | `dict[str, Any]` | Sí | Contexto mutable. |

---

##### `Flask.make_shell_context()`

```python
def make_shell_context(self) -> dict[str, Any]:
    """Ejecuta procesadores de contexto shell.

    Returns:
        Diccionario con 'app', 'g' y valores de shell_context_processors.
    """
```

---

##### `Flask.run()`

```python
def run(self, host: str | None = None, port: int | None = None, debug: bool | None = None, load_dotenv: bool = True, **options: Any) -> None:
    """Ejecuta servidor de desarrollo Werkzeug.

    Args:
        host: Hostname. Default '127.0.0.1' o SERVER_NAME.
        port: Puerto. Default 5000 o SERVER_NAME.
        debug: Sobrescribe flag debug.
        load_dotenv: Carga .env/.flaskenv si True.
        **options: Opciones para werkzeug.serving.run_simple (use_reloader, use_debugger, threaded).

    Returns:
        None
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `host` | `str \| None` | No | Default `None`. |
| `port` | `int \| None` | No | Default `None`. |
| `debug` | `bool \| None` | No | Default `None`. |
| `load_dotenv` | `bool` | No | Default `True`. |
| `**options` | `Any` | No | Opciones Werkzeug. |

---

##### `Flask.test_client()`

```python
def test_client(self, use_cookies: bool = True, **kwargs: Any) -> FlaskClient:
    """Crea un cliente de pruebas WSGI.

    Args:
        use_cookies: Si True, mantiene cookies entre peticiones.
        **kwargs: Argumentos para test_client_class.

    Returns:
        Instancia de FlaskClient.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `use_cookies` | `bool` | No | Default `True`. |
| `**kwargs` | `Any` | No | Args adicionales. |

---

##### `Flask.test_cli_runner()`

```python
def test_cli_runner(self, **kwargs: Any) -> FlaskCliRunner:
    """Crea un runner CLI para pruebas.

    Args:
        **kwargs: Argumentos para test_cli_runner_class.

    Returns:
        Instancia de FlaskCliRunner.
    """
```

---

##### `Flask.handle_http_exception()`

```python
def handle_http_exception(self, ctx: AppContext, e: HTTPException) -> HTTPException | ResponseReturnValue:
    """Maneja HTTPException buscando handler registrado.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción HTTP.

    Returns:
        Respuesta del handler o la excepción original si no hay handler o es RoutingException.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `HTTPException` | Sí | Excepción. |

---

##### `Flask.handle_user_exception()`

```python
def handle_user_exception(self, ctx: AppContext, e: Exception) -> HTTPException | ResponseReturnValue:
    """Maneja excepciones de usuario, delegando a handle_http_exception si aplica.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción capturada.

    Returns:
        Valor de respuesta del handler.

    Raises:
        Exception: Relanza si no hay handler registrado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `Exception` | Sí | Excepción. |

---

##### `Flask.handle_exception()`

```python
def handle_exception(self, ctx: AppContext, e: Exception) -> Response:
    """Maneja excepciones no capturadas generando 500 InternalServerError.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción no manejada.

    Returns:
        Response finalizada (500 o handler de 500).

    Raises:
        Exception: Si PROPAGATE_EXCEPTIONS es True.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `Exception` | Sí | Excepción. |

---

##### `Flask.log_exception()`

```python
def log_exception(self, ctx: AppContext, exc_info: tuple[type, BaseException, TracebackType] | tuple[None, None, None]) -> None:
    """Registra excepción en logger.

    Args:
        ctx: Contexto con request.path y request.method.
        exc_info: Tupla exc_info de sys.exc_info().

    Returns:
        None
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc_info` | `tuple` | Sí | Info de excepción. |

---

##### `Flask.dispatch_request()`

```python
def dispatch_request(self, ctx: AppContext) -> ResponseReturnValue:
    """Despacha la petición a la view function correspondiente.

    Args:
        ctx: Contexto con request.url_rule y view_args.

    Returns:
        Valor de retorno de la vista.

    Raises:
        RoutingException: Vía raise_routing_exception.
        KeyError: Si endpoint no existe en view_functions.
    """
```

---

##### `Flask.full_dispatch_request()`

```python
def full_dispatch_request(self, ctx: AppContext) -> Response:
    """Despacho completo con pre/post-procesamiento y manejo de errores.

    Args:
        ctx: Contexto de aplicación.

    Returns:
        Response finalizada.
    """
```

---

##### `Flask.finalize_request()`

```python
def finalize_request(self, ctx: AppContext, rv: ResponseReturnValue | HTTPException, from_error_handler: bool = False) -> Response:
    """Convierte rv en Response y ejecuta post-procesamiento.

    Args:
        ctx: Contexto.
        rv: Valor de retorno de vista o excepción HTTP.
        from_error_handler: Si True, suprime errores en process_response y loguea.

    Returns:
        Response final.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `rv` | `ResponseReturnValue \| HTTPException` | Sí | Valor a convertir. |
| `from_error_handler` | `bool` | No | Default `False`. |

---

##### `Flask.make_default_options_response()`

```python
def make_default_options_response(self, ctx: AppContext) -> Response:
    """Genera respuesta OPTIONS automática.

    Args:
        ctx: Contexto con url_adapter.

    Returns:
        Response con header Allow poblado.
    """
```

---

##### `Flask.ensure_sync()`

```python
def ensure_sync(self, func: Callable[..., Any]) -> Callable[..., Any]:
    """Garantiza que la función sea síncrona para workers WSGI.

    Args:
        func: Función sync o async.

    Returns:
        Callable síncrono (original o envuelto vía async_to_sync).
    """
```

---

##### `Flask.async_to_sync()`

```python
def async_to_sync(self, func: Callable[..., Coroutine[Any, Any, Any]]) -> Callable[..., Any]:
    """Convierte corrutina en función síncrona.

    Args:
        func: Función async def.

    Returns:
        Función síncrona que ejecuta la corrutina.

    Raises:
        RuntimeError: Si asgiref no está instalado.
    """
```

---

##### `Flask.url_for()`

```python
def url_for(self, /, endpoint: str, *, _anchor: str | None = None, _method: str | None = None, _scheme: str | None = None, _external: bool | None = None, **values: Any) -> str:
    """Genera URL para un endpoint.

    Args:
        endpoint: Nombre del endpoint (prefijo blueprint con '.').
        _anchor: Ancla URL (#anchor).
        _method: Método HTTP para selección de regla.
        _scheme: Esquema (http/https) requiere _external=True.
        _external: Si True fuerza URL externa.
        **values: Valores para variables de URL y query string.

    Returns:
        URL generada como string.

    Raises:
        RuntimeError: Si se llama fuera de request sin SERVER_NAME.
        ValueError: Si _scheme se especifica con _external=False.
        BuildError: Si handle_url_build_error no retorna string (propagado).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `endpoint` | `str` | Sí | Endpoint destino. |
| `_anchor` | `str \| None` | No | Default `None`. |
| `_method` | `str \| None` | No | Default `None`. |
| `_scheme` | `str \| None` | No | Default `None`. |
| `_external` | `bool \| None` | No | Default `None`. |
| `**values` | `Any` | No | Variables de URL. |

---

##### `Flask.make_response()`

```python
def make_response(self, rv: ResponseReturnValue) -> Response:
    """Convierte valor de vista en instancia de response_class.

    Args:
        rv: Valor de retorno (str, bytes, dict, list, tuple, Response, WSGI callable, iterator).

    Returns:
        Instancia de Response.

    Raises:
        TypeError: Si rv es None, tupla inválida o tipo no soportado.
    """
```

---

##### `Flask.preprocess_request()`

```python
def preprocess_request(self, ctx: AppContext) -> ResponseReturnValue | None:
    """Ejecuta url_value_preprocessors y before_request_funcs.

    Args:
        ctx: Contexto.

    Returns:
        Valor de respuesta si un before_request lo retorna, None en caso contrario.
    """
```

---

##### `Flask.process_response()`

```python
def process_response(self, ctx: AppContext, response: Response) -> Response:
    """Ejecuta after_request_funcs y guarda sesión.

    Args:
        ctx: Contexto.
        response: Response a procesar.

    Returns:
        Response modificada.
    """
```

---

##### `Flask.do_teardown_request()`

```python
def do_teardown_request(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta teardown_request_funcs y señal request_tearing_down.

    Args:
        ctx: Contexto.
        exc: Excepción no manejada durante dispatch, o None.

    Returns:
        None

    Raises:
        ExceptionGroup | BaseException: Errores agregados durante teardown vía _CollectErrors.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc` | `BaseException \| None` | No | Default `None`. |

---

##### `Flask.do_teardown_appcontext()`

```python
def do_teardown_appcontext(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta teardown_appcontext_funcs y señal appcontext_tearing_down.

    Args:
        ctx: Contexto.
        exc: Excepción activa durante el contexto.

    Returns:
        None

    Raises:
        ExceptionGroup | BaseException: Errores agregados durante teardown.
    """
```

---

##### `Flask.app_context()`

```python
def app_context(self) -> AppContext:
    """Crea un AppContext sin request.

    Returns:
        AppContext asociado a la app.
    """
```

---

##### `Flask.request_context()`

```python
def request_context(self, environ: WSGIEnvironment) -> AppContext:
    """Crea AppContext con información de request desde environ WSGI.

    Args:
        environ: Diccionario WSGI.

    Returns:
        AppContext con request, session, g y current_app disponibles al hacer push.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |

---

##### `Flask.test_request_context()`

```python
def test_request_context(self, *args: Any, **kwargs: Any) -> AppContext:
    """Crea AppContext de prueba usando EnvironBuilder.

    Args:
        *args: Argumentos posicionales para EnvironBuilder.
        **kwargs: Argumentos nominales (path, base_url, subdomain, url_scheme, data, json, etc.).

    Returns:
        AppContext de prueba.
    """
```

---

##### `Flask.wsgi_app()`

```python
def wsgi_app(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
    """Aplicación WSGI real. Gestiona ciclo de vida del contexto.

    Args:
        environ: Entorno WSGI.
        start_response: Callable WSGI para iniciar respuesta.

    Returns:
        Iterable de bytes de la respuesta.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `environ` | `WSGIEnvironment` | Sí | Entorno. |
| `start_response` | `StartResponse` | Sí | Callback WSGI. |

---

##### `Flask.__call__()`

```python
def __call__(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
    """Entry-point WSGI. Delega a wsgi_app.

    Args:
        environ: Entorno WSGI.
        start_response: Callback WSGI.

    Returns:
        Iterable de bytes.
    """
```

---

### 3. Ejemplo de Uso

```python
from flask import Flask, request, jsonify, g

app = Flask(__name__)
app.config["SERVER_NAME"] = "example.com"
app.config["SECRET_KEY"] = "dev"

@app.route("/hello/<name>", methods=["GET"])
def hello(name: str):
    """Vista de ejemplo que usa g y retorna JSON."""
    g.visitor = name
    return jsonify(message=f"Hola, {name}!", visitor=g.visitor)

@app.before_request
def log_request():
    print(f"Request: {request.method} {request.path}")

@app.teardown_request
def teardown_request(exc):
    print(f"Teardown request, exc={exc}")

# Uso de url_for dentro y fuera de request
with app.app_context():
    print(app.url_for("hello", name="Mundo", _external=True))
    # https://example.com/hello/Mundo

# Uso de test_client y test_request_context
with app.test_client() as client:
    rv = client.get("/hello/Flask")
    assert rv.status_code == 200
    assert rv.json["message"] == "Hola, Flask!"

with app.test_request_context("/hello/Test?lang=es"):
    assert request.args["lang"] == "es"
    assert request.endpoint == "hello"

# Servir archivo estático y recurso
# with app.open_resource("schema.sql", mode="r", encoding="utf-8") as f:
#     schema = f.read()

if __name__ == "__main__":
    # No se ejecuta si FLASK_RUN_FROM_CLI=true
    app.run(host="127.0.0.1", port=5000, debug=True)
```

