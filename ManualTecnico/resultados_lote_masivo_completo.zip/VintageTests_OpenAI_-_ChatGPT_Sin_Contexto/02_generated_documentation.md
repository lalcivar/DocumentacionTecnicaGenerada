/**
 * <p><b>VintageTests</b></p>
 *
 * <p>
 * Clase de utilería cuyo único fin es verificar que el motor
 * <i>JUnit Vintage</i> (el puente que permite seguir ejecutando pruebas
 * escritas con JUnit 4 en la <i>JUnit Platform</i>) está correctamente
 * configurado dentro del proyecto.  Sirve como «smoke test»: si esta
 * prueba se ejecuta y finaliza con éxito, se demuestra que
 * <ul>
 *   <li>Las dependencias de JUnit 4 (org.junit.*) están presentes
 *       en el <code>classpath</code>.</li>
 *   <li>El motor Vintage está habilitado (por ejemplo, mediante
 *       <code>org.junit.vintage:junit-vintage-engine</code> en Maven
 *       o Gradle).</li>
 *   <li>La integración con la herramienta de construcción
 *       (Maven Surefire, Gradle Test, IDE, etc.) funciona
 *       correctamente.</li>
 * </ul>
 * </p>
 *
 * <h3>Ubicación del código</h3>
 * <pre>com.example.project.VintageTests</pre>
 *
 * <h3>Dependencias</h3>
 * <ul>
 *   <li>JUnit 4.x (paquete <code>org.junit</code>).</li>
 *   <li>JUnit Platform (Vintage Engine) si se ejecuta con
 *       JUnit 5.</li>
 * </ul>
 *
 * <h3>Uso típico</h3>
 * <pre>
 * // Vía Maven
 * mvn test
 *
 * // Vía Gradle
 * ./gradlew test
 * </pre>
 * En ambos casos el informe de pruebas debería mostrar 1 prueba
 * ejecutada con 0 fallos y 0 errores.
 *
 * <h3>Estructura de la clase</h3>
 * La clase contiene un único método de prueba:
 * <ul>
 *   <li><code>test()</code> – método vacío marcado con
 *       <code>@Test</code>. El simple hecho de que se descubra y se
 *       ejecute sin lanzar excepciones indica que la infraestructura
 *       de pruebas está operativa.</li>
 * </ul>
 *
 * <h3>Extensión o modificación</h3>
 * Puede añadir más métodos anotados con <code>@Test</code> para
 * construir un conjunto de pruebas real, o bien eliminar esta clase
 * una vez verificada la configuración.
 *
 * @author  the original author or authors
 * @since   2015-2026
 * @see     org.junit.Test
 */
package com.example.project;

import org.junit.Test;

/**
 * Prueba de humo mínima para comprobar la correcta integración de
 * JUnit 4 (Vintage).
 */
public class VintageTests {

    /**
     * Método de prueba vacío. Se considera satisfactorio mientras no
     * se lance ninguna excepción durante su ejecución.
     */
    @Test
    public void test() {
        // No-op: prueba de verificación de infraestructura
    }
}