# Documentación Técnica del Módulo  
> Cumple con PEP 257 y el estilo Google de docstrings.

---

## 1. Resumen ejecutivo
Este script automatiza la generación de un manual técnico para un archivo Java existente utilizando la API de OpenAI (vía OpenRouter).  
Lee el código fuente de `ResultPrinter.java`, envía el contenido al modelo `google/gemini-2.0-flash-001`, recibe la documentación generada y la guarda como `MANUAL_TECNICO_JUNIT.md`.

---

## 2. Especificación de funciones y métodos

### `generar_documentacion()`
```python
def generar_documentacion():
    """Genera y guarda la documentación técnica de un archivo Java.

    1. Lee el archivo `main/java/junit/textui/ResultPrinter.java`.
    2. Envía el contenido al modelo `google/gemini-2.0-flash-001` mediante la API de OpenAI.
    3. Guarda la respuesta en `MANUAL_TECNICO_JUNIT.md` y muestra un mensaje de confirmación.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| – | – | – | La función no recibe parámetros. |

| Valor de retorno | Tipo | Descripción |
|------------------|------|-------------|
| `None` | `NoneType` | No retorna datos; finaliza su ejecución tras crear el archivo de documentación. |

| Excepción | Condición de disparo |
|-----------|---------------------|
| `FileNotFoundError` | Cuando no se encuentra `main/java/junit/textui/ResultPrinter.java`. |
| `IOError` | Problemas de lectura/escritura al acceder a los archivos. |
| `openai.OpenAIError`* | Errores devueltos por la API de OpenAI (p. ej., credenciales inválidas, límite de cuota). |
| `Exception` | Cualquier otra excepción no controlada. |

\*Se incluye el comodín `openai.OpenAIError` para cubrir la jerarquía de excepciones propias del SDK de OpenAI.

---

## 3. Ejemplo de uso
```python
"""
Ejemplo rápido de ejecución desde otro módulo o desde la terminal.
Se asume que las variables de entorno o el archivo de clave API ya están configurados,
y que el archivo Java de entrada existe en la ruta especificada.
"""
import nombre_del_script  # Sustituir por el nombre real del archivo .py

# Llamada directa
nombre_del_script.generar_documentacion()
```

---

### Notas adicionales
1. El objeto `client` se instancia en tiempo de importación y reutiliza la clave y la URL base definidas en el módulo.  
2. Para modificar el archivo de entrada o el modelo, edite las constantes dentro de `generar_documentacion()` o parametricelas y adapte la docstring en consecuencia.