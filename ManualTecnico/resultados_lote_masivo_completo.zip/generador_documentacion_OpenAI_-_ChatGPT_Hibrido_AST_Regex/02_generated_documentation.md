# Documentación Técnica del Módulo

## 1. Resumen ejecutivo
Este script automatiza la generación de un manual técnico para un archivo Java existente mediante el consumo de un LLM hospedado en OpenRouter. El flujo consiste en leer el código fuente local, enviarlo a un modelo (Gemini 2.0 Flash) y guardar la respuesta en un archivo Markdown. De este modo, facilita la creación rápida de documentación sin intervención manual.

---

## 2. Especificación de funciones y métodos

### `generar_documentacion()`
```python
def generar_documentacion() -> None:
    ...
```

Descripción breve  
Lee un archivo Java, envía su contenido a un modelo de lenguaje a través del SDK de OpenAI-compatible (OpenRouter) y guarda la respuesta en un archivo Markdown.

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| — | — | — | La función no recibe argumentos. |

| Retorna | Tipo | Descripción |
|---------|------|-------------|
| `None`  | `NoneType` | No retorna ningún valor; los efectos son colaterales (creación de archivo y salida por consola). |

| Excepciones (`Raises`) | Situación de disparo |
|------------------------|----------------------|
| `FileNotFoundError` | Cuando `main/java/junit/textui/ResultPrinter.java` no existe en la ruta especificada. |
| `IOError` / `OSError` | Errores de lectura o escritura en disco. |
| `openai.OpenAIError`  | Cualquier error propagado por el SDK durante la llamada al endpoint (`client.chat.completions.create`). |
| `KeyError`            | Si la estructura devuelta por la API carece de `choices[0].message.content`. |

---

#### Docstring (Google Style) sugerida

```python
def generar_documentacion() -> None:
    """Genera un manual técnico para un archivo Java usando un modelo LLM.

    Lee el archivo ``main/java/junit/textui/ResultPrinter.java``, envía su
    contenido a Gemini 2.0 Flash a través de la API de OpenRouter y guarda la
    respuesta en ``MANUAL_TECNICO_JUNIT.md``.

    Raises:
        FileNotFoundError: Si el archivo Java no se encuentra.
        IOError: Problemas al leer o escribir archivos locales.
        openai.OpenAIError: Errores devueltos por la API de OpenAI-compatible.
        KeyError: Si la respuesta JSON no contiene el campo esperado.
    """
```

---

## 3. Ejemplo de uso

A continuación se muestra un caso de uso típico.  
**Requisitos previos:** instalar el SDK (`pip install openai`), exportar la variable de entorno `OPENAI_API_KEY` o sustituirla directamente en el código.

```python
from documentador import generar_documentacion  # Suponiendo que este módulo se llame documentador.py

if __name__ == '__main__':
    try:
        generar_documentacion()
    except FileNotFoundError:
        print("El archivo Java especificado no existe.")
    except Exception as exc:
        print(f"Ocurrió un error inesperado: {exc}")
```

Al ejecutarse, el script imprime el progreso en consola y genera el archivo `MANUAL_TECNICO_JUNIT.md` con la documentación del código Java analizado.