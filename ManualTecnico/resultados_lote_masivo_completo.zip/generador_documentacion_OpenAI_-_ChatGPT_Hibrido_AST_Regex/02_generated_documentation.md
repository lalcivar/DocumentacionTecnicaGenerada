# Documentación Técnica del Módulo

## 1. Resumen ejecutivo
Este script automatiza la generación de un manual técnico para un archivo Java existente (`ResultPrinter.java`) utilizando la API de OpenAI.  
Su flujo consiste en leer el código fuente local, enviarlo a un modelo LLM (Gemini 2.0 Flash) y almacenar la respuesta formateada en un archivo Markdown (`MANUAL_TECNICO_JUNIT.md`).

---

## 2. Especificación de funciones y métodos

### 2.1 `generar_documentacion()`
Función de más alto nivel que orquesta todo el proceso: lectura del archivo Java, invocación a la API de OpenAI y persistencia de la respuesta.

```python
def generar_documentacion() -> None:
    ...
```

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| – | – | – | La función no recibe argumentos. |

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| `None`  | `NoneType` | La operación es efectuada por sus efectos colaterales (E/S a disco y red). |

| Excepción | Tipo | Cuándo se dispara |
|-----------|------|-------------------|
| `FileNotFoundError` | nativo de Python | Si `main/java/junit/textui/ResultPrinter.java` no existe. |
| `OSError` / `IOError` | nativo de Python | Problemas de lectura/escritura de archivos. |
| `openai.OpenAIError` | SDK de OpenAI | Fallas en la comunicación con la API (cuotas, credenciales, red, etc.). |

Docstring sugerido (Google Style):

```python
def generar_documentacion() -> None:
    """Genera un manual técnico para un archivo Java usando la API de OpenAI.

    El procedimiento realiza los siguientes pasos:
      1. Lee el archivo Java localizado en
         ``main/java/junit/textui/ResultPrinter.java``.
      2. Envía su contenido al modelo ``google/gemini-2.0-flash-001`` mediante
         la ruta base de OpenRouter.
      3. Almacena la respuesta en ``MANUAL_TECNICO_JUNIT.md``.

    Raises:
        FileNotFoundError: Si el archivo Java no se encuentra.
        OSError: Si ocurre un error de E/S al leer o escribir archivos.
        openai.OpenAIError: Si la petición a la API de OpenAI falla.
    """
```

---

## 3. Ejemplo de uso

```python
"""
Uso básico desde CLI:

$ python generar_doc_java.py
"""

from generar_doc_java import generar_documentacion  # nombre hipotético del módulo

if __name__ == "__main__":
    try:
        generar_documentacion()
    except FileNotFoundError:
        print("El archivo Java no existe en la ruta especificada.")
    except Exception as exc:
        print(f"Error inesperado: {exc}")
```

---

Notas adicionales:

1. Seguridad: la clave API se encuentra en texto plano. Para entornos productivos,
   reemplácela por una variable de entorno o gestor de secretos.
2. Idempotencia: la función sobrescribe siempre `MANUAL_TECNICO_JUNIT.md`; haga
   copias de respaldo si el contenido previo es relevante.