# Documentación técnica: `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`
**Visibilidad:** package-private (`class DefaultLauncherTests`)
**Anotaciones:** `@NullMarked` (JSpecify)
**Desde:** 1.0

---

## 1. Descripción general

`DefaultLauncherTests` es una **clase de pruebas unitarias/de integración** (JUnit Jupiter) que verifica el comportamiento de la implementación por defecto del `Launcher` de la JUnit Platform (`DefaultLauncher`, instanciado a través de `LauncherFactoryForTestingPurposesOnly.createLauncher(...)`).

No forma parte de la API pública del producto: su propósito es **validar el contrato del ciclo de vida del Launcher**, que abarca dos fases:

1. **Descubrimiento (*discovery*)** — `launcher.discover(LauncherDiscoveryRequest)` → construcción del `TestPlan`.
2. **Ejecución (*execution*)** — `launcher.execute(LauncherExecutionRequest)` → notificación de eventos a los `TestExecutionListener`.

Aspectos concretos que se cubren:

| Área | Qué se verifica |
|---|---|
| Construcción del Launcher | Precondiciones (al menos un motor), IDs duplicados, IDs reservados (`junit-`, `junit-jupiter`, `junit-vintage`) |
| Descubrimiento | Planes vacíos, uno o varios motores, motores que devuelven `null` o lanzan excepciones |
| Filtros post-descubrimiento | Aplicación de `PostDiscoveryFilter` y poda (*pruning*) de descriptores huérfanos |
| Parámetros de configuración | Propagación al `ExecutionRequest`, *fallback* a propiedades del sistema |
| Eventos de ejecución | Orden y consistencia de `executionStarted/Finished/Skipped`, tests dinámicos |
| Robustez ante fallos del motor | Envoltura de excepciones en mensajes del tipo `"TestEngine with ID 'x' failed to ..."` |
| `DiscoveryIssue` | Severidad crítica configurable, fase de fallo (*discovery*/*execution*), *logging* de incidencias no críticas |
| Modo *dry-run* | Se reportan eventos pero no se ejecuta el código de los tests |
| Cancelación | Comportamiento con un `CancellationToken` ya cancelado |

### Tecnologías y colaboradores

- **JUnit Jupiter**: `@Test`, `@ParameterizedTest`, `@ValueSource`, `@SetSystemProperty`, `@TrackLogRecords`.
- **Mockito**: `mock`, `spy`, `verify`, `inOrder`, `ArgumentCaptor`, `doAnswer`.
- **AssertJ** (`assertThat`) y aserciones de Jupiter (`assertAll`, `assertThrows`, `assertPreconditionViolationFor`).
- **Dobles de prueba**: `TestEngineStub`, `TestEngineSpy`, `TestDescriptorStub`, `PostDiscoveryFilterStub`, `DemoHierarchicalTestEngine`, `FaultyTestEngines`.

---

## 2. Miembros de la clase

| Miembro | Tipo | Descripción |
|---|---|---|
| `FOO` | `static final String` | Clave de propiedad del sistema (`"DefaultLauncherTests.foo"`) usada en el test de *fallback*. |
| `BAR` | `static final String` | Valor asociado a `FOO`. |
| `noOp` | `private static final Runnable` | Cuerpo de test vacío reutilizado al registrar tests en `DemoHierarchicalTestEngine`. |

---

## 3. Métodos de prueba principales

### 3.1 Construcción y validación de motores

| Método | Comportamiento verificado |
|---|---|
| `constructLauncherWithoutAnyEngines()` | Un Launcher sin motores produce una violación de precondición con el mensaje *"Cannot create Launcher without at least one TestEngine"*. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | Dos motores con el mismo ID provocan `JUnitException` (*"multiple engines with the same ID"*). |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | Un motor de terceros con prefijo `junit-` genera una `DiscoveryIssueException` de severidad `WARNING`. |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` / `...Vintage...()` | Usar los IDs reservados `junit-jupiter` / `junit-vintage` lanza `JUnitException`. Delegan en `assertImposter(String)`. |

### 3.2 Descubrimiento y construcción del `TestPlan`

| Método | Comportamiento verificado |
|---|---|
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | Un motor sin tests produce un plan con una única raíz. |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | Si `discover()` devuelve `null`, se sintetiza una raíz de error y se notifica el fallo a los `LauncherDiscoveryListener`. |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class)` | *(parametrizado con `Error` y `RuntimeException`)* El fallo se transforma en un descriptor de error; al ejecutarse, el resultado contiene *"failed to discover tests"*. |
| `discoverTestPlanForSingleEngine()` | Jerarquía correcta (raíz + 2 hijos) y acceso por `UniqueId`. |
| `discoverTestPlanForMultipleEngines()` | Dos raíces, una por motor, con sus respectivos hijos. |
| `launcherAppliesPostDiscoveryFilters()` | Los filtros se combinan con AND lógico; solo sobrevive el descriptor que cumple todos. |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | Los contenedores que quedan sin tests tras el filtrado se eliminan del plan. |
| `launcherCanExecuteTestPlanExactlyOnce()` | `discover()` y `execute()` invocan al motor una sola vez; una segunda ejecución del mismo plan viola la precondición *"TestPlan must only be executed once"*. |

### 3.3 Reporte de eventos y fallos de ejecución

Familia `reportsEngineExecutionFailures*`: cada test usa un `TestEngineStub` que falla en un punto distinto del ciclo de vida y comprueba que el Launcher **siempre** emite un par coherente `executionStarted` / `executionFinished` con una excepción envolvente *"TestEngine with ID 'TestEngineStub' failed to execute tests"*.

| Método | Escenario |
|---|---|
| `reportsEngineExecutionFailuresWithoutPriorEvents()` | Excepción sin haber emitido ningún evento. |
| `reportsEngineExecutionFailuresForSkippedEngine()` | Excepción después de `executionSkipped` del motor. |
| `reportsEngineExecutionFailuresForStartedEngine()` | Excepción después de `executionStarted`. |
| `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` | Excepción después de finalizar con éxito. |
| `reportsEngineExecutionFailuresForFailedFinishedEngine()` | Excepción tras finalizar con fallo; el fallo original queda como *suppressed*. |
| `reportsSkippedEngines()` | Un motor omitido produce solo `executionSkipped` (sin *started*/*finished*). |
| `reportsFinishedEngines()` | Caso feliz: `executionStarted` + `executionFinished(successful())`. |
| `reportsDynamicTestDescriptorsCorrectly()` | Registro de tests dinámicos: se valida la relación padre-hijo en el `TestPlan` y el orden exacto de eventos mediante `InOrder`. |

### 3.4 Parámetros de configuración y listeners

| Método | Comportamiento verificado |
|---|---|
| `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()` | Sin parámetros, la consulta devuelve `Optional.empty()`. |
| `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()` | Los parámetros declarados llegan al `ExecutionRequest`. |
| `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | Con `@SetSystemProperty`, la búsqueda cae a propiedades del sistema. |
| `withAdditionalListener()` | Un `SummaryGeneratingListener` registrado en la petición recibe el resumen correcto. |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | Los `LauncherDiscoveryListener` registrados en el `LauncherConfig`, en el `Launcher` y en la petición reciben todos `selectorProcessed(...)`. |

### 3.5 Modo *dry-run*

- `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`: con `DRY_RUN_PROPERTY_NAME=true` se emite la secuencia completa de eventos y los tests se marcan como omitidos con el motivo *"JUnit Platform dry-run mode is enabled"*, sin ejecutar su cuerpo (que lanzaría una excepción).

### 3.6 Gestión de `DiscoveryIssue`

| Método | Comportamiento verificado |
|---|---|
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener)` | Las incidencias críticas (`ERROR`) provocan `DiscoveryIssueException` en ejecución; las no críticas se registran en el log con nivel `WARNING`. |
| `logsNonCriticalIssuesForRegularEngineExecution(...)` | Una incidencia `INFO` no impide el éxito; se registra a nivel `INFO`. |
| `logsAllIssuesForDiscoveryFailure(...)` | Si el descubrimiento falla, se registran tanto las incidencias críticas (`SEVERE`) como las no críticas (`INFO`). |
| `logsNonCriticalIssuesForExecutionFailure(...)` | Las incidencias no críticas se registran incluso si la ejecución falla. |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | Un `UniqueIdSelector` con el prefijo del motor que no se resuelve es una incidencia crítica. |
| `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` | Si el selector apunta a otro motor, se ignora silenciosamente (resultado `SUCCESSFUL`). |
| `reportsEngineExecutionFailureForSelectorResolutionFailure()` | Un fallo en la resolución de un selector se reporta con causa incluida en el mensaje. |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` | `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME` permite elevar `INFO` a crítico. |
| `failsIfCriticalSeverityIsConfiguredIncorrectly()` | Un valor inválido de severidad produce `JUnitException`. |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | Con `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery`, el fallo se lanza ya en `discover()`. |
| `logsNonCriticalIssuesOnlyOnce(String, LogRecordListener)` | *(parametrizado: `"discovery"`, `"execution"`)* Garantiza que no haya *logging* duplicado. |
| `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()` | Una fase inválida produce `JUnitException` con mensaje *"Invalid LauncherPhase 'wrong' ..."*. |

### 3.7 Cancelación

- `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`: con un `CancellationToken` ya cancelado, el motor **no** se ejecuta (`verify(engine, never()).execute(any())`), el descriptor del motor se inicia y finaliza con estado `ABORTED`, y sus hijos se reportan como omitidos con el motivo *"Execution cancelled"*.

---

## 4. Métodos auxiliares (privados)

| Método | Descripción |
|---|---|
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | Verifica, en orden, `engineDiscoveryStarted` / `engineDiscoveryFinished` y que el `EngineDiscoveryResult` tenga estado `FAILED` con el mensaje esperado. |
| `assertImposter(String id)` | Crea un motor con un ID reservado y comprueba la `JUnitException` con el mensaje de "ID prohibido". |
| `execute(TestEngine)` | Sobrecarga de conveniencia: descubre y ejecuta con configuración por defecto. |
| `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)` | Permite personalizar la petición de descubrimiento. |
| `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)` | **Método central de apoyo.** Crea el Launcher, aplica los configuradores, ejecuta el plan con un `TestExecutionListener` mockeado, registra los instantes de inicio/fin, valida el orden mínimo de eventos (`testPlanExecutionStarted → executionStarted → executionFinished → testPlanExecutionFinished`, sin más interacciones) y devuelve un `ReportedData`. Por defecto desactiva los parámetros implícitos y fija la fase de fallo en `execution` y el listener de descubrimiento en `logging`. |
| `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` | Obtiene el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con el nivel indicado; lanza excepción si no existe. |

---

## 5. Tipo anidado

```java
private record ReportedData(
    TestPlan testPlan,
    TestIdentifier testIdentifier,
    TestExecutionResult testExecutionResult,
    Instant startTime,
    Instant finishTime) { }
```

**`ReportedData`** es un *record* privado que encapsula el resultado observado de un ciclo completo descubrimiento + ejecución:

- `testPlan`: plan generado por el Launcher.
- `testIdentifier`: identificador del descriptor raíz (normalmente el motor) capturado en `executionStarted`.
- `testExecutionResult`: resultado capturado en `executionFinished`.
- `startTime` / `finishTime`: marcas temporales usadas para comprobar que los `LogRecord` de incidencias se emiten **dentro** de la ventana de ejecución.

---

## 6. Notas de uso y mantenimiento

- Los mensajes de error se asertan **textualmente**; cualquier cambio en los mensajes de `DefaultLauncher`, `EngineDiscoveryOrchestrator` o `DiscoveryIssueNotifier` requerirá actualizar estas pruebas.
- Las pruebas que dependen de propiedades del sistema usan `@SetSystemProperty` para garantizar aislamiento; las que inspeccionan logs usan `@TrackLogRecords` para inyectar un `LogRecordListener`.
- El uso extensivo de `InOrder` + `verifyNoMoreInteractions()` convierte a esta clase en la especificación de facto del **orden exacto de eventos** que el Launcher debe emitir.
- `LauncherFactoryForTestingPurposesOnly` se emplea para desactivar el *service loading* y construir Launchers deterministas con motores controlados.