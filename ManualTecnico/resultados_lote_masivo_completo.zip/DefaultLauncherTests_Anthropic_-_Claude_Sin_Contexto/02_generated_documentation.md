# Documentación Técnica: `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`
**Visibilidad:** package-private (`class DefaultLauncherTests`)
**Anotaciones:** `@NullMarked` (JSpecify — todos los tipos no anotados se consideran no nulos)
**Desde:** versión 1.0 de JUnit Platform

---

## 1. Descripción general

`DefaultLauncherTests` es una **clase de pruebas unitarias/integración** (no una clase de producción) que verifica el comportamiento de la implementación por defecto del `Launcher` del JUnit Platform (`DefaultLauncher`, instanciada a través de `LauncherFactoryForTestingPurposesOnly.createLauncher(...)`).

Su propósito es validar, de extremo a extremo y de forma aislada de motores reales (JUnit Jupiter / Vintage), el contrato del *Launcher* en sus dos fases fundamentales:

| Fase | Aspectos verificados |
|---|---|
| **Descubrimiento (discovery)** | Validación de precondiciones, IDs de motores duplicados o reservados, construcción del `TestPlan`, aplicación de `PostDiscoveryFilter`, poda (*pruning*) de descriptores, notificación a `LauncherDiscoveryListener`, tratamiento de `DiscoveryIssue`. |
| **Ejecución (execution)** | Propagación de parámetros de configuración, registro de *listeners*, reporte de eventos (`executionStarted`, `executionSkipped`, `executionFinished`), tests dinámicos, modo *dry-run*, cancelación mediante `CancellationToken`, tolerancia a fallos lanzados por el motor. |

La clase se apoya en:

* **Motores falsos / dobles de prueba:** `TestEngineStub`, `TestEngineSpy`, `DemoHierarchicalTestEngine`, `TestDescriptorStub`, `FaultyTestEngines`.
* **Mockito:** `mock`, `spy`, `verify`, `inOrder`, `ArgumentCaptor`, `doAnswer`.
* **AssertJ + JUnit Jupiter Assertions** para las aserciones.
* **Extensiones de soporte:** `@TrackLogRecords` (captura de `LogRecord` mediante `LogRecordListener`) y `@SetSystemProperty` (manipulación controlada de propiedades del sistema).

---

## 2. Miembros estáticos y campos

| Miembro | Tipo | Descripción |
|---|---|---|
| `FOO` | `static final String` | Clave de propiedad del sistema (`"DefaultLauncherTests.foo"`) usada para comprobar el *fallback* de parámetros de configuración a propiedades del sistema. |
| `BAR` | `static final String` | Valor asociado a `FOO`. |
| `noOp` | `private static final Runnable` | Cuerpo de test vacío, utilizado al registrar tests en `DemoHierarchicalTestEngine`. |

---

## 3. Métodos de prueba principales

### 3.1 Construcción y validación del Launcher

| Método | Comportamiento verificado |
|---|---|
| `constructLauncherWithoutAnyEngines()` | Descubrir sin ningún `TestEngine` registrado produce una violación de precondición con el mensaje *"Cannot create Launcher without at least one TestEngine"*. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | Dos motores con el mismo ID provocan una `JUnitException` (*"multiple engines with the same ID"*). |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | Un motor de terceros con prefijo reservado `junit-` genera un `DiscoveryIssue` de severidad `WARNING` que deriva en `DiscoveryIssueException`. |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` / `thirdPartyEngineClaimingToBeVintageResultsInException()` | Usar los IDs reservados `junit-jupiter` / `junit-vintage` lanza `JUnitException` (delegan en el *helper* `assertImposter`). |

### 3.2 Descubrimiento y construcción del `TestPlan`

| Método | Comportamiento verificado |
|---|---|
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | Un motor sin tests sigue aportando una raíz al `TestPlan`. |
| `discoverTestPlanForSingleEngine()` | Jerarquía correcta (raíz + 2 hijos) y acceso a hijos tanto por `TestIdentifier` como por `UniqueId`. |
| `discoverTestPlanForMultipleEngines()` | Con dos motores y selectores `selectUniqueId`, el plan contiene dos raíces, una por motor. |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | Si `discover()` devuelve `null`, el Launcher crea un descriptor de error y notifica el fallo a los *listeners*. |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class)` | **`@ParameterizedTest`** con `Error` y `RuntimeException`: se genera un descriptor de error, se notifica el ciclo completo de *discovery* y, al ejecutar, se reporta el fallo *"failed to discover tests"*. |
| `launcherAppliesPostDiscoveryFilters()` | Los `PostDiscoveryFilter` se aplican de forma acumulativa (AND lógico). |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | Los contenedores que quedan sin tests tras el filtrado se eliminan del plan. |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | Los `LauncherDiscoveryListener` registrados vía `LauncherConfig`, vía `Launcher.registerLauncherDiscoveryListeners` y vía *request* reciben todos el evento `selectorProcessed`. |

### 3.3 Reporte de fallos del motor en ejecución

Grupo de pruebas que comprueban que el Launcher **siempre** emite un par coherente `executionStarted` / `executionFinished` para el motor, envolviendo la causa raíz en un mensaje *"TestEngine with ID '…' failed to execute tests"*, independientemente de los eventos previamente emitidos por el motor:

* `reportsEngineExecutionFailuresWithoutPriorEvents()` — el motor falla sin emitir eventos.
* `reportsEngineExecutionFailuresForSkippedEngine()` — falla tras marcar el motor como *skipped*.
* `reportsEngineExecutionFailuresForStartedEngine()` — falla tras `executionStarted`.
* `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` — falla tras finalizar con éxito.
* `reportsEngineExecutionFailuresForFailedFinishedEngine()` — el fallo original se adjunta como *suppressed exception*.
* `reportsSkippedEngines()` — un motor omitido no genera `executionStarted`/`executionFinished`.
* `reportsFinishedEngines()` — ciclo normal satisfactorio.

### 3.4 Parámetros de configuración y *listeners*

| Método | Comportamiento verificado |
|---|---|
| `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()` | Sin parámetros, el `ExecutionRequest` recibe una configuración vacía. |
| `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()` | Los parámetros declarados llegan intactos al motor. |
| `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | Con `@SetSystemProperty`, la búsqueda de parámetros recurre a las propiedades del sistema. |
| `withAdditionalListener()` | Un `SummaryGeneratingListener` adicional recibe los eventos y produce un resumen correcto. |

### 3.5 Ciclo de vida, tests dinámicos, *dry-run* y cancelación

| Método | Comportamiento verificado |
|---|---|
| `launcherCanExecuteTestPlanExactlyOnce()` | `discover()` invoca el motor una sola vez; un `TestPlan` ya ejecutado no puede reejecutarse (*"TestPlan must only be executed once"*). |
| `reportsDynamicTestDescriptorsCorrectly()` | Los descriptores registrados dinámicamente se incorporan al `TestPlan` con la jerarquía padre/hijo correcta y los eventos se emiten en el orden esperado. |
| `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | Con `DRY_RUN_PROPERTY_NAME=true`, los tests se reportan como *skipped* (*"JUnit Platform dry-run mode is enabled"*) sin ejecutar su cuerpo. |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | Con un `CancellationToken` ya cancelado, el motor **no** se ejecuta (`verify(engine, never()).execute(any())`) y los hijos se reportan como *skipped* con motivo *"Execution cancelled"*, finalizando el motor con estado `ABORTED`. |

### 3.6 Gestión de `DiscoveryIssue`

| Método | Comportamiento verificado |
|---|---|
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener)` | Las incidencias críticas (`ERROR`) se convierten en `DiscoveryIssueException` durante la ejecución; las no críticas (`WARNING`) se registran en el log. Se preservan nombre y *tags* del descriptor del motor. |
| `logsNonCriticalIssuesForRegularEngineExecution(...)` | Las incidencias `INFO` se registran a nivel `INFO` y no afectan al resultado (`SUCCESSFUL`). |
| `logsAllIssuesForDiscoveryFailure(...)` | Si el descubrimiento lanza una excepción, se registran todas las incidencias (críticas en `SEVERE`, no críticas en `INFO`). |
| `logsNonCriticalIssuesForExecutionFailure(...)` | Un fallo de ejecución no impide el registro de incidencias no críticas. |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | Un `UniqueIdSelector` con prefijo del propio motor que no se resuelve es un error crítico. |
| `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` | Un `UniqueIdSelector` dirigido a otro motor se ignora silenciosamente. |
| `reportsEngineExecutionFailureForSelectorResolutionFailure()` | Un fallo al resolver un selector se reporta con causa incluida en el mensaje. |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` | `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME` permite elevar `INFO` a crítico. |
| `failsIfCriticalSeverityIsConfiguredIncorrectly()` | Un valor de severidad inválido produce `JUnitException` con mensaje explicativo. |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | Con `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery`, el fallo se lanza en la fase de descubrimiento. |
| `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()` | Un valor de fase inválido produce `JUnitException` (*"Invalid LauncherPhase"*). |
| `logsNonCriticalIssuesOnlyOnce(String, LogRecordListener)` | **`@ParameterizedTest`** (`"discovery"`, `"execution"`): las incidencias no críticas se registran exactamente una vez en cualquiera de las dos fases. |

---

## 4. Métodos auxiliares (privados)

| Firma | Responsabilidad |
|---|---|
| `private void assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | Verifica, en orden, los eventos `engineDiscoveryStarted` / `engineDiscoveryFinished` y que el `EngineDiscoveryResult` tenga estado `FAILED` con el mensaje *"TestEngine with ID '…' failed to discover tests"*. |
| `private void assertImposter(String id)` | Crea un motor de terceros con un ID reservado y comprueba el mensaje exacto de la `JUnitException` resultante. |
| `private static ReportedData execute(TestEngine)` | Sobrecarga de conveniencia: ejecuta con configuración por defecto (`identity()`). |
| `private static ReportedData execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)` | Permite personalizar la petición de descubrimiento. |
| `private static ReportedData execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)` | **Método central de la clase.** Crea el Launcher, construye la petición de descubrimiento (desactivando parámetros implícitos y fijando la fase de fallo en `execution` y el *listener* por defecto en `logging`), descubre el `TestPlan`, construye y ejecuta la petición de ejecución, registra marcas temporales de inicio/fin mediante `doAnswer`, valida el orden canónico de eventos y devuelve los datos recopilados. |
| `private static LogRecord findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` | Obtiene el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con el nivel indicado, o lanza excepción si no existe. |

---

## 5. Tipo anidado

```java
private record ReportedData(
    TestPlan testPlan,
    TestIdentifier testIdentifier,
    TestExecutionResult testExecutionResult,
    Instant startTime,
    Instant finishTime) { }
```

**Descripción:** *record* inmutable que agrupa el resultado observable de una ejecución orquestada por el método auxiliar `execute(...)`:

* `testPlan` — plan de pruebas descubierto.
* `testIdentifier` — identificador capturado en `executionStarted` (normalmente el motor raíz).
* `testExecutionResult` — resultado capturado en `executionFinished`.
* `startTime` / `finishTime` — instantes de inicio y fin, usados para comprobar que los mensajes de log se emiten **dentro** de la ventana de ejecución.

---

## 6. Notas de uso y mantenimiento

* La clase **no forma parte de la API pública**; depende de `LauncherFactoryForTestingPurposesOnly`, que deshabilita el `ServiceLoader` para evitar el descubrimiento automático de motores y *listeners* del *classpath*.
* Los tests son **deterministas y aislados**: cada uno construye su propio `Launcher` con motores dobles, por lo que no dependen de JUnit Jupiter ni de Vintage.
* Varias pruebas emplean supresiones intencionadas (`@SuppressWarnings("DataFlowIssue")`) para poder devolver `null` desde `TestEngine.discover(...)` y así ejercitar rutas de error.
* Al añadir nuevos escenarios de `DiscoveryIssue` se recomienda reutilizar el *helper* `execute(...)` para mantener homogéneo el contrato de verificación de eventos.