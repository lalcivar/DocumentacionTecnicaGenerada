# Documentación técnica: `DefaultLauncherTests`

## Información general

| Atributo | Valor |
|---|---|
| **Paquete** | `org.junit.platform.launcher.core` |
| **Tipo** | Clase de pruebas (package-private, `final` implícito por visibilidad de test) |
| **Anotaciones** | `@NullMarked` (JSpecify: los tipos de referencia no son nulos por defecto) |
| **Desde** | 1.0 |
| **Licencia** | Eclipse Public License v2.0 |

## Descripción general

`DefaultLauncherTests` es la **suite de pruebas unitarias del `DefaultLauncher`** (la implementación por defecto de la interfaz `Launcher` de la JUnit Platform). Su objetivo es verificar el comportamiento del ciclo de vida completo del *launcher*: **construcción**, **descubrimiento (discovery)** y **ejecución (execution)** de planes de prueba.

La clase no expone API pública reutilizable; sus «métodos principales» son casos de prueba (`@Test` / `@ParameterizedTest`) más un pequeño conjunto de métodos auxiliares privados.

### Áreas funcionales cubiertas

1. **Validación de precondiciones y construcción del launcher**
   - Rechazo de launchers sin ningún `TestEngine`.
   - Detección de motores con IDs duplicados.
   - Protección del prefijo reservado `junit-` y de los IDs `junit-jupiter` / `junit-vintage` frente a motores de terceros.

2. **Descubrimiento de planes de prueba (`Launcher#discover`)**
   - Planes vacíos, de un solo motor y de múltiples motores.
   - Motores que devuelven `null` como descriptor raíz o que lanzan `Error`/`RuntimeException` durante el descubrimiento.
   - Aplicación de `PostDiscoveryFilter` y poda (*pruning*) de descriptores que quedan sin hijos tras el filtrado.

3. **Ejecución de planes de prueba (`Launcher#execute`)**
   - Propagación y envoltura de fallos del motor en distintos estados (sin eventos previos, omitido, iniciado, finalizado con éxito, finalizado con fallo —verificando `suppressed` y `cause`—).
   - Notificación correcta de motores omitidos y finalizados.
   - Registro y reporte de tests dinámicos (`dynamicTestRegistered`) con verificación del orden de eventos mediante `InOrder`.
   - Garantía de que un `TestPlan` solo puede ejecutarse **una vez**.

4. **Parámetros de configuración**
   - Paso de parámetros vacíos/poblados al `ExecutionRequest`.
   - *Fallback* a propiedades del sistema (`@SetSystemProperty`).
   - Modo *dry-run* (`DRY_RUN_PROPERTY_NAME`): se emiten eventos pero no se ejecuta el código de prueba.

5. **Gestión de `DiscoveryIssue`**
   - Fallo de ejecución del motor ante incidencias críticas y registro (*logging*) de las no críticas.
   - Configuración de la severidad crítica (`CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME`) y de la fase de fallo (`DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME`), incluyendo valores inválidos.
   - Garantía de que las incidencias no críticas se registran **una sola vez**.
   - Selectores `UniqueId` no resueltos (con y sin prefijo de motor) y fallos de resolución de selectores.

6. **Listeners de descubrimiento**
   - Notificación de selectores procesados a listeners registrados vía `LauncherConfig`, vía `Launcher#registerLauncherDiscoveryListeners` y vía la propia petición.

7. **Cancelación**
   - Con un `CancellationToken` ya cancelado, el motor no se ejecuta y sus hijos se reportan como omitidos (`"Execution cancelled"`), finalizando el motor con estado `ABORTED`.

## Constantes y campos

| Miembro | Tipo | Descripción |
|---|---|---|
| `FOO` | `static final String` | Clave de propiedad de sistema usada en la prueba de *fallback* de configuración (`"DefaultLauncherTests.foo"`). |
| `BAR` | `static final String` | Valor esperado asociado a `FOO`. |
| `noOp` | `private static final Runnable` | Cuerpo de test vacío para los tests sintéticos de `DemoHierarchicalTestEngine`. |

## Métodos principales

### Casos de prueba destacados

| Método | Propósito |
|---|---|
| `constructLauncherWithoutAnyEngines()` | Verifica la violación de precondición al descubrir sin motores registrados. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | Espera `JUnitException` por IDs de motor duplicados. |
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | Un motor sin tests produce un plan con una única raíz. |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | Un descriptor raíz `null` se traduce en fallo de descubrimiento notificado al listener. |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class)` | *Parameterized* (`Error`, `RuntimeException`): se crea un descriptor de error y la ejecución falla con el mensaje *«failed to discover tests»*. |
| `reportsEngineExecutionFailures*` (5 variantes) | Verifican el envoltorio del fallo del motor según el estado de los eventos ya emitidos. |
| `reportsSkippedEngines()` / `reportsFinishedEngines()` | Propagación de `executionSkipped` / `executionStarted`+`executionFinished`. |
| `discoverTestPlanForSingleEngine()` / `...ForMultipleEngines()` | Estructura jerárquica del `TestPlan` resultante. |
| `launcherAppliesPostDiscoveryFilters()` | Composición (AND) de varios filtros post-descubrimiento. |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | Eliminación de contenedores que quedan sin tests. |
| `reportsDynamicTestDescriptorsCorrectly()` | Orden y jerarquía de eventos para tests registrados dinámicamente. |
| `launcherCanExecuteTestPlanExactlyOnce()` | El segundo `execute` del mismo plan lanza violación de precondición. |
| `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | Comportamiento del modo *dry-run*. |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | Las tres vías de registro de `LauncherDiscoveryListener` reciben `selectorProcessed`. |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` / `failsIfCriticalSeverityIsConfiguredIncorrectly()` | Configuración válida e inválida de la severidad crítica. |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` / `...ValueIsInvalid()` | Selección de la fase (`discovery`/`execution`) en la que fallan las incidencias. |
| `logsNonCriticalIssuesOnlyOnce(String)` | *Parameterized* (`discovery`, `execution`): evita el registro duplicado. |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | Semántica de cancelación previa a la ejecución. |

### Métodos auxiliares

| Método | Firma / Descripción |
|---|---|
| `assertDiscoveryFailed` | `private void assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` — Verifica, en orden, los eventos `engineDiscoveryStarted`/`engineDiscoveryFinished` y que el `EngineDiscoveryResult` tenga estado `FAILED` con el mensaje esperado. |
| `assertImposter` | `private void assertImposter(String id)` — Comprueba que un motor de terceros que usurpa un ID reservado provoca `JUnitException`. |
| `execute(TestEngine)` | Sobrecarga de conveniencia: descubre y ejecuta con configuración por defecto. |
| `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)` | Permite personalizar la petición de descubrimiento. |
| `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)` | **Método central de la infraestructura de pruebas**: crea el launcher, registra un `TestExecutionListener` *mock* que captura instantes de inicio/fin, ejecuta descubrimiento y ejecución, verifica el orden mínimo de eventos y devuelve un `ReportedData`. |
| `findFirstDiscoveryIssueLogRecord` | `private static LogRecord findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` — Obtiene el primer registro de log emitido por `DiscoveryIssueNotifier` en el nivel indicado. |

### Tipo anidado

```java
private record ReportedData(
    TestPlan testPlan,
    TestIdentifier testIdentifier,
    TestExecutionResult testExecutionResult,
    Instant startTime,
    Instant finishTime) {}
```

Agrupa los datos capturados durante una ejecución de prueba: el plan descubierto, el identificador del motor, su resultado de ejecución y la ventana temporal (`startTime`–`finishTime`) usada para validar que los mensajes de log se emitieron dentro de la ejecución.

## Dependencias y utilidades empleadas

- **JUnit Jupiter**: `@Test`, `@ParameterizedTest`, `@ValueSource`, `@SetSystemProperty`, `@TrackLogRecords`.
- **AssertJ** (`assertThat`) y aserciones de Jupiter (`assertAll`, `assertThrows`, `assertEquals`, `assertTrue`).
- **Mockito**: `mock`, `spy`, `verify`, `inOrder`, `doAnswer`, `ArgumentCaptor`, matchers (`any`, `eq`, `same`, `argThat`).
- **Dobles de prueba de la plataforma**: `TestEngineStub`, `TestEngineSpy`, `TestDescriptorStub`, `PostDiscoveryFilterStub`, `FaultyTestEngines`, `DemoHierarchicalTestEngine`, `DemoHierarchicalTestDescriptor`.
- **Fábricas internas**: `LauncherFactoryForTestingPurposesOnly.createLauncher(...)` y `createLauncherConfigBuilderWithDisabledServiceLoading()` para aislar las pruebas del `ServiceLoader`.

## Notas de uso

- Es una clase **interna de pruebas** del proyecto JUnit 5; no forma parte de la API pública ni debe usarse como dependencia externa.
- Las pruebas deshabilitan el *service loading* y los parámetros de configuración implícitos para garantizar determinismo.
- Varias pruebas dependen del orden de eventos; cualquier cambio en la secuencia de notificaciones del `DefaultLauncher` romperá estas verificaciones `InOrder`.