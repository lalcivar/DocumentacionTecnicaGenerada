# Documentación técnica: `test_factory.py`

## 1. Descripción general

Este archivo contiene las **pruebas unitarias de la fábrica de aplicaciones (application factory)** del paquete `flaskr`, una aplicación web construida con el framework **Flask**.

Su propósito es verificar dos aspectos fundamentales del arranque de la aplicación:

1. Que la función `create_app()` respete la configuración que se le pasa como argumento (o la configuración por defecto cuando no se le pasa ninguna).
2. Que la instancia de la aplicación generada responda correctamente a una ruta de prueba (`/hello`), validando de forma indirecta que el registro de rutas y el servidor de pruebas funcionan.

El archivo está diseñado para ser ejecutado con **pytest** y sigue la convención de nombres `test_*.py` para su descubrimiento automático.

---

## 2. Dependencias

| Dependencia | Tipo | Uso |
|---|---|---|
| `flaskr.create_app` | Interna (paquete de la aplicación) | Fábrica que construye y configura la instancia de `Flask`. |
| `pytest` | Externa (implícita) | Ejecutor de las pruebas y proveedor del mecanismo de *fixtures*. |
| *fixture* `client` | Externa al archivo (definida normalmente en `conftest.py`) | Cliente de pruebas HTTP de Flask (`app.test_client()`) que permite realizar peticiones sin levantar un servidor real. |

> **Nota:** la fixture `client` **no** se define en este archivo. Se inyecta automáticamente por pytest desde el archivo `conftest.py` del directorio de pruebas.

---

## 3. Importaciones

```python
from flaskr import create_app
```

Importa la función fábrica `create_app` desde el paquete `flaskr`. Este patrón (*application factory*) permite crear múltiples instancias de la aplicación con configuraciones distintas, lo que resulta especialmente útil en entornos de prueba.

---

## 4. Componentes principales

### 4.1 `test_config()`

```python
def test_config():
    """Test create_app without passing test config."""
    assert not create_app().testing
    assert create_app({"TESTING": True}).testing
```

**Propósito:** comprobar que la fábrica `create_app` aplica correctamente la configuración recibida.

**Parámetros:** ninguno.

**Retorno:** `None` (la prueba se valida mediante aserciones).

**Lógica de verificación:**

| Aserción | Qué valida |
|---|---|
| `assert not create_app().testing` | Al invocar la fábrica **sin argumentos**, la aplicación se crea en modo normal: el flag `TESTING` debe ser `False` (valor por defecto de Flask). |
| `assert create_app({"TESTING": True}).testing` | Al pasar un diccionario de configuración de prueba, el flag `TESTING` debe quedar activado (`True`), demostrando que la configuración sobrescribe los valores por defecto. |

**Resultado esperado:** la prueba pasa si la fábrica diferencia correctamente entre el modo producción/desarrollo y el modo de pruebas.

---

### 4.2 `test_hello(client)`

```python
def test_hello(client):
    response = client.get("/hello")
    assert response.data == b"Hello, World!"
```

**Propósito:** verificar que la ruta `/hello` está registrada en la aplicación y devuelve el contenido esperado.

**Parámetros:**

| Nombre | Tipo | Descripción |
|---|---|---|
| `client` | `flask.testing.FlaskClient` | Fixture de pytest que proporciona un cliente HTTP de pruebas asociado a una instancia de la aplicación configurada en modo `TESTING`. |

**Retorno:** `None`.

**Flujo de ejecución:**

1. Se realiza una petición `GET` a la ruta `/hello` mediante el cliente de pruebas.
2. Se obtiene un objeto `Response` de Werkzeug.
3. Se compara el cuerpo crudo de la respuesta (`response.data`, de tipo `bytes`) con el literal `b"Hello, World!"`.

**Resultado esperado:** la aplicación devuelve exactamente la cadena de bytes `Hello, World!` en el cuerpo de la respuesta.

---

## 5. Requisitos previos

Para que estas pruebas se ejecuten correctamente es necesario que:

- El paquete `flaskr` exponga una función `create_app(test_config=None)` en su `__init__.py`.
- Dicha fábrica registre una vista asociada a la ruta `/hello` que devuelva el texto `Hello, World!`.
- Exista un archivo `conftest.py` en el directorio de pruebas que defina (al menos) las fixtures `app` y `client`.

---

## 6. Ejecución

```bash
# Ejecutar todas las pruebas del proyecto
pytest

# Ejecutar únicamente este archivo
pytest tests/test_factory.py

# Ejecutar con salida detallada
pytest -v tests/test_factory.py
```

---

## 7. Consideraciones y posibles mejoras

- **Validación del código de estado:** `test_hello` solo comprueba el cuerpo de la respuesta. Sería recomendable añadir `assert response.status_code == 200`.
- **Comparación de texto:** se podría usar `response.get_data(as_text=True) == "Hello, World!"` para una comparación más legible, evitando el manejo explícito de bytes.
- **Aislamiento:** `test_config` crea instancias de la aplicación directamente (sin fixtures). Esto es intencional, ya que el objetivo es probar la propia fábrica y no una instancia preconfigurada.
- **Cobertura:** este archivo cubre únicamente el arranque y una ruta trivial; las funcionalidades de negocio deben probarse en archivos de test adicionales.