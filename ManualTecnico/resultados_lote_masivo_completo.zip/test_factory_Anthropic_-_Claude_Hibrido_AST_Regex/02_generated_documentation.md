# Documentación Técnica: `tests/test_factory.py`

## 1. Resumen ejecutivo

Módulo de pruebas automatizadas (suite `pytest`) destinado a validar el comportamiento de la *application factory* `create_app` del paquete `flaskr`. Verifica dos aspectos independientes: la correcta propagación del mapa de configuración hacia la instancia de Flask (modo testing activado/desactivado) y la respuesta HTTP del endpoint `/hello` mediante un cliente de pruebas inyectado como *fixture*.

El módulo no expone API pública reutilizable: su único punto de entrada es el *runner* de `pytest`, que descubre automáticamente las funciones cuyo nombre comienza por `test_`.

---

### 1.1. Dependencias e importaciones

| Símbolo | Origen | Tipo | Uso dentro del módulo |
| :--- | :--- | :--- | :--- |
| `create_app` | `flaskr` | Callable (*application factory*) | Instanciación directa de la aplicación en `test_config()`. |
| `client` | *Fixture* `pytest` (resolución externa, p. ej. `conftest.py`) | Argumento inyectado | Parámetro de `test_hello()`; se asume la interfaz de `FlaskClient`. |

> **Nota de alcance:** `create_app` y el *fixture* `client` no están definidos en el código fuente provisto. Esta documentación describe únicamente el contrato que el módulo espera de ellos, sin asumir su implementación interna.

---

## 2. Especificación de funciones

El módulo contiene **dos (2)** funciones de nivel superior. No existen clases, métodos, decoradores, funciones anidadas, *callbacks* ni *workers* de hilos en el código analizado.

---

### 2.1. `test_config()`

Verifica que la *factory* `create_app` respete el argumento de configuración opcional, comprobando el atributo `testing` de la instancia resultante en ambos escenarios (sin configuración y con `{"TESTING": True}`).

```python
def test_config():
    """Test create_app without passing test config."""
```

**Docstring normalizado (Google Style):**

```python
def test_config():
    """Valida la propagación de la configuración en la application factory.

    Ejecuta dos invocaciones de `create_app`:

    1. Sin argumentos: la aplicación debe arrancar con `app.testing`
       evaluado como falso (comportamiento por defecto de producción).
    2. Con el mapa `{"TESTING": True}`: la aplicación debe reflejar
       `app.testing is True`, confirmando que la configuración recibida
       se aplica sobre `app.config`.

    Returns:
        None: Las funciones de prueba de pytest no retornan valor;
            el resultado se comunica vía excepciones.

    Raises:
        AssertionError: Si `create_app()` devuelve una instancia con
            `testing` verdadero, o si `create_app({"TESTING": True})`
            devuelve una instancia con `testing` falso.
    """
```

#### Parámetros de entrada

| Nombre | Tipo | Requerido | Valor por defecto | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | La función no declara parámetros ni consume *fixtures*. |

#### Valor de retorno

| Tipo | Descripción |
| :--- | :--- |
| `None` | Retorno implícito. El éxito se determina por la ausencia de `AssertionError`. |

#### Excepciones (`Raises`)

| Excepción | Condición de activación |
| :--- | :--- |
| `AssertionError` | `create_app().testing` es un valor verdadero (falla `assert not create_app().testing`). |
| `AssertionError` | `create_app({"TESTING": True}).testing` es un valor falso (falla la segunda aserción). |
| *(Propagada)* | Cualquier excepción lanzada internamente por `create_app` durante la construcción de la aplicación se propaga sin capturar y pytest la reporta como *error*. |

#### Detalle de aserciones

| # | Expresión evaluada | Resultado esperado |
| :--- | :--- | :--- |
| 1 | `not create_app().testing` | `True` (modo testing desactivado por defecto) |
| 2 | `create_app({"TESTING": True}).testing` | `True` (configuración aplicada) |

---

### 2.2. `test_hello(client)`

Prueba funcional de integración sobre el endpoint `GET /hello`, validando el cuerpo exacto de la respuesta.

```python
def test_hello(client):
    response = client.get("/hello")
    assert response.data == b"Hello, World!"
```

**Docstring normalizado (Google Style):**

```python
def test_hello(client):
    """Verifica el cuerpo de la respuesta del endpoint GET /hello.

    Realiza una petición HTTP GET a la ruta `/hello` usando el cliente
    de pruebas inyectado y comprueba que el payload binario de la
    respuesta coincida exactamente con `b"Hello, World!"`.

    Args:
        client (flask.testing.FlaskClient): Cliente de pruebas de Flask
            inyectado por pytest como fixture. Debe exponer el método
            `get(path)` y devolver un objeto respuesta con atributo `data`.

    Returns:
        None: Las funciones de prueba de pytest no retornan valor.

    Raises:
        AssertionError: Si `response.data` difiere de `b"Hello, World!"`
            (incluyendo diferencias de codificación, espacios o
            puntuación).
    """
```

#### Parámetros de entrada

| Nombre | Tipo | Requerido | Valor por defecto | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `client` | `flask.testing.FlaskClient` | Sí (inyectado por `pytest`) | — | Cliente de pruebas resuelto por nombre como *fixture*. Debe proveer `get(path)` y una respuesta con el atributo `data` de tipo `bytes`. |

#### Variables locales

| Nombre | Tipo | Descripción |
| :--- | :--- | :--- |
| `response` | `werkzeug.wrappers.Response` (vía `FlaskClient`) | Objeto respuesta devuelto por `client.get("/hello")`. Solo se inspecciona su atributo `data`. |

#### Valor de retorno

| Tipo | Descripción |
| :--- | :--- |
| `None` | Retorno implícito. |

#### Excepciones (`Raises`)

| Excepción | Condición de activación |
| :--- | :--- |
| `AssertionError` | `response.data != b"Hello, World!"`. |
| `fixture 'client' not found` (error de pytest) | El *fixture* `client` no está definido en un `conftest.py` accesible desde el directorio de pruebas. |
| *(Propagada)* | Errores de enrutamiento o de ejecución de la vista `/hello` que el cliente de pruebas no capture y reemplace por una respuesta de error. |

#### Contrato HTTP validado

| Elemento | Valor esperado |
| :--- | :--- |
| Método | `GET` |
| Ruta | `/hello` |
| Cuerpo (`response.data`) | `b"Hello, World!"` (bytes, comparación estricta) |
| Código de estado | No verificado por esta prueba |
| Cabeceras | No verificadas por esta prueba |

---

## 3. Ejemplo de uso

El módulo se consume a través del *runner* de `pytest`. A continuación, un caso de uso real completo que incluye el `conftest.py` mínimo requerido para resolver el *fixture* `client`, y la ejecución programática de la suite.

### 3.1. Estructura de proyecto esperada

```
proyecto/
├── flaskr/
│   └── __init__.py        # define create_app(test_config=None)
└── tests/
    ├── conftest.py        # define el fixture `client`
    └── test_factory.py    # módulo documentado
```

### 3.2. `tests/conftest.py` (requisito externo para `test_hello`)

```python
import pytest

from flaskr import create_app


@pytest.fixture
def app():
    """Instancia la aplicación en modo testing para cada prueba."""
    app = create_app({"TESTING": True})
    yield app


@pytest.fixture
def client(app):
    """Expone el cliente de pruebas consumido por `test_hello()`."""
    return app.test_client()
```

### 3.3. Ejecución desde línea de comandos

```bash
# Ejecuta ambas pruebas del módulo
pytest tests/test_factory.py -v

# Ejecuta únicamente `test_config()`
pytest tests/test_factory.py::test_config

# Ejecuta únicamente `test_hello(client)`
pytest tests/test_factory.py::test_hello
```

### 3.4. Invocación programática y uso directo de las funciones

```python
"""Ejemplo de uso real: ejecución de la suite y llamada directa a las pruebas."""

import pytest

from flaskr import create_app
from tests.test_factory import test_config, test_hello

# --- Opción A: delegar el descubrimiento y la inyección de fixtures a pytest ---
exit_code = pytest.main(["-v", "tests/test_factory.py"])
print(f"Código de salida de la suite: {exit_code}")

# --- Opción B: invocar `test_config()` directamente (no requiere fixtures) ---
try:
    test_config()
    print("test_config(): OK")
except AssertionError as exc:
    print(f"test_config(): FALLO -> {exc}")

# --- Opción C: invocar `test_hello(client)` construyendo el cliente a mano ---
app = create_app({"TESTING": True})
with app.test_client() as client:
    try:
        test_hello(client)
        print("test_hello(client): OK")
    except AssertionError as exc:
        print(f"test_hello(client): FALLO -> {exc}")
```

**Salida esperada (escenario exitoso):**

```
==================== test session starts ====================
tests/test_factory.py::test_config PASSED              [ 50%]
tests/test_factory.py::test_hello  PASSED              [100%]
===================== 2 passed in 0.12s =====================
Código de salida de la suite: 0
test_config(): OK
test_hello(client): OK
```

---

## 4. Resumen de cobertura documental

| Función / Método | Tipo | Parámetros | Retorno | Excepciones documentadas | Estado |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `test_config()` | Función de prueba (nivel superior) | Ninguno | `None` | `AssertionError` | ✅ Documentada |
| `test_hello(client)` | Función de prueba (nivel superior, con *fixture*) | `client` | `None` | `AssertionError`, error de *fixture* no encontrado | ✅ Documentada |

**Cobertura: 2/2 funciones (100 %).** No se detectaron clases, métodos de instancia/clase/estáticos, decoradores definidos localmente, funciones anidadas, *callbacks* ni funciones ejecutadas en hilos dentro del código fuente provisto.