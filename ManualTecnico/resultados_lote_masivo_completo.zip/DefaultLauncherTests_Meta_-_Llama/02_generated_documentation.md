# Documentación Técnica - `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`  
**Tipo:** Clase de Prueba JUnit 5 (`@NullMarked`)  
**Anotación de Clase:** `@since 1.0`

---

### 1. Resumen Ejecutivo

`DefaultLauncherTests` es la suite de pruebas de integración y unitarias para `DefaultLauncher`, la implementación por defecto de la API `Launcher` de JUnit Platform. Valida el ciclo de vida completo de descubrimiento (`discover`) y ejecución (`execute`) de `TestEngine`s, incluyendo el manejo de fallos en descubrimiento/ejecución, filtrado `PostDiscoveryFilter`, propagación de `ConfigurationParameters`, modo `dry-run`, notificaciones a `LauncherDiscoveryListener`/`TestExecutionListener`, gestión de `DiscoveryIssue` y cancelación.

La clase no contiene lógica de producción; actúa como especificación ejecutable del contrato de `LauncherFactory` y `LauncherDiscoveryRequestBuilder`/`LauncherExecutionRequestBuilder` mediante mocks (Mockito), stubs (`TestEngineStub`, `DemoHierarchicalTestEngine`) y aserciones (AssertJ, JUnit Jupiter).

---

### 2. Especificación de Métodos y Constructores

#### 2.1 Información de Clase

| Atributo | Valor |
| :--- | :--- |
| **Nombre Completo** | `org.junit.platform.launcher.core.DefaultLauncherTests` |
| **Modificadores** | `class` (package-private), `@NullMarked` |
| **Superclase** | `java.lang.Object` |
| **Campos Estáticos** | `FOO: String = "DefaultLauncherTests.foo"`, `BAR: String = "DefaultLauncherTests.bar"`, `noOp: Runnable = () -> {}` |

#### 2.2 Constructor

| Firma | Descripción |
| :--- | :--- |
| `DefaultLauncherTests()` | Constructor por defecto implícito generado por el compilador. Sin parámetros. Requerido por JUnit Jupiter para instanciación por reflexión. |

> **Javadoc:**
> ```java
> /**
>  * Constructor por defecto.
>  * @author no especificado
>  */
> ```

---

#### 2.3 Métodos de Prueba Públicos (`@Test` / `@ParameterizedTest`)

Todos los métodos siguientes son `void`, anotados con `@Test` o `@ParameterizedTest`, y no declaran parámetros salvo donde se indica. Su contrato Javadoc es uniforme: verifican una invariante de `DefaultLauncher` mediante aserciones.

##### `constructLauncherWithoutAnyEngines()`
Verifica que `LauncherFactory` falle si no se registra ningún `TestEngine`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | No recibe parámetros |

| @return | Descripción |
| :--- | :--- |
| `void` | No retorna valor |

| @throws | Condición |
| :--- | :--- |
| `AssertionError` | Si `assertPreconditionViolationFor` no detecta la violación esperada |

##### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`
Verifica que se lance `JUnitException` al registrar dos engines con el mismo ID.

| @return | `void` |
| @throws | `AssertionError` si no se lanza `JUnitException` con mensaje `multiple engines with the same ID` |

##### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`
Valida que `discover()` retorne un `TestPlan` con 1 raíz vacía cuando el engine no aporta tests.

| @return | `void` |
| @throws | `AssertionError` si `getRoots().size() != 1` |

##### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
Valida el manejo de `null` retornado por `TestEngine.discover()`. Debe marcar `EngineDiscoveryResult.Status.FAILED`.

| @return | `void` |
| @throws | `AssertionError` |

##### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`
Prueba parametrizada que simula un fallo (`Error` o `RuntimeException`) durante `discover()` y verifica que se genere un descriptor de error y que `executionFinished` reporte el fallo.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `throwableClass` | `Class<? extends Throwable>` | Sí | Clase de la excepción a instanciar vía reflexión (`Error` o `RuntimeException`) |

| @return | `void` |
| @throws | `Exception` (envuelta por `ExceptionUtils.throwAsUncheckedException`) si falla la instanciación reflexiva |

##### `reportsEngineExecutionFailuresWithoutPriorEvents()`
Verifica que una excepción no capturada en `TestEngine.execute()` se reporte como `executionFinished` con mensaje `failed to execute tests`.

| @return | `void` |

##### `reportsEngineExecutionFailuresForSkippedEngine()`
Idem anterior, pero cuando el engine previamente invocó `executionSkipped()`.

| @return | `void` |

##### `reportsEngineExecutionFailuresForStartedEngine()`
Idem, cuando el engine invocó `executionStarted()` antes de fallar.

| @return | `void` |

##### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`
Idem, cuando el engine completó `executionFinished(successful())` y luego lanza excepción.

| @return | `void` |

##### `reportsEngineExecutionFailuresForFailedFinishedEngine()`
Verifica que si el engine ya reportó `failed(originalFailure)` y luego lanza `rootCause`, el resultado final contenga `rootCause` como causa y `originalFailure` como `suppressed`.

| @return | `void` |

##### `reportsSkippedEngines()`
Verifica que `executionSkipped` se propague correctamente a `TestExecutionListener` sin invocar `executionStarted/Finished`.

| @return | `void` |

##### `reportsFinishedEngines()`
Verifica el flujo feliz `executionStarted` -> `executionFinished(successful())`.

| @return | `void` |

##### `discoverTestPlanForSingleEngine()`
Valida descubrimiento con un `DemoHierarchicalTestEngine` con 2 tests.

| @return | `void` |

##### `discoverTestPlanForMultipleEngines()`
Valida descubrimiento con 2 engines y selectores `selectUniqueId`.

| @return | `void` |

##### `launcherAppliesPostDiscoveryFilters()`
Verifica la aplicación secuencial de `PostDiscoveryFilter` y que solo los descriptores que pasan ambos filtros permanezcan en el `TestPlan`.

| @return | `void` |

##### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`
Verifica que sin parámetros de configuración, `EngineDiscoveryRequest.getConfigurationParameters().get("key")` esté vacío.

| @return | `void` |

##### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`
Verifica que `configurationParameter("key", "value")` se propague al `ExecutionRequest`.

| @return | `void` |

##### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`
Con `@SetSystemProperty(key = FOO, value = BAR)`, verifica que `ConfigurationParameters` haga fallback a `System.getProperty`.

| @return | `void` |
| @throws | `AssertionError` si `optionalFoo` no está presente |

##### `withAdditionalListener()`
Verifica que un `SummaryGeneratingListener` registrado vía `request().listeners()` reciba eventos.

| @return | `void` |

##### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
Verifica que los contenedores vacíos tras aplicar `PostDiscoveryFilter` sean podados del `TestPlan`.

| @return | `void` |

##### `reportsDynamicTestDescriptorsCorrectly()`
Valida el registro dinámico de tests (`dynamicTestRegistered`) para descriptores `CONTAINER_AND_TEST` y la correcta construcción de `TestIdentifier` padre/hijo.

| @return | `void` |

##### `launcherCanExecuteTestPlanExactlyOnce()`
Verifica que un `TestPlan` solo pueda ejecutarse una vez; la segunda ejecución debe lanzar violación de precondición `TestPlan must only be executed once`.

| @return | `void` |
| @throws | `AssertionError` si no se detecta la violación |

##### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`
Verifica que un engine con ID `junit-using-reserved-prefix` lance `DiscoveryIssueException` con warning de prefijo reservado.

| @return | `void` |
| @throws | `DiscoveryIssueException` |

##### `thirdPartyEngineClaimingToBeJupiterResultsInException()`
Delega a `assertImposter("junit-jupiter")`.

| @return | `void` |
| @throws | `JUnitException` |

##### `thirdPartyEngineClaimingToBeVintageResultsInException()`
Delega a `assertImposter("junit-vintage")`.

| @return | `void` |
| @throws | `JUnitException` |

##### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`
Con `DRY_RUN_PROPERTY_NAME=true`, verifica que los tests se reporten como `executionSkipped("JUnit Platform dry-run mode is enabled")` y no se ejecuten.

| @return | `void` |

##### `notifiesDiscoveryListenersOfProcessedSelectors()`
Verifica que `LauncherDiscoveryListener.selectorProcessed()` sea notificado a listeners registrados en config, launcher y request.

| @return | `void` |

##### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)`
Valida que `Severity.ERROR` cause fallo en ejecución y `WARNING` se loguee como `Level.WARNING`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Inyectado por `@TrackLogRecords`, captura `LogRecord` de `DiscoveryIssueNotifier` |

| @return | `void` |

##### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)`
Valida que `Severity.INFO` no falle la ejecución pero se loguee como `Level.INFO`.

| @param | `listener` | `LogRecordListener` | Sí | Listener de logs |

##### `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)`
Valida que si `discover()` lanza `RuntimeException` tras reportar issues, todos los issues se logueen (`SEVERE` e `INFO`).

| @param | `listener` | `LogRecordListener` | Sí |

##### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)`
Valida que issues no críticos se logueen incluso si `execute()` falla.

| @param | `listener` | `LogRecordListener` | Sí |

##### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`
Con engine que no resuelve nada, verifica que `selectUniqueId(UniqueId.forEngine(engine.getId()))` genere `DiscoveryIssueException`.

| @return | `void` |

##### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`
Verifica que un selector con prefijo de otro engine sea ignorado (no falle).

| @return | `void` |

##### `reportsEngineExecutionFailureForSelectorResolutionFailure()`
Verifica que una excepción durante `SelectorResolution` se reporte como `DiscoveryIssueException` con causa `RuntimeException: boom`.

| @return | `void` |

##### `allowsConfiguringCriticalDiscoveryIssueSeverity()`
Verifica que `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME=info` eleve `INFO` a crítico y falle la ejecución.

| @return | `void` |

##### `failsIfCriticalSeverityIsConfiguredIncorrectly()`
Verifica que un valor inválido para `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME` lance `JUnitException` con causa `Invalid DiscoveryIssue.Severity`.

| @return | `void` |
| @throws | `JUnitException` |

##### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`
Con `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery`, verifica que el fallo ocurra en fase `discover()`.

| @return | `void` |
| @throws | `DiscoveryIssueException` |

##### `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)`
Prueba parametrizada (`@ValueSource(strings = {"discovery", "execution"})`) que verifica que issues no críticos se logueen solo una vez independientemente de la fase de fallo.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `phase` | `String` | Sí | Fase configurada (`discovery` o `execution`) |
| `listener` | `LogRecordListener` | Sí | Captura logs |

##### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`
Verifica que valor inválido para `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME` lance `JUnitException` con mensaje `Invalid LauncherPhase`.

| @return | `void` |
| @throws | `JUnitException` |

##### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`
Verifica que con `CancellationToken.cancel()` previo, `engine.execute()` nunca se invoque y los hijos se reporten como `ABORTED`/`Skipped("Execution cancelled")`.

| @return | `void` |

---

#### 2.4 Métodos Privados de Utilidad

##### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`
Helper que verifica la secuencia `engineDiscoveryStarted` -> `engineDiscoveryFinished(FAILED)` y el mensaje de excepción.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `testEngine` | `TestEngine` | Sí | Engine cuyo ID se usa para construir `UniqueId.forEngine()` |
| `inOrder` | `InOrder` | Sí | Mock de verificación ordenada de Mockito |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | Mock del listener a verificar |

| @return | `void` |
| @throws | `AssertionError` si el estado no es `FAILED` o el mensaje no coincide |

```java
/**
 * Verifica que el descubrimiento del engine haya fallado.
 * @param testEngine engine bajo prueba, no nulo
 * @param inOrder verificador de orden Mockito, no nulo
 * @param discoveryListener listener mockeado, no nulo
 */
private void assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)
```

##### `assertImposter(String id)`
Helper que crea un `TestEngineStub` con ID reservado y verifica que `discover()` lance `JUnitException` con mensaje de ID reservado.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | `String` | Sí | ID impostor (`junit-jupiter` o `junit-vintage`) |

| @return | `void` |
| @throws | `AssertionError` si no se lanza `JUnitException` |

---

#### 2.5 Métodos Estáticos Privados

##### `execute(TestEngine engine)`
Sobrecarga de conveniencia que delega a `execute(engine, identity())`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | Engine a ejecutar |

| @return | `ReportedData` | Record con `testPlan`, `testIdentifier`, `testExecutionResult`, `startTime`, `finishTime` |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)`
Sobrecarga que permite configurar el `LauncherDiscoveryRequestBuilder`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | Engine a ejecutar |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Función que muta el builder de descubrimiento |

| @return | `ReportedData` |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)`
Implementación principal. Crea `Launcher`, construye `LauncherDiscoveryRequest` con `enableImplicitConfigurationParameters(false)` y `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=execution`, ejecuta `discover` y `execute`, captura `TestIdentifier` y `TestExecutionResult` vía `ArgumentCaptor` y tiempos vía `doAnswer`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | Engine bajo prueba |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Configurador de descubrimiento |
| `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Configurador de ejecución |

| @return | `ReportedData` | Datos reportados por el `TestExecutionListener` mockeado |
| @throws | `NullPointerException` | Si `startTime` o `finishTime` no fueron capturados (`requireNonNull`) |

##### `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)`
Busca el primer `LogRecord` de `DiscoveryIssueNotifier` para un nivel dado.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Fuente de logs inyectada por `@TrackLogRecords` |
| `level` | `Level` | Sí | Nivel `java.util.logging.Level` a filtrar |

| @return | `LogRecord` | Primer registro encontrado |
| @throws | `NoSuchElementException` | Si no existe registro para ese nivel (`orElseThrow`) |

---

#### 2.6 Clases Anónimas, Internas y Métodos Sobrescritos

Todas las clases anónimas extienden `TestEngineStub`, `TestEngineSpy`, `TestDescriptorStub` o `EngineDescriptor`. Se documentan sus métodos sobrescritos.

##### `discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` - en `TestEngineStub` / `TestEngineSpy` anónimos
Implementación de `TestEngine.discover`. Usado en ~15 tests para simular: retorno `null`, lanzamiento de excepción, reporte de `DiscoveryIssue`, notificación de `selectorProcessed`, o construcción de jerarquía `EngineDescriptor -> Container -> Test`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Request con selectores y `DiscoveryListener` |
| `uniqueId` | `UniqueId` | Sí | ID único del engine (`UniqueId.forEngine(id)`) |

| @return | `TestDescriptor` | Descriptor raíz o `null` para simular fallo |
| @throws | `RuntimeException` / `Error` | Lanzado intencionalmente en tests de fallo |

##### `execute(ExecutionRequest request)` - en `TestEngineStub` anónimos
Implementación de `TestEngine.execute`. Simula: lanzar `RuntimeException`, invocar `executionSkipped/Started/Finished` sobre `request.getEngineExecutionListener()`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request` | `ExecutionRequest` | Sí | Contiene `getRootTestDescriptor()` y `getEngineExecutionListener()` |

| @return | `void` |
| @throws | `RuntimeException` | Simula fallo de ejecución |

##### `getType()` - en `TestDescriptorStub` anónimo
Sobrescribe `TestDescriptor.getType()` para retornar `Type.CONTAINER` o `Type.CONTAINER_AND_TEST`.

| @return | `TestDescriptor.Type` | Tipo del descriptor |

##### `getTags()` - en `EngineDescriptor` anónimo
Sobrescribe `EngineDescriptor.getTags()` para retornar `Set.of(TestTag.create("custom-tag"))`.

| @return | `Set<TestTag>` | Conjunto de tags |

##### `ReportedData` - Record Interno
```java
private record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier,
                            TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)
```
Record privado que encapsula el resultado de `execute(...)` para aserciones. Componentes:

| Componente | Tipo | Descripción |
| :--- | :--- | :--- |
| `testPlan` | `TestPlan` | Plan descubierto |
| `testIdentifier` | `TestIdentifier` | Identificador del engine ejecutado |
| `testExecutionResult` | `TestExecutionResult` | Resultado (`SUCCESSFUL`, `FAILED`, `ABORTED`) |
| `startTime` | `Instant` | Timestamp de `executionStarted` |
| `finishTime` | `Instant` | Timestamp de `executionFinished` |

---

### 3. Ejemplo de Uso

El siguiente bloque demuestra el uso real de `DefaultLauncher` (vía `LauncherFactoryForTestingPurposesOnly`) tal como se ejercita en la suite, incluyendo descubrimiento, filtros y ejecución con listeners.

```java
package org.junit.platform.launcher.core;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectPackage;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;

import org.junit.platform.engine.FilterResult;
import org.junit.platform.fakes.TestEngineSpy;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.PostDiscoveryFilterStub;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;

public class EjemploDefaultLauncher {

    public static void main(String[] args) {
        // 1. Crear engine de prueba y launcher
        TestEngineSpy engine = new TestEngineSpy();
        Launcher launcher = LauncherFactoryForTestingPurposesOnly.createLauncher(engine);

        // 2. Construir request de descubrimiento con filtro y listener
        var discoveryRequest = request()
                .selectors(selectPackage("com.example.tests"))
                .filters(new PostDiscoveryFilterStub(
                        descriptor -> FilterResult.includedIf(descriptor.getDisplayName().contains("importante")),
                        () -> "filtro-importante"))
                .build();

        // 3. Descubrir TestPlan
        TestPlan testPlan = launcher.discover(discoveryRequest);
        System.out.println("Roots descubiertos: " + testPlan.getRoots().size());
        System.out.println("Contiene tests: " + testPlan.containsTests());

        // 4. Ejecutar TestPlan exactamente una vez con listener
        SummaryGeneratingListener summaryListener = new SummaryGeneratingListener();
        var executionRequest = LauncherExecutionRequestBuilder.request(testPlan)
                .listeners(summaryListener)
                .configurationParameter("junit.platform.discovery.issue.failure.phase", "execution")
                .build();

        launcher.execute(executionRequest);

        // 5. Consultar resumen
        var summary = summaryListener.getSummary();
        System.out.println("Tests encontrados: " + summary.getTestsFoundCount());
        System.out.println("Tests exitosos: " + summary.getTestsSucceededCount());
        System.out.println("Tests fallidos: " + summary.getTestsFailedCount());

        // Nota: testPlan no puede reutilizarse
        // launcher.execute(executionRequest); // -> PreconditionViolation: TestPlan must only be executed once
    }
}
```

**Notas de uso:**
* `LauncherFactoryForTestingPurposesOnly.createLauncher(...)` es solo para tests; en producción usar `LauncherFactory.create()`.
* `TestPlan` es de un solo uso; intentar `execute()` dos veces lanza `PreconditionViolationException`.
* Los `LauncherDiscoveryListener` deben registrarse antes de `discover()` para recibir `selectorProcessed` y `issueEncountered`.
