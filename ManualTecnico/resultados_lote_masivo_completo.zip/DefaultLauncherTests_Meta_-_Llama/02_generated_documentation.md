# Documentación Técnica - `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`  
**Clase:** `DefaultLauncherTests`  
**Tipo:** Clase de pruebas JUnit Jupiter (`@NullMarked`)  
**Versión:** 1.0  
**Licencia:** Eclipse Public License v2.0

---

### 1. Resumen Ejecutivo

`DefaultLauncherTests` es la suite de pruebas de integración y unitarias para `DefaultLauncher`, la implementación por defecto de la API `Launcher` de JUnit Platform. Su propósito es validar exhaustivamente el ciclo de vida de descubrimiento (`discover`) y ejecución (`execute`) de `TestEngine`s, incluyendo el manejo de `PostDiscoveryFilter`, `LauncherDiscoveryListener`, `ConfigurationParameters`, `DiscoveryIssue`, modo `dry-run`, cancelación y reporte de fallos.

La clase no expone lógica de negocio productiva; actúa como arnés de verificación del contrato del Launcher frente a engines correctos, defectuosos, duplicados y de terceros, garantizando el cumplimiento de precondiciones, aislamiento de fallos y notificación correcta a `TestExecutionListener`.

---

### 2. Especificación de Métodos y Constructores

#### 2.1 Constructor

##### `DefaultLauncherTests()`
Constructor por defecto implícito generado por el compilador. Visibilidad package-private.

| Elemento | Descripción |
| :--- | :--- |
| **Firma** | `DefaultLauncherTests()` |
| **@return** | Instancia de la clase de pruebas |
| **@throws** | Ninguno |

> **Nota:** La clase define dos constantes estáticas y un campo:
> *   `static final String FOO = "DefaultLauncherTests.foo"`
> *   `static final String BAR = "DefaultLauncherTests.bar"`
> *   `private static final Runnable noOp = () -> {}`

#### 2.2 Métodos de Prueba y Utilidad - Clase Principal

##### `constructLauncherWithoutAnyEngines()`
```java
@Test void constructLauncherWithoutAnyEngines()
```
Verifica la precondición de que un `Launcher` no puede crearse sin al menos un `TestEngine`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | No recibe parámetros |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| `void` | - | No retorna valor. La aserción se realiza vía `assertPreconditionViolationFor` |

| @throws | Condición |
| :--- | :--- |
| `AssertionError` | Si la violación de precondición no contiene el mensaje `Cannot create Launcher without at least one TestEngine` |

##### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`
```java
@Test void constructLauncherWithMultipleTestEnginesWithDuplicateIds()
```
Valida que el Launcher falle si se registran múltiples engines con el mismo ID.

| @return | `void` |
| @throws | `AssertionError` si no se lanza `JUnitException` con mensaje `multiple engines with the same ID` |

##### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`
```java
@Test void discoverEmptyTestPlanWithEngineWithoutAnyTests()
```
Comprueba que `discover()` retorna un `TestPlan` con una única raíz cuando el engine no aporta tests.

| @return | `void` |
| @throws | `AssertionError` si `testPlan.getRoots().size() != 1` |

##### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
```java
@Test void discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()
```
Verifica el manejo de un engine que retorna `null` en `discover()`. Debe reportar `EngineDiscoveryResult.Status.FAILED`.

| @return | `void` |
| @throws | `AssertionError` si no se notifica fallo vía `LauncherDiscoveryListener` |

**Clase Anónima Interna 1:** `new TestEngineStub("some-engine-id") { ... }`
| Método | Firma | @param | @return | @throws |
| :--- | :--- | :--- | :--- | :--- |
| `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | `discoveryRequest` (`EngineDiscoveryRequest`, Sí), `uniqueId` (`UniqueId`, Sí) | `TestDescriptor` - retorna `null` intencionalmente | Ninguno |

##### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`
```java
@ParameterizedTest @ValueSource(classes = { Error.class, RuntimeException.class })
void discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `throwableClass` | `Class<? extends Throwable>` | Sí | Clase de excepción a instanciar y lanzar vía reflexión durante el descubrimiento |

| @return | `void` |
| @throws | `AssertionError` si el `TestPlan` no contiene el engine o si `TestExecutionResult` no contiene el mensaje `failed to discover tests` |

**Clase Anónima Interna 2:** `new TestEngineStub("my-engine-id") { ... }`
| Método | Firma | Descripción |
| :--- | :--- | :--- |
| `discover()` | `TestDescriptor discover(EngineDiscoveryRequest, UniqueId)` | Instancia `throwableClass` con constructor `String` y lo lanza vía `ExceptionUtils.throwAsUncheckedException`. Retorna `null` si falla la reflexión. |

##### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`
```java
private void assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)
```
Método de utilidad privado para verificar la secuencia de eventos de fallo de descubrimiento.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `testEngine` | `TestEngine` | Sí | Engine cuyo ID se usa para verificar `UniqueId.forEngine()` |
| `inOrder` | `InOrder` | Sí | Mock de verificación ordenada de Mockito |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | Listener mock capturado con `ArgumentCaptor<EngineDiscoveryResult>` |

| @return | `void` |
| @throws | `AssertionError` si `Status != FAILED` o el mensaje no es `TestEngine with ID '...' failed to discover tests` |

##### `reportsEngineExecutionFailuresWithoutPriorEvents()`, `reportsEngineExecutionFailuresForSkippedEngine()`, `reportsEngineExecutionFailuresForStartedEngine()`, `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`, `reportsEngineExecutionFailuresForFailedFinishedEngine()`
Cinco variantes que validan que cualquier excepción lanzada por `TestEngine.execute()` se reporte como `TestExecutionResult` fallido con mensaje `failed to execute tests`, independientemente del estado previo del `EngineDescriptor`.

| @param | - | No reciben parámetros |
| @return | `void` |
| @throws | `AssertionError` si `TestExecutionResult.getThrowable()` no está presente o no encadena `rootCause` |

**Clases Anónimas Internas 3-7:** `new TestEngineStub() { void execute(ExecutionRequest request) }`
| Método | Firma | Comportamiento específico |
| :--- | :--- | :--- |
| `execute()` | `void execute(ExecutionRequest request)` | Variante 1: lanza `RuntimeException` directamente. Variante 2: notifica `executionSkipped` y luego lanza. Variante 3: notifica `executionStarted` y lanza. Variante 4: `executionStarted` + `executionFinished(successful())` y lanza. Variante 5: `executionStarted` + `executionFinished(failed(originalFailure))` y lanza (verifica `hasSuppressedException`). |

##### `reportsSkippedEngines()`
```java
@Test void reportsSkippedEngines()
```
Verifica que un engine que invoca `executionSkipped` no dispare `executionStarted/Finished`.
**Anónima:** `execute(ExecutionRequest)` -> `request.getEngineExecutionListener().executionSkipped(engineDescriptor, "not today")`

##### `reportsFinishedEngines()`
```java
@Test void reportsFinishedEngines()
```
Verifica el flujo feliz `executionStarted` -> `executionFinished(successful())`.
**Anónima:** `execute(ExecutionRequest)` -> notifica started y finished.

##### `discoverTestPlanForSingleEngine()` / `discoverTestPlanForMultipleEngines()` / `launcherAppliesPostDiscoveryFilters()`
Validan descubrimiento con uno o múltiples `DemoHierarchicalTestEngine` y la aplicación de `PostDiscoveryFilter`.

| Método | @param | @return | @throws |
| :--- | :--- | :--- | :--- |
| `discoverTestPlanForSingleEngine()` | - | `void` | `AssertionError` si `getChildren` != 2 |
| `discoverTestPlanForMultipleEngines()` | - | `void` | `AssertionError` si roots != 2 |
| `launcherAppliesPostDiscoveryFilters()` | - | `void` | `AssertionError` si filtrado no deja 1 hijo |

##### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()` / `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()` / `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`
Validan la propagación de `ConfigurationParameters` al `ExecutionRequest` y el fallback a `System.getProperty`.

| Método | @param | @return |
| :--- | :--- | :--- |
| `withoutConfigurationParameters_...` | - | `void` - verifica `configurationParameters.get("key").isNotPresent()` |
| `withConfigurationParameters_...` | - | `void` - verifica `get("key")` contiene `"value"` |
| `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | - | `void` - anotado con `@SetSystemProperty(key=FOO, value=BAR)`, verifica `assertTrue` y `assertEquals` |

##### `withAdditionalListener()`
```java
@Test void withAdditionalListener()
```
Verifica que un `SummaryGeneratingListener` adicional reciba eventos.
| @return | `void` | @throws | `AssertionError` si `getSummary()` es null o conteos != 1 |

##### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
```java
@Test void prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()
```
Verifica que contenedores sin hijos tras filtrado sean podados del `TestPlan`.
**Anónima 8:** `new TestEngineSpy() { TestDescriptor discover(EngineDiscoveryRequest, UniqueId) }` - construye `EngineDescriptor` -> `Container` -> `Test` y retorna engineDescriptor.
**Anónima 9:** `new TestDescriptorStub(...) { Type getType() }` -> `Type.CONTAINER`

##### `reportsDynamicTestDescriptorsCorrectly()`
```java
@Test void reportsDynamicTestDescriptorsCorrectly()
```
Valida registro y jerarquía de tests dinámicos vía `dynamicTestRegistered`.
**Anónima 10:** `new TestEngineSpy(...) { TestDescriptor discover(...) }` - retorna engine con hijo `CONTAINER_AND_TEST`.
**Anónima 11:** `new TestDescriptorStub(...) { Type getType() }` -> `CONTAINER_AND_TEST`
**Anónima 12:** `new TestEngineSpy(...) { void execute(ExecutionRequest) }` - simula ciclo `executionStarted` -> `dynamicTestRegistered` -> `executionStarted/Finished` dinámico.

##### `launcherCanExecuteTestPlanExactlyOnce()`
```java
@Test void launcherCanExecuteTestPlanExactlyOnce()
```
Verifica que un `TestPlan` solo pueda ejecutarse una vez.
| @throws | `AssertionError` si segunda ejecución no lanza violación `TestPlan must only be executed once` |

##### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` / `thirdPartyEngineClaimingToBeJupiterResultsInException()` / `thirdPartyEngineClaimingToBeVintageResultsInException()` / `assertImposter(String id)`
Validan la protección de IDs reservados `junit-`.

| Método | @param | @return | @throws |
| :--- | :--- | :--- | :--- |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | - | `void` | `DiscoveryIssueException` con mensaje `forbidden to use the reserved 'junit-' prefix` |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` | - | `void` | `JUnitException` |
| `thirdPartyEngineClaimingToBeVintageResultsInException()` | - | `void` | `JUnitException` |
| `assertImposter(String id)` | `id` (`String`, Sí) - ID impostor a probar | `void` | `JUnitException` con mensaje `forbidden to use the reserved '...' TestEngine ID.` | `private` |

##### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`
```java
@Test void dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()
```
Verifica modo `DRY_RUN_PROPERTY_NAME=true`: se reporta `executionSkipped` con mensaje `JUnit Platform dry-run mode is enabled` y no se ejecuta el código del test (que lanzaría `RuntimeException`).

##### `notifiesDiscoveryListenersOfProcessedSelectors()`
```java
@Test void notifiesDiscoveryListenersOfProcessedSelectors()
```
Verifica que `selectorProcessed` se notifique a listeners registrados en config, launcher y request.
**Anónima 13:** `new TestEngineStub("some-engine-id") { TestDescriptor discover(...) }` - itera `getSelectorsByType` y notifica `unresolved()`.

##### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)` / `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)` / `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)` / `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)`
Suite de 4 tests parametrizados por `Severity` que validan el manejo de `DiscoveryIssue` y logging vía `DiscoveryIssueNotifier`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Inyectado por `@TrackLogRecords`, captura `LogRecord` de `DiscoveryIssueNotifier` |

| @return | `void` |
| @throws | `AssertionError` si `Status` o mensajes de log no coinciden con severidad crítica/no crítica |

**Anónimas 14-17:** Cada test define `new TestEngineStub("engine-id") { TestDescriptor discover(...) }` y opcionalmente `void execute(...)` y `Set<TestTag> getTags()` (retorna `custom-tag`).

##### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` / `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` / `reportsEngineExecutionFailureForSelectorResolutionFailure()`
Validan el tratamiento de `SelectorResolutionResult.unresolved()` y fallos de resolución.

| Método | @return | Comportamiento esperado |
| :--- | :--- | :--- |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | `void` | `Status.FAILED` con mensaje `could not be resolved` |
| `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` | `void` | `Status.SUCCESSFUL` |
| `reportsEngineExecutionFailureForSelectorResolutionFailure()` | `void` | `Status.FAILED` con `resolution failed` y causa `boom` |

##### `allowsConfiguringCriticalDiscoveryIssueSeverity()` / `failsIfCriticalSeverityIsConfiguredIncorrectly()` / `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` / `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)` / `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`
Validan los parámetros `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME` y `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME`.

| Método | @param | @throws |
| :--- | :--- | :--- |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` | - | `DiscoveryIssueException` si severidad `info` se configura como crítica |
| `failsIfCriticalSeverityIsConfiguredIncorrectly()` | - | `JUnitException` con `Invalid DiscoveryIssue.Severity 'wrong'` |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | - | `DiscoveryIssueException` en fase `discovery` |
| `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)` | `phase` (`String`, Sí) - `discovery`/`execution`, `listener` (`LogRecordListener`, Sí) | `AssertionError` si `listener.stream(...).size() != 1` |
| `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()` | - | `JUnitException` con `Invalid LauncherPhase 'wrong'` |

**Anónimas 18-22:** Todas usan `new TestEngineStub("engine-id") { TestDescriptor discover(...) }` y algunas `void execute(...)`.

##### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`
```java
@Test void reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()
```
Verifica que con `CancellationToken.cancel()` los hijos se reporten como `ABORTED` y `executionSkipped("Execution cancelled")` sin invocar `engine.execute()`.
**Anónima 23:** `new TestEngineStub("engine-id") { TestDescriptor discover(...) }` - construye `EngineDescriptor` -> `Container` -> `Test`.

#### 2.3 Métodos de Utilidad Estáticos Privados

##### `execute(TestEngine engine)`
```java
private static ReportedData execute(TestEngine engine)
```
Sobrecarga de conveniencia que delega a `execute(engine, identity())`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | Engine a ejecutar |

| @return | `ReportedData` | Record con `testPlan`, `testIdentifier`, `testExecutionResult`, `startTime`, `finishTime` |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)`
```java
private static ReportedData execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)
```
Sobrecarga que permite configurar el `LauncherDiscoveryRequestBuilder`.

| @param | Tipo | Requerido |
| :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí - función de transformación del builder |

| @return | `ReportedData` |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)`
```java
private static ReportedData execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)
```
Implementación central: crea `Launcher`, construye `LauncherDiscoveryRequest` con `enableImplicitConfigurationParameters(false)` y `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=execution`, ejecuta `discover` y `execute` capturando tiempos vía `doAnswer` en mock `TestExecutionListener`.

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | Engine bajo prueba |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Configurador de descubrimiento |
| `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Configurador de ejecución |

| @return | `ReportedData` | Datos capturados vía `ArgumentCaptor<TestIdentifier>` y `ArgumentCaptor<TestExecutionResult>` |
| @throws | `NullPointerException` | Si `startTime` o `finishTime` no fueron capturados (`requireNonNull`) |

##### `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)`
```java
private static LogRecord findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Fuente de `LogRecord`s |
| `level` | `Level` | Sí | Nivel de log a filtrar (`INFO`, `WARNING`, `SEVERE`) |

| @return | `LogRecord` | Primer registro de `DiscoveryIssueNotifier` con el nivel dado |
| @throws | `NoSuchElementException` | Si no existe registro para ese nivel (`orElseThrow`) |

#### 2.4 Record Interno

##### `ReportedData(TestPlan testPlan, TestIdentifier testIdentifier, TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)`
```java
private record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier, TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)
```
Record inmutable para transportar resultados de ejecución en tests de utilidad.

| @param | Tipo | Descripción |
| :--- | :--- | :--- |
| `testPlan` | `TestPlan` | Plan descubierto |
| `testIdentifier` | `TestIdentifier` | Identificador del engine ejecutado |
| `testExecutionResult` | `TestExecutionResult` | Resultado de la ejecución |
| `startTime` | `Instant` | Timestamp de `executionStarted` |
| `finishTime` | `Instant` | Timestamp de `executionFinished` |

Métodos accesorios generados: `testPlan()`, `testIdentifier()`, `testExecutionResult()`, `startTime()`, `finishTime()` - todos `@return` el componente correspondiente.

---

### 3. Ejemplo de Uso

El siguiente bloque ilustra el uso real de `DefaultLauncher` (vía `LauncherFactoryForTestingPurposesOnly`) tal como se ejercita en la suite, incluyendo descubrimiento, filtrado y ejecución con listeners:

```java
package org.junit.platform.launcher.core;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectPackage;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;

import org.junit.platform.engine.support.hierarchical.DemoHierarchicalTestEngine;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.mockito.Mockito;

public class EjemploDefaultLauncher {

    public static void main(String[] args) {
        // 1. Crear engine con tests jerárquicos
        var engine = new DemoHierarchicalTestEngine("myEngine");
        engine.addTest("test1", () -> System.out.println("Ejecutando test1"));
        engine.addTest("test2", () -> System.out.println("Ejecutando test2"));

        // 2. Crear Launcher (equivalente a LauncherFactory.create())
        Launcher launcher = LauncherFactoryForTestingPurposesOnly.createLauncher(engine);

        // 3. Descubrir TestPlan con selector y listener
        TestExecutionListener listenerMock = Mockito.mock(TestExecutionListener.class);
        SummaryGeneratingListener summaryListener = new SummaryGeneratingListener();

        TestPlan testPlan = launcher.discover(
            request()
                .selectors(selectPackage("org.example"))
                .listeners(listenerMock)
                .build()
        );

        System.out.println("Roots descubiertos: " + testPlan.getRoots().size());
        System.out.println("Tests encontrados: " + testPlan.countTestIdentifiers(t -> t.isTest()));

        // 4. Ejecutar el plan (solo una vez por instancia de TestPlan)
        var executionRequest = LauncherExecutionRequestBuilder.request(testPlan)
                .listeners(summaryListener, listenerMock)
                .build();

        launcher.execute(executionRequest);

        // 5. Consultar resumen
        System.out.println("Tests exitosos: " + summaryListener.getSummary().getTestsSucceededCount());

        // 6. Modo dry-run (no ejecuta tests, solo reporta skipped)
        var dryRunPlan = launcher.discover(request().build());
        var dryRunRequest = LauncherExecutionRequestBuilder.request(dryRunPlan)
                .configurationParameter(LauncherConstants.DRY_RUN_PROPERTY_NAME, "true")
                .listeners(summaryListener)
                .build();
        // launcher.execute(dryRunRequest); // Descomentar para ejecutar en dry-run
    }
}
```

**Notas de uso:**
*   `LauncherDiscoveryRequestBuilder.request()` es el punto de entrada para construir solicitudes de descubrimiento.
*   `LauncherExecutionRequestBuilder.request(testPlan)` requiere un `TestPlan` previamente descubierto y solo puede ejecutarse una vez; una segunda invocación lanza `PreconditionViolationException`.
*   Los `LauncherDiscoveryListener` y `TestExecutionListener` deben registrarse antes de `discover()`/`execute()` para recibir eventos `engineDiscoveryStarted/Finished` y `executionStarted/Finished`.
