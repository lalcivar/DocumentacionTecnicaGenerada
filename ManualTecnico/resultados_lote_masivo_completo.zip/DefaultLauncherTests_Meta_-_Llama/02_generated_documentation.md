# Documentación Técnica - `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`  
**Clase:** `DefaultLauncherTests`  
**Anotaciones de Clase:** `@NullMarked`, `@since 1.0`  
**Tipo:** Clase de pruebas JUnit Jupiter (package-private) para `DefaultLauncher`

---

### 1. Resumen Ejecutivo

`DefaultLauncherTests` es la suite de pruebas de integración y unitarias para `DefaultLauncher`, la implementación por defecto de la API `Launcher` de JUnit Platform. Su propósito es validar exhaustivamente el ciclo de vida de descubrimiento (`discover`) y ejecución (`execute`) de `TestEngine`s, incluyendo el manejo de fallos, filtrado post-descubrimiento, propagación de `ConfigurationParameters`, notificaciones a `LauncherDiscoveryListener`/`TestExecutionListener`, gestión de `DiscoveryIssue` y el comportamiento en modo `dry-run` y cancelación.

La clase actúa como especificación ejecutable del contrato de `LauncherFactory` y `LauncherDiscoveryRequestBuilder`, garantizando el aislamiento de errores entre engines y el cumplimiento de las restricciones de IDs reservados (`junit-`).

---

### 2. Especificación de Métodos y Constructores

#### 2.1 Constructor

| Firma | Descripción |
| :--- | :--- |
| `DefaultLauncherTests()` | Constructor por defecto implícito, package-private, generado por el compilador. No inicializa estado. Requerido por JUnit Jupiter para instanciación por reflexión. |

> **Javadoc:**
> ```java
> /**
>  * Construye una nueva instancia de DefaultLauncherTests.
>  * @author JUnit Team
>  * @since 1.0
>  */
> ```

#### 2.2 Métodos de Prueba Públicos (`@Test` / `@ParameterizedTest`)

##### `constructLauncherWithoutAnyEngines()`
Valida la precondición de que un `Launcher` no puede crearse sin `TestEngine`s.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `org.opentest4j.AssertionFailedError` si `assertPreconditionViolationFor` no detecta la violación. |

##### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`
Verifica que IDs duplicados de `TestEngine` provoquen `JUnitException`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `org.opentest4j.AssertionFailedError` si no se lanza `JUnitException` con mensaje `multiple engines with the same ID`. |

##### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`
Verifica que un engine sin tests genere un `TestPlan` con una sola raíz (el engine).

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` si `getRoots().size() != 1` |

##### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
Valida el manejo de `null` retornado por `TestEngine.discover()` y la notificación `EngineDiscoveryResult.Status.FAILED`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` si no se notifica el fallo vía `LauncherDiscoveryListener` |

##### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`
Prueba parametrizada que simula excepciones (`Error`, `RuntimeException`) durante el descubrimiento.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `throwableClass` | `Class<? extends Throwable>` | Sí | Clase de la excepción a instanciar vía reflexión y lanzar dentro de `discover()`. Provisto por `@ValueSource`. |
| `@return` | - | `void` | - | - |
| `@throws` | - | `AssertionFailedError` | - | Si el `TestPlan` no contiene el engine o si `executionFinished` no reporta `TestEngine with ID 'my-engine-id' failed to discover tests`. |

##### `reportsEngineExecutionFailuresWithoutPriorEvents()`
Verifica que una excepción no capturada en `TestEngine.execute()` se reporte como `executionFinished` con `FAILED`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` si no se verifica `cause().isSameAs(rootCause)` |

##### `reportsEngineExecutionFailuresForSkippedEngine()`
Idem anterior, pero cuando el engine ya notificó `executionSkipped`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsEngineExecutionFailuresForStartedEngine()`
Idem, cuando el engine ya notificó `executionStarted`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`
Idem, cuando el engine ya notificó `executionFinished(successful())` y luego lanza excepción.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsEngineExecutionFailuresForFailedFinishedEngine()`
Verifica que si el engine ya reportó `failed(originalFailure)` y luego lanza `rootCause`, el resultado final contenga `rootCause` como causa y `originalFailure` como `suppressed`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsSkippedEngines()`
Valida que `executionSkipped` se propague correctamente a `TestExecutionListener` sin invocar `executionStarted/Finished`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsFinishedEngines()`
Valida el flujo feliz `executionStarted` -> `executionFinished(successful())`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `discoverTestPlanForSingleEngine()`
Verifica descubrimiento con un `DemoHierarchicalTestEngine` con 2 tests.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `discoverTestPlanForMultipleEngines()`
Verifica descubrimiento con dos engines y selectores `selectUniqueId`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `launcherAppliesPostDiscoveryFilters()`
Valida la aplicación secuencial de `PostDiscoveryFilter`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`
Verifica que sin parámetros, `ConfigurationParameters.get("key")` sea vacío.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError`, `NullPointerException` si `requestForExecution` es null |

##### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`
Verifica propagación de `configurationParameter("key", "value")`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`
Valida fallback a `System.getProperty` vía `@SetSystemProperty(key=FOO, value=BAR)`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `withAdditionalListener()`
Verifica que un `SummaryGeneratingListener` adicional reciba eventos.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
Verifica que contenedores sin hijos tras filtrado sean podados del `TestPlan`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsDynamicTestDescriptorsCorrectly()`
Valida el registro dinámico `dynamicTestRegistered` y la jerarquía de `TestIdentifier`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `launcherCanExecuteTestPlanExactlyOnce()`
Verifica que un `TestPlan` no pueda ejecutarse dos veces (precondición).

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`
Valida que ID `junit-using-reserved-prefix` lance `DiscoveryIssueException` con `[WARNING]`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `thirdPartyEngineClaimingToBeJupiterResultsInException()`
Delega a `assertImposter("junit-jupiter")`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `thirdPartyEngineClaimingToBeVintageResultsInException()`
Delega a `assertImposter("junit-vintage")`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`
Valida modo `DRY_RUN_PROPERTY_NAME=true`: tests son `SKIPPED` con mensaje `JUnit Platform dry-run mode is enabled` y no se ejecuta el código.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `notifiesDiscoveryListenersOfProcessedSelectors()`
Verifica que `selectorProcessed` se notifique a listeners registrados en config, launcher y request.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)`
Valida que `Severity.ERROR` cause `FAILED` y `WARNING` se loguee.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `listener` | `LogRecordListener` | Sí | Inyectado por `@TrackLogRecords`, captura `LogRecord` de `DiscoveryIssueNotifier`. |
| `@return` | `void` | - | - | - |
| `@throws` | `AssertionFailedError` | - | - | Si el estado no es `FAILED` o el log no contiene el mensaje esperado. |

##### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)`
Valida que `Severity.INFO` no falle la ejecución pero se loguee en `Level.INFO`.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `listener` | `LogRecordListener` | Sí | Listener de logs |
| `@return` | `void` | - | - | - |
| `@throws` | `AssertionFailedError` | - | - | - |

##### `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)`
Valida que tras fallo en `discover()` (throw `RuntimeException`), se logueen tanto `ERROR` (SEVERE) como `INFO`.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `listener` | `LogRecordListener` | Sí | Listener de logs |
| `@return` | `void` | - | - | - |
| `@throws` | `AssertionFailedError` | - | - | - |

##### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)`
Valida log de `INFO` cuando `discover` es exitoso pero `execute` falla.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `listener` | `LogRecordListener` | Sí | Listener de logs |
| `@return` | `void` | - | - | - |
| `@throws` | `AssertionFailedError` | - | - | - |

##### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`
Valida que `UniqueId` no resoluble con prefijo del engine genere `DiscoveryIssueException`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`
Valida que `UniqueId` de otro engine sea ignorado (SUCCESSFUL).

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsEngineExecutionFailureForSelectorResolutionFailure()`
Valida que fallo en resolución (`RuntimeException: boom`) genere `DiscoveryIssueException` con `Cause`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `allowsConfiguringCriticalDiscoveryIssueSeverity()`
Valida configuración `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME=info` convierte `INFO` en crítico.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `failsIfCriticalSeverityIsConfiguredIncorrectly()`
Valida que valor inválido `wrong` para severidad crítica lance `JUnitException`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`
Valida `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery` hace fallar en fase de descubrimiento.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)`
Valida que issues no críticos se logueen solo una vez independientemente de la fase.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `phase` | `String` | Sí | Valor parametrizado `discovery` o `execution` vía `@ValueSource`. |
| `@param` | `listener` | `LogRecordListener` | Sí | Listener de logs |
| `@return` | `void` | - | - | - |
| `@throws` | `AssertionFailedError` | - | - | - |

##### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`
Valida que valor `wrong` para `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME` lance `JUnitException`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

##### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`
Valida que con `CancellationToken.cancel()` previo, no se invoque `engine.execute()` y los hijos se reporten como `ABORTED`/`SKIPPED`.

| Tag | Detalle |
| :--- | :--- |
| `@param` | Ninguno |
| `@return` | `void` |
| `@throws` | `AssertionFailedError` |

#### 2.3 Métodos Auxiliares Privados

##### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`
Helper para verificar secuencia `engineDiscoveryStarted` -> `engineDiscoveryFinished(FAILED)`.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `testEngine` | `TestEngine` | Sí | Engine cuyo ID se usa para construir `UniqueId.forEngine()`. |
| `@param` | `inOrder` | `InOrder` | Sí | Mockito `InOrder` para verificar orden de invocaciones. |
| `@param` | `discoveryListener` | `LauncherDiscoveryListener` | Sí | Mock del listener. |
| `@return` | `void` | - | - | - |
| `@throws` | `AssertionFailedError` | - | - | Si el status no es `FAILED` o el mensaje no coincide. |

##### `assertImposter(String id)`
Helper que verifica que un engine con ID reservado (`junit-jupiter`, `junit-vintage`) lance `JUnitException`.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `id` | `String` | Sí | ID reservado a probar. |
| `@return` | `void` | - | - | - |
| `@throws` | `AssertionFailedError` | - | - | Si no se lanza la excepción esperada. |

#### 2.4 Métodos Estáticos Privados de Utilidad

##### `execute(TestEngine engine)`
Sobrecarga de conveniencia que delega a `execute(engine, identity())`.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `engine` | `TestEngine` | Sí | Engine a ejecutar. |
| `@return` | `ReportedData` | - | - | Record con `TestPlan`, `TestIdentifier`, `TestExecutionResult` y timestamps. |
| `@throws` | `NullPointerException` | - | - | Si `startTime` o `finishTime` no fueron capturados. |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)`
Sobrecarga que permite configurar el `LauncherDiscoveryRequestBuilder`.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `engine` | `TestEngine` | Sí | Engine a ejecutar. |
| `@param` | `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Función para mutar el builder de descubrimiento. |
| `@return` | `ReportedData` | - | - | Datos reportados. |
| `@throws` | `NullPointerException` | - | - | - |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)`
Implementación central: crea `Launcher`, construye `LauncherDiscoveryRequest` con `enableImplicitConfigurationParameters(false)` y `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=execution`, ejecuta y captura `executionStarted/Finished` vía `ArgumentCaptor`.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `engine` | `TestEngine` | Sí | Engine a ejecutar. |
| `@param` | `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Configurador de descubrimiento. |
| `@param` | `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Configurador de ejecución. |
| `@return` | `ReportedData` | - | - | Contenedor inmutable con resultados. |
| `@throws` | `NullPointerException` | - | - | Si `requireNonNull(startTime)` falla. |

##### `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)`
Busca el primer `LogRecord` de `DiscoveryIssueNotifier` para un nivel dado.

| @param | Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `@param` | `listener` | `LogRecordListener` | Sí | Fuente de logs capturados. |
| `@param` | `level` | `Level` | Sí | Nivel `java.util.logging.Level` a filtrar. |
| `@return` | `LogRecord` | - | - | Primer registro encontrado. |
| `@throws` | `NoSuchElementException` | - | - | Si `findFirst().orElseThrow()` no encuentra elemento. |

#### 2.5 Clases Anónimas e Internas - Métodos Sobrescritos

Todos los métodos siguientes pertenecen a clases anónimas instanciadas dentro de los tests. Se documentan por su firma exacta.

| Clase Anónima Padre | Método | Firma | Descripción |
| :--- | :--- | :--- | :--- |
| `TestEngineStub` en `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Retorna `null` deliberadamente para simular engine defectuoso. `@return null` `@throws` ninguno. |
| `TestEngineStub` en `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Instancia `throwableClass` vía reflexión y la lanza como unchecked. `@param discoveryRequest` request, `@param uniqueId` id del engine, `@return null` (inaccesible), `@throws Throwable` la instancia creada. |
| `TestEngineStub` en `reportsEngineExecutionFailures*` (5 variantes) | `execute()` | `void execute(ExecutionRequest request)` | Simula fallos en distintas fases: sin eventos, tras `executionSkipped`, tras `executionStarted`, tras `executionFinished(successful/failed)` y luego `throw rootCause`. `@param request` contiene `RootTestDescriptor` y `EngineExecutionListener`. `@throws RuntimeException rootCause`. |
| `TestEngineStub` en `reportsSkippedEngines()` / `reportsFinishedEngines()` | `execute()` | `void execute(ExecutionRequest request)` | Notifica `executionSkipped` o `executionStarted/Finished(successful())` respectivamente. |
| `TestEngineSpy` en `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Construye jerarquía `EngineDescriptor -> Container (Type.CONTAINER) -> Test` y la retorna. |
| `TestDescriptorStub` (containerDescriptor) interno | `getType()` | `Type getType()` | `@return Type.CONTAINER` |
| `TestEngineSpy` en `reportsDynamicTestDescriptorsCorrectly()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Crea engine con hijo `CONTAINER_AND_TEST`. |
| `TestDescriptorStub` (containerAndTest) interno | `getType()` | `Type getType()` | `@return Type.CONTAINER_AND_TEST` |
| `TestEngineSpy` en `reportsDynamicTestDescriptorsCorrectly()` | `execute()` | `void execute(ExecutionRequest request)` | Simula registro dinámico: `dynamicTestRegistered`, `executionStarted/Finished` para test dinámico. |
| `EngineDescriptor` anónimo en `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()` | `getTags()` | `Set<TestTag> getTags()` | `@return Set.of(TestTag.create("custom-tag"))` |
| `TestEngineStub` en `notifiesDiscoveryListenersOfProcessedSelectors()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Itera `getSelectorsByType(DiscoverySelector.class)` y notifica `selectorProcessed(..., unresolved())`. `@return EngineDescriptor` |
| `TestEngineStub` en `logs*` y `allowsConfiguring*` | `discover()` / `execute()` | `TestDescriptor discover(...)` / `void execute(ExecutionRequest request)` | Generan `DiscoveryIssue` con `Severity.INFO/WARNING/ERROR` y opcionalmente lanzan `RuntimeException("boom")` o notifican `executionStarted/Finished`. |

#### 2.6 Record Interno `ReportedData`

```java
private record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier,
        TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime) {}
```

| Componente | Tipo | Descripción |
| :--- | :--- | :--- |
| `@param testPlan` | `TestPlan` | Plan descubierto por el launcher. |
| `@param testIdentifier` | `TestIdentifier` | Identificador del engine capturado vía `ArgumentCaptor` en `executionStarted`. |
| `@param testExecutionResult` | `TestExecutionResult` | Resultado capturado en `executionFinished`. |
| `@param startTime` | `Instant` | Timestamp capturado vía `doAnswer` en `executionStarted`. |
| `@param finishTime` | `Instant` | Timestamp capturado vía `doAnswer` en `executionFinished`. |
| `@return` | Accessors `testPlan()`, `testIdentifier()`, etc. | Generados automáticamente. |

---

### 3. Ejemplo de Uso

El siguiente ejemplo ilustra el uso real de `DefaultLauncher` (clase bajo prueba) tal como se ejercita en `DefaultLauncherTests`, incluyendo descubrimiento, filtrado y ejecución con listeners.

```java
package org.junit.platform.launcher.core;

import org.junit.platform.engine.support.hierarchical.DemoHierarchicalTestEngine;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherExecutionRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactoryForTestingPurposesOnly;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectPackage;

public class EjemploDefaultLauncher {

    public static void main(String[] args) {
        // 1. Crear engine de demostración con tests
        var engine = new DemoHierarchicalTestEngine("myEngine");
        engine.addTest("test1", () -> System.out.println("Ejecutando test1"));
        engine.addTest("test2", () -> System.out.println("Ejecutando test2"));

        // 2. Crear Launcher (DefaultLauncher) vía factory
        var launcher = LauncherFactoryForTestingPurposesOnly.createLauncher(engine);

        // 3. Construir request de descubrimiento con selector y listener
        var discoveryListener = new SummaryGeneratingListener();
        LauncherDiscoveryRequest discoveryRequest = LauncherDiscoveryRequestBuilder.request()
                .selectors(selectPackage("org.example"))
                .build();

        // 4. Descubrir TestPlan
        TestPlan testPlan = launcher.discover(discoveryRequest);
        System.out.println("Roots descubiertos: " + testPlan.getRoots().size());
        System.out.println("Tests encontrados: " + testPlan.countTestIdentifiers(t -> t.isTest()));

        // 5. Ejecutar TestPlan exactamente una vez
        var executionListener = new SummaryGeneratingListener();
        var executionRequest = LauncherExecutionRequestBuilder.request(testPlan)
                .listeners(executionListener)
                .build();

        launcher.execute(executionRequest);

        // 6. Consultar resumen
        var summary = executionListener.getSummary();
        System.out.println("Tests exitosos: " + summary.getTestsSucceededCount());
        System.out.println("Tests fallidos: " + summary.getTestsFailedCount());

        // Nota: Re-ejecutar el mismo TestPlan lanzará PreconditionViolation:
        // launcher.execute(executionRequest); // -> "TestPlan must only be executed once"
    }
}
```

**Notas de uso:**
* `LauncherFactoryForTestingPurposesOnly.createLauncher(TestEngine...)` es la vía de creación usada en los tests; en producción se usa `LauncherFactory.create()`.
* El `TestPlan` es de un solo uso; cualquier segundo `execute()` viola la precondición verificada en `launcherCanExecuteTestPlanExactlyOnce()`.
* Para modo dry-run, añadir `.configurationParameter(LauncherConstants.DRY_RUN_PROPERTY_NAME, "true")` al builder, como en `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`.
