# Documentación Técnica - `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`  
**Clase:** `DefaultLauncherTests`  
**Anotaciones de clase:** `@NullMarked`, `@since 1.0`  
**Visibilidad:** package-private (`class DefaultLauncherTests`)  
**Superclase:** `java.lang.Object`

---

### 1. Resumen Ejecutivo

`DefaultLauncherTests` es la suite de pruebas unitarias y de integración para `DefaultLauncher`, la implementación por defecto de la API `Launcher` de JUnit Platform. Valida el ciclo de vida completo de descubrimiento (`discover`) y ejecución (`execute`) de `TestEngine`s, incluyendo el manejo de fallos en descubrimiento/ejecución, filtrado `PostDiscoveryFilter`, propagación de `ConfigurationParameters`, notificaciones a `LauncherDiscoveryListener` y `TestExecutionListener`, gestión de `DiscoveryIssue` y severidades críticas, modo `dry-run` y cancelación vía `CancellationToken`.

La clase no contiene lógica de negocio productiva; su propósito es garantizar contractualmente el comportamiento de `LauncherFactory`, `LauncherDiscoveryRequestBuilder` y `LauncherExecutionRequestBuilder` frente a engines válidos, defectuosos y de terceros.

---

### 2. Especificación de Métodos y Constructores

#### 2.1 Constructores

##### `DefaultLauncherTests()`
Constructor por defecto implícito generado por el compilador. No declarado explícitamente en el código fuente.

| Atributo | Valor |
|---|---|
| **Visibilidad** | package-private |
| **Parámetros** | Ninguno |
| **Excepciones** | Ninguna |

```java
/**
 * Constructor por defecto.
 * @author JUnit Platform Team
 */
DefaultLauncherTests()
```

| @return | Descripción |
|---|---|
| `DefaultLauncherTests` | Nueva instancia de la suite de pruebas |

---

#### 2.2 Métodos de Prueba Públicos / Package-Private (`@Test`, `@ParameterizedTest`)

> Todos los métodos de esta sección son `package-private` (visibilidad por defecto en clases de test JUnit Jupiter), anotados con `@Test` o `@ParameterizedTest`, `void` y sin parámetros salvo donde se indique. No retornan valor y lanzan `AssertionError` / `JUnitException` si la aserción falla.

##### `constructLauncherWithoutAnyEngines()`
```java
/**
 * Verifica que la creación de un Launcher sin TestEngines falle por precondición.
 * @throws AssertionError si no se lanza PreconditionViolation
 */
@Test void constructLauncherWithoutAnyEngines()
```
| @throws | Condición |
|---|---|
| `PreconditionViolation` | Al invocar `launcher.discover()` sin engines registrados. Mensaje esperado: `Cannot create Launcher without at least one TestEngine` |

##### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`
```java
/**
 * Verifica que IDs duplicados de TestEngine provoquen JUnitException.
 * @throws JUnitException si existen múltiples engines con el mismo ID
 */
@Test void constructLauncherWithMultipleTestEnginesWithDuplicateIds()
```
| @throws | Condición |
|---|---|
| `JUnitException` | Mensaje contiene `multiple engines with the same ID` |

##### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`
```java
/**
 * Valida descubrimiento de TestPlan vacío con engine sin tests.
 */
@Test void discoverEmptyTestPlanWithEngineWithoutAnyTests()
```
| @return | `void` |
|---|---|
| @throws | `AssertionError` si `testPlan.getRoots().size() != 1` |

##### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
```java
/**
 * Valida manejo de engine que retorna null en discover().
 * Verifica notificación de fallo vía LauncherDiscoveryListener.
 */
@Test void discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()
```

##### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`
```java
/**
 * Valida creación de descriptor de error cuando el engine lanza excepción en fase de descubrimiento.
 * @param throwableClass tipo de Throwable a simular (Error o RuntimeException)
 */
@ParameterizedTest @ValueSource(classes = {Error.class, RuntimeException.class})
void discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `throwableClass` | `Class<? extends Throwable>` | Sí | Clase de excepción a instanciar vía reflexión y lanzar |

| @throws | Condición |
|---|---|
| `Exception` | Propagada vía `ExceptionUtils.throwAsUncheckedException` si falla la instanciación |

##### `reportsEngineExecutionFailuresWithoutPriorEvents()`
```java
/**
 * Verifica reporte de fallo de ejecución cuando el engine lanza RuntimeException sin eventos previos.
 */
@Test void reportsEngineExecutionFailuresWithoutPriorEvents()
```

##### `reportsEngineExecutionFailuresForSkippedEngine()`
```java
/**
 * Verifica reporte de fallo incluso si el engine previamente notificó executionSkipped.
 */
@Test void reportsEngineExecutionFailuresForSkippedEngine()
```

##### `reportsEngineExecutionFailuresForStartedEngine()`
```java
/**
 * Verifica reporte de fallo cuando el engine notificó executionStarted y luego lanza excepción.
 */
@Test void reportsEngineExecutionFailuresForStartedEngine()
```

##### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`
```java
/**
 * Verifica reporte de fallo cuando el engine notificó executionFinished(successful) y luego lanza excepción.
 */
@Test void reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()
```

##### `reportsEngineExecutionFailuresForFailedFinishedEngine()`
```java
/**
 * Verifica que el fallo original sea suprimido y la causa raíz sea la excepción lanzada post-finished.
 */
@Test void reportsEngineExecutionFailuresForFailedFinishedEngine()
```

##### `reportsSkippedEngines()`
```java
/**
 * Verifica que un engine que invoca executionSkipped sea reportado correctamente sin started/finished.
 */
@Test void reportsSkippedEngines()
```

##### `reportsFinishedEngines()`
```java
/**
 * Verifica flujo exitoso started -> finished con TestExecutionResult.successful().
 */
@Test void reportsFinishedEngines()
```

##### `discoverTestPlanForSingleEngine()`
```java
/**
 * Valida descubrimiento con un solo DemoHierarchicalTestEngine con 2 tests.
 */
@Test void discoverTestPlanForSingleEngine()
```

##### `discoverTestPlanForMultipleEngines()`
```java
/**
 * Valida descubrimiento con múltiples engines usando selectUniqueId.
 */
@Test void discoverTestPlanForMultipleEngines()
```

##### `launcherAppliesPostDiscoveryFilters()`
```java
/**
 * Verifica aplicación secuencial de PostDiscoveryFilters.
 */
@Test void launcherAppliesPostDiscoveryFilters()
```

##### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`
```java
/**
 * Verifica que sin parámetros de configuración, ConfigurationParameters esté vacío.
 */
@Test void withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()
```

##### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`
```java
/**
 * Verifica propagación de configurationParameter("key","value") al ExecutionRequest.
 */
@Test void withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()
```

##### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`
```java
/**
 * Verifica fallback a System.getProperty cuando no hay ConfigurationParameters explícitos.
 * Requiere @SetSystemProperty(key=FOO, value=BAR)
 */
@Test @SetSystemProperty(key = DefaultLauncherTests.FOO, value = DefaultLauncherTests.BAR)
void withoutConfigurationParameters_LookupFallsBackToSystemProperty()
```

##### `withAdditionalListener()`
```java
/**
 * Verifica registro de TestExecutionListener adicional (SummaryGeneratingListener).
 */
@Test void withAdditionalListener()
```

##### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
```java
/**
 * Verifica poda de descriptores hijos cuando el filtro excluye tests pero incluye containers.
 */
@Test void prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()
```

##### `reportsDynamicTestDescriptorsCorrectly()`
```java
/**
 * Verifica registro y reporte correcto de tests dinámicos (CONTAINER_AND_TEST + dynamicTestRegistered).
 */
@Test void reportsDynamicTestDescriptorsCorrectly()
```

##### `launcherCanExecuteTestPlanExactlyOnce()`
```java
/**
 * Verifica que un TestPlan solo pueda ejecutarse una vez; segunda ejecución lanza PreconditionViolation.
 * @throws PreconditionViolation con mensaje "TestPlan must only be executed once"
 */
@Test void launcherCanExecuteTestPlanExactlyOnce()
```

##### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`
```java
/**
 * Verifica que engine de terceros con ID "junit-using-reserved-prefix" emita DiscoveryIssueException de tipo WARNING.
 * @throws DiscoveryIssueException mensaje contiene "forbidden to use the reserved 'junit-' prefix"
 */
@Test void thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()
```

##### `thirdPartyEngineClaimingToBeJupiterResultsInException()`
```java
/**
 * Delega a assertImposter("junit-jupiter").
 * @throws JUnitException si engine intenta suplantar ID reservado
 */
@Test void thirdPartyEngineClaimingToBeJupiterResultsInException()
```

##### `thirdPartyEngineClaimingToBeVintageResultsInException()`
```java
/**
 * Delega a assertImposter("junit-vintage").
 */
@Test void thirdPartyEngineClaimingToBeVintageResultsInException()
```

##### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`
```java
/**
 * Verifica modo dry-run (DRY_RUN_PROPERTY_NAME=true): reporta skipped para tests sin ejecutarlos.
 */
@Test void dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()
```

##### `notifiesDiscoveryListenersOfProcessedSelectors()`
```java
/**
 * Verifica que selectorProcessed sea notificado a listeners registrados en config, launcher y request.
 */
@Test void notifiesDiscoveryListenersOfProcessedSelectors()
```

##### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)`
```java
/**
 * Verifica fallo de ejecución por DiscoveryIssue ERROR y log de WARNING restante.
 * @param listener inyectado por @TrackLogRecords para capturar LogRecords de DiscoveryIssueNotifier
 */
@Test void reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(@TrackLogRecords LogRecordListener listener)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Listener de logs inyectado por extensión TrackLogRecords |

##### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)`
```java
/**
 * Verifica log INFO para issue no crítico cuando la ejecución es exitosa.
 * @param listener LogRecordListener inyectado
 */
@Test void logsNonCriticalIssuesForRegularEngineExecution(@TrackLogRecords LogRecordListener listener)
```

##### `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)`
```java
/**
 * Verifica log SEVERE para ERROR crítico y log INFO para INFO no crítico tras fallo en discover().
 * @param listener LogRecordListener inyectado
 */
@Test void logsAllIssuesForDiscoveryFailure(@TrackLogRecords LogRecordListener listener)
```

##### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)`
```java
/**
 * Verifica log INFO para issue no crítico cuando la ejecución falla con RuntimeException.
 * @param listener LogRecordListener inyectado
 */
@Test void logsNonCriticalIssuesForExecutionFailure(@TrackLogRecords LogRecordListener listener)
```

##### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`
```java
/**
 * Verifica fallo por selector UniqueId no resuelto cuando el prefijo coincide con el engine.
 */
@Test void reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()
```

##### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`
```java
/**
 * Verifica que selector UniqueId no resuelto con prefijo distinto sea ignorado (SUCCESSFUL).
 */
@Test void ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()
```

##### `reportsEngineExecutionFailureForSelectorResolutionFailure()`
```java
/**
 * Verifica fallo por excepción durante resolución de selector (selectClass).
 */
@Test void reportsEngineExecutionFailureForSelectorResolutionFailure()
```

##### `allowsConfiguringCriticalDiscoveryIssueSeverity()`
```java
/**
 * Verifica configuración de severidad crítica vía CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME=info.
 */
@Test void allowsConfiguringCriticalDiscoveryIssueSeverity()
```

##### `failsIfCriticalSeverityIsConfiguredIncorrectly()`
```java
/**
 * Verifica JUnitException si la severidad crítica configurada es inválida ("wrong").
 * @throws JUnitException con rootCause "Invalid DiscoveryIssue.Severity 'wrong'..."
 */
@Test void failsIfCriticalSeverityIsConfiguredIncorrectly()
```

##### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`
```java
/**
 * Verifica DiscoveryIssueException inmediata en fase discovery si DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery.
 * @throws DiscoveryIssueException
 */
@Test void failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()
```

##### `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)`
```java
/**
 * Verifica que issues no críticos se logueen solo una vez independientemente de la fase configurada.
 * @param phase fase configurada ("discovery" o "execution") vía @ValueSource
 * @param listener LogRecordListener inyectado
 */
@ParameterizedTest @ValueSource(strings = {"discovery", "execution"})
void logsNonCriticalIssuesOnlyOnce(String phase, @TrackLogRecords LogRecordListener listener)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `phase` | `String` | Sí | Valor de `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME` |
| `listener` | `LogRecordListener` | Sí | Capturador de logs |

##### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`
```java
/**
 * Verifica JUnitException si LauncherPhase configurado es inválido ("wrong").
 * @throws JUnitException con rootCause "Invalid LauncherPhase 'wrong'..."
 */
@Test void failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()
```

##### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`
```java
/**
 * Verifica que hijos del EngineDescriptor sean reportados como skipped con "Execution cancelled" tras cancelación.
 */
@Test void reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()
```

---

#### 2.3 Métodos Privados de Utilidad

##### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`
```java
/**
 * Aserción helper que verifica secuencia engineDiscoveryStarted -> engineDiscoveryFinished(FAILED).
 * @param testEngine engine bajo prueba
 * @param inOrder mock InOrder para verificar orden de invocaciones
 * @param discoveryListener mock del listener
 * @throws AssertionError si el status no es FAILED o el mensaje no coincide
 */
private void assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testEngine` | `TestEngine` | Sí | Engine cuyo ID se usa para construir `UniqueId.forEngine()` |
| `inOrder` | `InOrder` | Sí | Verificador de orden Mockito |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | Mock verificado |

| @return | `void` |
| @throws | `AssertionError` (vía AssertJ) |

##### `assertImposter(String id)`
```java
/**
 * Helper que verifica que un engine con ID reservado lance JUnitException.
 * @param id ID reservado a probar (ej. "junit-jupiter", "junit-vintage")
 * @throws AssertionError si no se lanza JUnitException o el mensaje no coincide
 */
private void assertImposter(String id)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `id` | `String` | Sí | ID reservado que el engine impostor intenta usar |

---

#### 2.4 Métodos Estáticos Privados

##### `execute(TestEngine engine)`
```java
/**
 * Sobrecarga convenience que delega a execute(engine, identity()).
 * @param engine engine a ejecutar
 * @return ReportedData con testPlan, testIdentifier, testExecutionResult y timestamps
 */
private static ReportedData execute(TestEngine engine)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Engine bajo prueba |

| @return | `ReportedData` | Datos capturados del listener mock |
| @throws | `NullPointerException` | Si `startTime` o `finishTime` son null |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)`
```java
/**
 * Sobrecarga que permite configurar el LauncherDiscoveryRequestBuilder.
 * @param engine engine a ejecutar
 * @param discoveryConfigurer función que muta el builder de descubrimiento
 * @return ReportedData
 */
private static ReportedData execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Engine |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Configurador (usar `identity()` para no modificar) |

##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)`
```java
/**
 * Método central de ejecución para tests de DiscoveryIssue. Crea launcher, ejecuta discover y execute capturando eventos.
 * @param engine engine a ejecutar
 * @param discoveryConfigurer configurador de discovery (deshabilita implicit params y setea failurePhase=execution por defecto)
 * @param executionConfigurer configurador de execution (añade listeners, cancellationToken, etc.)
 * @return ReportedData con plan, identificador, resultado y timestamps de started/finished
 * @throws NullPointerException si startTime/finishTime no fueron capturados
 */
private static ReportedData execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Engine |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Mutador del builder de descubrimiento |
| `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Mutador del builder de ejecución |

| @return | `ReportedData` | Record con 5 componentes |
| @throws | `DiscoveryIssueException` | Si hay issues críticos y `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery` |

##### `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)`
```java
/**
 * Busca el primer LogRecord de DiscoveryIssueNotifier para un nivel dado.
 * @param listener capturador de logs
 * @param level nivel de log a filtrar (INFO, WARNING, SEVERE)
 * @return LogRecord encontrado
 * @throws NoSuchElementException si no existe log para ese nivel
 */
private static LogRecord findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)
```
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Fuente de LogRecords |
| `level` | `Level` | Sí | Nivel `java.util.logging.Level` |

| @return | `LogRecord` | Primer registro coincidente |
| @throws | `NoSuchElementException` | Si `stream(...).findFirst()` está vacío |

---

#### 2.5 Clases Anónimas e Internas - Métodos Sobrescritos

Todos los métodos siguientes pertenecen a clases anónimas instanciadas dentro de los tests. Se documentan por completitud.

| Clase Anónima (contexto) | Método | Firma | Descripción |
|---|---|---|---|
| `TestEngineStub` en `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor` | `discover` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Retorna `null` para simular engine defectuoso. `@return null` |
| `TestEngineStub` en `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase` | `discover` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Instancia `throwableClass` vía reflexión y lanza como unchecked. `@throws RuntimeException/Error` |
| `TestEngineStub` en `reportsEngineExecutionFailuresWithoutPriorEvents` | `execute` | `void execute(ExecutionRequest request)` | Lanza `RuntimeException("something went horribly wrong")`. `@throws RuntimeException` |
| `TestEngineStub` en `reportsEngineExecutionFailuresForSkippedEngine` | `execute` | `void execute(ExecutionRequest request)` | Notifica `executionSkipped` y luego lanza `RuntimeException`. |
| `TestEngineStub` en `reportsEngineExecutionFailuresForStartedEngine` | `execute` | `void execute(ExecutionRequest request)` | Notifica `executionStarted` y lanza `RuntimeException`. |
| `TestEngineStub` en `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine` | `execute` | `void execute(ExecutionRequest request)` | Notifica `started` + `finished(successful)` y lanza `RuntimeException`. |
| `TestEngineStub` en `reportsEngineExecutionFailuresForFailedFinishedEngine` | `execute` | `void execute(ExecutionRequest request)` | Notifica `finished(failed)` y lanza `RuntimeException` (suppressed). |
| `TestEngineStub` en `reportsSkippedEngines` | `execute` | `void execute(ExecutionRequest request)` | Solo `executionSkipped("not today")`. |
| `TestEngineStub` en `reportsFinishedEngines` | `execute` | `void execute(ExecutionRequest request)` | `executionStarted` + `executionFinished(successful)`. |
| `TestEngineSpy` en `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters` | `discover` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Construye `EngineDescriptor` + `Container` + `Test` hijo. `@return TestDescriptor` |
| `TestDescriptorStub` (interno a anterior) | `getType` | `Type getType()` | `@return Type.CONTAINER` |
| `TestEngineSpy` en `reportsDynamicTestDescriptorsCorrectly` | `discover` | `TestDescriptor discover(...)` | Retorna engine con hijo `CONTAINER_AND_TEST`. |
| `TestDescriptorStub` (interno) | `getType` | `Type getType()` | `@return Type.CONTAINER_AND_TEST` |
| `TestEngineSpy` en `reportsDynamicTestDescriptorsCorrectly` | `execute` | `void execute(ExecutionRequest request)` | Simula `dynamicTestRegistered` + `executionStarted/Finished` para test dinámico. |
| `TestEngineStub` en `notifiesDiscoveryListenersOfProcessedSelectors` | `discover` | `TestDescriptor discover(...)` | Itera `getSelectorsByType` y notifica `selectorProcessed(unresolved)`. |
| `TestEngineStub` en `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining` | `discover` | `TestDescriptor discover(...)` | Reporta `DiscoveryIssue` ERROR y WARNING, retorna `EngineDescriptor` con `getTags()`. |
| `EngineDescriptor` anónimo (interno) | `getTags` | `Set<TestTag> getTags()` | `@return Set.of(TestTag.create("custom-tag"))` |
| `TestEngineStub` en `logsNonCriticalIssuesForRegularEngineExecution` | `discover` | `TestDescriptor discover(...)` | Reporta `INFO` issue. |
| `TestEngineStub` en `logsNonCriticalIssuesForRegularEngineExecution` | `execute` | `void execute(ExecutionRequest request)` | `executionStarted` + `executionFinished(successful)`. |
| `TestEngineStub` en `logsAllIssuesForDiscoveryFailure` | `discover` | `TestDescriptor discover(...)` | Reporta `ERROR` + `INFO` y lanza `RuntimeException("boom")`. |
| `TestEngineStub` en `logsNonCriticalIssuesForExecutionFailure` | `discover` | `TestDescriptor discover(...)` | Reporta `INFO`. |
| `TestEngineStub` en `logsNonCriticalIssuesForExecutionFailure` | `execute` | `void execute(...)` | Lanza `RuntimeException("boom")`. |
| `TestEngineStub` en `allowsConfiguringCriticalDiscoveryIssueSeverity` | `discover` | `TestDescriptor discover(...)` | Reporta `INFO`. |
| `TestEngineStub` en `failsIfCriticalSeverityIsConfiguredIncorrectly` | `discover` | `TestDescriptor discover(...)` | Reporta `INFO`. |
| `TestEngineStub` en `failsIfCriticalSeverityIsConfiguredIncorrectly` | `execute` | `void execute(...)` | `started` + `finished(successful)`. |
| `TestEngineStub` en `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly` | `discover` | `TestDescriptor discover(...)` | Reporta `ERROR`. |
| `TestEngineStub` en `logsNonCriticalIssuesOnlyOnce` | `discover` | `TestDescriptor discover(...)` | Reporta `WARNING`. |
| `TestEngineStub` en `logsNonCriticalIssuesOnlyOnce` | `execute` | `void execute(...)` | `started` + `finished(successful)`. |
| `TestEngineStub` en `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested` | `discover` | `TestDescriptor discover(...)` | Construye `EngineDescriptor` con `Container` + `Test`. |

**Parámetros comunes de `discover`:**

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Request con selectors y DiscoveryListener |
| `uniqueId` | `UniqueId` | Sí | ID único del engine (`UniqueId.forEngine(id)`) |

| @return | `TestDescriptor` | Descriptor raíz o `null` para simular fallo |
| @throws | `RuntimeException` | Simulado en varios stubs |

**Parámetros comunes de `execute`:**

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Contiene `getRootTestDescriptor()` y `getEngineExecutionListener()` |

---

#### 2.6 Record Interno `ReportedData`

```java
private record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier,
        TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime) {}
```

Record inmutable usado como DTO para capturar resultados de `execute()`.

| Componente | Tipo | Descripción |
|---|---|---|
| `testPlan` | `TestPlan` | Plan descubierto por `launcher.discover()` |
| `testIdentifier` | `TestIdentifier` | Identificador capturado en `executionStarted` |
| `testExecutionResult` | `TestExecutionResult` | Resultado capturado en `executionFinished` |
| `startTime` | `Instant` | Timestamp capturado vía `doAnswer` en `executionStarted` |
| `finishTime` | `Instant` | Timestamp capturado vía `doAnswer` en `executionFinished` |

Métodos generados automáticamente: `testPlan()`, `testIdentifier()`, `testExecutionResult()`, `startTime()`, `finishTime()`, `equals()`, `hashCode()`, `toString()`, constructor canónico `ReportedData(TestPlan, TestIdentifier, TestExecutionResult, Instant, Instant)`.

---

### 3. Ejemplo de Uso

El siguiente bloque muestra un caso real de uso de `DefaultLauncher` (vía `LauncherFactoryForTestingPurposesOnly`) tal como se ejercita en la suite, incluyendo descubrimiento con filtros, ejecución con listener y manejo de `DiscoveryIssue`.

```java
package org.junit.platform.launcher.core;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectPackage;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;

import org.junit.platform.engine.FilterResult;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.PostDiscoveryFilter;
import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherFactoryForTestingPurposesOnly;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.engine.support.hierarchical.DemoHierarchicalTestEngine;

public class EjemploDefaultLauncher {

    public static void main(String[] args) {
        // 1. Crear engine de demostración con tests
        var engine = new DemoHierarchicalTestEngine("myEngine");
        engine.addTest("test1", () -> System.out.println("ejecutando test1"));
        engine.addTest("test2", () -> System.out.println("ejecutando test2"));

        // 2. Crear Launcher (DefaultLauncher) con el engine
        Launcher launcher = LauncherFactoryForTestingPurposesOnly.createLauncher(engine);

        // 3. Definir filtro post-descubrimiento
        PostDiscoveryFilter filtro = descriptor ->
                FilterResult.includedIf(descriptor.getUniqueId().toString().contains("test1"));

        // 4. Descubrir TestPlan
        var discoveryRequest = request()
                .selectors(selectPackage("any"))
                .filters(filtro)
                .build();

        TestPlan testPlan = launcher.discover(discoveryRequest);
        System.out.println("Roots: " + testPlan.getRoots().size()); // 1
        System.out.println("Tests encontrados: " + testPlan.countTestIdentifiers(t -> true));

        // 5. Ejecutar con listener
        SummaryGeneratingListener summaryListener = new SummaryGeneratingListener();
        var executionRequest = LauncherExecutionRequestBuilder.request(testPlan)
                .listeners(summaryListener)
                .build();

        launcher.execute(executionRequest);

        // 6. Consultar resumen
        var summary = summaryListener.getSummary();
        System.out.println("Containers: " + summary.getContainersSucceededCount());
        System.out.println("Tests exitosos: " + summary.getTestsSucceededCount());

        // 7. Modo dry-run (no ejecuta tests, solo reporta skipped)
        var dryRunRequest = request()
                .configurationParameter("junit.platform.execution.dryRun.enabled", "true")
                .forExecution()
                .listeners((TestExecutionListener) summaryListener)
                .build();
        // launcher.execute(dryRunRequest); // Descomentar para dry-run
    }
}
```

**Notas del ejemplo:**
* `LauncherFactoryForTestingPurposesOnly.createLauncher()` es la factory usada en los tests para instanciar `DefaultLauncher` sin ServiceLoader.
* `LauncherDiscoveryRequestBuilder.request()` y `LauncherExecutionRequestBuilder.request(testPlan)` son los builders oficiales.
* Un `TestPlan` solo puede ejecutarse una vez; una segunda invocación a `launcher.execute()` lanza `PreconditionViolation: TestPlan must only be executed once` (ver `launcherCanExecuteTestPlanExactlyOnce()`).
* Para capturar `DiscoveryIssue` críticos, configurar `LauncherConstants.CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME` y `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME`.

