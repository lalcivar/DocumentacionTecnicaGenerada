# Documentación Técnica - `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`  
**Clase:** `DefaultLauncherTests`  
**Tipo:** Clase de pruebas JUnit Jupiter (`@NullMarked`)  
**Visibilidad:** package-private (`class DefaultLauncherTests`)  
**Anotación de clase:** `@NullMarked`  
**Since:** `1.0`

---

### 1. Resumen Ejecutivo

`DefaultLauncherTests` es la suite de pruebas de integración y unitarias para `DefaultLauncher`, la implementación por defecto de la API `Launcher` de JUnit Platform. Valida el ciclo de vida completo de descubrimiento (`discover`) y ejecución (`execute`) de `TestEngine`, incluyendo el manejo de fallos en descubrimiento, reporte de `DiscoveryIssue`, aplicación de `PostDiscoveryFilter`, propagación de `ConfigurationParameters`, modo `dry-run`, cancelación y notificaciones a `LauncherDiscoveryListener` y `TestExecutionListener`.

La clase no contiene lógica de producción; actúa como especificación ejecutable del contrato de `LauncherFactory` y `LauncherDiscoveryRequestBuilder`/`LauncherExecutionRequestBuilder` frente a engines correctos, defectuosos y de terceros.

---

### 2. Especificación de Métodos y Constructores

#### 2.1 Constructor

| Firma | Descripción |
| :--- | :--- |
| `DefaultLauncherTests()` | Constructor por defecto implícito, package-private, generado por el compilador. Inicializa la clase de test. No realiza lógica. |

**Javadoc:**
```java
/**
 * Constructor por defecto para DefaultLauncherTests.
 * @author JUnit Platform Team
 */
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | No recibe parámetros |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| - | `void` | - |

| @throws | Condición |
| :--- | :--- |
| - | - |

---

#### 2.2 Métodos de Prueba Públicos (package-private con `@Test`)

Todos los métodos siguientes son `void`, sin parámetros salvo donde se indique, anotados con `@Test` o `@ParameterizedTest`. No declaran `throws` checked; las fallas se reportan vía `AssertionError` de JUnit/AssertJ.

| # | Método Exacto | Anotación | Propósito |
| :--- | :--- | :--- | :--- |
| 1 | `constructLauncherWithoutAnyEngines()` | `@Test` | Verifica precondición: crear `Launcher` sin `TestEngine` debe fallar en `discover()`. |
| 2 | `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | `@Test` | Verifica que IDs duplicados de `TestEngine` lanzan `JUnitException`. |
| 3 | `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | `@Test` | Verifica `TestPlan` con 1 root cuando el engine no aporta tests. |
| 4 | `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | `@Test` | Verifica manejo de `null` retornado por `TestEngine.discover()` y notificación `EngineDiscoveryResult.Status.FAILED`. |
| 5 | `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable>)` | `@ParameterizedTest @ValueSource` | Verifica que excepciones `Error`/`RuntimeException` en descubrimiento generan `TestPlan` con fallo y `TestExecutionResult` con mensaje `failed to discover tests`. |
| 6 | `reportsEngineExecutionFailuresWithoutPriorEvents()` | `@Test` | Verifica reporte de fallo de `execute()` sin eventos previos. |
| 7 | `reportsEngineExecutionFailuresForSkippedEngine()` | `@Test` | Verifica reporte de fallo cuando el engine hizo `executionSkipped` y luego lanza excepción. |
| 8 | `reportsEngineExecutionFailuresForStartedEngine()` | `@Test` | Verifica reporte de fallo cuando el engine hizo `executionStarted` y luego lanza excepción. |
| 9 | `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` | `@Test` | Verifica reporte de fallo cuando el engine completó con `successful()` y luego lanza excepción. |
| 10 | `reportsEngineExecutionFailuresForFailedFinishedEngine()` | `@Test` | Verifica que fallo original se preserva como `suppressed` y `rootCause` como `cause`. |
| 11 | `reportsSkippedEngines()` | `@Test` | Verifica que `executionSkipped` se propaga a `TestExecutionListener` sin `executionStarted/Finished`. |
| 12 | `reportsFinishedEngines()` | `@Test` | Verifica propagación correcta de `executionStarted`/`executionFinished(successful())`. |
| 13 | `discoverTestPlanForSingleEngine()` | `@Test` | Verifica descubrimiento con 1 engine y 2 tests hijos. |
| 14 | `discoverTestPlanForMultipleEngines()` | `@Test` | Verifica descubrimiento con 2 engines y selectores `selectUniqueId`. |
| 15 | `launcherAppliesPostDiscoveryFilters()` | `@Test` | Verifica filtrado compuesto con `PostDiscoveryFilterStub`. |
| 16 | `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()` | `@Test` | Verifica que `ConfigurationParameters` vacíos se propagan a `ExecutionRequest`. |
| 17 | `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()` | `@Test` | Verifica propagación de parámetro `key=value`. |
| 18 | `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | `@Test @SetSystemProperty` | Verifica fallback a `System.getProperty` para `FOO=BAR`. |
| 19 | `withAdditionalListener()` | `@Test` | Verifica registro de `SummaryGeneratingListener` y conteos `containersFound`/`testsFound`. |
| 20 | `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | `@Test` | Verifica poda de descriptores `CONTAINER` sin hijos tras filtro `isContainer()`. |
| 21 | `reportsDynamicTestDescriptorsCorrectly()` | `@Test` | Verifica registro y jerarquía de tests dinámicos `CONTAINER_AND_TEST` + `dynamicTestRegistered`. |
| 22 | `launcherCanExecuteTestPlanExactlyOnce()` | `@Test` | Verifica que un `TestPlan` solo puede ejecutarse una vez (`PreconditionViolation`). |
| 23 | `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | `@Test` | Verifica que ID con prefijo `junit-` lanza `DiscoveryIssueException` con `[WARNING]`. |
| 24 | `thirdPartyEngineClaimingToBeJupiterResultsInException()` | `@Test` | Delega a `assertImposter("junit-jupiter")`. |
| 25 | `thirdPartyEngineClaimingToBeVintageResultsInException()` | `@Test` | Delega a `assertImposter("junit-vintage")`. |
| 26 | `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | `@Test` | Verifica modo `DRY_RUN_PROPERTY_NAME=true` reporta `executionSkipped` y no ejecuta lógica. |
| 27 | `notifiesDiscoveryListenersOfProcessedSelectors()` | `@Test` | Verifica que `selectorProcessed` se notifica a listeners de config, launcher y request. |
| 28 | `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener)` | `@Test` | Verifica fallo en ejecución por `Severity.ERROR` y log `WARNING` para no críticos. |
| 29 | `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener)` | `@Test` | Verifica log `INFO` para `Severity.INFO` sin fallo. |
| 30 | `logsAllIssuesForDiscoveryFailure(LogRecordListener)` | `@Test` | Verifica logs `SEVERE` e `INFO` cuando `discover` lanza `RuntimeException`. |
| 31 | `logsNonCriticalIssuesForExecutionFailure(LogRecordListener)` | `@Test` | Verifica log `INFO` preservado aunque `execute` falle. |
| 32 | `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | `@Test` | Verifica fallo por `UniqueId` no resuelto con prefijo del engine. |
| 33 | `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` | `@Test` | Verifica que `UniqueId` de otro engine se ignora (`SUCCESSFUL`). |
| 34 | `reportsEngineExecutionFailureForSelectorResolutionFailure()` | `@Test` | Verifica fallo por `RuntimeException` en resolución de `selectClass`. |
| 35 | `allowsConfiguringCriticalDiscoveryIssueSeverity()` | `@Test` | Verifica configuración `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME=info`. |
| 36 | `failsIfCriticalSeverityIsConfiguredIncorrectly()` | `@Test` | Verifica `JUnitException` por severity inválido `wrong`. |
| 37 | `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | `@Test` | Verifica fallo en fase `discovery` si `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery`. |
| 38 | `logsNonCriticalIssuesOnlyOnce(String, LogRecordListener)` | `@ParameterizedTest @ValueSource` | Verifica que issues no críticos se loguean solo una vez para `discovery`/`execution`. |
| 39 | `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()` | `@Test` | Verifica `JUnitException` por `LauncherPhase` inválido `wrong`. |
| 40 | `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | `@Test` | Verifica que `CancellationToken.cancel()` aborta ejecución y reporta `ABORTED` + `executionSkipped`. |

**Tabla Javadoc genérica para métodos `@Test` sin parámetros:**

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | No recibe parámetros (salvo parametrizados) |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| - | `void` | No retorna valor. La verificación se hace vía aserciones. |

| @throws | Tipo | Condición |
| :--- | :--- | :--- |
| `AssertionError` | `org.opentest4j.AssertionFailedError` | Si la aserción `assertThat`, `assertEquals`, `verify` falla. |
| `JUnitException` | `org.junit.platform.commons.JUnitException` | Lanzada por `launcher.discover()` en casos de IDs duplicados o impostores. |
| `DiscoveryIssueException` | `org.junit.platform.launcher.core.DiscoveryIssueException` | Cuando hay `DiscoveryIssue` crítica según severidad configurada. |

**Métodos parametrizados específicos:**

**`discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()`**
| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `throwableClass` | `Class<? extends Throwable>` | Sí | Clase de excepción a instanciar vía reflexión (`Error` o `RuntimeException`). Mensaje `ignored`. |

**`reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()` / `logsNonCriticalIssuesForRegularEngineExecution()` / `logsAllIssuesForDiscoveryFailure()` / `logsNonCriticalIssuesForExecutionFailure()`**
| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Inyectado por `@TrackLogRecords`. Captura `LogRecord` de `DiscoveryIssueNotifier`. |

**`logsNonCriticalIssuesOnlyOnce()`**
| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `phase` | `String` | Sí | Valor de `@ValueSource`: `discovery` o `execution`. Define `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME`. |
| `listener` | `LogRecordListener` | Sí | Listener de logs inyectado. |

---

#### 2.3 Métodos Privados de Instancia

**`assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)`**
```java
private void assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `testEngine` | `TestEngine` | Sí | Engine cuyo ID se usa para construir `UniqueId.forEngine(engineId)` y validar mensaje de fallo. |
| `inOrder` | `InOrder` | Sí | Mock `InOrder` de Mockito para verificar orden `engineDiscoveryStarted` -> `engineDiscoveryFinished`. |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | Mock verificado. |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| - | `void` | Verifica vía `ArgumentCaptor<EngineDiscoveryResult>` que `Status.FAILED` y mensaje `TestEngine with ID '...' failed to discover tests`. |

| @throws | Condición |
| :--- | :--- |
| `AssertionError` | Si `Status` no es `FAILED` o mensaje no coincide. |

**`assertImposter(String)`**
```java
private void assertImposter(String id)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | `String` | Sí | ID reservado a probar (`junit-jupiter`, `junit-vintage`). |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| - | `void` | Verifica que `launcher.discover()` lanza `JUnitException` con mensaje `Third-party TestEngine '...' is forbidden to use the reserved '...' TestEngine ID.` |

| @throws | Condición |
| :--- | :--- |
| `AssertionError` | Si no se lanza `JUnitException` o mensaje no coincide. |

---

#### 2.4 Métodos Privados Estáticos de Utilidad

**`execute(TestEngine)`**
```java
private static ReportedData execute(TestEngine engine)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | Engine a ejecutar. |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| `ReportedData` | `ReportedData` | Record con `testPlan`, `testIdentifier`, `testExecutionResult`, `startTime`, `finishTime`. Delega a `execute(engine, identity())`. |

**`execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)`**
```java
private static ReportedData execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | Engine a ejecutar. |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Función que muta el builder de descubrimiento (ej. `request -> request.selectors(...)`). |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| `ReportedData` | `ReportedData` | Delega a `execute(engine, discoveryConfigurer, identity())`. |

**`execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)`**
```java
private static ReportedData execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | Engine a ejecutar. |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Configura `LauncherDiscoveryRequestBuilder` (deshabilita `enableImplicitConfigurationParameters(false)`, setea `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=execution` y `DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME=logging`). |
| `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Configura `LauncherExecutionRequestBuilder` (ej. añadir `listeners`, `cancellationToken`). |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| `ReportedData` | `ReportedData` | Captura `TestPlan`, `TestIdentifier` y `TestExecutionResult` vía `ArgumentCaptor` y `InOrder` sobre `TestExecutionListener` mock. Captura `Instant` de `executionStarted`/`executionFinished` vía `doAnswer`. |

| @throws | Condición |
| :--- | :--- |
| `NullPointerException` | Si `startTime` o `finishTime` son `null` (`requireNonNull`). |
| `AssertionError` | Si `InOrder` no verifica `testPlanExecutionStarted` -> `executionStarted` -> `executionFinished` -> `testPlanExecutionFinished`. |

**`findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)`**
```java
private static LogRecord findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Fuente de `LogRecord` filtrada por `DiscoveryIssueNotifier.class` y `Level`. |
| `level` | `Level` | Sí | Nivel `java.util.logging.Level` (`INFO`, `WARNING`, `SEVERE`). |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| `LogRecord` | `java.util.logging.LogRecord` | Primer `LogRecord` del stream `listener.stream(DiscoveryIssueNotifier.class, level)`. |

| @throws | Condición |
| :--- | :--- |
| `NoSuchElementException` | Si `findFirst().orElseThrow()` no encuentra registro. |

---

#### 2.5 Clases Anónimas, Internas y Record

**Record `ReportedData`**
```java
private record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier, TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)
```

| Componente | Tipo | Descripción |
| :--- | :--- | :--- |
| `testPlan` | `TestPlan` | Plan descubierto por `launcher.discover()`. |
| `testIdentifier` | `TestIdentifier` | Identificador capturado en `executionStarted`. |
| `testExecutionResult` | `TestExecutionResult` | Resultado capturado en `executionFinished`. |
| `startTime` | `Instant` | Timestamp de `executionStarted`. |
| `finishTime` | `Instant` | Timestamp de `executionFinished`. |

Métodos generados automáticamente: `testPlan()`, `testIdentifier()`, `testExecutionResult()`, `startTime()`, `finishTime()`, `equals()`, `hashCode()`, `toString()` y constructor canónico `ReportedData(TestPlan, TestIdentifier, TestExecutionResult, Instant, Instant)`.

**Clases Anónimas - Métodos Sobrescritos Detectados (todos documentados al 100%)**

| Clase Anónima Padre | Método Exacto Sobrescrito | Firma | Descripción |
| :--- | :--- | :--- | :--- |
| `TestEngineStub` en `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Retorna `null` deliberadamente para probar manejo de descriptor nulo. `@SuppressWarnings("DataFlowIssue")`. |
| `TestEngineStub` en `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Instancia `throwableClass` vía reflexión y lanza con `ExceptionUtils.throwAsUncheckedException`. Retorna `null` en `catch`. |
| `TestEngineStub` en `reportsEngineExecutionFailuresWithoutPriorEvents()` | `execute()` | `void execute(ExecutionRequest request)` | Lanza `rootCause` directamente sin notificar listener. |
| `TestEngineStub` en `reportsEngineExecutionFailuresForSkippedEngine()` | `execute()` | `void execute(ExecutionRequest request)` | Notifica `executionSkipped(engineDescriptor, "not today")` y luego lanza `rootCause`. |
| `TestEngineStub` en `reportsEngineExecutionFailuresForStartedEngine()` | `execute()` | `void execute(ExecutionRequest request)` | Notifica `executionStarted(engineDescriptor)` y luego lanza `rootCause`. |
| `TestEngineStub` en `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` | `execute()` | `void execute(ExecutionRequest request)` | Notifica `executionStarted` + `executionFinished(successful())` y luego lanza `rootCause`. |
| `TestEngineStub` en `reportsEngineExecutionFailuresForFailedFinishedEngine()` | `execute()` | `void execute(ExecutionRequest request)` | Notifica `executionStarted` + `executionFinished(failed(originalFailure))` y luego lanza `rootCause`. |
| `TestEngineStub` en `reportsSkippedEngines()` | `execute()` | `void execute(ExecutionRequest request)` | Solo `executionSkipped(engineDescriptor, "not today")`. |
| `TestEngineStub` en `reportsFinishedEngines()` | `execute()` | `void execute(ExecutionRequest request)` | `executionStarted` + `executionFinished(successful())`. |
| `TestEngineSpy` en `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Crea `EngineDescriptor` + `TestDescriptorStub` tipo `CONTAINER` con hijo `test`. |
| `TestDescriptorStub` anónimo en `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | `getType()` | `Type getType()` | Retorna `Type.CONTAINER`. |
| `TestEngineSpy` en `reportsDynamicTestDescriptorsCorrectly()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Crea `EngineDescriptor` con hijo `CONTAINER_AND_TEST`. |
| `TestDescriptorStub` anónimo en `reportsDynamicTestDescriptorsCorrectly()` | `getType()` | `Type getType()` | Retorna `Type.CONTAINER_AND_TEST`. |
| `TestEngineSpy` en `reportsDynamicTestDescriptorsCorrectly()` | `execute()` | `void execute(ExecutionRequest request)` | Simula ciclo dinámico: `executionStarted` engine/container, `dynamicTestRegistered`, `executionStarted/Finished` dynamicTest. |
| `TestEngineStub` en `notifiesDiscoveryListenersOfProcessedSelectors()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Itera `getSelectorsByType` y notifica `selectorProcessed(uniqueId, selector, unresolved())`. |
| `TestEngineStub` en `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()` | `discover()` | `TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` | Reporta `DiscoveryIssue` `ERROR` y `WARNING` y retorna `EngineDescriptor` con `TestTag`. Sobrescribe `getTags()` retornando `Set.of(TestTag.create("custom-tag"))`. |
| `TestEngineStub` en `logsNonCriticalIssuesForRegularEngineExecution()` | `discover()` / `execute()` | `discover(...)` reporta `INFO`; `execute(...)` hace `executionStarted/Finished(successful())`. |
| `TestEngineStub` en `logsAllIssuesForDiscoveryFailure()` | `discover()` | `TestDescriptor discover(...)` | Reporta `ERROR`+`INFO` y lanza `RuntimeException("boom")`. |
| `TestEngineStub` en `logsNonCriticalIssuesForExecutionFailure()` | `discover()` / `execute()` | `discover` reporta `INFO`; `execute` lanza `RuntimeException("boom")`. |
| `TestEngineStub` en `allowsConfiguringCriticalDiscoveryIssueSeverity()` | `discover()` | `TestDescriptor discover(...)` | Reporta `INFO` y retorna `EngineDescriptor`. |
| `TestEngineStub` en `failsIfCriticalSeverityIsConfiguredIncorrectly()` | `discover()` / `execute()` | `discover` reporta `INFO`; `execute` hace `executionStarted/Finished`. |
| `TestEngineStub` en `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | `discover()` | `TestDescriptor discover(...)` | Reporta `ERROR` y retorna `EngineDescriptor`. |
| `TestEngineStub` en `logsNonCriticalIssuesOnlyOnce()` | `discover()` / `execute()` | `discover` reporta `WARNING`; `execute` hace `executionStarted/Finished`. |
| `TestEngineStub` en `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` (spy) | `discover()` | `TestDescriptor discover(...)` | Crea `EngineDescriptor` con `container` y `test` hijo. |

Para cada método anónimo:

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Request con selectores y `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID único del engine (`UniqueId.forEngine(id)`). |
| `request` | `ExecutionRequest` | Sí | Contiene `getRootTestDescriptor()` y `getEngineExecutionListener()`. |

| @return | Tipo | Descripción |
| :--- | :--- | :--- |
| `discover` | `TestDescriptor` / `null` | Descriptor raíz o `null` para simular fallo. |
| `execute` | `void` | Notifica al `EngineExecutionListener`. |
| `getType` | `TestDescriptor.Type` | `CONTAINER` o `CONTAINER_AND_TEST`. |

| @throws | Condición |
| :--- | :--- |
| `RuntimeException` / `Error` | Lanzada deliberadamente para probar manejo de fallos de engine. |

---

### 3. Ejemplo de Uso

El siguiente bloque reproduce un caso real extraído de la clase: descubrimiento y ejecución con `DemoHierarchicalTestEngine`, verificación de `TestPlan` y manejo de `TestExecutionListener` mock.

```java
package org.junit.platform.launcher.core;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectPackage;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;
import static org.junit.platform.launcher.core.LauncherFactoryForTestingPurposesOnly.createLauncher;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.junit.platform.engine.TestExecutionResult.successful;

import org.junit.platform.engine.UniqueId;
import org.junit.platform.engine.support.hierarchical.DemoHierarchicalTestEngine;
import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.TestPlan;

public class EjemploDefaultLauncher {

    private static final Runnable noOp = () -> {};

    public static void main(String[] args) {
        // 1. Crear engine con tests jerárquicos
        var engine = new DemoHierarchicalTestEngine("myEngine");
        engine.addTest("test1", noOp);
        engine.addTest("test2", noOp);

        // 2. Crear launcher (equivalente a LauncherFactory.create())
        var launcher = createLauncher(engine);

        // 3. Descubrir TestPlan
        TestPlan testPlan = launcher.discover(
            request().selectors(selectPackage("any")).build()
        );

        assertThat(testPlan.getRoots()).hasSize(1);
        assertThat(testPlan.getChildren(UniqueId.forEngine("myEngine"))).hasSize(2);

        // 4. Ejecutar con listener
        TestExecutionListener listener = mock(TestExecutionListener.class);
        var executionRequest = LauncherExecutionRequestBuilder.request(testPlan)
                .listeners(listener)
                .build();

        launcher.execute(executionRequest);

        // 5. Verificar notificaciones
        verify(listener).executionStarted(any());
        // El engine notifica successful() para cada descriptor
        verify(listener).executionFinished(any(), eq(successful()));

        // 6. Ejemplo de manejo de fallo en descubrimiento (engine que retorna null)
        // var faultyEngine = new TestEngineStub("faulty") {
        //     @Override public TestDescriptor discover(EngineDiscoveryRequest req, UniqueId id) { return null; }
        // };
        // TestPlan faultyPlan = createLauncher(faultyEngine).discover(request().build());
        // assertThat(faultyPlan.getRoots()).hasSize(1); // Plan contiene engine con fallo
    }
}
```

**Notas de uso:**
* `LauncherDiscoveryRequestBuilder.request()` es el entry-point para construir `LauncherDiscoveryRequest`.
* `LauncherExecutionRequestBuilder.request(testPlan)` requiere un `TestPlan` previamente descubierto y solo puede ejecutarse una vez; un segundo `launcher.execute()` lanza `PreconditionViolation: TestPlan must only be executed once`.
* Para modo dry-run: `request().configurationParameter(LauncherConstants.DRY_RUN_PROPERTY_NAME, "true")` provoca `executionSkipped` con mensaje `JUnit Platform dry-run mode is enabled` sin ejecutar la lógica del test.
