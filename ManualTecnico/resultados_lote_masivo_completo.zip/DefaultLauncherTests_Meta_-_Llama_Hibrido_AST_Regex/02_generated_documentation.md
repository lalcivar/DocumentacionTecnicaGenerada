# Documentación Técnica - `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`  
**Clase:** `DefaultLauncherTests`  
**Anotaciones de clase:** `@NullMarked`  
**Visibilidad:** `package-private` (`class DefaultLauncherTests`)  
**Superclase:** `java.lang.Object`  
**Desde:** `1.0`

---

## 1. Resumen Ejecutivo

`DefaultLauncherTests` es una clase de pruebas de integración y unitarias para `DefaultLauncher`, la implementación por defecto de la API `Launcher` de JUnit Platform. Su propósito es validar exhaustivamente el ciclo de vida de descubrimiento (`discover`) y ejecución (`execute`) de `TestEngine`s, incluyendo el manejo de fallos, filtros `PostDiscoveryFilter`, parámetros de configuración, notificaciones a `LauncherDiscoveryListener` y `TestExecutionListener`, y el tratamiento de `DiscoveryIssue` con diferentes severidades y fases.

La clase no expone lógica de negocio reutilizable; actúa como suite de regresión que garantiza el contrato de `LauncherFactory`, `LauncherDiscoveryRequestBuilder` y `LauncherExecutionRequestBuilder` frente a condiciones normales, límites y errores.

---

## 2. Especificación de Métodos y Constructores

### 2.1 Información de la Clase

| Atributo | Valor |
|---|---|
| **Nombre completo** | `org.junit.platform.launcher.core.DefaultLauncherTests` |
| **Tipo** | Clase de prueba JUnit Jupiter |
| **Anotaciones** | `@NullMarked` (JSR-305 / JSpecify: no nulabilidad por defecto) |
| **Campos estáticos** | `FOO: String`, `BAR: String`, `noOp: Runnable` |

### 2.2 Constructores

La clase no declara constructores explícitos. El compilador genera el constructor por defecto.

#### `DefaultLauncherTests()`

Constructor por defecto implícito sin argumentos.

| Elemento | Descripción |
|---|---|
| **Visibilidad** | `package-private` |
| **@param** | Ninguno |
| **@return** | Instancia de `DefaultLauncherTests` |
| **@throws** | Ninguno |

---

### 2.3 Métodos de Prueba Públicos (`@Test` / `@ParameterizedTest`)

Todos los métodos de esta sección son `void`, sin valor de retorno, y son invocados por el motor JUnit Jupiter.

#### `constructLauncherWithoutAnyEngines()`
Verifica que `LauncherFactory` falle si no se registra ningún `TestEngine`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| - | - | - | No recibe parámetros |

| @return | Descripción |
|---|---|
| `void` | No retorna valor. La aserción valida la precondición. |

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se lanza `PreconditionViolationException` con mensaje `Cannot create Launcher without at least one TestEngine` |

#### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`
Valida que dos `TestEngine` con el mismo ID provoquen `JUnitException`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| - | - | - | No recibe parámetros |

| @return | `void` |
| @throws | `AssertionError` si no se lanza `JUnitException` con mensaje `multiple engines with the same ID` |

#### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`
Comprueba que un `DemoHierarchicalTestEngine` sin tests genere un `TestPlan` con una sola raíz (el engine).

| @param | - |
| @return | `void` |
| @throws | `AssertionError` si `testPlan.getRoots().size() != 1` |

#### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
Valida el manejo de `null` retornado por `TestEngine.discover()`. Debe marcar el descubrimiento como `FAILED` y notificar a `LauncherDiscoveryListener`.

| @param | - |
| @return | `void` |
| @throws | `AssertionError` si el `TestPlan` no contiene 1 raíz o si no se verifica `engineDiscoveryFailed` |

#### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`
Prueba parametrizada que simula un `TestEngine` que lanza `Error` o `RuntimeException` durante `discover()`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `throwableClass` | `Class<? extends Throwable>` | Sí | Clase de la excepción a instanciar vía reflexión (`Error` o `RuntimeException`) |

| @return | `void` |
| @throws | `AssertionError` si el `TestPlan` no reporta fallo o si `executionFinished` no contiene `Throwable` con mensaje `TestEngine with ID 'my-engine-id' failed to discover tests` |
| @throws | `Exception` (envuelta) si falla la instanciación reflexiva |

#### `reportsEngineExecutionFailuresWithoutPriorEvents()`
Verifica que una excepción no capturada en `TestEngine.execute()` sin eventos previos se reporte como `executionFinished` con `FAILED`.

| @param | - |
| @return | `void` |
| @throws | `AssertionError` si no se captura `TestExecutionResult` con causa `rootCause` |

#### `reportsEngineExecutionFailuresForSkippedEngine()`
Valida el reporte de fallo cuando el engine notifica `executionSkipped` y luego lanza excepción.

| @param | - |
| @return | `void` |
| @throws | `AssertionError` si el resultado no contiene el mensaje `failed to execute tests` |

#### `reportsEngineExecutionFailuresForStartedEngine()`
Valida el reporte de fallo cuando el engine notifica `executionStarted` y luego lanza excepción.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`
Valida que incluso si el engine reporta `executionFinished(successful())`, una excepción posterior se reporte como fallo.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `reportsEngineExecutionFailuresForFailedFinishedEngine()`
Valida que si el engine reporta `executionFinished(failed(originalFailure))` y luego lanza `rootCause`, el resultado final contenga `rootCause` como causa y `originalFailure` como `suppressed`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `reportsSkippedEngines()`
Verifica que `executionSkipped` se propague correctamente a `TestExecutionListener` sin invocar `executionStarted/Finished`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `reportsFinishedEngines()`
Verifica el flujo feliz `executionStarted` -> `executionFinished(successful())`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `discoverTestPlanForSingleEngine()`
Descubre un plan con un solo `DemoHierarchicalTestEngine` con 2 tests y valida `getChildren()`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `discoverTestPlanForMultipleEngines()`
Descubre un plan con dos engines y selectores `selectUniqueId` específicos.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `launcherAppliesPostDiscoveryFilters()`
Valida la aplicación secuencial de dos `PostDiscoveryFilterStub` y el filtrado por `UniqueId`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`
Verifica que sin parámetros de configuración, `ConfigurationParameters.get("key")` esté vacío en `ExecutionRequest`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`
Verifica que `configurationParameter("key", "value")` se propague a `ExecutionRequest`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`
Anotado con `@SetSystemProperty(key = FOO, value = BAR)`. Valida fallback a `System.getProperty`.

| @param | - | @return | `void` | @throws | `AssertionError` si `configurationParameters.get(FOO)` no contiene `BAR` |

#### `withAdditionalListener()`
Valida que un `SummaryGeneratingListener` adicional reciba eventos y genere `Summary` con `containersFoundCount=1` y `testsFoundCount=1`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
Verifica que tras aplicar un `PostDiscoveryFilter` que solo incluye `isContainer()`, los hijos de tipo `test` sean podados y el engine quede sin hijos.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `reportsDynamicTestDescriptorsCorrectly()`
Valida el registro dinámico de tests (`dynamicTestRegistered`) para descriptores `CONTAINER_AND_TEST`.

| @param | - | @return | `void` | @throws | `AssertionError` si la jerarquía de `TestIdentifier` no es correcta |

#### `launcherCanExecuteTestPlanExactlyOnce()`
Verifica que un `TestPlan` solo pueda ejecutarse una vez; la segunda ejecución debe lanzar `PreconditionViolationException`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`
Valida que un engine con ID `junit-using-reserved-prefix` lance `DiscoveryIssueException` con `WARNING`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `thirdPartyEngineClaimingToBeJupiterResultsInException()`
Delega en `assertImposter("junit-jupiter")`.

| @param | - | @return | `void` | @throws | `AssertionError` / `JUnitException` |

#### `thirdPartyEngineClaimingToBeVintageResultsInException()`
Delega en `assertImposter("junit-vintage")`.

| @param | - | @return | `void` | @throws | `AssertionError` / `JUnitException` |

#### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`
Valida el modo `DRY_RUN_PROPERTY_NAME=true`: el test debe reportarse como `executionSkipped` con mensaje `JUnit Platform dry-run mode is enabled` y no ejecutar la lógica que lanza `RuntimeException`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `notifiesDiscoveryListenersOfProcessedSelectors()`
Verifica que `selectorProcessed` se notifique a los tres niveles de listeners: config, launcher y request.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)`
Valida que un `DiscoveryIssue` de severidad `ERROR` provoque `FAILED` y que `WARNING` se loguee como `Level.WARNING`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Inyectado por `@TrackLogRecords`, captura `LogRecord` de `DiscoveryIssueNotifier` |

| @return | `void` |
| @throws | `AssertionError` |

#### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)`
Valida que un `INFO` no crítico se loguee como `Level.INFO` y la ejecución sea `SUCCESSFUL`.

| @param | `listener: LogRecordListener` | Sí | @return | `void` | @throws | `AssertionError` |

#### `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)`
Valida que tras una excepción en `discover()`, tanto `ERROR` (SEVERE) como `INFO` se logueen.

| @param | `listener: LogRecordListener` | Sí | @return | `void` | @throws | `AssertionError` |

#### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)`
Valida que un `INFO` se loguee aunque `execute()` falle con `RuntimeException`.

| @param | `listener: LogRecordListener` | Sí | @return | `void` | @throws | `AssertionError` |

#### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`
Usa `createEngineThatCannotResolveAnything("some-engine")` y selector `selectUniqueId(UniqueId.forEngine("some-engine"))`. Debe fallar con `DiscoveryIssueException`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`
Mismo engine pero selector para `some-other-engine`. Debe ser `SUCCESSFUL` (ignorado).

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `reportsEngineExecutionFailureForSelectorResolutionFailure()`
Usa `createEngineThatFailsToResolveAnything` con `RuntimeException("boom")`. Debe reportar `resolution failed` con causa.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `allowsConfiguringCriticalDiscoveryIssueSeverity()`
Configura `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME=info` y verifica que un `INFO` se vuelva crítico (`FAILED`).

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `failsIfCriticalSeverityIsConfiguredIncorrectly()`
Configura severidad `wrong` y espera `JUnitException` con causa `Invalid DiscoveryIssue.Severity`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`
Configura `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery` y espera `DiscoveryIssueException` inmediata en `discover()`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)`
Prueba parametrizada `@ValueSource(strings = {"discovery", "execution"})`. Verifica que un `WARNING` solo se loguee una vez independientemente de la fase.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `phase` | `String` | Sí | Valor de `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME` |
| `listener` | `LogRecordListener` | Sí | Captura logs |

| @return | `void` | @throws | `AssertionError` |

#### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`
Configura `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=wrong` y espera `JUnitException` con mensaje `Invalid LauncherPhase`.

| @param | - | @return | `void` | @throws | `AssertionError` |

#### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`
Valida que con `CancellationToken.cancel()` previo, `engine.execute()` nunca se invoque y los hijos se reporten como `ABORTED` / `Execution cancelled`.

| @param | - | @return | `void` | @throws | `AssertionError` |

---

### 2.4 Métodos Auxiliares Privados

#### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`
Helper para verificar la secuencia `engineDiscoveryStarted` -> `engineDiscoveryFinished(FAILED)`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testEngine` | `TestEngine` | Sí | Engine cuyo ID se usa para construir `UniqueId.forEngine()` |
| `inOrder` | `InOrder` | Sí | Mock de Mockito para verificación ordenada |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | Mock verificado |

| @return | `void` |
| @throws | `AssertionError` si el `EngineDiscoveryResult` no es `FAILED` o el mensaje no contiene `failed to discover tests` |

#### `assertImposter(String id)`
Helper que crea un `TestEngineStub` con ID reservado y verifica que `discover()` lance `JUnitException` con mensaje `Third-party TestEngine ... is forbidden to use the reserved ...`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `id` | `String` | Sí | ID reservado (`junit-jupiter`, `junit-vintage`) |

| @return | `void` |
| @throws | `AssertionError` si no se lanza `JUnitException` |

---

### 2.5 Métodos Estáticos Privados de Utilidad

#### `execute(TestEngine engine)`
Sobrecarga de conveniencia que delega en `execute(engine, identity())`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Engine a ejecutar |

| @return | `ReportedData` | Record con `testPlan`, `testIdentifier`, `testExecutionResult`, `startTime`, `finishTime` |
| @throws | `NullPointerException` si `startTime` o `finishTime` son nulos |

#### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)`
Sobrecarga que delega en la versión de 3 parámetros con `identity()` para `executionConfigurer`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Engine a ejecutar |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Función para configurar el `LauncherDiscoveryRequestBuilder` |

| @return | `ReportedData` |
| @throws | `JUnitException` / `DiscoveryIssueException` según configuración |

#### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)`
Método central que orquesta `discover` y `execute`, captura tiempos con `doAnswer` y verifica interacciones con `TestExecutionListener` mock.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Engine bajo prueba |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Configurador de descubrimiento |
| `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Configurador de ejecución |

| @return | `ReportedData` | Contiene el `TestPlan` descubierto, el `TestIdentifier` del engine, el `TestExecutionResult` y los `Instant` de inicio/fin |
| @throws | `NullPointerException` si `startTime`/`finishTime` no fueron capturados |
| @throws | `JUnitException` si la configuración de severidad/fase es inválida |

#### `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)`
Busca el primer `LogRecord` de `DiscoveryIssueNotifier` para un nivel dado.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Listener que almacena `LogRecord`s |
| `level` | `Level` | Sí | Nivel `java.util.logging.Level` a filtrar |

| @return | `LogRecord` | Primer registro encontrado |
| @throws | `NoSuchElementException` si no existe registro para ese nivel/clase |

---

### 2.6 Clases y Métodos Anónimos / Internos

Todas las clases anónimas extienden `TestEngineStub` o `TestEngineSpy` o `TestDescriptorStub` o `EngineDescriptor`. Se documentan los métodos sobreescritos.

#### `discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)` - Anónimo `TestEngineStub`
Presente en: `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`, `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()`, `notifiesDiscoveryListenersOfProcessedSelectors()`, `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()`, `logsNonCriticalIssuesForRegularEngineExecution()`, `logsAllIssuesForDiscoveryFailure()`, `logsNonCriticalIssuesForExecutionFailure()`, `allowsConfiguringCriticalDiscoveryIssueSeverity()`, `failsIfCriticalSeverityIsConfiguredIncorrectly()`, `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`, `logsNonCriticalIssuesOnlyOnce()`, `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` y otros.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Solicitud con selectores y `DiscoveryListener` |
| `uniqueId` | `UniqueId` | Sí | ID único del engine (`UniqueId.forEngine(id)`) |

| @return | `TestDescriptor` | Descriptor raíz o `null` (para probar fallo) o `EngineDescriptor` |
| @throws | `RuntimeException` / `Error` (simulado) en casos de prueba de fallo |

#### `execute(ExecutionRequest request)` - Anónimo `TestEngineStub` / `TestEngineSpy`
Presente en: `reportsEngineExecutionFailuresWithoutPriorEvents()`, `reportsEngineExecutionFailuresForSkippedEngine()`, `reportsEngineExecutionFailuresForStartedEngine()`, `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`, `reportsEngineExecutionFailuresForFailedFinishedEngine()`, `reportsSkippedEngines()`, `reportsFinishedEngines()`, `reportsDynamicTestDescriptorsCorrectly()`, `logsNonCriticalIssuesForRegularEngineExecution()`, `logsNonCriticalIssuesForExecutionFailure()`, etc.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Contiene `getRootTestDescriptor()` y `getEngineExecutionListener()` |

| @return | `void` |
| @throws | `RuntimeException` (simulado `rootCause`) para validar manejo de errores |

#### `getType()` - Anónimo `TestDescriptorStub`
Presente en `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` y `reportsDynamicTestDescriptorsCorrectly()`.

| @param | - |
| @return | `TestDescriptor.Type` | Retorna `Type.CONTAINER` o `Type.CONTAINER_AND_TEST` |
| @throws | Ninguno |

#### `getTags()` - Anónimo `EngineDescriptor`
Presente en `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()`.

| @param | - |
| @return | `Set<TestTag>` | Retorna `Set.of(TestTag.create("custom-tag"))` |
| @throws | Ninguno |

---

### 2.7 Record Interno `ReportedData`

```java
private record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier,
        TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)
```

Record privado que encapsula el resultado de la ejecución de un engine para aserciones.

| Componente | Tipo | Descripción |
|---|---|---|
| `testPlan` | `TestPlan` | Plan descubierto por `launcher.discover()` |
| `testIdentifier` | `TestIdentifier` | Identificador del engine (`TestIdentifier.from(engineDescriptor)`) |
| `testExecutionResult` | `TestExecutionResult` | Resultado capturado vía `ArgumentCaptor` |
| `startTime` | `Instant` | Timestamp capturado en `executionStarted` vía `doAnswer` |
| `finishTime` | `Instant` | Timestamp capturado en `executionFinished` vía `doAnswer` |

Constructor canónico generado automáticamente con los 5 parámetros. Métodos `equals()`, `hashCode()`, `toString()` y accesores generados por el compilador.

---

## 3. Ejemplo de Uso

El siguiente ejemplo ilustra el uso real de `DefaultLauncher` (a través de `LauncherFactory`) tal como se ejercita en la suite `DefaultLauncherTests`. No utiliza APIs externas fuera del código provisto.

```java
package org.junit.platform.launcher.core;

import org.junit.platform.engine.TestEngine;
import org.junit.platform.engine.support.hierarchical.DemoHierarchicalTestEngine;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherExecutionRequestBuilder;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectPackage;
import static org.junit.platform.launcher.core.LauncherFactoryForTestingPurposesOnly.createLauncher;

public class EjemploDefaultLauncher {

    public static void main(String[] args) {
        // 1. Crear un TestEngine de demostración con dos tests
        DemoHierarchicalTestEngine engine = new DemoHierarchicalTestEngine("myEngine");
        engine.addTest("test1", () -> System.out.println("Ejecutando test1"));
        engine.addTest("test2", () -> System.out.println("Ejecutando test2"));

        // 2. Crear el Launcher (DefaultLauncher) con el engine
        Launcher launcher = createLauncher(engine);

        // 3. Descubrir el TestPlan
        var discoveryRequest = LauncherDiscoveryRequestBuilder.request()
                .selectors(selectPackage("any"))
                .build();

        TestPlan testPlan = launcher.discover(discoveryRequest);
        System.out.println("Roots descubiertos: " + testPlan.getRoots().size());
        System.out.println("Tests contenidos: " + testPlan.containsTests());

        // 4. Ejecutar el TestPlan exactamente una vez con un listener
        SummaryGeneratingListener listener = new SummaryGeneratingListener();
        var executionRequest = LauncherExecutionRequestBuilder.request(testPlan)
                .listeners(listener)
                .build();

        launcher.execute(executionRequest);

        // 5. Consultar el resumen
        var summary = listener.getSummary();
        System.out.println("Containers encontrados: " + summary.getContainersFoundCount());
        System.out.println("Tests encontrados: " + summary.getTestsFoundCount());
        System.out.println("Tests exitosos: " + summary.getTestsSucceededCount());

        // 6. Modo dry-run (no ejecuta tests, solo reporta skipped)
        var dryRunRequest = LauncherDiscoveryRequestBuilder.request()
                .configurationParameter("junit.platform.execution.dryRun.enabled", "true")
                .selectors(selectPackage("any"))
                .build();
        TestPlan dryRunPlan = launcher.discover(dryRunRequest);
        // launcher.execute(...) reportará executionSkipped con mensaje "JUnit Platform dry-run mode is enabled"
    }
}
```

**Notas del ejemplo:**
* `createLauncher(TestEngine...)` es el factory usado en todos los tests para instanciar `DefaultLauncher`.
* `LauncherDiscoveryRequestBuilder.request()` y `LauncherExecutionRequestBuilder.request(testPlan)` son los builders oficiales para construir requests.
* Un `TestPlan` solo puede ejecutarse una vez; una segunda llamada a `launcher.execute(executionRequest)` lanza `PreconditionViolationException` con mensaje `TestPlan must only be executed once`, como verifica `launcherCanExecuteTestPlanExactlyOnce()`.
* Los `LauncherDiscoveryListener` y `TestExecutionListener` se registran vía `request().listeners(...)` o `launcher.registerLauncherDiscoveryListeners(...)`.

