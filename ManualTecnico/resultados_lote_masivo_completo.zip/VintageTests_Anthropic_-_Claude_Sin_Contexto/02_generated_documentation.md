# Documentación técnica: `VintageTests`

## 1. Información general

| Atributo | Valor |
|---|---|
| **Nombre de la clase** | `VintageTests` |
| **Paquete** | `com.example.project` |
| **Tipo** | Clase pública, no final, sin herencia explícita (extiende implícitamente `java.lang.Object`) |
| **Framework de pruebas** | JUnit 4 (`org.junit.Test`) |
| **Dependencias** | `junit:junit` (JUnit 4.x); opcionalmente `junit-vintage-engine` si se ejecuta sobre la JUnit Platform (JUnit 5) |
| **Licencia** | Eclipse Public License v2.0 |

---

## 2. Descripción general

`VintageTests` es una **clase de pruebas unitarias escrita con la API clásica de JUnit 4**. Su nombre hace referencia al *JUnit Vintage Engine*, el motor de ejecución de la JUnit Platform que permite ejecutar pruebas heredadas de JUnit 3 y JUnit 4 dentro del entorno de JUnit 5 (JUnit Jupiter).

En su estado actual, la clase actúa como un **caso de prueba mínimo o "smoke test"**: contiene un único método de prueba vacío cuyo propósito no es validar lógica de negocio, sino **verificar que la infraestructura de ejecución de pruebas funciona correctamente**. Es un patrón habitual en:

- Proyectos de ejemplo o plantillas (*archetypes*) que demuestran la coexistencia de JUnit 4 y JUnit 5 en el mismo build.
- Pruebas de integración del propio *build* (Maven Surefire / Gradle Test) para comprobar que el motor Vintage está correctamente registrado en el *classpath*.
- Escenarios de verificación de herramientas de reporte, cobertura o descubrimiento de pruebas.

Al no contener aserciones ni código ejecutable, el método siempre finaliza con éxito, por lo que el resultado esperado de la ejecución es **1 prueba ejecutada, 0 fallos**.

---

## 3. Estructura de la clase

### 3.1 Constructores

| Constructor | Visibilidad | Descripción |
|---|---|---|
| `VintageTests()` | `public` (implícito) | Constructor por defecto generado por el compilador. JUnit 4 lo invoca mediante reflexión **una vez por cada método de prueba**, creando una instancia nueva para garantizar el aislamiento entre casos. |

### 3.2 Atributos

La clase no declara campos de instancia ni estáticos; por tanto, no mantiene estado entre ejecuciones.

---

## 4. Métodos principales

### `public void test()`

```java
@Test
public void test() {
}
```

| Aspecto | Detalle |
|---|---|
| **Anotación** | `@Test` (`org.junit.Test`) — marca el método como caso de prueba ejecutable por el *runner* de JUnit 4. |
| **Modificadores** | `public` — requisito obligatorio de JUnit 4 para los métodos de prueba. |
| **Parámetros** | Ninguno. JUnit 4 exige métodos de prueba sin argumentos (salvo con *runners* especializados como `Parameterized` o `Theories`). |
| **Valor de retorno** | `void` — requisito obligatorio de JUnit 4. |
| **Excepciones** | No declara excepciones comprobadas. |
| **Comportamiento** | Cuerpo vacío: no realiza invocaciones, no define aserciones y no modifica estado alguno. |
| **Resultado** | Se considera **aprobada (PASSED)** siempre, ya que JUnit marca como fallida una prueba únicamente cuando lanza una excepción o un `AssertionError`. |
| **Propósito** | Confirmar que el motor de pruebas descubre y ejecuta correctamente clases basadas en JUnit 4. |

> **Nota:** la clase no define métodos de ciclo de vida (`@Before`, `@After`, `@BeforeClass`, `@AfterClass`), por lo que no existe lógica de preparación ni de limpieza asociada.

---

## 5. Ciclo de vida de ejecución

1. El motor de pruebas (Vintage Engine o Surefire con el *provider* de JUnit 4) descubre la clase por convención de nombre (`*Tests`) y/o por la presencia de métodos anotados con `@Test`.
2. Se instancia `VintageTests` mediante su constructor por defecto.
3. Se invoca `test()` por reflexión.
4. El método retorna sin excepciones → la prueba se reporta como satisfactoria.
5. La instancia queda disponible para recolección de basura.

---

## 6. Ejemplo de ejecución

**Maven**

```bash
mvn test -Dtest=VintageTests
```

**Gradle**

```bash
./gradlew test --tests "com.example.project.VintageTests"
```

**Configuración mínima para ejecutarla sobre la JUnit Platform (Maven):**

```xml
<dependency>
  <groupId>org.junit.vintage</groupId>
  <artifactId>junit-vintage-engine</artifactId>
  <version>5.x.x</version>
  <scope>test</scope>
</dependency>
```

---

## 7. Observaciones y recomendaciones

| Observación | Recomendación |
|---|---|
| El método `test()` no contiene aserciones, por lo que no valida ningún comportamiento real. | Si el objetivo es validar lógica, añadir aserciones (`Assert.assertEquals`, etc.). Si es un *marker test*, documentarlo explícitamente con Javadoc para evitar que se interprete como una prueba incompleta. |
| Los nombres `VintageTests` y `test` no son descriptivos. | Usar nombres que expresen la intención, p. ej. `shouldBeDiscoveredByVintageEngine()`. |
| Ausencia de Javadoc. | Documentar el propósito de la clase, especialmente al tratarse de un artefacto de verificación de infraestructura. |
| Uso de JUnit 4. | Para código nuevo, preferir JUnit Jupiter (`org.junit.jupiter.api.Test`); mantener JUnit 4 solo por compatibilidad heredada. |

---

## 8. Versión documentada propuesta

```java
package com.example.project;

import org.junit.Test;

/**
 * Caso de prueba mínimo basado en la API de JUnit 4.
 *
 * <p>Esta clase no valida lógica de negocio: su finalidad es comprobar que el
 * motor <em>JUnit Vintage</em> descubre y ejecuta correctamente pruebas escritas
 * con JUnit 4 dentro de la JUnit Platform.</p>
 *
 * @since 1.0
 */
public class VintageTests {

	/**
	 * Prueba de humo sin aserciones.
	 *
	 * <p>Se considera satisfactoria siempre que el motor de pruebas sea capaz de
	 * instanciar la clase e invocar este método sin errores.</p>
	 */
	@Test
	public void test() {
		// Intencionadamente vacío: valida únicamente el descubrimiento y la ejecución.
	}
}
```