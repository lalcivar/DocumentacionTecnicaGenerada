# Documentación Técnica del Módulo de Pruebas

## 1. Resumen ejecutivo
Este módulo contiene un pequeño conjunto de pruebas unitarias para verificar la correcta configuración de la aplicación Flask creada por `create_app()` y la respuesta de la ruta `/hello`.  
Fue diseñado para ser ejecutado con **pytest** y depende de las fixtures convencionales (`client`) provistas por la extensión `pytest-flask`.

---

## 2. Especificación de funciones y métodos

### `test_config()`
Prueba que la aplicación Flask creada por `create_app()` adopte correctamente el modo de pruebas cuando se le pasa un diccionario de configuración y que, por defecto, no lo haga.

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| _N/A_ | — | — | La función no recibe argumentos. |

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| `None` | `NoneType` | No retorna explícitamente; la prueba pasa si no se generan excepciones. |

| Excepciones (`Raises`) | Condición |
|------------------------|-----------|
| `AssertionError` | Si `create_app().testing` es `True` o `create_app({"TESTING": True}).testing` es `False`. |

---

### `test_hello(client)`
Verifica que la ruta `/hello` devuelva exactamente el cuerpo `b"Hello, World!"`.

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| `client` | `flask.testing.FlaskClient` | Sí | Fixture de **pytest-flask** que provee un cliente de prueba para la aplicación Flask. |

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| `None` | `NoneType` | No retorna explícitamente; la prueba pasa si no se generan excepciones. |

| Excepciones (`Raises`) | Condición |
|------------------------|-----------|
| `AssertionError` | Si la respuesta de `client.get("/hello")` no coincide con `b"Hello, World!"`. |

---

## 3. Ejemplo de uso

```bash
# Estructura de archivos recomendada
.
├── flaskr/          # Paquete con la aplicación Flask
│   └── __init__.py  # Debe exponer la función create_app
└── tests/
    └── test_app.py  # (Este módulo)
```

```python
# tests/test_app.py
from flaskr import create_app


def test_config():
    """Prueba la bandera TESTING de la app."""
    assert not create_app().testing
    assert create_app({"TESTING": True}).testing


def test_hello(client):
    """Prueba la ruta /hello."""
    response = client.get("/hello")
    assert response.data == b"Hello, World!"
```

Ejecución de las pruebas:

```bash
$ pytest -q
..                                                                   [100%]
2 passed in 0.12s
```

Este flujo garantiza que:
1. La aplicación se construye en modo normal y en modo de pruebas de forma confiable.
2. El endpoint `/hello` responde el mensaje esperado, validando tanto la ruta como el contenido.