Claro, aquí tienes la documentación técnica exhaustiva del código fuente de Flask, siguiendo el estándar de Docstrings de Google y la estructura solicitada.

***

## 1. Resumen Ejecutivo

Este módulo define la clase `Flask`, el objeto central del framework Flask. Actúa como una aplicación WSGI, gestionando el enrutamiento de peticiones, el ciclo de vida del contexto (aplicación y petición) y la configuración general. Esta clase proporciona la funcionalidad principal para registrar vistas, procesadores de plantillas, manejadores de errores y comandos de interfaz de línea de comandos (CLI).

## 2. Especificación de Funciones y Métodos

### Funciones a Nivel de Módulo

#### `_make_timedelta()`
Convierte un valor, que puede ser un entero representando segundos, en un objeto `timedelta`. Si el valor ya es un `timedelta` o `None`, lo devuelve sin cambios.

| Parámetro | Tipo                      | Requerido | Descripción                               |
| :-------- | :------------------------ | :-------- | :---------------------------------------- |
| `value`   | `timedelta \| int \| None` | Sí        | El valor a convertir en un `timedelta`.   |

**Retorno:**

| Tipo                 | Descripción                                           |
| :------------------- | :---------------------------------------------------- |
| `timedelta \| None`  | El objeto `timedelta` resultante o `None` si la entrada fue `None`. |

---

#### `remove_ctx()`
Decorador diseñado para proporcionar compatibilidad hacia atrás. Envuelve un método de clase que no espera el nuevo parámetro `ctx: AppContext`, eliminándolo de los argumentos antes de llamar a la función original.

| Parámetro | Tipo       | Requerido | Descripción                       |
| :-------- | :--------- | :-------- | :-------------------------------- |
| `f`       | `Callable` | Sí        | La función o método a envolver.   |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Callable` | La función envuelta (`wrapper`).          |

---

#### `add_ctx()`
Decorador que asegura que un método de clase reciba el contexto de la aplicación (`app_ctx`) como primer argumento. Si el contexto no se pasa explícitamente, lo obtiene del objeto global `app_ctx` y lo inserta en los argumentos de la llamada.

| Parámetro | Tipo       | Requerido | Descripción                       |
| :-------- | :--------- | :-------- | :-------------------------------- |
| `f`       | `Callable` | Sí        | La función o método a envolver.   |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Callable` | La función envuelta (`wrapper`).          |

---

### Clase `Flask`

La clase `Flask` es el núcleo de la aplicación. Hereda de `sansio.app.App` y implementa la lógica WSGI completa.

#### `__init_subclass__()`
Un método de clase especial que se ejecuta cuando `Flask` es subclaseada. Detecta si métodos clave han sido sobrescritos con una firma obsoleta (sin el parámetro `ctx`) y emite una `DeprecationWarning` para notificar al desarrollador, aplicando un decorador para mantener la compatibilidad temporalmente.

| Parámetro  | Tipo  | Requerido | Descripción                                   |
| :--------- | :---- | :-------- | :-------------------------------------------- |
| `cls`      | `type`| Sí        | La nueva subclase que se está creando.        |
| `**kwargs` | `Any` | No        | Argumentos de palabra clave adicionales.      |

**Retorno:**
- `None`

---

#### `__init__()`
El constructor de la aplicación Flask. Inicializa la configuración, las rutas a recursos (como `static_folder` y `template_folder`) y registra la ruta para servir archivos estáticos si está configurada.

| Parámetro                  | Tipo                          | Requerido | Descripción                                                                                             |
| :------------------------- | :---------------------------- | :-------- | :------------------------------------------------------------------------------------------------------ |
| `import_name`              | `str`                         | Sí        | El nombre del paquete o módulo de la aplicación.                                                        |
| `static_url_path`          | `str \| None`                 | No        | La ruta URL para los archivos estáticos.                                                                |
| `static_folder`            | `str \| os.PathLike \| None`  | No        | La carpeta que contiene los archivos estáticos. Por defecto, `'static'`.                                |
| `static_host`              | `str \| None`                 | No        | El host a usar para la ruta de archivos estáticos.                                                      |
| `host_matching`            | `bool`                        | No        | Habilita la coincidencia de rutas por host.                                                             |
| `subdomain_matching`       | `bool`                        | No        | Habilita la coincidencia de rutas por subdominio.                                                       |
| `template_folder`          | `str \| os.PathLike \| None`  | No        | La carpeta que contiene las plantillas. Por defecto, `'templates'`.                                     |
| `instance_path`            | `str \| None`                 | No        | Ruta personalizada para la carpeta de instancia.                                                        |
| `instance_relative_config` | `bool`                        | No        | Si `True`, las rutas de configuración relativas son relativas a `instance_path`.                        |
| `root_path`                | `str \| None`                 | No        | Ruta raíz de la aplicación.                                                                             |

**Retorno:**
- `None`

**Raises:**

| Excepción         | Condición                                                               |
| :---------------- | :---------------------------------------------------------------------- |
| `AssertionError`  | Si `host_matching` es `True` pero `static_host` no se ha proporcionado. |

##### Función Anidada: `lambda view_func`
Función anónima que actúa como la vista para servir archivos estáticos. Utiliza una referencia débil (`weakref`) a la instancia de la aplicación para evitar ciclos de referencia.

| Parámetro | Tipo   | Requerido | Descripción                                                              |
| :-------- | :----- | :-------- | :----------------------------------------------------------------------- |
| `**kw`    | `dict` | Sí        | Argumentos de palabra clave de la URL, que incluyen `filename`.          |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Response` | La respuesta HTTP con el archivo estático.|

---

#### `get_send_file_max_age()`
Determina el valor de `max_age` para la caché del navegador al servir un archivo. El valor se obtiene de la configuración `SEND_FILE_MAX_AGE_DEFAULT`.

| Parámetro | Tipo        | Requerido | Descripción                 |
| :-------- | :---------- | :-------- | :-------------------------- |
| `filename`| `str \| None` | Sí        | El nombre del archivo.      |

**Retorno:**

| Tipo        | Descripción                                                              |
| :---------- | :----------------------------------------------------------------------- |
| `int \| None` | El tiempo máximo de caché en segundos, o `None` para usar ETag.          |

---

#### `send_static_file()`
La función de vista utilizada para servir archivos desde la carpeta `static_folder`. Se registra automáticamente una ruta si `static_folder` está definido.

| Parámetro | Tipo  | Requerido | Descripción                 |
| :-------- | :---- | :-------- | :-------------------------- |
| `filename`| `str` | Sí        | El nombre del archivo a servir. |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Response` | La respuesta HTTP con el archivo estático.|

**Raises:**

| Excepción     | Condición                                           |
| :------------ | :-------------------------------------------------- |
| `RuntimeError`| Si se llama al método sin tener un `static_folder` configurado. |

---

#### `open_resource()`
Abre un archivo de recurso para lectura. La ruta del recurso es relativa al `root_path` de la aplicación.

| Parámetro  | Tipo        | Requerido | Descripción                                                              |
| :--------- | :---------- | :-------- | :----------------------------------------------------------------------- |
| `resource` | `str`       | Sí        | Ruta relativa del recurso.                                               |
| `mode`     | `str`       | No        | Modo de apertura. Solo se permite lectura (`'r'`, `'rt'`, `'rb'`).       |
| `encoding` | `str \| None` | No        | Codificación a usar en modo texto.                                       |

**Retorno:**

| Tipo         | Descripción                               |
| :----------- | :---------------------------------------- |
| `IO[AnyStr]` | Un objeto de archivo abierto para lectura.|

**Raises:**

| Excepción   | Condición                               |
| :---------- | :-------------------------------------- |
| `ValueError`| Si el `mode` no es de solo lectura.     |

---

#### `open_instance_resource()`
Abre un archivo de recurso desde la carpeta de instancia (`instance_path`). A diferencia de `open_resource`, permite la escritura.

| Parámetro  | Tipo        | Requerido | Descripción                                                              |
| :--------- | :---------- | :-------- | :----------------------------------------------------------------------- |
| `resource` | `str`       | Sí        | Ruta relativa del recurso en la carpeta de instancia.                    |
| `mode`     | `str`       | No        | Modo de apertura del archivo (lectura, escritura, etc.).                 |
| `encoding` | `str \| None` | No        | Codificación a usar en modo texto.                                       |

**Retorno:**

| Tipo         | Descripción                               |
| :----------- | :---------------------------------------- |
| `IO[AnyStr]` | Un objeto de archivo abierto.             |

---

#### `create_jinja_environment()`
Crea y configura el entorno de plantillas Jinja2 para la aplicación. Añade variables globales y filtros específicos de Flask.

**Retorno:**

| Tipo          | Descripción                               |
| :------------ | :---------------------------------------- |
| `Environment` | La instancia del entorno Jinja2 configurada. |

---

#### `create_url_adapter()`
Crea un adaptador de URL de Werkzeug para la petición dada. Este adaptador se usa para el enrutamiento y la generación de URLs.

| Parámetro | Tipo            | Requerido | Descripción                                                              |
| :-------- | :-------------- | :-------- | :----------------------------------------------------------------------- |
| `request` | `Request \| None` | Sí        | La petición actual. Puede ser `None` si se crea fuera de un contexto de petición. |

**Retorno:**

| Tipo               | Descripción                                                              |
| :----------------- | :----------------------------------------------------------------------- |
| `MapAdapter \| None` | Una instancia de `MapAdapter` o `None` si no se puede crear (ej. falta `SERVER_NAME`). |

---

#### `raise_routing_exception()`
Intercepta excepciones de enrutamiento de Werkzeug. En modo `DEBUG`, puede transformar una redirección en un error para evitar la pérdida de datos de formularios.

| Parámetro | Tipo      | Requerido | Descripción                 |
| :-------- | :-------- | :-------- | :-------------------------- |
| `request` | `Request` | Sí        | La petición actual.         |

**Retorno:**
- `NoReturn` (siempre lanza una excepción).

**Raises:**

| Excepción                 | Condición                                                              |
| :------------------------ | :--------------------------------------------------------------------- |
| `RequestRedirect`         | Si no está en modo debug o la redirección es segura (307, 308).        |
| `FormDataRoutingRedirect` | Si está en modo debug y una redirección podría perder datos de un POST. |

---

#### `update_template_context()`
Actualiza el diccionario de contexto de una plantilla con variables globales de Flask (`request`, `session`, `g`) y las variables inyectadas por los procesadores de contexto.

| Parámetro | Tipo               | Requerido | Descripción                                   |
| :-------- | :----------------- | :-------- | :-------------------------------------------- |
| `ctx`     | `AppContext`       | Sí        | El contexto de la aplicación actual.          |
| `context` | `dict[str, Any]`   | Sí        | El diccionario de contexto a actualizar.      |

**Retorno:**
- `None`

---

#### `make_shell_context()`
Crea un diccionario de contexto para ser usado en un shell interactivo (`flask shell`). Ejecuta todos los procesadores de contexto de shell registrados.

**Retorno:**

| Tipo             | Descripción                                                              |
| :--------------- | :----------------------------------------------------------------------- |
| `dict[str, Any]` | Un diccionario que contiene `app`, `g` y otras variables personalizadas. |

---

#### `run()`
Inicia un servidor de desarrollo local de Werkzeug para ejecutar la aplicación. **No debe usarse en producción.**

| Parámetro     | Tipo          | Requerido | Descripción                                                              |
| :------------ | :------------ | :-------- | :----------------------------------------------------------------------- |
| `host`        | `str \| None` | No        | El hostname en el que escuchar.                                          |
| `port`        | `int \| None` | No        | El puerto del servidor.                                                  |
| `debug`       | `bool \| None`| No        | Activa o desactiva el modo debug.                                        |
| `load_dotenv` | `bool`        | No        | Carga variables de entorno desde archivos `.env` y `.flaskenv`.          |
| `**options`   | `Any`         | No        | Opciones adicionales para pasar a `werkzeug.serving.run_simple`.         |

**Retorno:**
- `None`

---

#### `test_client()`
Crea un cliente de pruebas para la aplicación, útil para tests unitarios y de integración.

| Parámetro     | Tipo   | Requerido | Descripción                                                              |
| :------------ | :----- | :-------- | :----------------------------------------------------------------------- |
| `use_cookies` | `bool` | No        | Si el cliente debe manejar cookies.                                      |
| `**kwargs`    | `Any`  | No        | Argumentos adicionales para el constructor de `test_client_class`.       |

**Retorno:**

| Tipo          | Descripción                               |
| :------------ | :---------------------------------------- |
| `FlaskClient` | Una instancia del cliente de pruebas.     |

---

#### `test_cli_runner()`
Crea un ejecutor de comandos CLI para probar los comandos personalizados de la aplicación.

| Parámetro  | Tipo  | Requerido | Descripción                                                              |
| :--------- | :---- | :-------- | :----------------------------------------------------------------------- |
| `**kwargs` | `Any` | No        | Argumentos adicionales para el constructor de `test_cli_runner_class`.   |

**Retorno:**

| Tipo             | Descripción                               |
| :--------------- | :---------------------------------------- |
| `FlaskCliRunner` | Una instancia del ejecutor de CLI de pruebas. |

---

#### `handle_http_exception()`
Maneja una `HTTPException` de Werkzeug. Busca un manejador de errores registrado para el código de estado o la clase de excepción y lo invoca.

| Parámetro | Tipo            | Requerido | Descripción                                   |
| :-------- | :-------------- | :-------- | :-------------------------------------------- |
| `ctx`     | `AppContext`    | Sí        | El contexto de la aplicación actual.          |
| `e`       | `HTTPException` | Sí        | La excepción HTTP que se ha producido.        |

**Retorno:**

| Tipo                            | Descripción                                                              |
| :------------------------------ | :----------------------------------------------------------------------- |
| `HTTPException \| ResponseReturnValue` | El resultado del manejador de errores o la excepción original si no hay manejador. |

---

#### `handle_user_exception()`
Maneja excepciones generales que ocurren durante el despacho de una petición. Si la excepción es una `HTTPException`, la delega a `handle_http_exception`. De lo contrario, busca un manejador de errores genérico.

| Parámetro | Tipo        | Requerido | Descripción                                   |
| :-------- | :---------- | :-------- | :-------------------------------------------- |
| `ctx`     | `AppContext`| Sí        | El contexto de la aplicación actual.          |
| `e`       | `Exception` | Sí        | La excepción producida en el código de usuario. |

**Retorno:**

| Tipo                            | Descripción                                                              |
| :------------------------------ | :----------------------------------------------------------------------- |
| `HTTPException \| ResponseReturnValue` | El resultado del manejador de errores.                                   |

**Raises:**

| Excepción   | Condición                               |
| :---------- | :-------------------------------------- |
| `Exception` | La excepción original `e` si no se encuentra un manejador de errores. |

---

#### `handle_exception()`
El manejador de último recurso para cualquier excepción no capturada. Siempre resulta en un error `500 InternalServerError`.

| Parámetro | Tipo        | Requerido | Descripción                                   |
| :-------- | :---------- | :-------- | :-------------------------------------------- |
| `ctx`     | `AppContext`| Sí        | El contexto de la aplicación actual.          |
| `e`       | `Exception` | Sí        | La excepción no manejada.                     |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Response` | Una respuesta de error 500.               |

**Raises:**

| Excepción   | Condición                               |
| :---------- | :-------------------------------------- |
| `Exception` | La excepción original `e` si `PROPAGATE_EXCEPTIONS` es `True`. |

---

#### `log_exception()`
Registra una excepción en el logger de la aplicación. Es llamado por `handle_exception` antes de generar la respuesta de error 500.

| Parámetro  | Tipo                                                              | Requerido | Descripción                                   |
| :--------- | :---------------------------------------------------------------- | :-------- | :-------------------------------------------- |
| `ctx`      | `AppContext`                                                      | Sí        | El contexto de la aplicación actual.          |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí        | La tupla de información de la excepción (`sys.exc_info()`). |

**Retorno:**
- `None`

---

#### `dispatch_request()`
Realiza el despacho de la petición. Encuentra la regla de URL coincidente y ejecuta la función de vista asociada, devolviendo su resultado.

| Parámetro | Tipo         | Requerido | Descripción                          |
| :-------- | :----------- | :-------- | :----------------------------------- |
| `ctx`     | `AppContext` | Sí        | El contexto de la aplicación actual. |

**Retorno:**

| Tipo                  | Descripción                                                              |
| :-------------------- | :----------------------------------------------------------------------- |
| `ResponseReturnValue` | El valor devuelto por la función de vista o el manejador de `OPTIONS`.   |

---

#### `full_dispatch_request()`
Orquesta el ciclo de vida completo de una petición: ejecuta pre-procesadores, despacha la petición a la vista, maneja excepciones y finaliza la respuesta.

| Parámetro | Tipo         | Requerido | Descripción                          |
| :-------- | :----------- | :-------- | :----------------------------------- |
| `ctx`     | `AppContext` | Sí        | El contexto de la aplicación actual. |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Response` | La respuesta HTTP final y procesada.      |

---

#### `finalize_request()`
Finaliza la petición convirtiendo el valor de retorno de una vista en un objeto `Response` completo y ejecutando los post-procesadores (`after_request`).

| Parámetro            | Tipo                                  | Requerido | Descripción                                                              |
| :------------------- | :------------------------------------ | :-------- | :----------------------------------------------------------------------- |
| `ctx`                | `AppContext`                          | Sí        | El contexto de la aplicación actual.                                     |
| `rv`                 | `ResponseReturnValue \| HTTPException`| Sí        | El valor de retorno de la vista o una excepción HTTP.                    |
| `from_error_handler` | `bool`                                | No        | Si `True`, activa un modo seguro que ignora errores durante esta fase.   |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Response` | La respuesta HTTP final.                  |

---

#### `make_default_options_response()`
Crea la respuesta por defecto para peticiones con el método `OPTIONS`, incluyendo la cabecera `Allow` con los métodos HTTP permitidos para esa URL.

| Parámetro | Tipo         | Requerido | Descripción                          |
| :-------- | :----------- | :-------- | :----------------------------------- |
| `ctx`     | `AppContext` | Sí        | El contexto de la aplicación actual. |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Response` | Una respuesta vacía con la cabecera `Allow` configurada. |

---

#### `ensure_sync()`
Asegura que una función sea síncrona. Si la función es `async def`, la envuelve para que se ejecute de forma síncrona.

| Parámetro | Tipo       | Requerido | Descripción                       |
| :-------- | :--------- | :-------- | :-------------------------------- |
| `func`    | `Callable` | Sí        | La función a sincronizar.         |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Callable` | La función síncrona o la envoltura síncrona. |

---

#### `async_to_sync()`
Convierte una función de corutina (`async def`) en una función síncrona que se puede llamar directamente. Utiliza `asgiref` internamente.

| Parámetro | Tipo        | Requerido | Descripción                       |
| :-------- | :---------- | :-------- | :-------------------------------- |
| `func`    | `Coroutine` | Sí        | La corutina a envolver.           |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Callable` | Una función síncrona que ejecuta la corutina. |

**Raises:**

| Excepción     | Condición                               |
| :------------ | :-------------------------------------- |
| `RuntimeError`| Si la dependencia `asgiref` no está instalada. |

---

#### `url_for()`
Genera una URL para un endpoint específico, similar a `flask.url_for`.

| Parámetro  | Tipo          | Requerido | Descripción                                                              |
| :--------- | :------------ | :-------- | :----------------------------------------------------------------------- |
| `endpoint` | `str`         | Sí        | El nombre del endpoint para el que generar la URL.                       |
| `_anchor`  | `str \| None` | No        | Fragmento de anclaje para añadir a la URL (ej. `#section`).              |
| `_method`  | `str \| None` | No        | Método HTTP a considerar para la generación de la URL.                   |
| `_scheme`  | `str \| None` | No        | Esquema de URL a usar (ej. `https`).                                      |
| `_external`| `bool \| None`| No        | Si `True`, genera una URL absoluta con host y esquema.                   |
| `**values` | `Any`         | No        | Valores para las partes variables de la URL y parámetros de consulta.    |

**Retorno:**

| Tipo  | Descripción                               |
| :---- | :---------------------------------------- |
| `str` | La URL generada como una cadena.          |

**Raises:**

| Excepción      | Condición                                                              |
| :------------- | :--------------------------------------------------------------------- |
| `RuntimeError` | Si se intenta generar una URL externa fuera de una petición sin `SERVER_NAME`. |
| `ValueError`   | Si se especifica `_scheme` pero `_external` no es `True`.              |
| `BuildError`   | Si la generación de la URL falla (endpoint no encontrado, etc.).       |

---

#### `make_response()`
Convierte el valor de retorno de una vista en una instancia de `response_class`.

| Parámetro | Tipo                  | Requerido | Descripción                                                              |
| :-------- | :-------------------- | :-------- | :----------------------------------------------------------------------- |
| `rv`      | `ResponseReturnValue` | Sí        | El valor devuelto por la vista (`str`, `bytes`, `dict`, `list`, `tuple`, `Response`, etc.). |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Response` | Una instancia de la clase de respuesta de la aplicación. |

**Raises:**

| Excepción   | Condición                                                              |
| :---------- | :--------------------------------------------------------------------- |
| `TypeError` | Si el valor de retorno `rv` es `None` o de un tipo no válido.          |

---

#### `preprocess_request()`
Ejecuta las funciones de pre-procesamiento de la petición (`before_request`) registradas en la aplicación y en el blueprint actual.

| Parámetro | Tipo         | Requerido | Descripción                          |
| :-------- | :----------- | :-------- | :----------------------------------- |
| `ctx`     | `AppContext` | Sí        | El contexto de la aplicación actual. |

**Retorno:**

| Tipo                        | Descripción                                                              |
| :-------------------------- | :----------------------------------------------------------------------- |
| `ResponseReturnValue \| None` | Un valor de respuesta si una función `before_request` lo devuelve, o `None` para continuar. |

---

#### `process_response()`
Ejecuta las funciones de post-procesamiento de la respuesta (`after_request`) y guarda la sesión si es necesario.

| Parámetro  | Tipo         | Requerido | Descripción                          |
| :--------- | :----------- | :-------- | :----------------------------------- |
| `response` | `Response`   | Sí        | El objeto de respuesta a procesar.   |
| `ctx`      | `AppContext` | Sí        | El contexto de la aplicación actual. |

**Retorno:**

| Tipo       | Descripción                               |
| :--------- | :---------------------------------------- |
| `Response` | El objeto de respuesta, posiblemente modificado. |

---

#### `do_teardown_request()`
Ejecuta las funciones de limpieza (`teardown_request`) después de que la petición ha sido despachada, justo antes de que el contexto de la petición sea destruido.

| Parámetro | Tipo                | Requerido | Descripción                                   |
| :-------- | :------------------ | :-------- | :-------------------------------------------- |
| `ctx`     | `AppContext`        | Sí        | El contexto de la aplicación actual.          |
| `exc`     | `BaseException \| None` | No        | La excepción no manejada, si hubo alguna.     |

**Retorno:**
- `None`

**Raises:**

| Excepción     | Condición                               |
| :------------ | :-------------------------------------- |
| `Exception`   | Si una o más funciones de teardown fallan. |

---

#### `do_teardown_appcontext()`
Ejecuta las funciones de limpieza (`teardown_appcontext`) justo antes de que el contexto de la aplicación sea destruido.

| Parámetro | Tipo                | Requerido | Descripción                                   |
| :-------- | :------------------ | :-------- | :-------------------------------------------- |
| `ctx`     | `AppContext`        | Sí        | El contexto de la aplicación actual.          |
| `exc`     | `BaseException \| None` | No        | La excepción no manejada, si hubo alguna.     |

**Retorno:**
- `None`

**Raises:**

| Excepción     | Condición                               |
| :------------ | :-------------------------------------- |
| `Exception`   | Si una o más funciones de teardown fallan. |

---

#### `app_context()`
Crea un contexto de aplicación (`AppContext`). Útil para acceder a `current_app` y `g` fuera del ciclo de una petición, como en scripts de inicialización o pruebas.

**Retorno:**

| Tipo         | Descripción                               |
| :----------- | :---------------------------------------- |
| `AppContext` | Una nueva instancia de `AppContext`.      |

---

#### `request_context()`
Crea un contexto de aplicación y petición a partir de un entorno WSGI. Este método es de bajo nivel y generalmente no se usa directamente.

| Parámetro | Tipo             | Requerido | Descripción                               |
| :-------- | :--------------- | :-------- | :---------------------------------------- |
| `environ` | `WSGIEnvironment`| Sí        | Un diccionario de entorno WSGI.           |

**Retorno:**

| Tipo         | Descripción                               |
| :----------- | :---------------------------------------- |
| `AppContext` | Una nueva instancia de `AppContext` con un contexto de petición. |

---

#### `test_request_context()`
Crea un contexto de petición para pruebas. Es la forma recomendada de simular una petición sin ejecutar un servidor completo.

| Parámetro  | Tipo  | Requerido | Descripción                                                              |
| :--------- | :---- | :-------- | :----------------------------------------------------------------------- |
| `*args`    | `Any` | No        | Argumentos posicionales para `werkzeug.test.EnvironBuilder`.             |
| `**kwargs` | `Any` | No        | Argumentos de palabra clave para `werkzeug.test.EnvironBuilder`.         |

**Retorno:**

| Tipo         | Descripción                               |
| :----------- | :---------------------------------------- |
| `AppContext` | Un contexto listo para ser usado en un bloque `with`. |

---

#### `wsgi_app()`
La implementación real de la aplicación WSGI. Es el punto de entrada que recibe el entorno WSGI del servidor.

| Parámetro        | Tipo               | Requerido | Descripción                               |
| :--------------- | :----------------- | :-------- | :---------------------------------------- |
| `environ`        | `WSGIEnvironment`  | Sí        | El diccionario de entorno WSGI.           |
| `start_response` | `StartResponse`    | Sí        | La función de callback para iniciar la respuesta. |

**Retorno:**

| Tipo                | Descripción                               |
| :------------------ | :---------------------------------------- |
| `Iterable[bytes]`   | Un iterable que produce los bytes del cuerpo de la respuesta. |

---

#### `__call__()`
Hace que la instancia de `Flask` sea un objeto "callable", permitiendo que un servidor WSGI la invoque directamente. Simplemente delega la llamada a `wsgi_app`.

| Parámetro        | Tipo               | Requerido | Descripción                               |
| :--------------- | :----------------- | :-------- | :---------------------------------------- |
| `environ`        | `WSGIEnvironment`  | Sí        | El diccionario de entorno WSGI.           |
| `start_response` | `StartResponse`    | Sí        | La función de callback para iniciar la respuesta. |

**Retorno:**

| Tipo                | Descripción                               |
| :------------------ | :---------------------------------------- |
| `Iterable[bytes]`   | El resultado de `wsgi_app`.               |

## 3. Ejemplo de Uso

El siguiente bloque de código muestra un caso de uso básico y completo de la clase `Flask` para crear una aplicación web simple.

```python
from flask import Flask, jsonify

# 1. Instanciar la aplicación Flask.
# '__name__' ayuda a Flask a localizar recursos como plantillas y archivos estáticos.
app = Flask(__name__)

# 2. Configurar la aplicación (opcional).
# La configuración se puede cargar desde variables de entorno, archivos, etc.
app.config["DEBUG"] = True

# 3. Definir una ruta y su función de vista asociada usando un decorador.
# Esta vista responderá a las peticiones GET en la URL raíz ('/').
@app.route("/")
def index():
    """Vista para la página de inicio."""
    # Flask convierte automáticamente un string en una respuesta HTTP 200.
    return "<h1>¡Hola, Mundo!</h1><p>Bienvenido a mi aplicación Flask.</p>"

# 4. Definir otra ruta que devuelve datos en formato JSON.
# Flask convierte automáticamente diccionarios en respuestas JSON.
@app.route("/api/data")
def get_data():
    """Endpoint de API que devuelve datos de ejemplo."""
    user_data = {
        "id": 1,
        "username": "senior_dev",
        "role": "Technical Writer"
    }
    return jsonify(user_data)

# 5. Definir una ruta con una parte variable.
@app.route("/user/<username>")
def show_user_profile(username):
    """Muestra el perfil de un usuario específico."""
    return f"<h2>Perfil de Usuario: {username}</h2>"

# 6. Usar un manejador de errores personalizado para el error 404.
@app.errorhandler(404)
def page_not_found(error):
    """Manejador para páginas no encontradas (404)."""
    # El valor de retorno puede ser una tupla (body, status_code).
    return "<h3>Error 404: La página que buscas no existe.</h3>", 404

# 7. El bloque de guarda asegura que app.run() solo se ejecute
# cuando el script es el programa principal.
if __name__ == "__main__":
    # Inicia el servidor de desarrollo integrado.
    # No usar en un entorno de producción.
    app.run(host="0.0.0.0", port=5000)

```