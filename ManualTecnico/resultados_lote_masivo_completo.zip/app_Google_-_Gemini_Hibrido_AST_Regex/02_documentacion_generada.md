Claro, aquí tienes la documentación técnica exhaustiva del código fuente proporcionado, siguiendo el estándar de Google Style Docstrings y la estructura solicitada.

***

## 1. Resumen Ejecutivo

Este módulo define la clase principal `Flask`, que actúa como el objeto central de una aplicación web Flask. Implementa una aplicación WSGI completa, gestionando el ciclo de vida de las peticiones (request-response), el enrutamiento de URLs, el manejo de contextos, la renderización de plantillas y la gestión de excepciones. Además, proporciona métodos de utilidad para el desarrollo, las pruebas y la ejecución de la aplicación a través de un servidor de desarrollo integrado.

## 2. Especificación de Funciones y Métodos

A continuación se detalla cada función y método presente en el código fuente.

### Funciones Auxiliares a Nivel de Módulo

#### `_make_timedelta()`

Convierte un valor, que puede ser un entero (representando segundos) o `None`, en un objeto `timedelta`. Si el valor ya es un `timedelta`, lo devuelve sin cambios.

| Parámetro | Tipo                  | Requerido | Descripción                               |
| :-------- | :-------------------- | :-------- | :---------------------------------------- |
| `value`   | `timedelta \| int \| None` | Sí        | El valor a convertir en un `timedelta`. |

| Retorno             | Descripción                                                              |
| :------------------ | :----------------------------------------------------------------------- |
| `timedelta \| None` | Un objeto `timedelta` o `None` si la entrada fue `None`. |

---

#### `remove_ctx()`

Decorador diseñado para la retrocompatibilidad. Envuelve un método de la clase `Flask` para eliminar el primer argumento si es una instancia de `AppContext`, permitiendo que las subclases con firmas de método antiguas s-igan funcionando.

| Parámetro | Tipo | Requerido | Descripción                               |
| :-------- | :--- | :-------- | :---------------------------------------- |
| `f`       | `F`  | Sí        | La función o método a envolver.           |

| Retorno | Descripción                                                              |
| :------ | :----------------------------------------------------------------------- |
| `F`     | Una nueva función `wrapper` que invoca a la original sin el argumento `ctx`. |

---

#### `add_ctx()`

Decorador diseñado para la retrocompatibilidad. Envuelve un método base de `Flask` para añadir una instancia de `AppContext` como primer argumento si no está presente, asegurando que las llamadas `super()` desde métodos sobreescritos antiguos funcionen correctamente.

| Parámetro | Tipo | Requerido | Descripción                               |
| :-------- | :--- | :-------- | :---------------------------------------- |
| `f`       | `F`  | Sí        | La función o método a envolver.           |

| Retorno | Descripción                                                              |
| :------ | :----------------------------------------------------------------------- |
| `F`     | Una nueva función `wrapper` que invoca a la original con el argumento `ctx`. |

---

### Clase `Flask`

#### `__init_subclass__()`

Método de clase que se ejecuta cuando se crea una subclase de `Flask`. Verifica si ciertos métodos del ciclo de vida de la petición han sido sobreescritos con la firma antigua (sin el parámetro `ctx: AppContext`) y, en tal caso, emite una `DeprecationWarning` y aplica los decoradores `remove_ctx` y `add_ctx` para mantener la compatibilidad.

| Parámetro | Tipo    | Requerido | Descripción                                 |
| :-------- | :------ | :-------- | :------------------------------------------ |
| `**kwargs` | `t.Any` | No        | Argumentos de palabra clave adicionales.    |

| Retorno | Descripción |
| :------ | :---------- |
| `None`  | No retorna ningún valor. |

---

#### `__init__()`

Constructor de la aplicación `Flask`. Inicializa la aplicación, configura las rutas para archivos estáticos, establece las carpetas de plantillas y de instancia, y prepara el grupo de comandos CLI.

| Parámetro                  | Tipo                          | Requerido | Descripción                                                                                              |
| :------------------------- | :---------------------------- | :-------- | :------------------------------------------------------------------------------------------------------- |
| `import_name`              | `str`                         | Sí        | El nombre del paquete o módulo de la aplicación.                                                         |
| `static_url_path`          | `str \| None`                 | No        | La ruta URL para los archivos estáticos. Por defecto, se basa en `static_folder`.                        |
| `static_folder`            | `str \| os.PathLike[str] \| None` | No        | La carpeta que contiene los archivos estáticos. Por defecto, `'static'`.                                 |
| `static_host`              | `str \| None`                 | No        | El host a utilizar para la ruta de archivos estáticos.                                                   |
| `host_matching`            | `bool`                        | No        | Habilita la coincidencia de rutas basada en el host.                                                     |
| `subdomain_matching`       | `bool`                        | No        | Habilita la coincidencia de rutas basada en el subdominio.                                               |
| `template_folder`          | `str \| os.PathLike[str] \| None` | No        | La carpeta que contiene las plantillas. Por defecto, `'templates'`.                                      |
| `instance_path`            | `str \| None`                 | No        | Ruta a la carpeta de instancia de la aplicación.                                                         |
| `instance_relative_config` | `bool`                        | No        | Si `True`, las rutas de configuración relativas son relativas a la carpeta de instancia.                 |
| `root_path`                | `str \| None`                 | No        | Ruta a la raíz de los archivos de la aplicación.                                                         |

**Funciones Anidadas:**
- **`lambda **kw: self_ref().send_static_file(**kw)`**: Función anónima utilizada como `view_func` para la regla de URL de archivos estáticos. Utiliza una referencia débil (`weakref`) a la instancia de la aplicación para evitar ciclos de referencia.

---

#### `get_send_file_max_age()`

Determina el valor de caché `max_age` para un archivo estático. Por defecto, obtiene el valor de la configuración `SEND_FILE_MAX_AGE_DEFAULT`.

| Parámetro  | Tipo        | Requerido | Descripción                               |
| :--------- | :---------- | :-------- | :---------------------------------------- |
| `filename` | `str \| None` | Sí        | La ruta del archivo (actualmente no se usa en la lógica interna, pero es parte de la firma). |

| Retorno       | Descripción                                                              |
| :------------ | :----------------------------------------------------------------------- |
| `int \| None` | El valor de `max_age` en segundos, o `None` para usar peticiones condicionales. |

---

#### `send_static_file()`

La función de vista utilizada para servir archivos desde la carpeta estática (`static_folder`).

| Parámetro  | Tipo  | Requerido | Descripción                               |
| :--------- | :---- | :-------- | :---------------------------------------- |
| `filename` | `str` | Sí        | El nombre del archivo a servir.           |

| Retorno    | Descripción                                      |
| :--------- | :----------------------------------------------- |
| `Response` | Un objeto `Response` que contiene el archivo.    |

| Lanza (Raises)    | Descripción                                                              |
| :---------------- | :----------------------------------------------------------------------- |
| `RuntimeError`    | Si `has_static_folder` es `False`.                                       |

---

#### `open_resource()`

Abre un archivo de recurso para lectura desde la ruta raíz de la aplicación (`root_path`).

| Parámetro  | Tipo          | Requerido | Descripción                                                              |
| :--------- | :------------ | :-------- | :----------------------------------------------------------------------- |
| `resource` | `str`         | Sí        | La ruta relativa del recurso.                                            |
| `mode`     | `str`         | No        | El modo de apertura del archivo (`'rb'`, `'r'`, `'rt'`). Por defecto, `'rb'`. |
| `encoding` | `str \| None` | No        | La codificación a usar en modo texto. Por defecto, `None`.               |

| Retorno       | Descripción                                      |
| :------------ | :----------------------------------------------- |
| `t.IO[t.AnyStr]` | Un objeto de archivo abierto para lectura.       |

| Lanza (Raises) | Descripción                                                              |
| :------------- | :----------------------------------------------------------------------- |
| `ValueError`   | Si el modo de apertura no es uno de los modos de lectura permitidos.     |

---

#### `open_instance_resource()`

Abre un archivo de recurso desde la carpeta de instancia de la aplicación (`instance_path`). Permite modos de escritura.

| Parámetro  | Tipo          | Requerido | Descripción                                                              |
| :--------- | :------------ | :-------- | :----------------------------------------------------------------------- |
| `resource` | `str`         | Sí        | La ruta relativa del recurso en la carpeta de instancia.                 |
| `mode`     | `str`         | No        | El modo de apertura del archivo. Por defecto, `'rb'`.                    |
| `encoding` | `str \| None` | No        | La codificación a usar en modo texto. Por defecto, `'utf-8'`.            |

| Retorno       | Descripción                                      |
| :------------ | :----------------------------------------------- |
| `t.IO[t.AnyStr]` | Un objeto de archivo abierto.                    |

---

#### `create_jinja_environment()`

Crea y configura el entorno de plantillas Jinja2 para la aplicación.

| Retorno       | Descripción                                                              |
| :------------ | :----------------------------------------------------------------------- |
| `Environment` | Una instancia del entorno Jinja2 configurada con las opciones de la aplicación. |

---

#### `create_url_adapter()`

Crea un adaptador de URL (`MapAdapter`) de Werkzeug para la petición dada, que se utiliza para el enrutamiento y la generación de URLs.

| Parámetro | Tipo            | Requerido | Descripción                                                              |
| :-------- | :-------------- | :-------- | :----------------------------------------------------------------------- |
| `request` | `Request \| None` | Sí        | La petición actual para la cual crear el adaptador. Puede ser `None` si se está fuera de un contexto de petición. |

| Retorno             | Descripción                                                              |
| :------------------ | :----------------------------------------------------------------------- |
| `MapAdapter \| None` | Una instancia de `MapAdapter` o `None` si no se puede crear (por ejemplo, fuera de una petición sin `SERVER_NAME` configurado). |

---

#### `raise_routing_exception()`

Intercepta excepciones de enrutamiento de Werkzeug. En modo de depuración, convierte una redirección `RequestRedirect` en un error `FormDataRoutingRedirect` para evitar la pérdida de datos de formulario en peticiones no-GET.

| Parámetro | Tipo    | Requerido | Descripción                               |
| :-------- | :------ | :-------- | :---------------------------------------- |
| `request` | `Request` | Sí        | La petición actual.                       |

| Retorno      | Descripción                                                              |
| :----------- | :----------------------------------------------------------------------- |
| `t.NoReturn` | Esta función siempre lanza una excepción.                                |

| Lanza (Raises)            | Descripción                                                              |
| :------------------------ | :----------------------------------------------------------------------- |
| `RequestRedirect`         | Si no está en modo debug o si la redirección es segura.                  |
| `FormDataRoutingRedirect` | En modo debug para peticiones con cuerpo que serían redirigidas.         |

---

#### `update_template_context()`

Actualiza el diccionario de contexto de una plantilla con variables globales de Flask (como `request`, `session`, `g`) y las variables inyectadas por los procesadores de contexto de plantillas.

| Parámetro | Tipo                 | Requerido | Descripción                                                              |
| :-------- | :------------------- | :-------- | :----------------------------------------------------------------------- |
| `ctx`     | `AppContext`         | Sí        | El contexto de la aplicación actual.                                     |
| `context` | `dict[str, t.Any]`   | Sí        | El diccionario de contexto a actualizar.                                 |

| Retorno | Descripción |
| :------ | :---------- |
| `None`  | No retorna ningún valor (modifica `context` in-place). |

---

#### `make_shell_context()`

Crea un diccionario de contexto para ser usado en un shell interactivo (ej. `flask shell`).

| Retorno            | Descripción                                                              |
| :----------------- | :----------------------------------------------------------------------- |
| `dict[str, t.Any]` | Un diccionario que contiene `app`, `g` y variables de los procesadores de contexto de shell. |

---

#### `run()`

Inicia un servidor de desarrollo local de Werkzeug para ejecutar la aplicación. **No debe usarse en producción.**

| Parámetro     | Tipo          | Requerido | Descripción                                                              |
| :------------ | :------------ | :-------- | :----------------------------------------------------------------------- |
| `host`        | `str \| None` | No        | El hostname en el que escuchar. Por defecto, `'127.0.0.1'`.              |
| `port`        | `int \| None` | No        | El puerto del servidor. Por defecto, `5000`.                             |
| `debug`       | `bool \| None`| No        | Activa o desactiva el modo de depuración.                                |
| `load_dotenv` | `bool`        | No        | Si `True`, carga variables de entorno desde archivos `.env` y `.flaskenv`. |
| `**options`   | `t.Any`       | No        | Opciones adicionales para pasar a `werkzeug.serving.run_simple`.         |

| Retorno | Descripción |
| :------ | :---------- |
| `None`  | No retorna ningún valor. |

---

#### `test_client()`

Crea un cliente de pruebas (`FlaskClient`) para la aplicación, útil para tests unitarios.

| Parámetro     | Tipo    | Requerido | Descripción                                                              |
| :------------ | :------ | :-------- | :----------------------------------------------------------------------- |
| `use_cookies` | `bool`  | No        | Si `True`, el cliente de pruebas manejará cookies. Por defecto, `True`.  |
| `**kwargs`    | `t.Any` | No        | Argumentos adicionales para pasar al constructor de `test_client_class`. |

| Retorno       | Descripción                                      |
| :------------ | :----------------------------------------------- |
| `FlaskClient` | Una instancia del cliente de pruebas.            |

---

#### `test_cli_runner()`

Crea un ejecutor de pruebas (`FlaskCliRunner`) para los comandos CLI de la aplicación.

| Parámetro  | Tipo    | Requerido | Descripción                                                              |
| :--------- | :------ | :-------- | :----------------------------------------------------------------------- |
| `**kwargs` | `t.Any` | No        | Argumentos adicionales para pasar al constructor de `test_cli_runner_class`. |

| Retorno          | Descripción                                      |
| :--------------- | :----------------------------------------------- |
| `FlaskCliRunner` | Una instancia del ejecutor de pruebas CLI.       |

---

#### `handle_http_exception()`

Maneja una excepción de tipo `HTTPException`. Busca y ejecuta un manejador de errores registrado para el código de error o la clase de la excepción.

| Parámetro | Tipo          | Requerido | Descripción                               |
| :-------- | :------------ | :-------- | :---------------------------------------- |
| `ctx`     | `AppContext`  | Sí        | El contexto de la aplicación actual.      |
| `e`       | `HTTPException` | Sí        | La excepción HTTP a manejar.              |

| Retorno                         | Descripción                                                              |
| :------------------------------ | :----------------------------------------------------------------------- |
| `HTTPException \| ft.ResponseReturnValue` | El valor de retorno del manejador de errores, o la excepción original si no se encuentra un manejador. |

---

#### `handle_user_exception()`

Maneja una excepción genérica ocurrida en el código del usuario. Si es una `HTTPException`, la delega a `handle_http_exception`. De lo contrario, busca un manejador de errores registrado.

| Parámetro | Tipo        | Requerido | Descripción                               |
| :-------- | :---------- | :-------- | :---------------------------------------- |
| `ctx`     | `AppContext`| Sí        | El contexto de la aplicación actual.      |
| `e`       | `Exception` | Sí        | La excepción a manejar.                   |

| Retorno                         | Descripción                                                              |
| :------------------------------ | :----------------------------------------------------------------------- |
| `HTTPException \| ft.ResponseReturnValue` | El valor de retorno del manejador de errores. Si no hay manejador, la excepción es relanzada. |

| Lanza (Raises) | Descripción                                                              |
| :------------- | :----------------------------------------------------------------------- |
| `Exception`    | La excepción original `e` si no se encuentra un manejador de errores.    |

---

#### `handle_exception()`

Manejador de último recurso para excepciones que no fueron capturadas por otros manejadores. Siempre resulta en un error `InternalServerError` (500).

| Parámetro | Tipo        | Requerido | Descripción                               |
| :-------- | :---------- | :-------- | :---------------------------------------- |
| `ctx`     | `AppContext`| Sí        | El contexto de la aplicación actual.      |
| `e`       | `Exception` | Sí        | La excepción no manejada.                 |

| Retorno    | Descripción                                      |
| :--------- | :----------------------------------------------- |
| `Response` | Una respuesta de error 500.                      |

| Lanza (Raises) | Descripción                                                              |
| :------------- | :----------------------------------------------------------------------- |
| `Exception`    | La excepción original `e` si `PROPAGATE_EXCEPTIONS` es `True`.           |

---

#### `log_exception()`

Registra una excepción en el logger de la aplicación. Es llamado por `handle_exception`.

| Parámetro  | Tipo                                                              | Requerido | Descripción                               |
| :--------- | :---------------------------------------------------------------- | :-------- | :---------------------------------------- |
| `ctx`      | `AppContext`                                                      | Sí        | El contexto de la aplicación actual.      |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí        | La tupla de información de la excepción (`sys.exc_info()`). |

| Retorno | Descripción |
| :------ | :---------- |
| `None`  | No retorna ningún valor. |

---

#### `dispatch_request()`

Realiza el despacho principal de la petición. Coincide la URL con una regla, y ejecuta la función de vista correspondiente.

| Parámetro | Tipo         | Requerido | Descripción                          |
| :-------- | :----------- | :-------- | :----------------------------------- |
| `ctx`     | `AppContext` | Sí        | El contexto de la aplicación actual. |

| Retorno                 | Descripción                                                              |
| :---------------------- | :----------------------------------------------------------------------- |
| `ft.ResponseReturnValue` | El valor de retorno de la función de vista o del manejador de errores.   |

---

#### `full_dispatch_request()`

Orquesta el ciclo completo de despacho de una petición, incluyendo pre-procesamiento, despacho real, manejo de excepciones y post-procesamiento.

| Parámetro | Tipo         | Requerido | Descripción                          |
| :-------- | :----------- | :-------- | :----------------------------------- |
| `ctx`     | `AppContext` | Sí        | El contexto de la aplicación actual. |

| Retorno    | Descripción                                      |
| :--------- | :----------------------------------------------- |
| `Response` | El objeto de respuesta finalizado.               |

---

#### `finalize_request()`

Finaliza la petición convirtiendo el valor de retorno de una vista en un objeto `Response` y aplicando las funciones de post-procesamiento.

| Parámetro            | Tipo                                | Requerido | Descripción                                                              |
| :------------------- | :---------------------------------- | :-------- | :----------------------------------------------------------------------- |
| `ctx`                | `AppContext`                        | Sí        | El contexto de la aplicación actual.                                     |
| `rv`                 | `ft.ResponseReturnValue \| HTTPException` | Sí        | El valor de retorno de la vista o una excepción HTTP.                    |
| `from_error_handler` | `bool`                              | No        | Si `True`, indica que se está ejecutando desde un manejador de errores.  |

| Retorno    | Descripción                                      |
| :--------- | :----------------------------------------------- |
| `Response` | El objeto de respuesta finalizado.               |

---

#### `make_default_options_response()`

Crea la respuesta por defecto para peticiones con el método `OPTIONS`.

| Parámetro | Tipo         | Requerido | Descripción                          |
| :-------- | :----------- | :-------- | :----------------------------------- |
| `ctx`     | `AppContext` | Sí        | El contexto de la aplicación actual. |

| Retorno    | Descripción                                      |
| :--------- | :----------------------------------------------- |
| `Response` | Una respuesta vacía con la cabecera `Allow` poblada con los métodos permitidos. |

---

#### `ensure_sync()`

Asegura que una función sea síncrona. Si la función es una corutina (`async def`), la envuelve para que se ejecute de forma síncrona.

| Parámetro | Tipo                  | Requerido | Descripción                               |
| :-------- | :-------------------- | :-------- | :---------------------------------------- |
| `func`    | `t.Callable[..., t.Any]` | Sí        | La función a sincronizar.                 |

| Retorno                  | Descripción                                      |
| :----------------------- | :----------------------------------------------- |
| `t.Callable[..., t.Any]` | La función original si es síncrona, o una versión envuelta si es asíncrona. |

---

#### `async_to_sync()`

Convierte una función de corutina en una función síncrona que se puede llamar. Utiliza `asgiref.sync.async_to_sync` internamente.

| Parámetro | Tipo                                             | Requerido | Descripción                               |
| :-------- | :----------------------------------------------- | :-------- | :---------------------------------------- |
| `func`    | `t.Callable[..., t.Coroutine[t.Any, t.Any, t.Any]]` | Sí        | La función de corutina a envolver.        |

| Retorno                  | Descripción                                      |
| :----------------------- | :----------------------------------------------- |
| `t.Callable[..., t.Any]` | Una función síncrona que ejecuta la corutina.    |

| Lanza (Raises) | Descripción                                                              |
| :------------- | :----------------------------------------------------------------------- |
| `RuntimeError` | Si no está instalado el extra `[async]` (falta `asgiref`).               |

---

#### `url_for()`

Genera una URL para un endpoint dado con los valores proporcionados.

| Parámetro | Tipo          | Requerido | Descripción                                                              |
| :-------- | :------------ | :-------- | :----------------------------------------------------------------------- |
| `endpoint`| `str`         | Sí        | El nombre del endpoint para el cual generar la URL.                      |
| `_anchor` | `str \| None` | No        | Un ancla para añadir a la URL (ej. `#section`).                          |
| `_method` | `str \| None` | No        | El método HTTP a considerar para la generación de la URL.                |
| `_scheme` | `str \| None` | No        | El esquema a usar para URLs externas (ej. `https`).                      |
| `_external`| `bool \| None`| No        | Si `True`, genera una URL absoluta con host y esquema.                   |
| `**values`| `t.Any`       | No        | Valores para las partes variables de la regla de URL y parámetros de consulta. |

| Retorno | Descripción                                      |
| :------ | :----------------------------------------------- |
| `str`   | La URL generada como una cadena de texto.        |

| Lanza (Raises) | Descripción                                                              |
| :------------- | :----------------------------------------------------------------------- |
| `RuntimeError` | Si se intenta generar una URL fuera de un contexto de petición sin `SERVER_NAME` configurado. |
| `BuildError`   | Si la generación de la URL falla (manejado por `handle_url_build_error`). |
| `ValueError`   | Si se especifica `_scheme` pero `_external` no es `True`.                |

---

#### `make_response()`

Convierte el valor de retorno de una función de vista en una instancia de `response_class`.

| Parámetro | Tipo                   | Requerido | Descripción                                                              |
| :-------- | :--------------------- | :-------- | :----------------------------------------------------------------------- |
| `rv`      | `ft.ResponseReturnValue` | Sí        | El valor de retorno de la vista (puede ser `str`, `bytes`, `dict`, `list`, `tuple`, `Response`, etc.). |

| Retorno    | Descripción                                      |
| :--------- | :----------------------------------------------- |
| `Response` | Una instancia de `response_class`.               |

| Lanza (Raises) | Descripción                                                              |
| :------------- | :----------------------------------------------------------------------- |
| `TypeError`    | Si el valor de retorno `rv` es `None` o de un tipo no válido.            |

---

#### `preprocess_request()`

Ejecuta las funciones de pre-procesamiento de la petición (`before_request` y `url_value_preprocessors`).

| Parámetro | Tipo         | Requerido | Descripción                          |
| :-------- | :----------- | :-------- | :----------------------------------- |
| `ctx`     | `AppContext` | Sí        | El contexto de la aplicación actual. |

| Retorno                      | Descripción                                                              |
| :--------------------------- | :----------------------------------------------------------------------- |
| `ft.ResponseReturnValue \| None` | Un valor de respuesta si una función `before_request` lo devuelve; de lo contrario, `None`. |

---

#### `process_response()`

Ejecuta las funciones de post-procesamiento de la respuesta (`after_request`) y guarda la sesión.

| Parámetro  | Tipo         | Requerido | Descripción                          |
| :--------- | :----------- | :-------- | :----------------------------------- |
| `ctx`      | `AppContext` | Sí        | El contexto de la aplicación actual. |
| `response` | `Response`   | Sí        | El objeto de respuesta a procesar.   |

| Retorno    | Descripción                                      |
| :--------- | :----------------------------------------------- |
| `Response` | El objeto de respuesta, posiblemente modificado por las funciones `after_request`. |

---

#### `do_teardown_request()`

Ejecuta las funciones de desmontaje del contexto de la petición (`teardown_request`). Se llama justo antes de que el contexto de la petición sea destruido.

| Parámetro | Tipo                  | Requerido | Descripción                                                              |
| :-------- | :-------------------- | :-------- | :----------------------------------------------------------------------- |
| `ctx`     | `AppContext`          | Sí        | El contexto de la aplicación actual.                                     |
| `exc`     | `BaseException \| None` | No        | Una excepción no manejada que ocurrió durante el despacho, si la hubo.   |

| Retorno | Descripción |
| :------ | :---------- |
| `None`  | No retorna ningún valor. |

---

#### `do_teardown_appcontext()`

Ejecuta las funciones de desmontaje del contexto de la aplicación (`teardown_appcontext`). Se llama justo antes de que el contexto de la aplicación sea destruido.

| Parámetro | Tipo                  | Requerido | Descripción                                                              |
| :-------- | :-------------------- | :-------- | :----------------------------------------------------------------------- |
| `ctx`     | `AppContext`          | Sí        | El contexto de la aplicación actual.                                     |
| `exc`     | `BaseException \| None` | No        | Una excepción no manejada que ocurrió durante la vida del contexto, si la hubo. |

| Retorno | Descripción |
| :------ | :---------- |
| `None`  | No retorna ningún valor. |

---

#### `app_context()`

Crea un contexto de aplicación (`AppContext`). Útil para acceder a `current_app` y `g` fuera del ciclo de una petición.

| Retorno      | Descripción                                      |
| :----------- | :----------------------------------------------- |
| `AppContext` | Una nueva instancia de `AppContext`.             |

---

#### `request_context()`

Crea un contexto de aplicación y de petición a partir de un entorno WSGI.

| Parámetro | Tipo             | Requerido | Descripción                               |
| :-------- | :--------------- | :-------- | :---------------------------------------- |
| `environ` | `WSGIEnvironment`| Sí        | Un diccionario de entorno WSGI.           |

| Retorno      | Descripción                                      |
| :----------- | :----------------------------------------------- |
| `AppContext` | Una nueva instancia de `AppContext` con un contexto de petición. |

---

#### `test_request_context()`

Crea un contexto de petición para propósitos de prueba, sin necesidad de realizar una petición HTTP real.

| Parámetro  | Tipo    | Requerido | Descripción                                                              |
| :--------- | :------ | :-------- | :----------------------------------------------------------------------- |
| `*args`    | `t.Any` | No        | Argumentos posicionales para `werkzeug.test.EnvironBuilder`.             |
| `**kwargs` | `t.Any` | No        | Argumentos de palabra clave para `werkzeug.test.EnvironBuilder`.         |

| Retorno      | Descripción                                      |
| :----------- | :----------------------------------------------- |
| `AppContext` | Un contexto de aplicación y petición listo para ser usado en un bloque `with`. |

---

#### `wsgi_app()`

La aplicación WSGI real. Maneja el ciclo completo de una petición WSGI, desde la creación del contexto hasta el envío de la respuesta.

| Parámetro        | Tipo                | Requerido | Descripción                                                              |
| :--------------- | :------------------ | :-------- | :----------------------------------------------------------------------- |
| `environ`        | `WSGIEnvironment`   | Sí        | El diccionario de entorno WSGI proporcionado por el servidor.            |
| `start_response` | `StartResponse`     | Sí        | Una función callback para iniciar la respuesta HTTP.                     |

| Retorno             | Descripción                                      |
| :------------------ | :----------------------------------------------- |
| `cabc.Iterable[bytes]` | Un iterable que produce los bytes del cuerpo de la respuesta. |

---

#### `__call__()`

Hace que la instancia de `Flask` sea un objeto llamable (callable) compatible con WSGI. Simplemente delega la llamada a `wsgi_app`.

| Parámetro        | Tipo                | Requerido | Descripción                                                              |
| :--------------- | :------------------ | :-------- | :----------------------------------------------------------------------- |
| `environ`        | `WSGIEnvironment`   | Sí        | El diccionario de entorno WSGI.                                          |
| `start_response` | `StartResponse`     | Sí        | La función callback para iniciar la respuesta.                           |

| Retorno             | Descripción                                      |
| :------------------ | :----------------------------------------------- |
| `cabc.Iterable[bytes]` | El resultado de la llamada a `wsgi_app`.         |

## 3. Ejemplo de Uso

El siguiente bloque de código muestra un caso de uso real y completo, creando una aplicación Flask mínima, definiendo una ruta, utilizando un procesador de contexto y ejecutando el servidor de desarrollo.

```python
from flask import Flask, g, url_for, render_template_string

# 1. Instanciación de la aplicación Flask
# Se usa __name__ para que Flask sepa dónde buscar recursos como plantillas y archivos estáticos.
app = Flask(__name__)

# 2. Configuración de la aplicación
app.config['SECRET_KEY'] = 'un-secreto-muy-seguro'

# 3. Uso de un procesador de contexto para inyectar variables en las plantillas
# Este método demuestra el uso de `update_template_context` de forma implícita.
@app.context_processor
def inject_user_info():
    """Inyecta información del usuario en el contexto de la plantilla."""
    # En una aplicación real, esto podría venir de una base de datos o sesión.
    return {'username': 'Visitante'}

# 4. Definición de una ruta y su función de vista
@app.route('/')
def index():
    """Página de inicio que saluda al usuario."""
    # `g` es un objeto global de la aplicación, disponible gracias al contexto.
    g.request_id = "req-12345"
    
    # Se usa una plantilla simple para demostrar el contexto inyectado.
    template_string = """
    <h1>Hola, {{ username }}!</h1>
    <p>Tu ID de petición es: {{ g.request_id }}</p>
    <p>Ve a la <a href="{{ url_for('about_page') }}">página de 'Acerca de'</a>.</p>
    """
    # `render_template_string` usará el contexto actualizado por `inject_user_info`.
    return render_template_string(template_string, g=g)

@app.route('/about')
def about_page():
    """Página 'Acerca de'."""
    return "Esta es la página de 'Acerca de'."

# 5. Uso de un manejador de teardown para limpiar recursos
# Este método demuestra el uso de `do_teardown_request`.
@app.teardown_request
def teardown_request_handler(exception=None):
    """Se ejecuta después de cada petición, incluso si hay un error."""
    if hasattr(g, 'request_id'):
        print(f"Finalizando petición con ID: {g.request_id}")
    if exception:
        print(f"La petición finalizó con una excepción: {exception}")

# 6. Ejecución del servidor de desarrollo
# El bloque `if __name__ == '__main__'` asegura que `app.run()` solo se llame
# cuando el script se ejecuta directamente.
if __name__ == '__main__':
    # `app.run()` inicia el servidor de desarrollo integrado.
    # `debug=True` activa el recargador automático y el depurador.
    app.run(host='0.0.0.0', port=5001, debug=True)

```