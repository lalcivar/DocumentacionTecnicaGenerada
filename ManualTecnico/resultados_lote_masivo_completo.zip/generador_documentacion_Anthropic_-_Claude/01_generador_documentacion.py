from openai import OpenAI

# 1. Configuración del cliente
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="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", 
)

def generar_documentacion():
    # Ruta del archivo Java que ya sabemos que existe
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    
    # Leemos el código del archivo
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    
    print(f"--- Procesando código de: {ruta_java} ---")

    # 2. Solicitud a la IA para documentar
    # Usaremos Gemini 2.0 Flash por su gran capacidad de análisis de código
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {
          "role": "system", 
          "content": "Eres un experto en ingeniería de software. Tu tarea es generar un manual técnico detallado "
          "en español para el código Java proporcionado. Explica el propósito de la clase, sus métodos y cómo se "
          "integra en el sistema."
        },
        {"role": "user", "content": codigo}
      ]
    )

    # 3. Guardar el manual en un archivo nuevo
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    
    print("\n¡Documentación generada con éxito!")
    print("Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.")

generar_documentacion()