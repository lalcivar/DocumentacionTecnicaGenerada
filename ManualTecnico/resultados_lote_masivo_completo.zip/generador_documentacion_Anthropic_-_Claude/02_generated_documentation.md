# Documentación Técnica — `generar_documentacion.py`

> Módulo de generación automática de manuales técnicos mediante LLM (OpenRouter / OpenAI SDK).

---

## 1. Resumen ejecutivo

Este script es una utilidad de línea de comandos (ejecución directa) que automatiza la generación de documentación técnica para código fuente Java. Lee el contenido de un archivo `.java` desde una ruta fija, lo envía a un modelo de lenguaje (`google/gemini-2.0-flash-001`) a través del endpoint compatible con OpenAI de **OpenRouter**, y persiste la respuesta en un archivo Markdown local (`MANUAL_TECNICO_JUNIT.md`).

El módulo es de propósito único (*single-purpose script*): no expone API reutilizable, no acepta argumentos de entrada y se autoejecuta al ser importado o invocado.

---

## 2. Inventario de elementos detectados

Análisis estático completo del código fuente provisto:

| Tipo de elemento | Nombre | Ámbito | Documentado en |
|---|---|---|---|
| Importación | `from openai import OpenAI` | Módulo | §2.1 |
| Variable global | `client` | Módulo | §2.2 |
| Función | `generar_documentacion()` | Módulo | §3.1 |
| Variable local | `ruta_java`, `codigo`, `response`, `manual_contenido` | Función | §3.1.4 |
| Sentencia de ejecución | `generar_documentacion()` | Módulo (nivel raíz) | §3.2 |

**Declaración de exhaustividad:** el código fuente **no contiene** clases, métodos de instancia/clase/estáticos, decoradores, funciones anidadas, callbacks, generadores, *context managers* personalizados ni *workers* de hilos. La única unidad funcional definida por el autor es `generar_documentacion()`. Las llamadas `OpenAI()`, `client.chat.completions.create()`, `open()`, `f.read()`, `m.write()` y `print()` pertenecen a la biblioteca estándar o al SDK `openai` y, conforme a las restricciones, se documentan únicamente como **dependencias externas invocadas**, no como funciones propias del módulo.

### 2.1 Dependencias

| Dependencia | Origen | Uso dentro del módulo |
|---|---|---|
| `OpenAI` | Paquete `openai` (≥ 1.0.0) | Instanciación del cliente HTTP compatible OpenAI |
| `open` | *builtins* | Lectura del `.java` y escritura del `.md` |
| `print` | *builtins* | Trazas de progreso en `stdout` |

### 2.2 Variable global `client`

Cliente HTTP inicializado a nivel de módulo. Se crea en el momento del `import`, **antes** de cualquier llamada a `generar_documentacion()`.

| Atributo | Valor | Tipo | Descripción |
|---|---|---|---|
| `base_url` | `"https://openrouter.ai/api/v1"` | `str` | Redirige el SDK oficial de OpenAI hacia la pasarela de OpenRouter. |
| `api_key` | `"sk-or-v1-7489f18c…"` | `str` | Credencial de autenticación **embebida en código (hardcoded)**. |

> **⚠️ Riesgo de seguridad crítico:** la clave de API está escrita literalmente en el código fuente. Esto implica exposición en el historial de control de versiones y en cualquier distribución del archivo. La clave mostrada debe considerarse **comprometida y revocada**. Sustituir por `api_key=os.environ["OPENROUTER_API_KEY"]`.

---

## 3. Especificación de funciones

### 3.1 `generar_documentacion()`

Orquesta el flujo completo de generación documental: lectura → inferencia → persistencia.

#### 3.1.1 Firma

```python
def generar_documentacion() -> None
```

#### 3.1.2 Docstring propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en Markdown a partir de un archivo Java.

    Lee el código fuente ubicado en la ruta fija
    ``main/java/junit/textui/ResultPrinter.java``, lo envía al modelo
    ``google/gemini-2.0-flash-001`` mediante el cliente OpenRouter
    previamente configurado y escribe la respuesta textual del modelo en
    el archivo ``MANUAL_TECNICO_JUNIT.md`` del directorio de trabajo
    actual. Emite trazas de progreso por ``stdout``.

    Returns:
        None: La función produce efectos de lado (E/S de archivos y
            consola) y no retorna valor alguno.

    Raises:
        FileNotFoundError: Si no existe el archivo Java de entrada.
        IsADirectoryError: Si la ruta de entrada apunta a un directorio.
        PermissionError: Si no hay permisos de lectura sobre el archivo
            de entrada o de escritura en el directorio de salida.
        UnicodeDecodeError: Si el archivo Java no es decodificable en UTF-8.
        openai.AuthenticationError: Si la ``api_key`` es inválida o fue revocada.
        openai.RateLimitError: Si se excede la cuota del proveedor.
        openai.APIConnectionError: Si falla la conectividad con OpenRouter.
        openai.APIStatusError: Para cualquier respuesta HTTP 4xx/5xx no
            cubierta por las excepciones anteriores.
        TypeError: Si el modelo devuelve ``content`` nulo y se intenta
            escribirlo en el archivo de salida.
        OSError: Ante errores genéricos del sistema de archivos.

    Note:
        La función no recibe parámetros: tanto la ruta de entrada como el
        nombre del archivo de salida y el identificador del modelo están
        codificados literalmente en el cuerpo.
    """
```

#### 3.1.3 Parámetros de entrada

| Nombre | Tipo | Requerido | Valor por defecto | Descripción |
|---|---|---|---|---|
| — | — | — | — | La función **no declara parámetros**. Toda su configuración es interna (acoplamiento fuerte). |

**Entradas implícitas (acoplamiento):**

| Origen | Identificador | Tipo | Descripción |
|---|---|---|---|
| Global del módulo | `client` | `OpenAI` | Cliente consumido vía *closure* sobre el ámbito global. |
| Sistema de archivos | `main/java/junit/textui/ResultPrinter.java` | `str` (ruta relativa) | Debe existir **relativa al CWD** del proceso. |
| Red | `https://openrouter.ai/api/v1` | Endpoint HTTPS | Requiere conectividad saliente. |

#### 3.1.4 Variables locales

| Nombre | Tipo | Descripción |
|---|---|---|
| `ruta_java` | `str` | Ruta relativa fija del archivo fuente a documentar. |
| `codigo` | `str` | Contenido íntegro del archivo Java decodificado en UTF-8. |
| `response` | `ChatCompletion` | Objeto de respuesta del SDK `openai`. |
| `manual_contenido` | `str \| None` | Texto Markdown extraído de `response.choices[0].message.content`. |

#### 3.1.5 Valor de retorno

| Tipo | Descripción |
|---|---|
| `None` | Retorno implícito. El resultado útil se materializa como efecto de lado. |

**Efectos de lado producidos:**

| # | Efecto | Destino |
|---|---|---|
| 1 | Lectura de archivo | `main/java/junit/textui/ResultPrinter.java` |
| 2 | Petición HTTP `POST` | `/chat/completions` de OpenRouter |
| 3 | Escritura/sobrescritura de archivo | `MANUAL_TECNICO_JUNIT.md` (modo `"w"`) |
| 4 | Trazas de progreso | `stdout` (2 bloques de `print`) |

#### 3.1.6 Manejo de excepciones (`Raises`)

| Excepción | Causa probable | Capturada por el código |
|---|---|---|
| `FileNotFoundError` | La ruta `ruta_java` no existe respecto al CWD. | ❌ No |
| `IsADirectoryError` | La ruta apunta a un directorio. | ❌ No |
| `PermissionError` | Sin permisos de lectura/escritura. | ❌ No |
| `UnicodeDecodeError` | Archivo Java en codificación distinta de UTF-8 (p. ej. Latin-1). | ❌ No |
| `openai.AuthenticationError` | `api_key` inválida, revocada o sin saldo. | ❌ No |
| `openai.RateLimitError` | Límite de peticiones/tokens excedido. | ❌ No |
| `openai.APIConnectionError` | Fallo DNS, proxy o timeout de red. | ❌ No |
| `openai.BadRequestError` | Código fuente excede la ventana de contexto del modelo. | ❌ No |
| `openai.APIStatusError` | Respuesta HTTP no exitosa genérica. | ❌ No |
| `IndexError` | `response.choices` vacío (respuesta degenerada del proveedor). | ❌ No |
| `TypeError` | `manual_contenido is None` al invocar `m.write()`. | ❌ No |
| `OSError` | Disco lleno o ruta de salida no escribible. | ❌ No |

> **Observación de robustez:** `generar_documentacion()` **no implementa bloque `try/except` alguno**. Cualquier fallo propaga el *traceback* al intérprete y aborta el proceso. En entornos productivos debe envolverse en manejo explícito de errores con política de reintentos para los errores transitorios (`RateLimitError`, `APIConnectionError`).

#### 3.1.7 Configuración de la inferencia

| Campo | Valor | Tipo |
|---|---|---|
| `model` | `"google/gemini-2.0-flash-001"` | `str` |
| `messages[0].role` | `"system"` | `str` |
| `messages[0].content` | Instrucción de rol: generar manual técnico en español para código Java. | `str` |
| `messages[1].role` | `"user"` | `str` |
| `messages[1].content` | `codigo` (contenido crudo del `.java`) | `str` |
| `temperature`, `max_tokens`, `stream` | No especificados → valores por defecto del proveedor | — |

#### 3.1.8 Flujo de ejecución

```
1. Asignar ruta_java (constante literal)
2. open(ruta_java, 'r', utf-8)  →  codigo = f.read()        [context manager]
3. print("--- Procesando código de: ... ---")
4. client.chat.completions.create(model, messages)  →  response
5. manual_contenido = response.choices[0].message.content
6. open("MANUAL_TECNICO_JUNIT.md", 'w', utf-8)  →  m.write(...)  [context manager]
7. print(confirmación × 2)
8. return None (implícito)
```

### 3.2 Sentencia de ejecución a nivel de módulo

```python
generar_documentacion()
```

| Aspecto | Detalle |
|---|---|
| Ubicación | Última línea, ámbito global |
| Comportamiento | Se ejecuta en el `import` del módulo, no solo en ejecución directa |
| Problema detectado | Ausencia de guarda `if __name__ == "__main__":`, lo que impide importar el módulo sin disparar la llamada a la API (y su coste asociado) |
| Corrección recomendada | Envolver en `if __name__ == "__main__": generar_documentacion()` |

---

## 4. Ejemplo de uso

### 4.1 Uso tal como está implementado

```python
# Estructura de directorios requerida (relativa al CWD):
#
# proyecto/
# ├── generar_documentacion.py
# └── main/
#     └── java/
#         └── junit/
#             └── textui/
#                 └── ResultPrinter.java

# Ejecución desde terminal, posicionado en 'proyecto/':
#   $ python generar_documentacion.py
#
# Salida esperada en stdout:
#   --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
#
#   ¡Documentación generada con éxito!
#   Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
#
# Artefacto generado: proyecto/MANUAL_TECNICO_JUNIT.md
```

### 4.2 Invocación programática con manejo de errores

Caso de uso real que reutiliza la función existente añadiendo una capa defensiva, **sin modificar el código fuente original**:

```python
import os
import sys
from pathlib import Path

import openai

# La importación dispara la ejecución: se verifica el entorno antes.
RUTA_ENTRADA = Path("main/java/junit/textui/ResultPrinter.java")
RUTA_SALIDA = Path("MANUAL_TECNICO_JUNIT.md")


def ejecutar_con_validacion() -> int:
    """Valida precondiciones e invoca generar_documentacion() de forma segura.

    Returns:
        int: Código de salida POSIX (0 = éxito, 1 = error controlado).
    """
    if not RUTA_ENTRADA.is_file():
        print(f"[ERROR] No se encontró el archivo de entrada: {RUTA_ENTRADA}",
              file=sys.stderr)
        print(f"[INFO ] CWD actual: {os.getcwd()}", file=sys.stderr)
        return 1

    try:
        # Importar el módulo ejecuta generar_documentacion() automáticamente.
        from generar_documentacion import generar_documentacion  # noqa: F401
    except FileNotFoundError as exc:
        print(f"[ERROR] Archivo no disponible: {exc}", file=sys.stderr)
        return 1
    except UnicodeDecodeError:
        print("[ERROR] El archivo Java no está codificado en UTF-8.",
              file=sys.stderr)
        return 1
    except openai.AuthenticationError:
        print("[ERROR] Credencial de OpenRouter inválida o revocada.",
              file=sys.stderr)
        return 1
    except openai.RateLimitError:
        print("[ERROR] Cuota de la API excedida. Reintente más tarde.",
              file=sys.stderr)
        return 1
    except openai.APIConnectionError as exc:
        print(f"[ERROR] Fallo de conectividad con OpenRouter: {exc}",
              file=sys.stderr)
        return 1

    # Verificación del artefacto producido.
    if RUTA_SALIDA.is_file() and RUTA_SALIDA.stat().st_size > 0:
        print(f"[OK   ] Manual generado "
              f"({RUTA_SALIDA.stat().st_size} bytes) en {RUTA_SALIDA.resolve()}")
        return 0

    print("[WARN ] La función finalizó pero el archivo de salida está vacío.",
          file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(ejecutar_con_validacion())
```

### 4.3 Preparación del entorno

```bash
# 1. Instalar la dependencia
pip install "openai>=1.0.0"

# 2. (Recomendado) Externalizar la credencial antes de ejecutar
export OPENROUTER_API_KEY="sk-or-v1-..."   # Linux / macOS
setx  OPENROUTER_API_KEY "sk-or-v1-..."    # Windows

# 3. Ejecutar
python generar_documentacion.py
```

---

## 5. Observaciones técnicas y deuda identificada

| # | Hallazgo | Severidad | Remediación sugerida |
|---|---|---|---|
| 1 | Clave de API *hardcoded* en el código fuente | **Crítica** | Leer de `os.environ` o de un gestor de secretos; revocar la clave expuesta. |
| 2 | Ausencia total de `try/except` | Alta | Añadir manejo por tipo de excepción y reintentos exponenciales. |
| 3 | Falta de guarda `if __name__ == "__main__"` | Alta | Impide reutilizar el módulo como librería. |
| 4 | Rutas de entrada/salida y modelo codificados literalmente | Media | Parametrizar `generar_documentacion(ruta_java, ruta_salida, modelo)` o usar `argparse`. |
| 5 | No se valida `manual_contenido is not None` | Media | Verificar antes de `m.write()` para evitar `TypeError`. |
| 6 | Sin límite de tamaño de entrada | Media | Validar longitud/tokens del archivo frente a la ventana de contexto del modelo. |
| 7 | Modo `"w"` sobrescribe silenciosamente el manual previo | Baja | Versionar la salida o solicitar confirmación. |
| 8 | Ausencia de *docstring* y *type hints* | Baja | Aplicar el docstring de §3.1.2 y anotar `-> None`. |