Documentación técnica  
Clase: org.junit.platform.launcher.core.DefaultLauncherTests  
Tipo: Prueba de unidad (JUnit 5, JUnit Platform)  
Ámbito: módulo junit-platform-launcher

1. Propósito general  
DefaultLauncherTests verifica, de extremo a extremo, el contrato público de la implementación por defecto de la interfaz org.junit.platform.launcher.Launcher.  
Los casos de prueba cubren todo el ciclo de vida de una ejecución:

• Creación del Launcher y validación de su configuración inicial.  
• Descubrimiento de tests (Test Plan).  
• Aplicación de PostDiscoveryFilters.  
• Ejecución de un TestPlan, incluidas cancelaciones, dry-run, fallos y eventos dinámicos.  
• Propagación de ConfigurationParameters y notificación a TestExecutionListener y LauncherDiscoveryListener.  
• Tratamiento de DiscoveryIssue y su severidad configurable.  
• Manejo de engines con IDs no válidos o duplicados.  

Con ello, la suite garantiza la estabilidad de la API pública y sirve como especificación ejecutable para colaboradores externos que implementen TestEngine o utilicen Launcher programáticamente.

2. Principales métodos de prueba (ordenados por funcionalidad)

A. Validación de construcción del Launcher  
• constructLauncherWithoutAnyEngines()  
  – Comprueba que no se permite instanciar un Launcher sin engines registrados.  
• constructLauncherWithMultipleTestEnginesWithDuplicateIds()  
  – Verifica la detección de IDs de engine duplicados.

B. Descubrimiento de tests  
• discoverEmptyTestPlanWithEngineWithoutAnyTests()  
  – Un engine sin tests debe producir un TestPlan con la raíz del engine.  
• discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()  
  – Si el engine devuelve null en discover, se registra como fallo pero se entrega un TestPlan mínimo.  
• discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<?>)  
  – Cuando el engine lanza Error o RuntimeException en discover, el Launcher envuelve la excepción en EngineDiscoveryResult.Status.FAILED y coloca un descriptor de “error”.  
• discoverTestPlanForSingleEngine() / discoverTestPlanForMultipleEngines()  
  – Caminos felices con uno o varios engines y selectores combinados.  
• launcherAppliesPostDiscoveryFilters() / prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()  
  – Demuestra la aplicación en cascada de PostDiscoveryFilters y la poda posterior del árbol.  
• notifiesDiscoveryListenersOfProcessedSelectors()  
  – Comprueba que los LauncherDiscoveryListener configurados reciben selectorProcessed().

C. Parámetros de configuración  
• withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()  
• withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()  
• withoutConfigurationParameters_LookupFallsBackToSystemProperty()  
  – Valida la resolución de parámetros vía LauncherDiscoveryRequest o System.getProperty.

D. Ejecución de tests  
• reportsEngineExecutionFailures* (cinco sobrecargas)  
  – Todas ellas aseguran que, ante fallos en execute(), ejecución ya iniciada, saltada o finalizada, el Launcher encapsula la causa y notifica correctamente a los listeners.  
• reportsSkippedEngines() / reportsFinishedEngines()  
  – Cobertura para executionSkipped y executionFinished.  
• reportsDynamicTestDescriptorsCorrectly()  
  – Verifica el soporte para TestDescriptor dinámico registrado mediante dynamicTestRegistered().  
• dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()  
  – Demuestra el funcionamiento del modo dry-run (configuración junit.platform.launcher.dryRun=true).  
• launcherCanExecuteTestPlanExactlyOnce()  
  – Garantiza que un TestPlan solo puede ejecutarse una vez.

E. DiscoveryIssue y severidad configurable  
• reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()  
• logsNonCriticalIssuesForRegularEngineExecution()  
• logsAllIssuesForDiscoveryFailure()  
• logsNonCriticalIssuesForExecutionFailure()  
• allowsConfiguringCriticalDiscoveryIssueSeverity()  
• failsIfCriticalSeverityIsConfiguredIncorrectly()  
• failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()  
• logsNonCriticalIssuesOnlyOnce(String)  
• failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()  
  – El conjunto comprueba mapeo de severidades, fase de fallo (discovery/execution) y logging único por DiscoveryIssueNotifier.

F. Cancelación  
• reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()  
  – Si el CancellationToken ya está cancelado antes de execute(), los nodos hijos del engine se marcan como skipped y el engine no se invoca.

G. Protección frente a IDs de engine reservados  
• thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()  
• thirdPartyEngineClaimingToBeJupiterResultsInException()  
• thirdPartyEngineClaimingToBeVintageResultsInException()  
  – Refuerza la regla de que solo JUnit puede usar los prefijos reservados “junit-”, “junit-jupiter” y “junit-vintage”.

3. Métodos auxiliares privados

• assertDiscoveryFailed(..)  
  – Factoriza verificación de EngineDiscoveryResult.FAILED con mensaje uniforme.  
• assertImposter(String)  
  – Pequeño helper reutilizado por dos tests de impostores.  
• execute(..) (tres sobrecargas)  
  – Ejecuta la secuencia discovery-execute parametrizable, captura resultados y tiempos e inyecta listeners espía; devuelve un record ReportedData con la información relevante.  
• findFirstDiscoveryIssueLogRecord(..)  
  – Busca, por clase emisora y nivel de log, el primer LogRecord asociado a DiscoveryIssueNotifier.  

4. Dependencias principales

• JUnit 5 Jupiter (sistema de parámetros, Assertions, fixtures).  
• JUnit Platform Launcher/Engine API (TestPlan, TestIdentifier, etc.).  
• Mockito (mock, spy, ArgumentCaptor, InOrder).  
• AssertJ para aserciones expresivas.  
• Clases fake de prueba: DemoHierarchicalTestEngine, TestEngineStub, TestEngineSpy, FaultyTestEngines.  

5. Conclusiones

DefaultLauncherTests actúa como contrato viviente de la API pública de org.junit.platform.launcher.Launcher.  
Cada método de prueba representa un requisito funcional que debe preservarse en futuras versiones: correcta notificación de eventos, estrategias de fallo configurables, soporte para ejecución dinámica, filtros, cancelación y validación de engines.  
Mantener esta suite actualizada es esencial antes de refactorizar el core del Launcher o introducir cambios de comportamiento.