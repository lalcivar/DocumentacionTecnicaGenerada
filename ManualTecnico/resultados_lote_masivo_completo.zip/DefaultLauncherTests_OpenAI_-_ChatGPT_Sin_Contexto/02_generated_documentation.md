Documentación técnica  
Clase: org.junit.platform.launcher.core.DefaultLauncherTests

1. Propósito general  
DefaultLauncherTests es un conjunto exhaustivo de pruebas de regresión para la implementación por defecto de org.junit.platform.launcher.Launcher (“DefaultLauncher”).  
Su objetivo es:

• Verificar que el lanzador pueda descubrir planes de prueba (TestPlan) y ejecutarlos correctamente.  
• Asegurar que los errores, excepciones y situaciones límite se notifiquen de forma coherente a los TestExecutionListener y LauncherDiscoveryListener.  
• Comprobar la correcta propagación de parámetros de configuración, filtros, token de cancelación y modo «dry-run».  
• Validar la interacción con motores de prueba (TestEngine) reales, espías (Stub/Spy) o defectuosos (FaultyTestEngine).  
• Garantizar que se respeten las restricciones sobre el id de los motores (prefijos reservados «junit-»).  
• Corroborar que los DiscoveryIssue se gestionen y registren (logging) según su gravedad configurada.

2. Dependencias y utilidades usadas  
– JUnit Jupiter (annotations @Test, @ParameterizedTest, etc.).  
– Mockito para la creación de mocks, espías, capturadores y verificación de llamadas.  
– AssertJ para aserciones encadenadas.  
– Utilidades de la propia plataforma JUnit (LauncherFactory, DiscoverySelectors, etc.).  
– Motores de prueba stub/spy y auxiliares incluidos en el proyecto de pruebas (DemoHierarchicalTestEngine, TestEngineStub, etc.).

3. Categorías de pruebas y métodos principales  

A. Construcción del Launcher  
• constructLauncherWithoutAnyEngines() – Falla si se crea un Launcher sin motores.  
• constructLauncherWithMultipleTestEnginesWithDuplicateIds() – Detecta ids de motor duplicados.

B. Descubrimiento de pruebas (discover)  
• discoverEmptyTestPlanWithEngineWithoutAnyTests() – Plan vacío pero con root descriptor.  
• discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor() – Motor que devuelve null.  
• discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase() – Motor que lanza excepción en discovery.  
• discoverTestPlanForSingleEngine() / discoverTestPlanForMultipleEngines() – Verifica la creación de TestPlan con uno o varios motores.  
• launcherAppliesPostDiscoveryFilters() – Comprueba la aplicación de PostDiscoveryFilter.  
• prunesTestDescriptorsAfterApplyingPostDiscoveryFilters() – Elimina descriptores excluidos.  
• notifiesDiscoveryListenersOfProcessedSelectors() – Listener informado de cada selector procesado.  

C. Ejecución de pruebas (execute) y manejo de fallos del motor  
• reportsEngineExecutionFailuresWithoutPriorEvents(), …ForSkippedEngine(), …ForStartedEngine(), …ForSuccessfullyFinishedEngine(), …ForFailedFinishedEngine() – Serie de pruebas que aseguran la traducción de excepciones del motor en TestExecutionResult FAILED.  
• reportsSkippedEngines() – Verifica eventos de skipped.  
• reportsFinishedEngines() – Verifica eventos de éxito.  
• launcherCanExecuteTestPlanExactlyOnce() – Impide la re-ejecución de un mismo TestPlan.

D. Parámetros de configuración y listeners  
• withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()  
• withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()  
• withoutConfigurationParameters_LookupFallsBackToSystemProperty() – Prioridad de system property.  
• withAdditionalListener() – Registro de listeners de ejecución adicionales.

E. Pruebas sobre dinámica y modo dry-run  
• reportsDynamicTestDescriptorsCorrectly() – Comprueba registro y jerarquía de pruebas dinámicas.  
• dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem() – Confirmación del modo «dry-run».

F. Validaciones sobre ids de motores  
• thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()  
• thirdPartyEngineClaimingToBeJupiterResultsInException()  
• thirdPartyEngineClaimingToBeVintageResultsInException()  

G. Gestión de DiscoveryIssue  
• reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()  
• logsNonCriticalIssuesForRegularEngineExecution()  
• logsAllIssuesForDiscoveryFailure()  
• logsNonCriticalIssuesForExecutionFailure()  
• allowsConfiguringCriticalDiscoveryIssueSeverity()  
• failsIfCriticalSeverityIsConfiguredIncorrectly()  
• failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()  
• logsNonCriticalIssuesOnlyOnce()  
• failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()  
• reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()  
• ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()  
• reportsEngineExecutionFailureForSelectorResolutionFailure()

H. Cancelación  
• reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested() – Al cancelar, marca los hijos como skipped y finaliza el motor con estado ABORTED.

4. Métodos de apoyo internos  
• assertDiscoveryFailed(…) – Factor común para validar fallos de descubrimiento.  
• execute(…) – Ejecuta un motor con configuraciones variables y devuelve un contenedor ReportedData (TestPlan, TestIdentifier, resultado y marcas de tiempo).  
• findFirstDiscoveryIssueLogRecord(…) – Ayuda a ubicar registros de log para DiscoveryIssue.  

5. Cobertura funcional  
Las pruebas abarcan la mayoría de los caminos de código críticos de DefaultLauncher:  
– Creación y validación de TestPlan.  
– Propagación de selectores, filtros y parámetros.  
– Tratamiento de todos los estados de TestExecutionResult (SUCCESSFUL, FAILED, ABORTED, SKIPPED).  
– Integridad del flujo de eventos hacia TestExecutionListener y LauncherDiscoveryListener.  
– Conformidad con restricciones contractuales (ej.: ejecución única de un TestPlan).  
– Correcto registro (java.util.logging) de problemas de descubrimiento.  

6. Consideraciones para mantenimiento  
• La clase utiliza varios motores stub/spy internos; su API puede cambiar con las versiones de JUnit Platform: actualizar importaciones y helpers si se mueven de paquete.  
• Añadir nuevas pruebas cuando DefaultLauncher incorpore fases o listeners adicionales (por ejemplo, reporting de tiempos o filtros previos a ejecución).  
• Revisar la severidad por defecto y los parámetros implicados (LauncherConstants.*) en cada versión del framework.  

Esta documentación ofrece una visión de alto nivel que facilita entender la organización de las pruebas y sirve de guía para extender o depurar la funcionalidad de DefaultLauncher.