Documentación técnica  
Clase: org.junit.platform.launcher.core.DefaultLauncherTests

1. Propósito general  
DefaultLauncherTests es la batería de pruebas de regresión para la implementación por defecto de org.junit.platform.launcher.Launcher (creada a través de LauncherFactoryForTestingPurposesOnly#createLauncher).  
Las pruebas comprueban, entre otros aspectos:

• La correcta construcción del Launcher y la validación de sus TestEngine.  
• El flujo de descubrimiento (discover) y ejecución (execute) de planes de prueba (TestPlan).  
• El tratamiento de fallos y situaciones límite: motores duplicados, motores sin tests, errores en discovery / execution, dry-run, cancelación, etc.  
• La aplicación de filtros, parámetros de configuración y listeners adicionales.  
• El registro y propagación de DiscoveryIssue según su gravedad y configuración.  
• Garantías de inmutabilidad (un TestPlan solo puede ejecutarse una vez).

2. Principales métodos de prueba  

A continuación se agrupan los test más representativos por funcionalidad. Cada método está anotado con @Test o @ParameterizedTest y se ejecuta de forma autónoma a través de JUnit Jupiter.

A. Construcción y validación del Launcher  
• constructLauncherWithoutAnyEngines  
  – Verifica que no se permite crear un Launcher sin al menos un TestEngine (‘PreconditionViolation’).  
• constructLauncherWithMultipleTestEnginesWithDuplicateIds  
  – Garantiza que se detectan motores con IDs duplicados y se lanza JUnitException.

B. Descubrimiento de planes de prueba  
• discoverEmptyTestPlanWithEngineWithoutAnyTests  
  – Un motor sin pruebas debe producir un TestPlan con una única raíz vacía.  
• discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor  
  – Si el motor devuelve null en discover(), el plan igualmente contiene la raíz del engine y se notifica el fallo mediante EngineDiscoveryResult.Status.FAILED.  
• discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase  
  – Simula throw en discover() (Error o RuntimeException) y verifica que:  
    ▸ El TestPlan se genera.  
    ▸ El EngineDiscoveryListener registra FAIL.  
    ▸ El ExecutionListener recibe un TestExecutionResult con la excepción envuelta.

C. Fallos en la fase de ejecución  
• reportsEngineExecutionFailuresWithoutPriorEvents  
• reportsEngineExecutionFailuresForSkippedEngine  
• reportsEngineExecutionFailuresForStartedEngine  
• reportsEngineExecutionFailuresForSuccessfullyFinishedEngine  
• reportsEngineExecutionFailuresForFailedFinishedEngine  
  – Las cinco pruebas anteriores exploran las distintas combinaciones de eventos enviados (o no) por el engine antes de lanzar un RuntimeException, verificando que DefaultLauncher propaga correctamente la causa y no pierde la información previa (started, skipped, finished).

D. Gestión de estados SKIPPED & SUCCESSFUL  
• reportsSkippedEngines  
  – Un engine que solo envía executionSkipped() no debe generar otros eventos.  
• reportsFinishedEngines  
  – Flujo nominal con executionStarted/Finished(SUCCESSFUL).

E. Selección, filtros y parámetros de descubrimiento  
• discoverTestPlanForSingleEngine / discoverTestPlanForMultipleEngines  
  – Comprobación de selectPackage y selectUniqueId sobre uno o varios motores.  
• launcherAppliesPostDiscoveryFilters  
  – Valida que los PostDiscoveryFilter se aplican secuencialmente y que solo permanecen los TestDescriptor incluidos.  
• prunesTestDescriptorsAfterApplyingPostDiscoveryFilters  
  – Comprueba que DefaultLauncher descarta físicamente los nodos excluidos del árbol.

F. Parámetros de configuración del Launcher  
• withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest  
• withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest  
• withoutConfigurationParameters_LookupFallsBackToSystemProperty  
  – Demuestran la construcción del objeto ConfigurationParameters y la búsqueda por system-property fallback.  
• withAdditionalListener  
  – Ejemplo de registro de un TestExecutionListener extra (SummaryGeneratingListener).

G. Detección de uso indebido de IDs reservados  
• thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue  
• thirdPartyEngineClaimingToBeJupiterResultsInException  
• thirdPartyEngineClaimingToBeVintageResultsInException  
  – El Launcher advierte o bloquea motores terceros que usen el prefijo “junit-” o suplanten IDs oficiales.

H. Dry-run y eventos dinámicos  
• dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem  
  – Con la property junit.platform.launcher.dryRun=true, todos los tests se marcan skipped sin ejecutarse.  
• reportsDynamicTestDescriptorsCorrectly  
  – Verifica el registro y notificación de TestDescriptor creados dinámicamente en tiempo de ejecución.

I. Control de ciclo de vida de TestPlan  
• launcherCanExecuteTestPlanExactlyOnce  
  – Un TestPlan no puede ejecutarse más de una vez; se produce PreconditionViolation.

J. DiscoveryIssue y severidades configurables  
• reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining  
• logsNonCriticalIssuesForRegularEngineExecution  
• logsAllIssuesForDiscoveryFailure  
• logsNonCriticalIssuesForExecutionFailure  
• allowsConfiguringCriticalDiscoveryIssueSeverity  
• failsIfCriticalSeverityIsConfiguredIncorrectly  
• failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly  
• logsNonCriticalIssuesOnlyOnce  
• failsDuringDiscoveryIfConfigurationParameterValueIsInvalid  
  – Conjunto de tests que cubren:  
    ▸ Generación de DiscoveryIssue con distintos Severity (ERROR, WARNING, INFO).  
    ▸ Propiedad critical-discovery-issue-severity.  
    ▸ Propiedad discovery-issue-failure-phase (discovery / execution).  
    ▸ Registro en DiscoveryIssueNotifier y consistencia temporal de los LogRecord.

K. Cancelación  
• reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested  
  – Cuando CancellationToken ya ha sido cancelado, el engine no se ejecuta; los nodos secundarios se marcan skipped y la raíz aborted.

L. Notificación de selectors procesados  
• notifiesDiscoveryListenersOfProcessedSelectors  
  – Garantiza que cualquier LauncherDiscoveryListener registrado a nivel de configuración, launcher o petición recibe selectorProcessed().

3. Métodos utilitarios internos  

• assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)  
  – Ayuda para verificar EngineDiscoveryResult.Status.FAILED y la excepción asociada.  

• execute(...)  
  – Abstrae la creación del Launcher, el build de peticiones de descubrimiento / ejecución, la ejecución propiamente dicha y la captura ordenada de eventos y tiempos. Devuelve un record ReportedData con la información recopilada.  

• findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)  
  – Recupera el primer LogRecord emitido por DiscoveryIssueNotifier con la severidad solicitada.

4. Cobertura funcional  
Las pruebas abarcan la inmensa mayoría de caminos de código en DefaultLauncher:

• Éxito y todo tipo de fallos en discovery y execution.  
• Múltiples motores, filtros, propiedades, modo dry-run, dynamic tests.  
• Integración con CancellationToken, LogRecordListener, EngineDiscoveryListener, etc.  

Con ello se garantiza que el contrato del API Launcher se cumpla frente a implementaciones reales de motores, motores defectuosos “fakes” y motores espía (“spy”) utilizados durante los tests.

Fin de la documentación.