# Documentación Técnica - Módulo de Tests `test_factory`

## 1. Resumen Ejecutivo

Este módulo corresponde a la suite de tests unitarios para la *Application Factory* del proyecto Flask `flaskr`. Su propósito es validar el comportamiento del factory `create_app` mediante `pytest`, verificando la correcta inicialización de la configuración por defecto y la respuesta del endpoint de verificación `/hello`.

No contiene lógica de negocio; actúa exclusivamente como capa de verificación y regresión para garantizar la integridad de la creación de la aplicación Flask.

## 2. Especificación de Funciones y Métodos

Análisis estático del código fuente: se detectaron **2 funciones** a nivel de módulo. No se detectaron clases, métodos de clase, decoradores, funciones auxiliares adicionales ni funciones anidadas/locales.

### 2.1 `test_config()`

Valida el patrón Factory de Flask. Comprueba que `create_app()` inicializa la aplicación en modo no-testing por defecto y que respeta la inyección de configuración de prueba cuando se le pasa el diccionario `{"TESTING": True}`.

**Docstring Propuesto (Google Style / PEP 257):**

```python
def test_config():
    """Verifica la configuración de la Application Factory.

    Valida que create_app respete la configuración por defecto y
    la configuración de prueba inyectada.

    Returns:
        None: Esta función no retorna valores. La validación se
            realiza mediante aserciones.

    Raises:
        AssertionError: Si create_app().testing no es False por defecto,
            o si create_app({"TESTING": True}).testing no es True.
    """
```

**Parámetros de Entrada:**

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | La función no recibe parámetros. |

**Valores de Retorno:**

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor explícito. Retorno implícito `None`. El éxito se determina por la no elevación de excepciones. |

**Manejo de Excepciones (Raises):**

| Tipo | Condición |
| :--- | :--- |
| `AssertionError` | Se lanza si `assert not create_app().testing` falla (la app se crea en modo testing sin solicitarlo). |
| `AssertionError` | Se lanza si `assert create_app({"TESTING": True}).testing` falla (la app ignora la configuración `TESTING=True` inyectada). |

**Dependencias:**
* `flaskr.create_app`: Factory a testear. Importado directamente.

### 2.2 `test_hello(client)`

Test de integración para el endpoint `/hello`. Verifica que una petición `GET` a dicha ruta retorne un código de estado exitoso y el cuerpo de respuesta esperado `b"Hello, World!"`.

**Docstring Propuesto (Google Style / PEP 257):**

```python
def test_hello(client):
    """Verifica el endpoint de health-check /hello.

    Realiza una petición GET al endpoint /hello y valida que
    el contenido de la respuesta sea el esperado.

    Args:
        client (FlaskClient): Fixture de pytest que provee un cliente
            de prueba para la aplicación Flask. Es inyectado
            automáticamente por pytest. Debe exponer el método
            get(path).

    Returns:
        None: Esta función no retorna valores. La validación se
            realiza mediante aserciones.

    Raises:
        AssertionError: Si response.data no es igual a b"Hello, World!".
        AttributeError: Si el objeto client no implementa el método get.
    """
```

**Parámetros de Entrada:**

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `client` | `FlaskClient` (`werkzeug.test.Client` / `Flask.testing.FlaskClient`) | Sí | Fixture de `pytest` que encapsula la aplicación Flask para testing. Permite simular peticiones HTTP sin levantar un servidor. |

**Valores de Retorno:**

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor explícito. Retorno implícito `None`. |

**Manejo de Excepciones (Raises):**

| Tipo | Condición |
| :--- | :--- |
| `AssertionError` | Se lanza si `response.data != b"Hello, World!"`. Indica que el endpoint no responde con el payload esperado. |
| `AttributeError` | Se lanza si el fixture `client` es `None` o no posee el método `.get()`. |

## 3. Ejemplo de Uso

Este módulo no se importa ni se ejecuta de forma programática, se ejecuta a través del runner de `pytest`. Se requiere un fixture `client` definido en `conftest.py`.

**`conftest.py` requerido:**

```python
import pytest
from flaskr import create_app

@pytest.fixture
def client():
    """Crea y configura un cliente de prueba para la app."""
    app = create_app({"TESTING": True})
    with app.test_client() as client:
        yield client
```

**Ejecución de la suite:**

```bash
# Ejecutar todos los tests del módulo
pytest -v

# Ejecutar solo este archivo
pytest tests/test_factory.py -v
```

**Invocación programática (uso alternativo):**

```python
from flaskr import create_app

# Equivalente a test_config() de forma manual
app_default = create_app()
assert not app_default.testing, "La app no debe estar en modo testing por defecto"

app_testing = create_app({"TESTING": True})
assert app_testing.testing, "La app debe estar en modo testing"

# Equivalente a test_hello(client) de forma manual
with app_testing.test_client() as client:
    response = client.get("/hello")
    assert response.data == b"Hello, World!"
    assert response.status_code == 200
    print("Todos los checks pasaron correctamente.")
```
