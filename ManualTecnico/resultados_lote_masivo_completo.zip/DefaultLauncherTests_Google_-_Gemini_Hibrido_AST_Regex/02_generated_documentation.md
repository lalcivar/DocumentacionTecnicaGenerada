Claro, aquí tienes la documentación técnica exhaustiva para la clase `DefaultLauncherTests`, siguiendo la estructura y restricciones solicitadas.

***

## Documentación Técnica: `org.junit.platform.launcher.core.DefaultLauncherTests`

### 1. Resumen Ejecutivo

La clase `DefaultLauncherTests` es una suite de pruebas interna del framework JUnit 5, diseñada para validar de manera exhaustiva la implementación `DefaultLauncher`. Su propósito es asegurar la correcta operación del ciclo de vida del lanzador de pruebas, abarcando el descubrimiento, filtrado, ejecución, manejo de errores y la notificación a los listeners registrados. Esta clase es fundamental para garantizar la estabilidad y fiabilidad del core de JUnit Platform.

### 2. Especificación de Métodos y Constructores

A continuación se detallan todos los métodos, constructores y clases internas/anónimas presentes en el código fuente.

#### Constructor

##### `DefaultLauncherTests()`
Constructor por defecto de la clase de pruebas.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `DefaultLauncherTests` (instancia) | *Ninguna* |

---

#### Métodos de Prueba y Auxiliares

##### `constructLauncherWithoutAnyEngines()`
Verifica que se lanza una `JUnitException` al intentar descubrir pruebas con un `Launcher` creado sin ningún `TestEngine`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la excepción esperada no es lanzada. |

---
##### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`
Verifica que se lanza una `JUnitException` al intentar descubrir pruebas con un `Launcher` configurado con múltiples `TestEngine` que tienen el mismo ID.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la excepción esperada no es lanzada. |

---
##### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`
Asegura que el proceso de descubrimiento genera un `TestPlan` con un solo nodo raíz (el motor) cuando el `TestEngine` no encuentra ninguna prueba.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el plan de pruebas no contiene exactamente una raíz. |

---
##### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
Prueba el comportamiento del `Launcher` cuando un `TestEngine` devuelve `null` durante la fase de descubrimiento. Se espera que el plan de pruebas contenga una raíz y que se notifique un fallo de descubrimiento al `LauncherDiscoveryListener`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si las aserciones sobre el plan de pruebas o las interacciones del listener fallan. |

###### Método anónimo `discover()` en `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
Implementación anónima de `TestEngineStub` que siempre devuelve `null` en la fase de descubrimiento.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | La solicitud de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | El ID único para el descriptor raíz del motor. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `TestDescriptor` | Siempre devuelve `null`. |

---
##### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`
Prueba parametrizada que verifica que si un `TestEngine` lanza un `Error` o `RuntimeException` durante el descubrimiento, se crea un descriptor de error y la ejecución posterior de ese descriptor falla correctamente.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `throwableClass` | `Class<? extends Throwable>` | Sí | La clase de la excepción (`Error` o `RuntimeException`) que se lanzará. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `void` | Este método no retorna ningún valor. |

**Excepciones (@throws):**
| Tipo | Condición |
|---|---|
| `AssertionError` | Si las aserciones sobre el plan de pruebas o los resultados de ejecución fallan. |

###### Método anónimo `discover()` en `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()`
Implementación anónima de `TestEngineStub` que lanza una instancia de la clase `throwableClass` proporcionada.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | La solicitud de descubrimiento (no utilizada). |
| `uniqueId` | `UniqueId` | Sí | El ID único para el descriptor raíz (no utilizado). |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `TestDescriptor` | Teóricamente `null`, ya que siempre lanza una excepción antes de retornar. |

**Excepciones (@throws):**
| Tipo | Condición |
|---|---|
| `Throwable` | Lanza una instancia de `throwableClass` para simular un fallo en el descubrimiento. |

---
##### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`
Método auxiliar privado para verificar que un motor de pruebas ha fallado durante la fase de descubrimiento y que el `LauncherDiscoveryListener` ha sido notificado correctamente.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testEngine` | `TestEngine` | Sí | El motor de pruebas que se espera que falle. |
| `inOrder` | `InOrder` | Sí | Verificador de orden de Mockito para asegurar la secuencia de llamadas. |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | El listener mockeado cuyas interacciones se verifican. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `void` | Este método no retorna ningún valor. |

---
##### `reportsEngineExecutionFailuresWithoutPriorEvents()`
Verifica que si un `TestEngine` lanza una excepción inmediatamente al inicio de `execute()`, el fallo se reporta correctamente al `TestExecutionListener`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el resultado de la ejecución no es el esperado. |

###### Método anónimo `execute()` en `reportsEngineExecutionFailuresWithoutPriorEvents()`
Implementación que lanza una `RuntimeException` inmediatamente.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |

**Excepciones (@throws):**
| Tipo | Condición |
|---|---|
| `RuntimeException` | Siempre se lanza para simular un fallo catastrófico. |

---
##### `reportsEngineExecutionFailuresForSkippedEngine()`
Verifica que un fallo en la ejecución del motor se reporta correctamente incluso si el motor ya había sido marcado como "saltado" (skipped).

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el resultado de la ejecución no es el esperado. |

###### Método anónimo `execute()` en `reportsEngineExecutionFailuresForSkippedEngine()`
Implementación que notifica un `executionSkipped` y luego lanza una `RuntimeException`.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |

**Excepciones (@throws):**
| Tipo | Condición |
|---|---|
| `RuntimeException` | Siempre se lanza para simular un fallo posterior al skip. |

---
##### `reportsEngineExecutionFailuresForStartedEngine()`
Verifica que un fallo en la ejecución del motor se reporta correctamente después de que el motor haya sido marcado como "iniciado" (started).

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el resultado de la ejecución no es el esperado. |

###### Método anónimo `execute()` en `reportsEngineExecutionFailuresForStartedEngine()`
Implementación que notifica un `executionStarted` y luego lanza una `RuntimeException`.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |

**Excepciones (@throws):**
| Tipo | Condición |
|---|---|
| `RuntimeException` | Siempre se lanza para simular un fallo durante la ejecución. |

---
##### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`
Verifica que un fallo en la ejecución del motor se reporta correctamente incluso si el motor ya había notificado una finalización exitosa.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el resultado de la ejecución no es el esperado. |

###### Método anónimo `execute()` en `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`
Implementación que notifica un `executionStarted`, un `executionFinished` exitoso y luego lanza una `RuntimeException`.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |

**Excepciones (@throws):**
| Tipo | Condición |
|---|---|
| `RuntimeException` | Siempre se lanza para simular un fallo post-ejecución. |

---
##### `reportsEngineExecutionFailuresForFailedFinishedEngine()`
Verifica que si un motor notifica una finalización fallida y además lanza una excepción, la excepción lanzada se convierte en la causa principal y el fallo original se adjunta como suprimido.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el resultado de la ejecución no es el esperado. |

###### Método anónimo `execute()` en `reportsEngineExecutionFailuresForFailedFinishedEngine()`
Implementación que notifica un `executionStarted`, un `executionFinished` fallido y luego lanza otra `RuntimeException`.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |

**Excepciones (@throws):**
| Tipo | Condición |
|---|---|
| `RuntimeException` | Siempre se lanza para simular un fallo post-ejecución. |

---
##### `reportsSkippedEngines()`
Verifica que cuando un motor se salta su propia ejecución, el `TestExecutionListener` es notificado con un evento `executionSkipped`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si las interacciones del listener no son las esperadas. |

###### Método anónimo `execute()` en `reportsSkippedEngines()`
Implementación que notifica un `executionSkipped` para su propio descriptor raíz.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |

---
##### `reportsFinishedEngines()`
Verifica que cuando un motor completa su ejecución, el `TestExecutionListener` es notificado con los eventos `executionStarted` y `executionFinished`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si las interacciones del listener no son las esperadas. |

###### Método anónimo `execute()` en `reportsFinishedEngines()`
Implementación que notifica un ciclo de vida de ejecución completo y exitoso.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |

---
##### `discoverTestPlanForSingleEngine()`
Verifica que el descubrimiento de pruebas para un único motor con múltiples tests genera un `TestPlan` con una raíz y los tests correspondientes como hijos.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la estructura del `TestPlan` no es la esperada. |

---
##### `discoverTestPlanForMultipleEngines()`
Verifica que el descubrimiento de pruebas para múltiples motores genera un `TestPlan` con múltiples raíces, una por cada motor.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la estructura del `TestPlan` no es la esperada. |

---
##### `launcherAppliesPostDiscoveryFilters()`
Asegura que los `PostDiscoveryFilter` se aplican correctamente después de la fase de descubrimiento, filtrando el `TestPlan` resultante.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el `TestPlan` no se filtra como se espera. |

---
##### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`
Verifica que si no se proporcionan parámetros de configuración, el `Launcher` pasa un mapa de parámetros vacío al `ExecutionRequest` del motor.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si los parámetros de configuración no están vacíos. |

---
##### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`
Verifica que los parámetros de configuración proporcionados al `Launcher` se pasan correctamente al `ExecutionRequest` del motor.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si los parámetros de configuración no se pasan correctamente. |

---
##### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`
Asegura que, en ausencia de parámetros de configuración explícitos, el `Launcher` recurre a las propiedades del sistema (`System.getProperty`).

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el parámetro no se obtiene de las propiedades del sistema. |

---
##### `withAdditionalListener()`
Verifica que un `TestExecutionListener` adicional, como `SummaryGeneratingListener`, se registra y se invoca correctamente durante la ejecución.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el resumen generado por el listener no es el esperado. |

---
##### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
Verifica que los descriptores de prueba que quedan vacíos después de aplicar los filtros post-descubrimiento son eliminados (podados) del `TestPlan`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si el plan de pruebas no se poda correctamente. |

###### Métodos anónimos en `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
1.  **`TestEngineSpy.discover()`**: Sobrescribe el método para crear una estructura de descriptores específica (motor -> contenedor -> test).
2.  **`TestDescriptorStub.getType()`**: Sobrescribe el método para definir un descriptor como de tipo `CONTAINER`.

---
##### `reportsDynamicTestDescriptorsCorrectly()`
Asegura que los tests registrados dinámicamente durante la ejecución son reportados correctamente a los `TestExecutionListener`, incluyendo su jerarquía en el `TestPlan`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si los eventos de los tests dinámicos no se reportan en el orden y con la estructura correcta. |

###### Métodos anónimos en `reportsDynamicTestDescriptorsCorrectly()`
1.  **`TestEngineSpy.discover()`**: Crea una estructura inicial con un descriptor de tipo `CONTAINER_AND_TEST`.
2.  **`TestDescriptorStub.getType()`**: Define el tipo del descriptor como `CONTAINER_AND_TEST`.
3.  **`TestEngineSpy.execute()`**: Simula la ejecución, registra un test dinámico y notifica todos los eventos de ciclo de vida correspondientes.

---
##### `launcherCanExecuteTestPlanExactlyOnce()`
Verifica que un `TestPlan` solo puede ser ejecutado una vez. Un segundo intento de ejecución debe lanzar una `JUnitException`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la excepción por ejecución duplicada no es lanzada. |

---
##### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`
Verifica que se lanza una `DiscoveryIssueException` si un motor de terceros utiliza el prefijo de ID reservado "junit-".

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la excepción esperada no es lanzada. |

---
##### `thirdPartyEngineClaimingToBeJupiterResultsInException()`
Verifica que se lanza una `JUnitException` si un motor de terceros intenta usar el ID "junit-jupiter".

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la excepción esperada no es lanzada. |

---
##### `thirdPartyEngineClaimingToBeVintageResultsInException()`
Verifica que se lanza una `JUnitException` si un motor de terceros intenta usar el ID "junit-vintage".

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la excepción esperada no es lanzada. |

---
##### `assertImposter(String id)`
Método auxiliar privado para verificar que el uso de un ID de motor reservado por un motor "impostor" resulta en una `JUnitException`.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `id` | `String` | Sí | El ID reservado que se va a probar. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `void` | Este método no retorna ningún valor. |

---
##### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`
Verifica que en modo "dry run" (`-n`), los tests se reportan como "saltados" (skipped) en lugar de ejecutarse, pero los contenedores se inician y finalizan normalmente.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la secuencia de eventos del listener no es la esperada para un dry-run. |

---
##### `notifiesDiscoveryListenersOfProcessedSelectors()`
Asegura que todos los `LauncherDiscoveryListener` (configurados en el `Launcher`, registrados programáticamente o en el `request`) son notificados cuando un selector es procesado por un motor.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si alguno de los listeners no es notificado. |

###### Método anónimo `discover()` en `notifiesDiscoveryListenersOfProcessedSelectors()`
Implementación que itera sobre los selectores y notifica al listener de descubrimiento que cada uno ha sido procesado.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | La solicitud de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | El ID único para el motor. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `TestDescriptor` | Un `EngineDescriptor` simple. |

---
##### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)`
Verifica que si un motor reporta un `DiscoveryIssue` crítico (ej. `ERROR`), la ejecución del motor falla con una `DiscoveryIssueException`. Los issues no críticos (ej. `WARNING`) son registrados en el log.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Listener para capturar los registros de log generados. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `void` | Este método no retorna ningún valor. |

---
##### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)`
Verifica que los `DiscoveryIssue` no críticos (ej. `INFO`) son simplemente registrados en el log y la ejecución del motor procede normalmente.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Listener para capturar los registros de log generados. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `void` | Este método no retorna ningún valor. |

---
##### `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)`
Verifica que si el descubrimiento de un motor falla con una excepción, todos los `DiscoveryIssue` reportados hasta ese momento (críticos y no críticos) son registrados en el log.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Listener para capturar los registros de log generados. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `void` | Este método no retorna ningún valor. |

---
##### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)`
Verifica que si la ejecución de un motor falla, los `DiscoveryIssue` no críticos reportados durante el descubrimiento previo son registrados en el log.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Listener para capturar los registros de log generados. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `void` | Este método no retorna ningún valor. |

---
##### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`
Verifica que la ejecución del motor falla si se le proporciona un selector de `UniqueId` que apunta a ese motor pero que no puede resolver.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la ejecución no falla como se espera. |

---
##### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`
Verifica que un motor ignora un selector de `UniqueId` que no puede resolver si el ID no pertenece a su espacio de nombres (es decir, no tiene el prefijo de su ID de motor).

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la ejecución no es exitosa. |

---
##### `reportsEngineExecutionFailureForSelectorResolutionFailure()`
Verifica que la ejecución del motor falla si la resolución de un selector falla con una excepción.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la ejecución no falla como se espera. |

---
##### `allowsConfiguringCriticalDiscoveryIssueSeverity()`
Verifica que la severidad mínima para que un `DiscoveryIssue` sea considerado crítico puede ser configurada a través de los parámetros de configuración del `Launcher`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la ejecución no falla con un issue de severidad `INFO` cuando esta se configura como crítica. |

---
##### `failsIfCriticalSeverityIsConfiguredIncorrectly()`
Verifica que se lanza una `JUnitException` si se proporciona un valor inválido para el parámetro de configuración de severidad crítica.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la excepción esperada no es lanzada. |

---
##### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`
Verifica que si se configura que los fallos por `DiscoveryIssue` ocurran en la fase de "discovery", la excepción se lanza durante la llamada a `launcher.discover()`.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la `DiscoveryIssueException` no es lanzada durante el descubrimiento. |

---
##### `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)`
Verifica que los `DiscoveryIssue` no críticos se registran en el log solo una vez, independientemente de si el fallo se configura para la fase de descubrimiento o de ejecución.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `phase` | `String` | Sí | La fase configurada para el fallo ("discovery" o "execution"). |
| `listener` | `LogRecordListener` | Sí | Listener para capturar los registros de log. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `void` | Este método no retorna ningún valor. |

---
##### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`
Verifica que se lanza una `JUnitException` si se proporciona un valor inválido para el parámetro de configuración de la fase de fallo.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la excepción esperada no es lanzada. |

---
##### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`
Verifica que si se solicita la cancelación antes de la ejecución, los tests se marcan como "saltados" y el motor se marca como "abortado", sin llegar a ejecutar ningún test.

| Parámetros (@param) | Retorno (@return) | Excepciones (@throws) |
| :--- | :--- | :--- |
| *Ninguno* | `void` | `AssertionError` si la secuencia de eventos del listener no es la esperada para una cancelación. |

---
##### `execute(TestEngine engine)`
Método auxiliar estático y privado que ejecuta un ciclo completo de descubrimiento y ejecución para un motor dado con configuración por defecto.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | El motor de pruebas a ejecutar. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `ReportedData` | Un registro con los datos capturados durante la ejecución. |

---
##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)`
Sobrecarga del método `execute` que permite personalizar la solicitud de descubrimiento.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | El motor de pruebas a ejecutar. |
| `discoveryConfigurer` | `UnaryOperator<...>` | Sí | Una función para configurar el `LauncherDiscoveryRequestBuilder`. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `ReportedData` | Un registro con los datos capturados durante la ejecución. |

---
##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)`
Sobrecarga completa del método `execute` que permite personalizar tanto la solicitud de descubrimiento como la de ejecución.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | El motor de pruebas a ejecutar. |
| `discoveryConfigurer` | `UnaryOperator<...>` | Sí | Una función para configurar el `LauncherDiscoveryRequestBuilder`. |
| `executionConfigurer` | `UnaryOperator<...>` | Sí | Una función para configurar el `LauncherExecutionRequestBuilder`. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `ReportedData` | Un registro con los datos capturados durante la ejecución. |

---
##### `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)`
Método auxiliar estático y privado para encontrar el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con un nivel de severidad específico.

**Parámetros (@param):**
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | El listener que ha capturado los logs. |
| `level` | `Level` | Sí | El nivel de log a buscar. |

**Retorno (@return):**
| Tipo | Descripción |
|---|---|
| `LogRecord` | El primer registro de log que coincide con los criterios. |

**Excepciones (@throws):**
| Tipo | Condición |
|---|---|
| `NoSuchElementException` | Si no se encuentra ningún registro que coincida. |

---

#### Clases y Registros Internos

##### `record ReportedData`
Registro (`record`) privado para encapsular los resultados de una ejecución de prueba realizada por los métodos auxiliares `execute`.

###### Constructor canónico `ReportedData(TestPlan, TestIdentifier, TestExecutionResult, Instant, Instant)`
| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testPlan` | `TestPlan` | Sí | El plan de pruebas descubierto. |
| `testIdentifier` | `TestIdentifier` | Sí | El identificador del test raíz ejecutado. |
| `testExecutionResult` | `TestExecutionResult` | Sí | El resultado de la ejecución del test raíz. |
| `startTime` | `Instant` | Sí | El momento de inicio de la ejecución. |
| `finishTime` | `Instant` | Sí | El momento de finalización de la ejecución. |

###### Métodos de acceso del `record`
- `testPlan()`: Retorna el `TestPlan`.
- `testIdentifier()`: Retorna el `TestIdentifier`.
- `testExecutionResult()`: Retorna el `TestExecutionResult`.
- `startTime()`: Retorna el `Instant` de inicio.
- `finishTime()`: Retorna el `Instant` de finalización.

---

### 3. Ejemplo de Uso

Dado que `DefaultLauncherTests` es una clase de prueba, no está diseñada para ser usada directamente. Sin embargo, el siguiente ejemplo ilustra el uso del `DefaultLauncher` (a través de `LauncherFactory`), que es el componente bajo prueba en esta clase.

Este código muestra cómo descubrir y ejecutar una clase de prueba simple mediante programación.

```java
import org.junit.jupiter.api.Test;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners.TestExecutionSummary;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;

/**
 * Ejemplo de uso del Launcher de JUnit Platform para descubrir y ejecutar tests.
 */
public class LauncherExample {

    // 1. Una clase de prueba simple que queremos ejecutar.
    public static class MySimpleTest {
        @Test
        void aSuccessfulTest() {
            assertTrue(true);
        }

        @Test
        void anotherSuccessfulTest() {
            assertTrue(2 + 2 == 4);
        }
    }

    public static void main(String[] args) {
        // 2. Crear una instancia del Launcher.
        // LauncherFactory encontrará y cargará los TestEngines disponibles (ej. junit-jupiter).
        Launcher launcher = LauncherFactory.create();

        // 3. Registrar un listener para recopilar un resumen de la ejecución.
        SummaryGeneratingListener listener = new SummaryGeneratingListener();
        launcher.registerTestExecutionListeners(listener);

        // 4. Crear una solicitud de descubrimiento para una clase de prueba específica.
        LauncherDiscoveryRequest request = LauncherDiscoveryRequestBuilder.request()
                .selectors(selectClass(MySimpleTest.class))
                .build();

        // 5. Descubrir el plan de pruebas. Esta fase identifica qué tests se ejecutarán.
        TestPlan testPlan = launcher.discover(request);
        System.out.println("Plan de pruebas descubierto. Tests encontrados: " + testPlan.getRoots().size());

        // 6. Ejecutar el plan de pruebas.
        System.out.println("Iniciando ejecución de pruebas...");
        launcher.execute(testPlan);
        System.out.println("Ejecución finalizada.");

        // 7. Obtener y mostrar el resumen de la ejecución.
        TestExecutionSummary summary = listener.getSummary();
        System.out.println("\n--- Resumen de Ejecución ---");
        System.out.println("Tests encontrados: " + summary.getTestsFoundCount());
        System.out.println("Tests exitosos: " + summary.getTestsSucceededCount());
        System.out.println("Tests fallidos: " + summary.getTestsFailedCount());
        System.out.println("Tiempo total: " + summary.getTimeFinished() + " ms");
    }
}
```