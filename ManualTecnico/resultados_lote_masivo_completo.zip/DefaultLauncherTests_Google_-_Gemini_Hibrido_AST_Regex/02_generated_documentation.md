Claro, aquí tienes la documentación técnica exhaustiva para la clase `DefaultLauncherTests`, siguiendo la estructura y restricciones solicitadas.

***

### Documentación Técnica: `org.junit.platform.launcher.core.DefaultLauncherTests`

**Autor:** JUnit Platform Team (original), Arquitecto de Software Senior (documentación)

### 1. Resumen Ejecutivo

La clase `DefaultLauncherTests` es una suite de pruebas de integración para la implementación `DefaultLauncher` de JUnit Platform. Su propósito principal es validar el comportamiento del lanzador en una amplia variedad de escenarios, incluyendo el descubrimiento de pruebas, la ejecución de planes, el manejo de errores, la aplicación de filtros y la gestión de la configuración. Esta clase es fundamental para garantizar la robustez, corrección y fiabilidad del ciclo de vida de ejecución de pruebas en JUnit 5.

### 2. Especificación de Métodos y Constructores

A continuación se detallan todos los métodos, constructores y clases internas de `DefaultLauncherTests`.

#### **Constructor**

##### `DefaultLauncherTests()`
Constructor por defecto de la clase de pruebas. No realiza ninguna operación especial.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `DefaultLauncherTests` | Una nueva instancia de la clase de pruebas. |

| Excepción | Condición |
| :--- | :--- |
| *(ninguna)* | N/A |

---

#### **Métodos de Prueba**

##### `constructLauncherWithoutAnyEngines()`
Verifica que se lanza una `JUnitException` al intentar descubrir pruebas con un `Launcher` que no ha sido configurado con ningún `TestEngine`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

| Excepción | Condición |
| :--- | :--- |
| `AssertionError` | Si la aserción de la excepción esperada falla. |

---
##### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`
Verifica que se lanza una `JUnitException` al intentar descubrir pruebas con un `Launcher` configurado con múltiples `TestEngine` que tienen el mismo ID.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

| Excepción | Condición |
| :--- | :--- |
| `AssertionError` | Si la aserción de la excepción esperada falla. |

---
##### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`
Verifica que el descubrimiento de pruebas con un `TestEngine` que no contiene ninguna prueba resulta en un `TestPlan` con un único nodo raíz (el descriptor del motor).

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

| Excepción | Condición |
| :--- | :--- |
| `AssertionError` | Si el plan de pruebas no contiene exactamente un nodo raíz. |

---
##### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`
Verifica que si un `TestEngine` devuelve `null` durante la fase de descubrimiento, el `TestPlan` resultante contiene un nodo raíz para ese motor y se notifica un fallo de descubrimiento al `LauncherDiscoveryListener`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

| Excepción | Condición |
| :--- | :--- |
| `AssertionError` | Si las aserciones sobre el plan de pruebas o las interacciones del listener fallan. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)`**: Sobrescribe el método para que siempre devuelva `null`, simulando un fallo en el descubrimiento.
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `discoveryRequest` | `EngineDiscoveryRequest` | Sí | La solicitud de descubrimiento. |
    | `uniqueId` | `UniqueId` | Sí | El ID único para el motor. |
    | **Retorno** | `TestDescriptor` | Siempre devuelve `null`. |
    | **Excepción** | *(ninguna)* | N/A |

---
##### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`
Verifica que si un `TestEngine` lanza un `Error` o `RuntimeException` durante el descubrimiento, se crea un descriptor de error y la ejecución de este descriptor resulta en un fallo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `throwableClass` | `Class<? extends Throwable>` | Sí | La clase de la excepción (`Error` o `RuntimeException`) que se lanzará durante la prueba. |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

| Excepción | Condición |
| :--- | :--- |
| `AssertionError` | Si las aserciones sobre el plan de pruebas o el resultado de la ejecución fallan. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId)`**: Sobrescribe el método para lanzar una instancia de `throwableClass`, simulando un error crítico durante el descubrimiento.
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `discoveryRequest` | `EngineDiscoveryRequest` | Sí | La solicitud de descubrimiento. |
    | `uniqueId` | `UniqueId` | Sí | El ID único para el motor. |
    | **Retorno** | `TestDescriptor` | Teóricamente retorna `null` si la excepción es capturada, pero la intención es que la excepción se propague como no chequeada. |
    | **Excepción** | `Throwable` | Lanza una instancia de la clase `throwableClass` proporcionada. |

---
##### `reportsEngineExecutionFailuresWithoutPriorEvents()`
Verifica que si un `TestEngine` lanza una excepción inmediatamente en su método `execute`, el `TestExecutionListener` es notificado correctamente con un resultado de ejecución fallido.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`execute(ExecutionRequest request)`**: Sobrescribe el método para lanzar inmediatamente una `RuntimeException`.
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |
    | **Retorno** | `void` | N/A |
    | **Excepción** | `RuntimeException` | Siempre se lanza para simular un fallo de ejecución. |

---
##### `reportsEngineExecutionFailuresForSkippedEngine()`
Verifica que si un `TestEngine` reporta que la ejecución fue omitida (`executionSkipped`) y luego lanza una excepción, el fallo de ejecución tiene prioridad y se reporta correctamente.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`execute(ExecutionRequest request)`**: Notifica que la ejecución del motor fue omitida y luego lanza una `RuntimeException`.
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |
    | **Retorno** | `void` | N/A |
    | **Excepción** | `RuntimeException` | Siempre se lanza después de notificar el `skip`. |

---
##### `reportsEngineExecutionFailuresForStartedEngine()`
Verifica que si un `TestEngine` reporta el inicio de la ejecución (`executionStarted`) y luego lanza una excepción, el fallo se captura y reporta adecuadamente.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`execute(ExecutionRequest request)`**: Notifica el inicio de la ejecución y luego lanza una `RuntimeException`.
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |
    | **Retorno** | `void` | N/A |
    | **Excepción** | `RuntimeException` | Siempre se lanza después de notificar el inicio. |

---
##### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`
Verifica que si un `TestEngine` reporta una finalización exitosa (`executionFinished`) pero luego lanza una excepción, el error de ejecución tiene prioridad y se reporta como el resultado final.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`execute(ExecutionRequest request)`**: Notifica un inicio y finalización exitosa, y luego lanza una `RuntimeException`.
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |
    | **Retorno** | `void` | N/A |
    | **Excepción** | `RuntimeException` | Siempre se lanza después de notificar la finalización. |

---
##### `reportsEngineExecutionFailuresForFailedFinishedEngine()`
Verifica que si un `TestEngine` reporta una finalización fallida y luego lanza otra excepción, la nueva excepción se reporta como la causa principal y el fallo original se adjunta como una excepción suprimida.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`execute(ExecutionRequest request)`**: Notifica un inicio y una finalización fallida, y luego lanza una nueva `RuntimeException`.
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |
    | **Retorno** | `void` | N/A |
    | **Excepción** | `RuntimeException` | Siempre se lanza después de notificar la finalización fallida. |

---
##### `reportsSkippedEngines()`
Verifica que cuando un `TestEngine` reporta que su ejecución fue omitida, el `TestExecutionListener` recibe la notificación `executionSkipped` y no se invocan los métodos `executionStarted` o `executionFinished`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`execute(ExecutionRequest request)`**: Notifica que la ejecución del motor fue omitida (`executionSkipped`).
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |
    | **Retorno** | `void` | N/A |
    | **Excepción** | *(ninguna)* | N/A |

---
##### `reportsFinishedEngines()`
Verifica que un `TestEngine` que completa su ciclo de vida de ejecución normalmente (inicio y fin) notifica correctamente al `TestExecutionListener`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`execute(ExecutionRequest request)`**: Simula un ciclo de ejecución normal notificando `executionStarted` y `executionFinished`.
    | Parámetro | Tipo | Requerido | Descripción |
    | :--- | :--- | :--- | :--- |
    | `request` | `ExecutionRequest` | Sí | La solicitud de ejecución. |
    | **Retorno** | `void` | N/A |
    | **Excepción** | *(ninguna)* | N/A |

---
##### `discoverTestPlanForSingleEngine()`
Verifica que el descubrimiento de pruebas para un único `TestEngine` con múltiples pruebas genera un `TestPlan` con un solo nodo raíz y los hijos correspondientes.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `discoverTestPlanForMultipleEngines()`
Verifica que el descubrimiento de pruebas para múltiples `TestEngine` genera un `TestPlan` con un nodo raíz por cada motor.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `launcherAppliesPostDiscoveryFilters()`
Verifica que los `PostDiscoveryFilter` se aplican correctamente después de la fase de descubrimiento, filtrando el `TestPlan` resultante.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`
Verifica que si no se proporcionan parámetros de configuración, el `Launcher` pasa un mapa de parámetros vacío al `TestEngine` durante la ejecución.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`
Verifica que los parámetros de configuración proporcionados al `Launcher` se pasan correctamente al `TestEngine` durante la ejecución.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`
Verifica que, en ausencia de parámetros de configuración explícitos, el `Launcher` recurre a las propiedades del sistema (`System.properties`) para resolverlos.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `withAdditionalListener()`
Verifica que un `TestExecutionListener` adicional, como `SummaryGeneratingListener`, se registra y se invoca correctamente durante la ejecución de las pruebas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`
Verifica que el `TestPlan` se "poda" (prunes) correctamente, eliminando los contenedores que quedan vacíos después de aplicar los `PostDiscoveryFilter`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineSpy`**
  * **`discover(...)`**: Crea una estructura de descriptores (motor -> contenedor -> test) para la prueba.
* **Clase Anónima Interna: `TestDescriptorStub`**
  * **`getType()`**: Devuelve `Type.CONTAINER` para simular un descriptor de tipo contenedor.

---
##### `reportsDynamicTestDescriptorsCorrectly()`
Verifica que los descriptores de prueba dinámicos, registrados durante la ejecución, se reportan correctamente a los `TestExecutionListener` y se integran en el `TestPlan`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineSpy`**
  * **`discover(...)`**: Descubre un descriptor inicial de tipo `CONTAINER_AND_TEST`.
  * **`execute(...)`**: Durante la ejecución, registra dinámicamente un nuevo descriptor de prueba hijo y notifica su ciclo de vida.
* **Clase Anónima Interna: `TestDescriptorStub`**
  * **`getType()`**: Devuelve `Type.CONTAINER_AND_TEST`.

---
##### `launcherCanExecuteTestPlanExactlyOnce()`
Verifica que un `TestPlan` solo puede ser ejecutado una vez. Un segundo intento de ejecución debe lanzar una `JUnitException`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`
Verifica que un `TestEngine` de terceros que utiliza el prefijo reservado `junit-` en su ID genera una `DiscoveryIssueException` durante el descubrimiento.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `thirdPartyEngineClaimingToBeJupiterResultsInException()`
Verifica que un `TestEngine` de terceros no puede usar el ID reservado `junit-jupiter`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `thirdPartyEngineClaimingToBeVintageResultsInException()`
Verifica que un `TestEngine` de terceros no puede usar el ID reservado `junit-vintage`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`
Verifica que en modo "dry run" (`-n`), las pruebas se reportan como omitidas (`skipped`) en lugar de ser ejecutadas, pero los eventos de inicio y fin de contenedores se disparan normalmente.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `notifiesDiscoveryListenersOfProcessedSelectors()`
Verifica que todos los `LauncherDiscoveryListener` registrados (en la configuración, en el lanzador y en la solicitud) son notificados cuando un selector es procesado por un motor.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Itera sobre los selectores y notifica `selectorProcessed` para cada uno.

---
##### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)`
Verifica que si un motor encuentra un `DiscoveryIssue` crítico (ERROR), la ejecución del motor falla con una `DiscoveryIssueException`. Los issues no críticos (WARNING) se registran en el log.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Fixture para capturar los registros de log generados. |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `ERROR` y otro de `WARNING`.
* **Clase Anónima Interna: `EngineDescriptor`**
  * **`getTags()`**: Devuelve un tag de prueba para verificar que el descriptor se creó correctamente.

---
##### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)`
Verifica que los `DiscoveryIssue` no críticos (INFO, WARNING) se registran en el log durante una ejecución normal y exitosa.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Fixture para capturar los registros de log generados. |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `INFO`.
  * **`execute(...)`**: Realiza una ejecución exitosa.

---
##### `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)`
Verifica que si el descubrimiento de un motor falla con una excepción, todos los `DiscoveryIssue` (críticos y no críticos) encontrados antes del fallo se registran en el log.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Fixture para capturar los registros de log generados. |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Emite issues de tipo `ERROR` e `INFO` y luego lanza una `RuntimeException`.

---
##### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)`
Verifica que los `DiscoveryIssue` no críticos se registran en el log incluso si la fase de ejecución del motor falla posteriormente.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | Fixture para capturar los registros de log generados. |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `INFO`.
  * **`execute(...)`**: Lanza una `RuntimeException`.

---
##### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`
Verifica que si un selector `UniqueId` apunta a un motor específico pero no puede ser resuelto por él, se genera un `DiscoveryIssue` crítico que causa un fallo en la ejecución.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`
Verifica que un selector `UniqueId` que no puede ser resuelto y que no pertenece al motor actual es simplemente ignorado, sin causar un fallo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `reportsEngineExecutionFailureForSelectorResolutionFailure()`
Verifica que si un motor lanza una excepción al intentar resolver un selector, se genera un `DiscoveryIssue` crítico que causa un fallo en la ejecución.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `allowsConfiguringCriticalDiscoveryIssueSeverity()`
Verifica que la severidad mínima para que un `DiscoveryIssue` sea considerado crítico puede ser configurada a través de un parámetro de configuración.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `INFO`, que será tratado como crítico por la configuración de la prueba.

---
##### `failsIfCriticalSeverityIsConfiguredIncorrectly()`
Verifica que se lanza una `JUnitException` si se proporciona un valor inválido para el parámetro de configuración de la severidad crítica de los `DiscoveryIssue`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `INFO`.
  * **`execute(...)`**: Realiza una ejecución exitosa.

---
##### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`
Verifica que si se configura que los fallos por `DiscoveryIssue` ocurran en la fase de "discovery", se lanza una `DiscoveryIssueException` directamente desde el método `discover` del lanzador.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `ERROR`.

---
##### `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)`
Verifica que los `DiscoveryIssue` no críticos se registran en el log solo una vez, independientemente de si la fase de fallo está configurada como "discovery" o "execution".

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `phase` | `String` | Sí | La fase configurada para el fallo ("discovery" o "execution"). |
| `listener` | `LogRecordListener` | Sí | Fixture para capturar los registros de log generados. |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Emite un `DiscoveryIssue` de severidad `WARNING`.
  * **`execute(...)`**: Realiza una ejecución exitosa.

---
##### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`
Verifica que se lanza una `JUnitException` si se proporciona un valor inválido para el parámetro de configuración de la fase de fallo de los `DiscoveryIssue`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`
Verifica que si se solicita la cancelación de la ejecución antes de que comience, los nodos hijos del motor se reportan como omitidos (`skipped`) y el motor finaliza como abortado (`ABORTED`), sin llegar a ejecutar el método `execute` del motor.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *(ninguno)* | N/A | N/A | N/A |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

* **Clase Anónima Interna: `TestEngineStub`**
  * **`discover(...)`**: Crea una estructura de descriptores (motor -> contenedor -> test).

---

#### **Métodos de Ayuda (Privados)**

##### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`
Método de ayuda para verificar que un `TestEngine` ha fallado durante la fase de descubrimiento y que el `LauncherDiscoveryListener` ha sido notificado correctamente.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `testEngine` | `TestEngine` | Sí | El motor de pruebas cuyo fallo se está verificando. |
| `inOrder` | `InOrder` | Sí | Objeto `InOrder` de Mockito para verificar la secuencia de llamadas. |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | El listener mockeado cuyas interacciones se verifican. |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `assertImposter(String id)`
Método de ayuda para verificar que un `TestEngine` que intenta usar un ID reservado (`junit-jupiter` o `junit-vintage`) provoca una `JUnitException`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | `String` | Sí | El ID reservado que se va a probar. |

| Retorno | Descripción |
| :--- | :--- |
| `void` | Este método no retorna ningún valor. |

---
##### `execute(TestEngine engine)`
Sobrecarga del método de ayuda `execute` que ejecuta un `TestEngine` con configuraciones por defecto.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | El motor de pruebas a ejecutar. |

| Retorno | Descripción |
| :--- | :--- |
| `ReportedData` | Un objeto `ReportedData` con los resultados de la ejecución. |

---
##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)`
Sobrecarga del método de ayuda `execute` que permite personalizar la solicitud de descubrimiento.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | El motor de pruebas a ejecutar. |
| `discoveryConfigurer` | `UnaryOperator<...>` | Sí | Una función para configurar el `LauncherDiscoveryRequestBuilder`. |

| Retorno | Descripción |
| :--- | :--- |
| `ReportedData` | Un objeto `ReportedData` con los resultados de la ejecución. |

---
##### `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)`
Método de ayuda principal para ejecutar un `TestEngine` con configuraciones personalizadas tanto para el descubrimiento como para la ejecución.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `engine` | `TestEngine` | Sí | El motor de pruebas a ejecutar. |
| `discoveryConfigurer` | `UnaryOperator<...>` | Sí | Una función para configurar el `LauncherDiscoveryRequestBuilder`. |
| `executionConfigurer` | `UnaryOperator<...>` | Sí | Una función para configurar el `LauncherExecutionRequestBuilder`. |

| Retorno | Descripción |
| :--- | :--- |
| `ReportedData` | Un objeto `ReportedData` con los resultados de la ejecución. |

---
##### `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)`
Método de ayuda para buscar el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con un nivel de severidad específico.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `listener` | `LogRecordListener` | Sí | El listener que ha capturado los registros. |
| `level` | `Level` | Sí | El nivel de log (`INFO`, `WARNING`, etc.) a buscar. |

| Retorno | Descripción |
| :--- | :--- |
| `LogRecord` | El primer registro de log que coincide con los criterios. |

| Excepción | Condición |
| :--- | :--- |
| `NoSuchElementException` | Si no se encuentra ningún registro que coincida. |

---

#### **Clases Internas y Registros**

##### `record ReportedData`
Un registro (`record`) inmutable para encapsular los datos clave reportados durante una ejecución de prueba, facilitando las aserciones en los métodos de prueba.

* **Constructor Canónico:** `ReportedData(TestPlan testPlan, TestIdentifier testIdentifier, TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)`

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `testPlan` | `TestPlan` | Sí | El plan de pruebas que fue ejecutado. |
| `testIdentifier` | `TestIdentifier` | Sí | El identificador del nodo raíz de la prueba ejecutada. |
| `testExecutionResult` | `TestExecutionResult` | Sí | El resultado de la ejecución del nodo raíz. |
| `startTime` | `Instant` | Sí | El momento en que comenzó la ejecución. |
| `finishTime` | `Instant` | Sí | El momento en que finalizó la ejecución. |

| Retorno | Descripción |
| :--- | :--- |
| `ReportedData` | Una nueva instancia del registro. |

---

### 3. Ejemplo de Uso

El siguiente bloque de código muestra un caso de uso típico del `DefaultLauncher`, similar a los escenarios probados en esta clase. El ejemplo configura un motor de pruebas simple, descubre las pruebas, registra un listener para obtener un resumen y ejecuta el plan de pruebas.

```java
import org.junit.platform.engine.TestDescriptor;
import org.junit.platform.engine.support.hierarchical.DemoHierarchicalTestEngine;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners.TestExecutionSummary;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;

public class DefaultLauncherExample {

    // Clase de ejemplo con una prueba
    public static class MySampleTest {
        public void testMethod() {
            // Lógica de la prueba
            System.out.println("Executing testMethod...");
        }
    }

    public static void main(String[] args) {
        // 1. Crear un motor de pruebas de demostración y añadirle una prueba.
        // En un caso real, los motores se descubrirían a través del ServiceLoader.
        DemoHierarchicalTestEngine testEngine = new DemoHierarchicalTestEngine("demo-engine");
        TestDescriptor test = testEngine.addTest("MySampleTest#testMethod", () -> new MySampleTest().testMethod());

        // 2. Crear una instancia del Launcher con el motor de pruebas.
        Launcher launcher = LauncherFactory.create(testEngine);

        // 3. Crear un listener para recopilar el resumen de la ejecución.
        SummaryGeneratingListener listener = new SummaryGeneratingListener();
        launcher.registerTestExecutionListeners(listener);

        // 4. Construir una solicitud de descubrimiento para una clase específica.
        LauncherDiscoveryRequest discoveryRequest = LauncherDiscoveryRequestBuilder.request()
                .selectors(selectClass(MySampleTest.class))
                .build();

        // 5. Descubrir el plan de pruebas.
        TestPlan testPlan = launcher.discover(discoveryRequest);
        System.out.println("Test plan discovered. Contains tests: " + testPlan.containsTests());

        // 6. Ejecutar el plan de pruebas.
        System.out.println("Executing test plan...");
        launcher.execute(testPlan);

        // 7. Obtener y mostrar el resumen de la ejecución.
        TestExecutionSummary summary = listener.getSummary();
        System.out.println("\n--- Test Execution Summary ---");
        System.out.println("Tests found: " + summary.getTestsFoundCount());
        System.out.println("Tests succeeded: " + summary.getTestsSucceededCount());
        System.out.println("Tests failed: " + summary.getTestsFailedCount());
        summary.printTo(new java.io.PrintWriter(System.out));
    }
}
```