# Documentación técnica — `flask/app.py`

## 1. Descripción general

Este módulo contiene la implementación de la clase **`Flask`**, el objeto central del framework Flask y el punto de entrada de toda aplicación WSGI construida con él.

El archivo implementa la parte **"con E/S" / runtime** del framework: toma la clase base `App` (definida en `flask.sansio.app`, que contiene la lógica agnóstica de protocolo: registro de rutas, blueprints, configuración, manejadores de errores, etc.) y le añade todo lo que depende del entorno WSGI real:

- Atención del ciclo de vida completo de una petición HTTP (`wsgi_app`, `full_dispatch_request`, `dispatch_request`, `finalize_request`).
- Creación y gestión de contextos de aplicación/petición (`app_context`, `request_context`, `test_request_context`).
- Conversión de valores devueltos por las vistas en objetos `Response` (`make_response`).
- Generación de URLs (`url_for`, `create_url_adapter`).
- Integración con Jinja2 (`create_jinja_environment`), sesiones, señales, CLI (Click) y servidor de desarrollo (`run`).
- Soporte para vistas asíncronas (`ensure_sync`, `async_to_sync`).
- Utilidades de pruebas (`test_client`, `test_cli_runner`).

En resumen: **`App` define "qué se registra"; `Flask` define "cómo se ejecuta"**.

---

## 2. Dependencias principales

| Origen | Uso |
|---|---|
| `werkzeug.routing` (`MapAdapter`, `Rule`, `BuildError`, `RequestRedirect`, `RoutingException`) | Enrutamiento y construcción de URLs. |
| `werkzeug.exceptions` (`HTTPException`, `InternalServerError`, `BadRequestKeyError`) | Manejo de errores HTTP. |
| `werkzeug.serving` / `run_simple` | Servidor de desarrollo. |
| `werkzeug.datastructures` (`Headers`, `ImmutableDict`) | Cabeceras y configuración inmutable por defecto. |
| `click` + `flask.cli` | Grupo de comandos CLI de la aplicación y carga de `.env`. |
| `.ctx.AppContext` | Contexto unificado de aplicación/petición. |
| `.globals` (`_cv_app`, `app_ctx`, `request`, `session`, `g`) | Proxies y variable de contexto activa. |
| `.sessions` (`SessionInterface`, `SecureCookieSessionInterface`) | Interfaz de sesión por defecto. |
| `.signals` | Señales Blinker del ciclo de vida (`request_started`, `request_finished`, `got_request_exception`, `request_tearing_down`, `appcontext_tearing_down`). |
| `.wrappers` (`Request`, `Response`) | Clases de petición/respuesta de Flask. |
| `.templating.Environment` | Entorno Jinja de Flask. |
| `asgiref.sync` (opcional) | Ejecución de vistas `async def`. |

Los imports bajo `if t.TYPE_CHECKING` (`WSGIEnvironment`, `StartResponse`, `FlaskClient`, `FlaskCliRunner`, `HeadersValue`) existen sólo para anotaciones de tipo y evitan importaciones circulares/costosas en tiempo de ejecución.

---

## 3. Componentes a nivel de módulo

### 3.1 Variables de tipo (`TypeVar`)

```python
T_shell_context_processor, T_teardown, T_template_filter,
T_template_global, T_template_test, F
```

Se usan para preservar la firma exacta de las funciones decoradas (decoradores que devuelven el mismo callable) y para tipar genéricamente los *wrappers* internos.

### 3.2 `_make_timedelta(value) -> timedelta | None`

Función auxiliar que normaliza un valor de configuración a `timedelta`:

- `None` → `None`
- `timedelta` → se devuelve tal cual
- `int` → se interpreta como segundos.

### 3.3 Compatibilidad de firmas: `remove_ctx(f)` y `add_ctx(f)`

Par de decoradores internos que implementan la **capa de retrocompatibilidad** para los métodos del ciclo de vida cuya firma cambió para recibir un primer parámetro `ctx: AppContext`.

- **`remove_ctx(f)`**: envuelve un método *sobreescrito por el usuario* con la firma antigua (sin `ctx`). Si el primer argumento posicional es un `AppContext`, lo descarta antes de invocar al método original.
- **`add_ctx(f)`**: envuelve el método *base de `Flask`* para que, si se le llama sin `ctx` (por ejemplo desde un `super().method(...)` escrito con la firma antigua), inserte automáticamente el contexto activo obtenido de `app_ctx._get_current_object()`.

Ambos usan `functools.update_wrapper` para conservar metadatos (`__name__`, `__doc__`, etc.).

---

## 4. Clase `Flask(App)`

Objeto central de la aplicación. Implementa el protocolo WSGI (es invocable: `app(environ, start_response)`) y actúa como registro central de vistas, reglas de URL, configuración de plantillas, etc.

Se instancia típicamente como:

```python
from flask import Flask
app = Flask(__name__)
```

El primer parámetro (`import_name`) determina cómo se resuelven recursos en disco (`root_path`, carpetas `static`/`templates`, ruta de instancia) y es utilizado por extensiones para mejorar la información de depuración.

### 4.1 Atributos de clase

| Atributo | Descripción |
|---|---|
| `default_config` | `ImmutableDict` con todos los valores de configuración por defecto: `DEBUG`, `TESTING`, `SECRET_KEY`, `SECRET_KEY_FALLBACKS`, `PERMANENT_SESSION_LIFETIME`, familia `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, `MAX_FORM_MEMORY_SIZE`, `MAX_FORM_PARTS`, `TRUSTED_HOSTS`, `SERVER_NAME`, `APPLICATION_ROOT`, `PREFERRED_URL_SCHEME`, `TRAP_HTTP_EXCEPTIONS`, `PROPAGATE_EXCEPTIONS`, `TEMPLATES_AUTO_RELOAD`, `MAX_COOKIE_SIZE`, `PROVIDE_AUTOMATIC_OPTIONS`, etc. |
| `request_class` | Clase usada para los objetos de petición (`flask.Request`). |
| `response_class` | Clase usada para los objetos de respuesta (`flask.Response`). |
| `session_interface` | Interfaz de sesión; por defecto `SecureCookieSessionInterface()`. |

### 4.2 `__init_subclass__(cls, **kwargs)`

Hook ejecutado al definir cualquier subclase de `Flask`. Su función es **detectar métodos sobreescritos con la firma antigua** (sin el parámetro `ctx: AppContext`) entre:

```
handle_http_exception, handle_user_exception, handle_exception, log_exception,
dispatch_request, full_dispatch_request, finalize_request,
make_default_options_response, preprocess_request, process_response,
do_teardown_request, do_teardown_appcontext
```

Mecanismo:

1. Para cada método, se compara con el de `Flask`; si no fue sobreescrito, se ignora.
2. Se inspecciona con `inspect.signature` el segundo parámetro (tras `self`) y se acepta si: se llama `ctx` sin anotación, su anotación en cadena termina en `AppContext`, o su anotación es una clase subtipo de `AppContext`.
3. Si no cumple, emite un `DeprecationWarning` (indicando que la firma antigua no se soportará en Flask 4.0) y aplica los *wrappers*: `remove_ctx` sobre el método de la subclase y `add_ctx` sobre el método base de `Flask`.

### 4.3 `__init__(...)`

Parámetros: `import_name`, `static_url_path`, `static_folder`, `static_host`, `host_matching`, `subdomain_matching`, `template_folder`, `instance_path`, `instance_relative_config`, `root_path`.

Tareas:

1. Delega la inicialización común en `App.__init__`.
2. Crea `self.cli = cli.AppGroup()` y asigna `self.cli.name = self.name` (grupo de comandos Click de la app).
3. Si hay `static_folder` configurado, valida la coherencia `static_host`/`host_matching` y registra la regla de URL `"{static_url_path}/<path:filename>"` con endpoint `"static"`. La vista se registra mediante una **`weakref.ref` a la app** para evitar un ciclo de referencias entre la aplicación y la función de vista.

---

## 5. Métodos agrupados por responsabilidad

### 5.1 Recursos y archivos estáticos

| Método | Descripción |
|---|---|
| `get_send_file_max_age(filename)` | Devuelve el valor `max_age` de caché para `send_file`, a partir de `SEND_FILE_MAX_AGE_DEFAULT` (acepta `int` o `timedelta`; `None` ⇒ peticiones condicionales). |
| `send_static_file(filename)` | Vista que sirve archivos desde `static_folder` usando `send_from_directory`. Lanza `RuntimeError` si no hay carpeta estática. |
| `open_resource(resource, mode="rb", encoding=None)` | Abre un archivo relativo a `root_path`, **sólo lectura** (`"r"`, `"rt"`, `"rb"`); otros modos provocan `ValueError`. |
| `open_instance_resource(resource, mode="rb", encoding="utf-8")` | Abre un archivo relativo a `instance_path`; aquí **sí** se permite escritura. |

### 5.2 Plantillas (Jinja2)

| Método | Descripción |
|---|---|
| `create_jinja_environment()` | Construye el entorno Jinja a partir de `jinja_options`, fijando `autoescape` (`select_jinja_autoescape`) y `auto_reload` (según `TEMPLATES_AUTO_RELOAD` o `debug`). Inyecta los globales `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g`, y configura la política `json.dumps_function`. |
| `update_template_context(ctx, context)` | Ejecuta los *context processors* de la app y de los blueprints implicados (en orden inverso), actualizando `context` **in place**. Los valores originales pasados a `render_template` se re-aplican al final para que tengan precedencia. |

### 5.3 URLs y enrutamiento

| Método | Descripción |
|---|---|
| `create_url_adapter(request)` | Crea el `MapAdapter`. Con petición: aplica `TRUSTED_HOSTS`, recalcula `request.host` con `get_host`, ajusta `server_name`/`subdomain` según `host_matching` y `subdomain_matching`, y llama a `url_map.bind_to_environ`. Sin petición: requiere `SERVER_NAME` y usa `url_map.bind` con `APPLICATION_ROOT` y `PREFERRED_URL_SCHEME`; si no hay `SERVER_NAME`, devuelve `None`. |
| `raise_routing_exception(request)` | *(interno)* Relanza `request.routing_exception`. En modo debug, convierte redirecciones de enrutamiento que descartarían el cuerpo (no 307/308, métodos con cuerpo) en `FormDataRoutingRedirect` para facilitar la depuración. |
| `url_for(endpoint, *, _anchor, _method, _scheme, _external, **values)` | Construye una URL. Resuelve endpoints relativos (`.endpoint`) respecto al blueprint actual, decide `_external` por defecto (interno dentro de una petición, externo fuera), valida que `_scheme` sólo se use con `_external=True`, aplica `inject_url_defaults`, delega en `url_adapter.build` y, ante `BuildError`, llama a `handle_url_build_error`. Añade el ancla con *quoting* mediante `urllib.parse.quote`. |

### 5.4 Construcción de respuestas

**`make_response(rv) -> Response`**

Normaliza el valor devuelto por una vista a una instancia de `response_class`:

- **Tuplas**: `(body, status, headers)`, `(body, status)` o `(body, headers)`; otros tamaños ⇒ `TypeError`.
- `str` / `bytes` / `bytearray` / iteradores (respuesta en *streaming*) ⇒ se pasan al constructor de `response_class`.
- `dict` / `list` ⇒ respuesta JSON vía `self.json.response`.
- Otra `BaseResponse` o callable WSGI ⇒ `response_class.force_type`.
- `None` o tipo no soportado ⇒ `TypeError` con mensaje descriptivo.

Finalmente aplica `status` (como cadena o código numérico) y extiende las cabeceras.

### 5.5 Manejo de errores y excepciones

| Método | Descripción |
|---|---|
| `handle_http_exception(ctx, e)` | Busca un manejador registrado para la `HTTPException` (por código y por MRO, considerando los blueprints). Las excepciones sin `code` y las `RoutingException` se devuelven sin tocar. |
| `handle_user_exception(ctx, e)` | Punto de entrada para excepciones durante el *dispatch*. Marca `show_exception` en `BadRequestKeyError` si procede (`debug` o `TRAP_BAD_REQUEST_ERRORS`), delega `HTTPException` en `handle_http_exception` (salvo `trap_http_exception`), o busca un manejador; si no hay, re-lanza. |
| `handle_exception(ctx, e)` | Trata excepciones sin manejador. Envía `got_request_exception`; si `PROPAGATE_EXCEPTIONS` (o `testing`/`debug`) re-lanza; en caso contrario registra el error (`log_exception`), crea un `InternalServerError(original_exception=e)`, aplica un manejador de 500 si existe y finaliza la petición con `from_error_handler=True`. |
| `log_exception(ctx, exc_info)` | Registra la excepción como `error` en `self.logger`, incluyendo ruta y método de la petición. |

### 5.6 Ciclo de vida de la petición

| Método | Descripción |
|---|---|
| `wsgi_app(environ, start_response)` | **Aplicación WSGI real**. Crea y hace *push* del `AppContext` derivado del `environ`, invoca `full_dispatch_request`, captura excepciones hacia `handle_exception`, devuelve `response(environ, start_response)` y, en el `finally`, preserva el contexto para el depurador de Werkzeug si corresponde, aplica `should_ignore_error` y hace `ctx.pop(error)`. Se expone como atributo para poder envolverlo con middlewares (`app.wsgi_app = MyMiddleware(app.wsgi_app)`). |
| `__call__(environ, start_response)` | Delega en `wsgi_app`; permite que el servidor WSGI invoque directamente el objeto app. |
| `full_dispatch_request(ctx)` | Marca `_got_first_request`, emite `DeprecationWarning` si hay `should_ignore_error`, envía `request_started`, ejecuta `preprocess_request` (cortocircuitando si devuelve algo no nulo), llama a `dispatch_request`, captura excepciones con `handle_user_exception` y termina con `finalize_request`. |
| `dispatch_request(ctx)` | Despacho propiamente dicho: relanza excepciones de enrutamiento, responde automáticamente a `OPTIONS` si la regla lo permite, y en otro caso invoca `view_functions[rule.endpoint]` con `view_args` (envuelto en `ensure_sync`). |
| `finalize_request(ctx, rv, from_error_handler=False)` | Convierte `rv` en respuesta (`make_response`), ejecuta `process_response` y envía `request_finished`. Con `from_error_handler=True`, los fallos de post-procesado se registran en lugar de propagarse. |
| `make_default_options_response(ctx)` | Construye la respuesta `OPTIONS` por defecto con la cabecera `Allow` a partir de `ctx.url_adapter.allowed_methods()`. |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y luego `before_request_funcs` de la app y los blueprints (app primero, blueprints en orden inverso). Si algún `before_request` devuelve un valor no nulo, se devuelve como respuesta y se detiene el procesamiento. |
| `process_response(ctx, response)` | Ejecuta las funciones `after_this_request` (`ctx._after_request_functions`) y los `after_request_funcs` (en orden inverso de registro, blueprints antes de la app) y, si la sesión no es nula, guarda la sesión mediante `session_interface.save_session`. |
| `do_teardown_request(ctx, exc=None)` | Ejecuta los `teardown_request` de blueprints y app y envía `request_tearing_down`. Usa `_CollectErrors` para ejecutar **todos** los callbacks aunque alguno falle, agregando los errores al final (`raise_any`). |
| `do_teardown_appcontext(ctx, exc=None)` | Equivalente para `teardown_appcontext`, seguido de la señal `appcontext_tearing_down`, con la misma recolección de errores. |

**Flujo resumido de una petición:**

```
__call__ → wsgi_app
            ├── request_context(environ) → ctx.push()
            ├── full_dispatch_request
            │     ├── request_started
            │     ├── preprocess_request        (url_value_preprocessors + before_request)
            │     ├── dispatch_request          (OPTIONS automático o vista)
            │     │     └── [excepción] → handle_user_exception → handle_http_exception
            │     └── finalize_request
            │           ├── make_response
            │           ├── process_response    (after_request + guardar sesión)
            │           └── request_finished
            ├── [excepción no manejada] → handle_exception (got_request_exception, log_exception)
            └── ctx.pop(error) → do_teardown_request / do_teardown_appcontext
```

### 5.7 Contextos

| Método | Descripción |
|---|---|
| `app_context()` | Devuelve un `AppContext(self)`; al hacer *push* habilita `current_app` y `g`. Pensado para uso como bloque `with` fuera de peticiones (inicialización, scripts, pruebas). |
| `request_context(environ)` | Crea un `AppContext` con información de petición a partir de un `environ` WSGI (`AppContext.from_environ`). Uso interno; para pruebas se recomienda `test_request_context`. |
| `test_request_context(*args, **kwargs)` | Construye un `environ` con `flask.testing.EnvironBuilder` (aceptando `path`, `base_url`, `subdomain`, `url_scheme`, `data`, `json`, …) y devuelve el contexto correspondiente. |

### 5.8 Soporte asíncrono

| Método | Descripción |
|---|---|
| `ensure_sync(func)` | Devuelve la función tal cual si es síncrona; si es corrutina (`iscoroutinefunction`), la envuelve con `async_to_sync`. Se aplica a vistas, manejadores de errores, hooks y señales. |
| `async_to_sync(func)` | Convierte una función corrutina en síncrona mediante `asgiref.sync.async_to_sync`. Si `asgiref` no está instalado, lanza `RuntimeError` indicando instalar Flask con el extra `async`. |

### 5.9 Servidor de desarrollo y CLI

**`run(host=None, port=None, debug=None, load_dotenv=True, **options)`**

Arranca el servidor de desarrollo (`werkzeug.serving.run_simple`). **No debe usarse en producción.** Comportamiento:

1. Si se ejecuta dentro de `flask run` (`FLASK_RUN_FROM_CLI == "true"`), se ignora la llamada (mostrando un aviso en rojo si no proviene del recargador).
2. Carga `.env`/`.flaskenv` (si `get_load_dotenv(load_dotenv)`), y `FLASK_DEBUG` sobreescribe `debug`; el argumento `debug` explícito tiene prioridad máxima.
3. Deriva host y puerto de `SERVER_NAME` (vía `urlsplit`) si no se indican; valores por defecto `127.0.0.1:5000`.
4. Fija por defecto `use_reloader`/`use_debugger` según `debug` y `threaded=True`; muestra el banner con `cli.show_server_banner`.
5. En el `finally` restablece `_got_first_request = False`.

**`make_shell_context()`** — Devuelve el diccionario de contexto para `flask shell`, con `app` y `g` más lo aportado por los `shell_context_processors` registrados.

### 5.10 Utilidades de pruebas

| Método | Descripción |
|---|---|
| `test_client(use_cookies=True, **kwargs)` | Crea un cliente de pruebas (`test_client_class` o `flask.testing.FlaskClient`). Usable como gestor de contexto para inspeccionar los *context locals*. Requiere `app.testing = True` para que las excepciones se propaguen. |
| `test_cli_runner(**kwargs)` | Crea un *runner* para probar comandos CLI (`test_cli_runner_class` o `flask.testing.FlaskCliRunner`), pasando la app como primer argumento. |

---

## 6. Notas de diseño relevantes

- **Separación sansio/runtime**: la lógica independiente del transporte vive en `App`; este módulo añade únicamente la capa WSGI, lo que permite reutilizar el registro de rutas/blueprints en otros contextos.
- **Contexto unificado**: `AppContext` sustituye a la separación clásica entre contexto de aplicación y de petición; se expone `ctx.has_request` para distinguir ambos casos.
- **Paso explícito de `ctx`**: los métodos del ciclo de vida reciben el contexto como primer parámetro en lugar de depender únicamente de proxies globales; `__init_subclass__` + `add_ctx`/`remove_ctx` garantizan compatibilidad con código anterior hasta Flask 4.0.
- **Evitación de ciclos de referencia**: la vista estática se registra con `weakref.ref(self)` (issue #3761).
- **Robustez en teardown**: `_CollectErrors` asegura que todos los callbacks de *teardown* se ejecuten, agregando los errores en lugar de abortar en el primero (cambio de 3.2).
- **Señales**: todas se emiten con `_async_wrapper=self.ensure_sync`, de modo que los receptores pueden ser corrutinas.