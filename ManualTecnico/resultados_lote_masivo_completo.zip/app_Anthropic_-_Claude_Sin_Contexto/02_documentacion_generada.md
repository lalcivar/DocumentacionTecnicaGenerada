# Documentación técnica — `flask/app.py`

## 1. Descripción general

Este módulo contiene la implementación de la clase **`Flask`**, el objeto central del framework Flask. El archivo define la capa **WSGI síncrona** del framework: es decir, la parte que recibe un `environ` de un servidor WSGI, construye el contexto de aplicación/petición, despacha la petición a la vista correspondiente, gestiona errores y devuelve una respuesta.

La clase `Flask` hereda de `App` (definida en `flask.sansio.app`), que contiene toda la lógica **independiente del protocolo** (registro de rutas, blueprints, configuración, logging, manejadores de errores, etc.). Por tanto, el reparto de responsabilidades es:

| Capa | Ubicación | Responsabilidad |
|---|---|---|
| `App` (sansio) | `flask/sansio/app.py` | Registro de rutas, blueprints, config, hooks, error handlers |
| `Flask` | **este archivo** | Ciclo de vida WSGI, contextos, despacho, respuestas, servidor de desarrollo, testing |

Funcionalidades principales que aporta el archivo:

- Punto de entrada WSGI (`__call__` / `wsgiI_app`).
- Creación y gestión de contextos de aplicación y de petición (`AppContext`).
- Despacho de peticiones y ejecución de hooks (`before_request`, `after_request`, `teardown_*`).
- Manejo jerárquico de excepciones (HTTP, de usuario, no controladas).
- Conversión del valor de retorno de una vista en un objeto `Response`.
- Generación de URLs (`url_for`).
- Creación del entorno Jinja2 y del contexto de plantillas.
- Servicio de archivos estáticos y apertura de recursos del paquete/instancia.
- Servidor de desarrollo (`run`) y utilidades de testing (`test_client`, `test_cli_runner`, `test_request_context`).
- Soporte para vistas asíncronas (`ensure_sync`, `async_to_sync`).

---

## 2. Dependencias relevantes

**Librería estándar:** `inspect`, `os`, `sys`, `typing`, `weakref`, `datetime.timedelta`, `functools.update_wrapper`, `itertools.chain`, `urllib.parse`.

**Terceros:**
- `click` — integración con la CLI (`flask`).
- `werkzeug` — enrutamiento (`MapAdapter`, `Rule`, `BuildError`, `RequestRedirect`), excepciones HTTP, estructuras de datos (`Headers`, `ImmutableDict`), servidor de desarrollo (`run_simple`) y wrappers WSGI.

**Internas de Flask:** `cli`, `ctx.AppContext`, `globals` (`request`, `session`, `g`, `app_ctx`, `_cv_app`), `helpers`, `sessions`, `signals`, `templating.Environment`, `wrappers.Request/Response`, `sansio.app.App`.

> Las importaciones bajo `if t.TYPE_CHECKING` (`StartResponse`, `WSGIEnvironment`, `FlaskClient`, `FlaskCliRunner`, `HeadersValue`) existen solo para anotaciones de tipo y evitan importaciones circulares en tiempo de ejecución.

---

## 3. Componentes a nivel de módulo

### 3.1 Variables de tipo (`TypeVar`)

```python
T_shell_context_processor, T_teardown, T_template_filter,
T_template_global, T_template_test, F
```

Se usan para preservar la firma exacta de las funciones decoradas (decoradores genéricos) y en los helpers `remove_ctx`/`add_ctx`.

### 3.2 `_make_timedelta(value)`

Función auxiliar que normaliza un valor de configuración a `timedelta`:

- `None` → `None`
- `timedelta` → se devuelve tal cual
- `int` → se interpreta como segundos y se convierte a `timedelta`

### 3.3 `remove_ctx(f)` y `add_ctx(f)` — capa de compatibilidad

Pareja de decoradores que dan soporte a un **cambio de firma retrocompatible**. En versiones recientes, varios métodos del ciclo de vida reciben como primer parámetro un `ctx: AppContext`. Estos helpers permiten que subclases escritas con la firma antigua sigan funcionando:

- **`remove_ctx`**: envuelve el método *sobreescrito por el usuario* (firma antigua) y, si el primer argumento posicional es un `AppContext`, lo **elimina** antes de invocarlo.
- **`add_ctx`**: envuelve el método *base de `Flask`* y, si falta, **inyecta** el `AppContext` actual (obtenido de `app_ctx._get_current_object()`) como primer argumento, para que las llamadas `super().metodo(...)` desde código antiguo sigan siendo válidas.

Ambos usan `update_wrapper` para conservar metadatos del original.

---

## 4. Clase `Flask(App)`

Objeto central de la aplicación. Se instancia típicamente como:

```python
from flask import Flask
app = Flask(__name__)
```

El primer parámetro (`import_name`) determina la resolución de rutas de recursos, plantillas y archivos estáticos.

### 4.1 Atributos de clase

| Atributo | Tipo | Descripción |
|---|---|---|
| `default_config` | `ImmutableDict` | Valores por defecto de toda la configuración (`DEBUG`, `SECRET_KEY`, `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, `PERMANENT_SESSION_LIFETIME`, `TRUSTED_HOSTS`, `SERVER_NAME`, `PREFERRED_URL_SCHEME`, etc.) |
| `request_class` | `type[Request]` | Clase usada para los objetos de petición |
| `response_class` | `type[Response]` | Clase usada para los objetos de respuesta |
| `session_interface` | `SessionInterface` | Interfaz de sesión; por defecto `SecureCookieSessionInterface()` |

### 4.2 `__init_subclass__(cls, **kwargs)`

Hook que se ejecuta al **definir una subclase** de `Flask`. Inspecciona un conjunto de métodos del ciclo de vida:

`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`.

Para cada uno, si está sobreescrito y **no** acepta un segundo parámetro llamado `ctx` o anotado como `AppContext` (detectado vía `inspect.signature`, admitiendo anotaciones en forma de cadena o de clase):

1. Emite un `DeprecationWarning` indicando que la firma antigua dejará de soportarse en Flask 4.0.
2. Envuelve el método de la subclase con `remove_ctx`.
3. Envuelve el método base de `Flask` con `add_ctx`.

### 4.3 `__init__(...)`

Parámetros principales: `import_name`, `static_url_path`, `static_folder`, `static_host`, `host_matching`, `subdomain_matching`, `template_folder`, `instance_path`, `instance_relative_config`, `root_path`.

Acciones:

1. Delega la inicialización común en `App.__init__`.
2. Crea el grupo de comandos Click `self.cli = cli.AppGroup()` y le asigna el nombre de la app.
3. Si existe carpeta estática, valida la coherencia `static_host` ↔ `host_matching` y registra automáticamente la regla `"<static_url_path>/<path:filename>"` con endpoint `"static"`.
   - La vista se registra mediante un `weakref.ref(self)` dentro de un `lambda` para **evitar un ciclo de referencias** entre la app y la función de vista.

---

## 5. Métodos agrupados por responsabilidad

### 5.1 Archivos estáticos y recursos

| Método | Descripción |
|---|---|
| `get_send_file_max_age(filename)` | Devuelve el `max_age` de caché a partir de `SEND_FILE_MAX_AGE_DEFAULT` (acepta `int` o `timedelta`); `None` activa peticiones condicionales |
| `send_static_file(filename)` | Vista que sirve archivos desde `static_folder` usando `send_from_directory`. Lanza `RuntimeError` si no hay carpeta estática |
| `open_resource(resource, mode="rb", encoding=None)` | Abre un archivo relativo a `root_path`. **Solo lectura** (`"r"`, `"rt"`, `"rb"`); otros modos → `ValueError` |
| `open_instance_resource(resource, mode="rb", encoding="utf-8")` | Abre un archivo relativo a `instance_path`; permite escritura |

### 5.2 Plantillas (Jinja2)

- **`create_jinja_environment()`**: construye el `Environment` a partir de `jinja_options`, estableciendo por defecto `autoescape` (`select_jinja_autoescape`) y `auto_reload` (según `TEMPLATES_AUTO_RELOAD` o `debug`). Inyecta en los *globals*: `url_for`, `get_flashed_messages`, `config`, y los proxies `request`, `session`, `g`. Configura la política `json.dumps_function`.
- **`update_template_context(ctx, context)`**: aplica los *context processors* registrados para la app (`None`) y para los blueprints de la petición (en orden inverso). Conserva una copia del contexto original y la reaplica al final, de modo que **los valores pasados a `render_template` tienen precedencia**.

### 5.3 Enrutamiento y generación de URLs

- **`create_url_adapter(request)`**: crea un `MapAdapter`.
  - Con petición: aplica `TRUSTED_HOSTS`, recalcula `request.host` con `get_host`, ajusta `server_name`/`subdomain` según `host_matching` y `subdomain_matching`, y usa `url_map.bind_to_environ`.
  - Sin petición: requiere `SERVER_NAME`; usa `url_map.bind` con `APPLICATION_ROOT` y `PREFERRED_URL_SCHEME`. Devuelve `None` si no hay `SERVER_NAME`.
- **`raise_routing_exception(request)`** *(interno)*: relanza la excepción de enrutamiento. En modo debug, convierte un redirect que descartaría el cuerpo en `FormDataRoutingRedirect` (no aplica a 307/308 ni a `GET`/`HEAD`/`OPTIONS`).
- **`url_for(endpoint, *, _anchor, _method, _scheme, _external, **values)`**: genera URLs.
  - Dentro de una petición: resuelve endpoints relativos que empiezan por `.` usando el blueprint actual; por defecto genera URLs internas.
  - Fuera de petición: usa el adaptador del contexto o crea uno; por defecto genera URLs **externas**. Sin `SERVER_NAME` → `RuntimeError`.
  - `_scheme` con `_external=False` → `ValueError`.
  - Aplica `inject_url_defaults`, captura `BuildError` delegando en `handle_url_build_error`, y añade el ancla con *quoting*.

### 5.4 Manejo de errores

| Método | Descripción |
|---|---|
| `handle_http_exception(ctx, e)` | Busca un handler por código y por MRO. Devuelve la excepción sin cambios si `e.code is None` o si es una `RoutingException` |
| `handle_user_exception(ctx, e)` | Punto de entrada general. Marca `show_exception` en `BadRequestKeyError` si `debug`/`TRAP_BAD_REQUEST_ERRORS`; delega `HTTPException` no "atrapadas" a `handle_http_exception`; si no hay handler, **relanza** |
| `handle_exception(ctx, e)` | Excepciones sin handler → 500. Emite la señal `got_request_exception`; si `PROPAGATE_EXCEPTIONS` (o `testing`/`debug`) relanza; en otro caso registra el error, construye un `InternalServerError(original_exception=e)`, busca handler y finaliza la petición con `from_error_handler=True` |
| `log_exception(ctx, exc_info)` | Registra la excepción como `error` en `self.logger` incluyendo ruta y método |

### 5.5 Ciclo de vida de la petición

Orden de ejecución:

```
__call__
 └─ wsgi_app
     ├─ request_context(environ) → ctx.push()
     ├─ full_dispatch_request(ctx)
     │    ├─ señal request_started
     │    ├─ preprocess_request(ctx)      # url_value_preprocessors + before_request
     │    ├─ dispatch_request(ctx)        # OPTIONS automático o vista
     │    ├─ (except) handle_user_exception(ctx, e)
     │    └─ finalize_request(ctx, rv)
     │         ├─ make_response(rv)
     │         ├─ process_response(ctx, resp)   # after_request + guardado de sesión
     │         └─ señal request_finished
     ├─ (except) handle_exception(ctx, e)
     └─ ctx.pop(error)  → do_teardown_request / do_teardown_appcontext
```

| Método | Descripción |
|---|---|
| `dispatch_request(ctx)` | Relanza excepciones de enrutamiento; responde automáticamente a `OPTIONS` si la regla lo permite; en otro caso invoca `view_functions[rule.endpoint](**view_args)` vía `ensure_sync` |
| `full_dispatch_request(ctx)` | Marca `_got_first_request`, avisa si `should_ignore_error` está sobreescrito (deprecado), ejecuta pre-procesado + despacho y captura excepciones |
| `finalize_request(ctx, rv, from_error_handler=False)` | Convierte `rv` en respuesta y ejecuta post-procesado. Con `from_error_handler=True`, los fallos del post-procesado se registran en lugar de propagarse |
| `make_default_options_response(ctx)` | Construye la respuesta `OPTIONS` con el header `Allow` a partir de `ctx.url_adapter.allowed_methods()` |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y `before_request_funcs` (app + blueprints). Si un hook devuelve algo distinto de `None`, ese valor corta el despacho |
| `process_response(ctx, response)` | Ejecuta `ctx._after_request_functions` y los `after_request_funcs` (blueprints → app, en orden inverso de registro) y guarda la sesión si no es nula |
| `do_teardown_request(ctx, exc=None)` | Ejecuta `teardown_request` de blueprints y app, y emite `request_tearing_down`. Usa `_CollectErrors` para ejecutar **todos** los callbacks y agregar los errores |
| `do_teardown_appcontext(ctx, exc=None)` | Ejecuta `teardown_appcontext` y emite `appcontext_tearing_down`, también con recolección de errores |

### 5.6 Construcción de respuestas — `make_response(rv)`

Normaliza el valor devuelto por una vista a una instancia de `response_class`. Tipos admitidos:

- `str`, `bytes`, `bytearray` → cuerpo de la respuesta
- `dict`, `list` → respuesta JSON (`self.json.response`)
- generador / iterador → respuesta en *streaming*
- `tuple` de 3 elementos `(body, status, headers)`, o de 2 `(body, status)` / `(body, headers)` (se discrimina comprobando si el segundo elemento es `Headers`/`dict`/`tuple`/`list`)
- instancia de `response_class` → se devuelve sin cambios
- otra `Response` de Werkzeug o un callable WSGI → se coacciona con `force_type`

Errores: tamaños de tupla inválidos, `None` como cuerpo o tipos no soportados generan `TypeError` con mensajes descriptivos. Finalmente aplica `status` (como `status` si es texto, o `status_code` si es entero) y extiende los headers.

### 5.7 Soporte asíncrono

- **`ensure_sync(func)`**: devuelve la función tal cual si es síncrona; si es `async def` (detectado con `iscoroutinefunction`), la envuelve con `async_to_sync`.
- **`async_to_sync(func)`**: usa `asgiref.sync.async_to_sync`. Si `asgiref` no está instalado, lanza `RuntimeError` indicando instalar `Flask[async]`.

Ambos métodos son puntos de extensión para cambiar cómo se ejecutan las vistas asíncronas.

### 5.8 Contextos

| Método | Descripción |
|---|---|
| `app_context()` | Crea un `AppContext`; al activarlo quedan disponibles `current_app` y `g` |
| `request_context(environ)` | Crea un `AppContext` con información de petición a partir de un `environ` WSGI (`AppContext.from_environ`). Uso interno |
| `test_request_context(*args, **kwargs)` | Construye un `environ` con `testing.EnvironBuilder` (aceptando los argumentos de `werkzeug.test.EnvironBuilder`) y devuelve el contexto de petición correspondiente |

### 5.9 Servidor de desarrollo — `run(...)`

Levanta el servidor de desarrollo de Werkzeug (`run_simple`). **No apto para producción.**

Lógica destacada:

1. Si `FLASK_RUN_FROM_CLI == "true"`, **ignora la llamada** (avisando en rojo si no es el proceso del reloader) para no arrancar un segundo servidor.
2. Carga `.env`/`.flaskenv` con `cli.load_dotenv()` si procede; `FLASK_DEBUG` sobrescribe `debug`.
3. El parámetro `debug` explícito tiene prioridad sobre todas las fuentes.
4. Deriva host/puerto de `SERVER_NAME` (vía `urlsplit`) si no se indican; por defecto `127.0.0.1:5000`.
5. Establece por defecto `use_reloader`, `use_debugger` (según `debug`) y `threaded=True`.
6. Muestra el banner (`cli.show_server_banner`) y, en el `finally`, restablece `_got_first_request = False`.

### 5.10 Testing

- **`test_client(use_cookies=True, **kwargs)`**: devuelve una instancia de `test_client_class` (por defecto `FlaskClient`). Soporta uso como gestor de contexto (`with`) para acceder a los *context locals*.
- **`test_cli_runner(**kwargs)`**: devuelve una instancia de `test_cli_runner_class` (por defecto `FlaskCliRunner`) para probar comandos de la CLI.

### 5.11 Interfaz WSGI

- **`wsgi_app(environ, start_response)`**: implementación real de la aplicación WSGI. Crea y empuja el contexto, despacha, captura excepciones (`handle_exception`), devuelve `response(environ, start_response)` y en el `finally`:
  - preserva el contexto si Werkzeug lo solicita (`werkzeug.debug.preserve_context`),
  - descarta el error si `should_ignore_error(error)` es verdadero,
  - hace `ctx.pop(error)` (lo que disparará los *teardown*).

  Está separado de `__call__` para permitir aplicar middlewares sin perder la referencia a la app:

  ```python
  app.wsgi_app = MyMiddleware(app.wsgi_app)
  ```

- **`__call__(environ, start_response)`**: hace que el objeto `Flask` sea invocable como aplicación WSGI; simplemente delega en `wsgi_app`.

---

## 6. Señales emitidas

| Señal | Momento |
|---|---|
| `request_started` | Al inicio de `full_dispatch_request` |
| `request_finished` | Tras el post-procesado, en `finalize_request` |
| `got_request_exception` | En `handle_exception`, siempre |
| `request_tearing_down` | Al final de `do_teardown_request` |
| `appcontext_tearing_down` | Al final de `do_teardown_appcontext` |

Todas se envían con `_async_wrapper=self.ensure_sync` para permitir receptores asíncronos.

---

## 7. Notas de compatibilidad y mantenimiento

- **Firma con `ctx: AppContext`**: los métodos del ciclo de vida reciben el contexto explícitamente. Las subclases con la firma antigua funcionan pero emiten `DeprecationWarning` (soporte eliminado en Flask 4.0).
- **`should_ignore_error`**: deprecado; se eliminará en Flask 3.3. Se recomienda gestionar errores en los *teardown handlers*.
- **Ciclos de referencia**: la vista estática se registra con `weakref` (ver issue #3761).
- **Recolección de errores en teardown**: desde 3.2 se invocan todos los callbacks y los errores se agregan con `_CollectErrors` en lugar de detenerse en el primero.