# Documentación técnica: `flask/app.py`

## 1. Descripción general

Este módulo define la clase **`Flask`**, el objeto central del framework Flask y la implementación concreta de una **aplicación WSGI**.

El archivo representa la capa "con E/S" (*sync / WSGI*) del framework: hereda de `App` (definida en `flask.sansio.app`), que contiene toda la lógica *sans-IO* —registro de rutas, blueprints, configuración, manejadores de error, plantillas, etc.— y añade sobre ella:

- El ciclo de vida completo de una petición HTTP (`wsgi_app`, `full_dispatch_request`, `dispatch_request`, `finalize_request`).
- La creación y gestión de contextos (`app_context`, `request_context`, `test_request_context`).
- La conversión de valores de retorno de vistas en objetos `Response` (`make_response`).
- La generación de URLs (`url_for`, `create_url_adapter`).
- El manejo centralizado de excepciones (`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`).
- Utilidades de desarrollo y pruebas (`run`, `test_client`, `test_cli_runner`).
- Soporte para vistas asíncronas (`ensure_sync`, `async_to_sync`).
- Servicio de archivos estáticos y apertura de recursos (`send_static_file`, `open_resource`, `open_instance_resource`).

Además incluye un mecanismo de **compatibilidad retroactiva** para subclases que sobreescriben métodos cuya firma cambió al recibir un parámetro `ctx: AppContext`.

---

## 2. Dependencias principales

| Origen | Elementos relevantes | Uso |
|---|---|---|
| `werkzeug.routing` | `MapAdapter`, `Rule`, `BuildError`, `RequestRedirect`, `RoutingException` | Enrutamiento y construcción de URLs |
| `werkzeug.exceptions` | `HTTPException`, `InternalServerError`, `BadRequestKeyError` | Manejo de errores HTTP |
| `werkzeug.wrappers` | `Response as BaseResponse` | Coerción de respuestas |
| `werkzeug.serving` | `run_simple`, `is_running_from_reloader` | Servidor de desarrollo |
| `werkzeug.datastructures` | `Headers`, `ImmutableDict` | Cabeceras y configuración por defecto |
| `click` | `secho`, `AppGroup` (vía `flask.cli`) | Interfaz de línea de comandos |
| `.ctx` | `AppContext` | Contexto unificado de aplicación/petición |
| `.globals` | `_cv_app`, `app_ctx`, `g`, `request`, `session` | Proxies de contexto |
| `.sessions` | `SessionInterface`, `SecureCookieSessionInterface` | Persistencia de sesión |
| `.signals` | `request_started`, `request_finished`, `request_tearing_down`, `appcontext_tearing_down`, `got_request_exception` | Señales Blinker |
| `.wrappers` | `Request`, `Response` | Clases de petición/respuesta |
| `.templating` | `Environment` | Entorno Jinja2 |
| `.helpers` | `_CollectErrors`, `get_debug_flag`, `get_load_dotenv`, `get_flashed_messages`, `send_from_directory` | Utilidades |

Las importaciones dentro de `if t.TYPE_CHECKING` (`StartResponse`, `WSGIEnvironment`, `FlaskClient`, `FlaskCliRunner`, `HeadersValue`) existen solo para anotaciones de tipo y evitan dependencias circulares/costosas en tiempo de ejecución.

---

## 3. Componentes a nivel de módulo

### 3.1 Variables de tipo (`TypeVar`)

Usadas para preservar la firma de las funciones decoradas en los *decorators* heredados de `App`:

| Nombre | Acotado a |
|---|---|
| `T_shell_context_processor` | `ft.ShellContextProcessorCallable` |
| `T_teardown` | `ft.TeardownCallable` |
| `T_template_filter` | `ft.TemplateFilterCallable` |
| `T_template_global` | `ft.TemplateGlobalCallable` |
| `T_template_test` | `ft.TemplateTestCallable` |
| `F` | `t.Callable[..., t.Any]` |

### 3.2 `_make_timedelta(value: timedelta | int | None) -> timedelta | None`

Función auxiliar de normalización: devuelve `None` o el `timedelta` recibido sin cambios; si recibe un entero lo interpreta como **segundos** y lo convierte a `timedelta`.

### 3.3 `remove_ctx(f: F) -> F`

Decorador interno. Envuelve un método **sobreescrito por el usuario con la firma antigua** (sin `ctx`) para que, si se le invoca con un `AppContext` como primer argumento posicional, este se descarte antes de delegar en la función original.

```python
# args == (ctx, e)  ->  f(self, e)
```

### 3.4 `add_ctx(f: F) -> F`

Decorador interno complementario. Envuelve el método **base de `Flask`** para que, cuando una subclase lo llame vía `super()` sin pasar `ctx`, se inyecte automáticamente el contexto activo (`app_ctx._get_current_object()`) como primer argumento.

Ambos decoradores usan `functools.update_wrapper` para conservar metadatos.

---

## 4. Clase `Flask(App)`

Objeto central de la aplicación. Se instancia típicamente como:

```python
from flask import Flask
app = Flask(__name__)
```

El primer parámetro (`import_name`) determina la raíz para resolver recursos del sistema de archivos y es usado por extensiones para depuración.

### 4.1 Atributos de clase

| Atributo | Tipo | Descripción |
|---|---|---|
| `default_config` | `ImmutableDict` | Valores de configuración por defecto (ver tabla 4.2). |
| `request_class` | `type[Request]` | Clase usada para los objetos de petición. |
| `response_class` | `type[Response]` | Clase usada para los objetos de respuesta. |
| `session_interface` | `SessionInterface` | Interfaz de sesión; por defecto `SecureCookieSessionInterface()`. |

### 4.2 `default_config` (claves principales)

- **Depuración/pruebas:** `DEBUG`, `TESTING`, `PROPAGATE_EXCEPTIONS`, `TRAP_BAD_REQUEST_ERRORS`, `TRAP_HTTP_EXCEPTIONS`, `EXPLAIN_TEMPLATE_LOADING`.
- **Firma y sesión:** `SECRET_KEY`, `SECRET_KEY_FALLBACKS`, `PERMANENT_SESSION_LIFETIME` (31 días), `SESSION_COOKIE_*` (`NAME`, `DOMAIN`, `PATH`, `HTTPONLY`, `SECURE`, `PARTITIONED`, `SAMESITE`), `SESSION_REFRESH_EACH_REQUEST`, `MAX_COOKIE_SIZE`.
- **URLs y hosts:** `SERVER_NAME`, `APPLICATION_ROOT`, `PREFERRED_URL_SCHEME`, `TRUSTED_HOSTS`.
- **Límites de cuerpo/formularios:** `MAX_CONTENT_LENGTH`, `MAX_FORM_MEMORY_SIZE` (500 000), `MAX_FORM_PARTS` (1 000).
- **Archivos estáticos:** `USE_X_SENDFILE`, `SEND_FILE_MAX_AGE_DEFAULT`.
- **Plantillas:** `TEMPLATES_AUTO_RELOAD`.
- **Rutas:** `PROVIDE_AUTOMATIC_OPTIONS`.

### 4.3 `__init_subclass__(cls, **kwargs)`

Hook de creación de subclases que implementa la **detección de firmas obsoletas**. Recorre la lista de métodos cuya firma ahora incluye `ctx: AppContext`:

`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`.

Para cada uno:

1. Si no está sobreescrito, lo ignora.
2. Inspecciona (`inspect.signature`) el segundo parámetro (el primero es `self`) y verifica que se llame `ctx` o esté anotado como `AppContext` (soporta anotación como clase o como cadena).
3. Si no cumple, emite un `DeprecationWarning` (eliminación prevista en Flask 4.0) y aplica los envoltorios: `remove_ctx` sobre el método de la subclase y `add_ctx` sobre el método base de `Flask`.

### 4.4 `__init__(...)`

Parámetros: `import_name`, `static_url_path`, `static_folder="static"`, `static_host`, `host_matching=False`, `subdomain_matching=False`, `template_folder="templates"`, `instance_path`, `instance_relative_config=False`, `root_path`.

Comportamiento:

1. Delega en `App.__init__` (lógica *sans-IO*).
2. Crea `self.cli = cli.AppGroup()` y le asigna `self.name`, para exponer comandos Click propios de la app.
3. Si hay `static_folder` configurado:
   - Valida la coherencia `bool(static_host) == host_matching`.
   - Registra la regla `"{static_url_path}/<path:filename>"` con endpoint `"static"`, usando una **`weakref.ref` a la app** en la función de vista para evitar un ciclo de referencias entre la app y la vista (issue #3761).

---

## 5. Métodos agrupados por responsabilidad

### 5.1 Recursos y archivos estáticos

| Método | Descripción |
|---|---|
| `get_send_file_max_age(filename)` | Devuelve el valor de caché `max_age` para `send_file`, tomado de `SEND_FILE_MAX_AGE_DEFAULT`. Convierte `timedelta` a segundos; `None` activa peticiones condicionales. |
| `send_static_file(filename)` | Vista que sirve archivos desde `static_folder`. Lanza `RuntimeError` si no hay carpeta estática. Usa `send_from_directory`. |
| `open_resource(resource, mode="rb", encoding=None)` | Abre un archivo **solo lectura** relativo a `root_path`. Modos válidos: `"r"`, `"rt"`, `"rb"`; otro valor provoca `ValueError`. |
| `open_instance_resource(resource, mode="rb", encoding="utf-8")` | Abre un archivo relativo a `instance_path`; a diferencia del anterior, **permite escritura**. |

### 5.2 Plantillas

| Método | Descripción |
|---|---|
| `create_jinja_environment()` | Construye el `Environment` de Jinja a partir de `jinja_options`. Establece `autoescape` (por `select_jinja_autoescape`) y `auto_reload` (por `TEMPLATES_AUTO_RELOAD` o `debug`). Inyecta globales: `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g`, y fija la política `json.dumps_function`. |
| `update_template_context(ctx, context)` | Actualiza *in place* el diccionario de contexto ejecutando los *context processors* de la app y de los blueprints implicados (en orden inverso). Los valores originales pasados a `render_template` se reaplican al final para que **tengan prioridad**. |

### 5.3 URLs y enrutamiento

| Método | Descripción |
|---|---|
| `create_url_adapter(request)` | Crea un `MapAdapter`. Con petición: aplica `TRUSTED_HOSTS`, recalcula `request.host` con `get_host`, omite `SERVER_NAME` cuando `host_matching` está activo y fuerza el subdominio por defecto si `subdomain_matching` está desactivado; finalmente usa `bind_to_environ`. Sin petición: requiere `SERVER_NAME` y usa `url_map.bind` con `APPLICATION_ROOT` y `PREFERRED_URL_SCHEME`; devuelve `None` si no es posible. |
| `raise_routing_exception(request)` | *(interno)* Relanza `request.routing_exception`. En modo debug, si se trata de un `RequestRedirect` con código distinto de 307/308 y método con cuerpo, lanza `FormDataRoutingRedirect` para advertir de pérdida de datos de formulario. |
| `url_for(endpoint, *, _anchor, _method, _scheme, _external, **values)` | Genera una URL. Si hay contexto de petición activo, usa su `url_adapter`, resuelve endpoints relativos que empiezan por `.` con el blueprint actual y por defecto genera URLs internas. Fuera de petición, construye un adaptador y por defecto genera URLs externas (`RuntimeError` si falta `SERVER_NAME`). Valida que `_scheme` requiera `_external=True`, aplica `inject_url_defaults`, delega a `handle_url_build_error` ante `BuildError` y añade el ancla con *quoting* seguro. |

### 5.4 Manejo de excepciones

| Método | Firma relevante | Descripción |
|---|---|---|
| `handle_http_exception(ctx, e)` | `HTTPException` | Devuelve la excepción tal cual si `e.code is None` o si es una `RoutingException`. En otro caso busca manejador con `_find_error_handler` según los blueprints de la petición. |
| `handle_user_exception(ctx, e)` | `Exception` | Activa `show_exception` en `BadRequestKeyError` bajo debug/`TRAP_BAD_REQUEST_ERRORS`. Delega las `HTTPException` no "atrapadas" a `handle_http_exception`. Si no hay manejador, **relanza** la excepción original. |
| `handle_exception(ctx, e)` | `-> Response` | Emite la señal `got_request_exception`. Si `PROPAGATE_EXCEPTIONS` (o `testing`/`debug`) está activo, re-lanza. En caso contrario registra el error, crea `InternalServerError(original_exception=e)`, busca manejador para 500 y finaliza la petición con `from_error_handler=True`. |
| `log_exception(ctx, exc_info)` | — | Registra el error en `self.logger` incluyendo ruta y método de la petición. |

### 5.5 Ciclo de vida de la petición

| Método | Descripción |
|---|---|
| `wsgi_app(environ, start_response)` | **Punto de entrada WSGI real.** Crea y empuja el contexto, ejecuta `full_dispatch_request`, captura excepciones con `handle_exception`, invoca la respuesta y, en el bloque `finally`, preserva el contexto para el depurador de Werkzeug si aplica, filtra errores con `should_ignore_error` y ejecuta `ctx.pop(error)`. Está separado de `__call__` para poder envolverlo con middlewares: `app.wsgi_app = MyMiddleware(app.wsgi_app)`. |
| `__call__(environ, start_response)` | Hace la app invocable por el servidor WSGI; simplemente delega en `wsgi_app`. |
| `full_dispatch_request(ctx)` | Marca `_got_first_request`, advierte si `should_ignore_error` está definido (obsoleto, eliminación en 3.3), envía `request_started`, ejecuta `preprocess_request` y, si no retornó respuesta, `dispatch_request`; captura excepciones con `handle_user_exception` y cierra con `finalize_request`. |
| `dispatch_request(ctx)` | Realiza el *dispatch*: relanza excepciones de enrutamiento, responde automáticamente a `OPTIONS` si la regla lo permite, y en otro caso invoca `view_functions[rule.endpoint]` con `view_args` (envuelto en `ensure_sync`). |
| `finalize_request(ctx, rv, from_error_handler=False)` | Convierte `rv` con `make_response`, ejecuta `process_response` y envía `request_finished`. En modo `from_error_handler`, los fallos de post-procesado se registran en lugar de propagarse. |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y luego `before_request_funcs` de la app y los blueprints (orden inverso). Si algún `before_request` devuelve algo distinto de `None`, ese valor cortocircuita el *dispatch*. |
| `process_response(ctx, response)` | Ejecuta `ctx._after_request_functions`, luego los `after_request_funcs` de blueprints y app **en orden inverso de registro**, y finalmente guarda la sesión con `session_interface.save_session` si no es una sesión nula. |
| `make_default_options_response(ctx)` | Construye la respuesta por defecto para `OPTIONS` usando `url_adapter.allowed_methods()` en la cabecera `Allow`. |
| `do_teardown_request(ctx, exc=None)` | Ejecuta `teardown_request_funcs` (blueprints + app, orden inverso) y envía `request_tearing_down`. Usa `_CollectErrors` para **ejecutar todos los callbacks** y luego agregar los errores (cambio en 3.2). |
| `do_teardown_appcontext(ctx, exc=None)` | Ejecuta `teardown_appcontext_funcs` en orden inverso y envía `appcontext_tearing_down`, con la misma estrategia de recolección de errores. |

#### Flujo resumido de una petición

```
WSGI server → __call__ → wsgi_app
  ├─ request_context(environ) → ctx.push()
  ├─ full_dispatch_request
  │    ├─ signal request_started
  │    ├─ preprocess_request  (url_value_preprocessors, before_request)
  │    ├─ dispatch_request    (OPTIONS automático | view function)
  │    └─ finalize_request
  │         ├─ make_response
  │         ├─ process_response (after_request, save_session)
  │         └─ signal request_finished
  ├─ (excepción) → handle_user_exception / handle_exception
  └─ ctx.pop(error) → do_teardown_request + do_teardown_appcontext
```

### 5.6 Conversión de respuestas

**`make_response(rv) -> Response`**

Normaliza el valor devuelto por una vista al tipo `response_class`:

1. **Tuplas:** acepta `(body, status, headers)`, `(body, status)` o `(body, headers)` (discrimina el segundo elemento según sea `Headers`/`dict`/`tuple`/`list`). Otros tamaños → `TypeError`.
2. **`None`** → `TypeError` explícito indicando el endpoint.
3. **Coerción del cuerpo:**
   - `str` / `bytes` / `bytearray` / iteradores (generadores → respuesta en *streaming*) → `response_class(...)`.
   - `dict` / `list` → respuesta JSON vía `self.json.response`.
   - `BaseResponse` o *callable* WSGI → `response_class.force_type(...)`.
   - Cualquier otro tipo → `TypeError` descriptivo.
4. Aplica `status` (como cadena o como `status_code`) y extiende `headers`.

### 5.7 Contextos

| Método | Descripción |
|---|---|
| `app_context()` | Devuelve un `AppContext`. Al empujarlo quedan disponibles `current_app` y `g`. Pensado para uso con `with` fuera de una petición. |
| `request_context(environ)` | Crea un `AppContext` con información de petición desde un entorno WSGI (`AppContext.from_environ`). Uso interno. |
| `test_request_context(*args, **kwargs)` | Construye un entorno WSGI con `flask.testing.EnvironBuilder` (cerrándolo en `finally`) y devuelve el contexto correspondiente. Acepta los argumentos de `werkzeug.test.EnvironBuilder` más defaults de la app (`path`, `base_url`, `subdomain`, `url_scheme`, `data`, `json`, …). |

### 5.8 Soporte asíncrono

| Método | Descripción |
|---|---|
| `ensure_sync(func)` | Devuelve `func` si es síncrona; si es `async def` (`iscoroutinefunction`) la envuelve con `async_to_sync`. Se usa en todos los puntos donde se invocan callbacks de usuario. |
| `async_to_sync(func)` | Convierte una corrutina en invocable síncrono usando `asgiref.sync.async_to_sync`. Lanza `RuntimeError` si `asgiref` no está instalado (requiere el extra `flask[async]`). |

### 5.9 Desarrollo, CLI y pruebas

| Método | Descripción |
|---|---|
| `run(host=None, port=None, debug=None, load_dotenv=True, **options)` | Arranca el **servidor de desarrollo** (`werkzeug.serving.run_simple`). **No apto para producción.** Ignora la llamada si se ejecuta desde `flask run` (`FLASK_RUN_FROM_CLI`), mostrando un aviso. Carga `.env`/`.flaskenv` y aplica `FLASK_DEBUG`; el parámetro `debug` tiene máxima prioridad. Deriva host/puerto de `SERVER_NAME` si no se indican (por defecto `127.0.0.1:5000`). Activa `use_reloader`/`use_debugger` según `debug` y `threaded=True`. Al terminar restablece `_got_first_request = False`. |
| `make_shell_context()` | Devuelve el diccionario del *shell* interactivo con `app` y `g`, ampliado por todos los `shell_context_processors`. |
| `test_client(use_cookies=True, **kwargs)` | Crea un cliente de pruebas de la clase `test_client_class` (por defecto `FlaskClient`). Usable con `with` para mantener el contexto activo. |
| `test_cli_runner(**kwargs)` | Crea un *runner* para probar comandos CLI (`test_cli_runner_class`, por defecto `FlaskCliRunner`). |

---

## 6. Notas de diseño relevantes

- **Separación *sans-IO*:** la lógica independiente de E/S vive en `flask.sansio.app.App`; este módulo añade únicamente la parte ligada a WSGI, lo que facilita implementaciones alternativas (p. ej. ASGI).
- **Contexto unificado:** `AppContext` sustituye el par histórico *app context / request context*; los métodos del ciclo de vida lo reciben explícitamente como primer parámetro `ctx`, en lugar de depender solo de proxies globales.
- **`weakref` en la ruta estática:** evita ciclos de referencia app ↔ vista.
- **Recolección de errores en *teardown*:** `_CollectErrors` garantiza que todos los callbacks de limpieza se ejecuten y agrega las excepciones resultantes.
- **Elementos obsoletos:** firmas sin `ctx` (eliminación en Flask 4.0) y `should_ignore_error` (eliminación en Flask 3.3).