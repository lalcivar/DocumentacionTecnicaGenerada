# Documentación técnica — `flask/app.py`

## 1. Descripción general

Este módulo contiene la implementación de la clase **`Flask`**, el objeto central del framework Flask y punto de entrada de toda aplicación web construida con él.

El archivo define la parte **"con E/S" / dependiente de WSGI** del objeto aplicación: hereda de `App` (definida en `flask.sansio.app`, que agrupa toda la lógica *sans-io*: registro de rutas, blueprints, configuración, manejadores, etc.) y añade todo lo que necesita interactuar con el entorno de ejecución real:

- Implementación del protocolo **WSGI** (`wsgi_app`, `__call__`).
- **Ciclo de vida completo de una petición**: creación del contexto, pre-procesamiento, despacho a la vista, construcción de la respuesta, post-procesamiento y *teardown*.
- **Manejo de errores y excepciones** HTTP y de usuario.
- **Generación de URLs** (`url_for`) y creación del adaptador de rutas de Werkzeug.
- **Integración con Jinja2** (creación del entorno de plantillas y su contexto).
- **Servidor de desarrollo** (`run`), **CLI** (`cli`, `make_shell_context`) y **utilidades de testing** (`test_client`, `test_cli_runner`, `test_request_context`).
- **Acceso a recursos del sistema de archivos** (`open_resource`, `open_instance_resource`, `send_static_file`).
- **Soporte para vistas asíncronas** (`ensure_sync`, `async_to_sync`).

En resumen: es el archivo que convierte la definición declarativa de una aplicación en una aplicación WSGI ejecutable.

---

## 2. Dependencias principales

| Origen | Uso |
|---|---|
| `werkzeug.routing` (`MapAdapter`, `Rule`, `BuildError`, `RequestRedirect`, `RoutingException`) | Enrutamiento y construcción de URLs. |
| `werkzeug.exceptions` (`HTTPException`, `InternalServerError`, `BadRequestKeyError`) | Jerarquía de errores HTTP. |
| `werkzeug.serving` (`run_simple`, `is_running_from_reloader`) | Servidor de desarrollo. |
| `werkzeug.datastructures` (`Headers`, `ImmutableDict`) | Cabeceras y configuración por defecto inmutable. |
| `click` | Grupo de comandos CLI de la aplicación. |
| `.sansio.app.App` | Clase base con la lógica independiente de E/S. |
| `.ctx.AppContext` | Contexto unificado de aplicación/petición. |
| `.globals` (`_cv_app`, `app_ctx`, `request`, `session`, `g`) | Proxies y variables de contexto. |
| `.sessions` (`SessionInterface`, `SecureCookieSessionInterface`) | Gestión de sesiones. |
| `.signals` | Señales Blinker del ciclo de vida. |
| `.wrappers` (`Request`, `Response`) | Objetos de petición/respuesta. |
| `.templating.Environment` | Entorno Jinja2 de Flask. |

> Las importaciones bajo `if t.TYPE_CHECKING` (`StartResponse`, `WSGIEnvironment`, `FlaskClient`, `FlaskCliRunner`, `HeadersValue`) existen solo para anotaciones de tipo y no se evalúan en tiempo de ejecución.

---

## 3. Componentes a nivel de módulo

### 3.1 Variables de tipo (`TypeVar`)

```python
T_shell_context_processor, T_teardown, T_template_filter,
T_template_global, T_template_test, F
```

Se usan para preservar la firma exacta de los *callables* en decoradores y *wrappers* (tipado genérico). `F` está acotado a `Callable[..., Any]`.

### 3.2 `_make_timedelta(value) -> timedelta | None`

Utilidad interna de normalización: devuelve `None` o el `timedelta` tal cual; si recibe un entero lo interpreta como segundos y lo convierte a `timedelta`.

### 3.3 `remove_ctx(f) -> F`

Decorador de compatibilidad. Envuelve un método **sobrescrito por el usuario con la firma antigua** (sin parámetro `ctx`): si el primer argumento posicional es una instancia de `AppContext`, lo descarta antes de invocar el método original.

### 3.4 `add_ctx(f) -> F`

Decorador complementario. Envuelve el **método base de `Flask`** para que, si se le llama sin `ctx` (por ejemplo, desde un `super()` escrito con la firma antigua), inserte automáticamente el contexto activo (`app_ctx._get_current_object()`) como primer argumento.

Ambos decoradores existen únicamente para la **transición de firmas** descrita en la sección 4.2.

---

## 4. Clase `Flask(App)`

Objeto aplicación WSGI y registro central de vistas, reglas de URL, configuración de plantillas, etc.

### 4.1 Atributos de clase

| Atributo | Tipo | Descripción |
|---|---|---|
| `default_config` | `ImmutableDict` | Valores por defecto de toda la configuración (`DEBUG`, `SECRET_KEY`, `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, `TRUSTED_HOSTS`, `SERVER_NAME`, `PREFERRED_URL_SCHEME`, `MAX_COOKIE_SIZE`, etc.). |
| `request_class` | `type[Request]` | Clase utilizada para los objetos de petición. |
| `response_class` | `type[Response]` | Clase utilizada para los objetos de respuesta. |
| `session_interface` | `SessionInterface` | Interfaz de sesión; por defecto `SecureCookieSessionInterface()`. |

### 4.2 `__init_subclass__(cls, **kwargs)`

Mecanismo de **detección de firmas obsoletas**. Al definirse una subclase de `Flask`, inspecciona los métodos del ciclo de vida que ahora reciben `ctx: AppContext` como primer parámetro:

`handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`.

Para cada método sobrescrito comprueba (vía `inspect.signature`) que el segundo parámetro se llame `ctx` o esté anotado como `AppContext`. Si no es así, emite un `DeprecationWarning` (eliminación anunciada para Flask 4.0) y aplica `remove_ctx` al método de la subclase y `add_ctx` al método base, garantizando interoperabilidad.

### 4.3 `__init__(...)`

Parámetros principales: `import_name`, `static_url_path`, `static_folder`, `static_host`, `host_matching`, `subdomain_matching`, `template_folder`, `instance_path`, `instance_relative_config`, `root_path`.

Responsabilidades:

1. Delegar en `App.__init__` toda la inicialización *sans-io*.
2. Crear `self.cli = cli.AppGroup()` y asignarle el nombre de la app.
3. Registrar automáticamente la ruta de archivos estáticos (`{static_url_path}/<path:filename>` con endpoint `"static"`) si hay `static_folder`, validando la coherencia entre `static_host` y `host_matching`.
   - La vista se registra mediante una **`weakref.ref`** a la aplicación para evitar ciclos de referencia entre la app y la función de vista.

---

## 5. Métodos agrupados por responsabilidad

### 5.1 Archivos estáticos y recursos

| Método | Descripción |
|---|---|
| `get_send_file_max_age(filename)` | Devuelve el valor `max_age` de caché a partir de `SEND_FILE_MAX_AGE_DEFAULT` (acepta `int` o `timedelta`). `None` ⇒ peticiones condicionales. |
| `send_static_file(filename)` | Vista que sirve ficheros desde `static_folder` usando `send_from_directory`. Lanza `RuntimeError` si no hay carpeta estática. |
| `open_resource(resource, mode="rb", encoding=None)` | Abre un fichero relativo a `root_path` **solo en lectura** (`"r"`, `"rt"`, `"rb"`). |
| `open_instance_resource(resource, mode="rb", encoding="utf-8")` | Abre un fichero relativo a `instance_path`; admite escritura. |

### 5.2 Plantillas (Jinja2)

| Método | Descripción |
|---|---|
| `create_jinja_environment()` | Construye el `Environment` a partir de `jinja_options`, fija `autoescape` y `auto_reload` (según `TEMPLATES_AUTO_RELOAD` o `debug`), e inyecta los globales `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g` y la política `json.dumps_function`. |
| `update_template_context(ctx, context)` | Ejecuta los *context processors* de la app y de los blueprints implicados, respetando la precedencia de los valores pasados a `render_template`. |

### 5.3 Enrutamiento y URLs

| Método | Descripción |
|---|---|
| `create_url_adapter(request)` | Crea el `MapAdapter`. Con petición: aplica `TRUSTED_HOSTS`, resuelve el host y hace `bind_to_environ` ajustando `server_name`/`subdomain` según `host_matching` y `subdomain_matching`. Sin petición: usa `SERVER_NAME`, `APPLICATION_ROOT` y `PREFERRED_URL_SCHEME`, o devuelve `None`. |
| `raise_routing_exception(request)` | *(interno)* Relanza la excepción de enrutamiento; en modo debug sustituye redirecciones que descartarían el cuerpo por `FormDataRoutingRedirect`. No intercepta 307/308. |
| `url_for(endpoint, *, _anchor, _method, _scheme, _external, **values)` | Genera URLs. Resuelve endpoints relativos (`.endpoint`) respecto al blueprint actual, decide si la URL es externa según el contexto, aplica `inject_url_defaults`, y delega los fallos en `handle_url_build_error`. Valida que `_scheme` requiera `_external=True`. |

### 5.4 Manejo de errores

| Método | Descripción |
|---|---|
| `handle_http_exception(ctx, e)` | Busca un manejador para la `HTTPException` (por código y por MRO). Devuelve la excepción sin tocar si no tiene `code` o es una `RoutingException`. |
| `handle_user_exception(ctx, e)` | Punto de entrada general: delega en `handle_http_exception` cuando aplica, activa `show_exception` para `BadRequestKeyError` en debug/`TRAP_BAD_REQUEST_ERRORS`, y relanza si no hay manejador. |
| `handle_exception(ctx, e)` | Excepciones no manejadas ⇒ 500. Emite la señal `got_request_exception`, relanza si `PROPAGATE_EXCEPTIONS` (o `testing`/`debug`), si no registra el error y construye un `InternalServerError` con `original_exception`, finalizando con `finalize_request(..., from_error_handler=True)`. |
| `log_exception(ctx, exc_info)` | Registra la excepción en `self.logger` con la ruta y el método de la petición. |

### 5.5 Ciclo de vida de la petición

| Método | Descripción |
|---|---|
| `full_dispatch_request(ctx)` | Orquestador: marca `_got_first_request`, emite `request_started`, ejecuta `preprocess_request` y, si no cortocircuita, `dispatch_request`; captura excepciones con `handle_user_exception` y finaliza con `finalize_request`. También advierte sobre el uso obsoleto de `should_ignore_error`. |
| `dispatch_request(ctx)` | Empareja la regla de URL y llama a la función de vista (con `ensure_sync`), o devuelve la respuesta `OPTIONS` automática. |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y `before_request_funcs` (app + blueprints en orden inverso). Si alguno devuelve un valor distinto de `None`, se usa como respuesta. |
| `process_response(ctx, response)` | Ejecuta las funciones `after_request` del contexto, de los blueprints y de la app (en orden inverso de registro) y guarda la sesión mediante `session_interface.save_session`. |
| `finalize_request(ctx, rv, from_error_handler=False)` | Convierte el valor de retorno en respuesta (`make_response`), aplica `process_response` y emite `request_finished`. En modo seguro (`from_error_handler=True`) registra y ignora fallos. |
| `make_default_options_response(ctx)` | Construye la respuesta `OPTIONS` por defecto con `Allow` a partir de `url_adapter.allowed_methods()`. |
| `make_response(rv)` | Normaliza el valor devuelto por la vista a `response_class`. Admite `str`, `bytes`, `dict`/`list` (JSON), generadores/iteradores (streaming), tuplas `(body, status, headers)` / `(body, status)` / `(body, headers)`, instancias de `Response`, otras `BaseResponse` (coerción con `force_type`) y *callables* WSGI. Lanza `TypeError` ante retornos inválidos o `None`. |
| `do_teardown_request(ctx, exc=None)` | Ejecuta todos los `teardown_request` (app y blueprints) y emite `request_tearing_down`. Usa `_CollectErrors` para ejecutar **todos** los callbacks y agrupar los errores. |
| `do_teardown_appcontext(ctx, exc=None)` | Ejecuta todos los `teardown_appcontext` y emite `appcontext_tearing_down`, con la misma recolección de errores. |

### 5.6 Contextos

| Método | Descripción |
|---|---|
| `app_context()` | Devuelve un `AppContext` para usar con `with` (habilita `current_app` y `g`). |
| `request_context(environ)` | Crea un `AppContext` con información de petición desde un entorno WSGI (`AppContext.from_environ`). Uso interno. |
| `test_request_context(*args, **kwargs)` | Construye un entorno WSGI con `testing.EnvironBuilder` y devuelve el contexto correspondiente; pensado para pruebas. |

### 5.7 Interfaz WSGI

| Método | Descripción |
|---|---|
| `wsgi_app(environ, start_response)` | Implementación real de la aplicación WSGI: crea y empuja el contexto, despacha la petición, maneja excepciones con `handle_exception`, preserva el contexto para el depurador de Werkzeug si procede, aplica `should_ignore_error` y siempre hace `ctx.pop(error)`. Separado de `__call__` para permitir envolverlo con middlewares (`app.wsgi_app = Middleware(app.wsgi_app)`). |
| `__call__(environ, start_response)` | Delega en `wsgi_app`; es lo que invoca el servidor WSGI. |

### 5.8 Ejecución, CLI y testing

| Método | Descripción |
|---|---|
| `run(host, port, debug, load_dotenv, **options)` | Arranca el servidor de desarrollo (`werkzeug.serving.run_simple`). **No apto para producción.** Carga `.env`/`.flaskenv`, resuelve host/puerto desde argumentos o `SERVER_NAME` (por defecto `127.0.0.1:5000`), activa `use_reloader`/`use_debugger`/`threaded`, muestra el banner y evita arrancar un segundo servidor si se invoca desde `flask run` (`FLASK_RUN_FROM_CLI`). |
| `make_shell_context()` | Devuelve el diccionario del shell interactivo (`app`, `g` + los `shell_context_processors` registrados). |
| `test_client(use_cookies=True, **kwargs)` | Crea un cliente de pruebas (`test_client_class` o `FlaskClient`), usable como gestor de contexto. |
| `test_cli_runner(**kwargs)` | Crea un *runner* para probar comandos CLI (`test_cli_runner_class` o `FlaskCliRunner`). |

### 5.9 Soporte asíncrono

| Método | Descripción |
|---|---|
| `ensure_sync(func)` | Devuelve `func` si es síncrona; si es una corrutina, la envuelve con `async_to_sync`. Se aplica a vistas, manejadores de error, hooks y señales. |
| `async_to_sync(func)` | Convierte una función corrutina en invocable síncronamente usando `asgiref.sync.async_to_sync`. Lanza `RuntimeError` si `asgiref` no está instalado (extra `flask[async]`). |

---

## 6. Flujo de ejecución de una petición (resumen)

```
Servidor WSGI
  └─ Flask.__call__
       └─ Flask.wsgi_app
            ├─ request_context(environ) → AppContext
            ├─ ctx.push()
            ├─ full_dispatch_request(ctx)
            │    ├─ señal request_started
            │    ├─ preprocess_request(ctx)        # url_value_preprocessors + before_request
            │    ├─ dispatch_request(ctx)          # vista o respuesta OPTIONS automática
            │    │    └─ (excepción) → handle_user_exception → handle_http_exception
            │    └─ finalize_request(ctx, rv)
            │         ├─ make_response(rv)
            │         ├─ process_response(ctx, resp) # after_request + save_session
            │         └─ señal request_finished
            ├─ (excepción no manejada) → handle_exception(ctx, e)  # 500 + got_request_exception
            └─ ctx.pop(error)
                 ├─ do_teardown_request
                 └─ do_teardown_appcontext
```

---

## 7. Notas y consideraciones

- **Deprecaciones activas**: los métodos del ciclo de vida reciben ahora `ctx: AppContext`; la firma antigua queda soportada mediante *wrappers* hasta Flask 4.0. El atributo/método `should_ignore_error` está deprecado y se eliminará en Flask 3.3 (se recomienda tratar los errores en los *teardown*).
- **`AppContext` unificado**: esta versión del código fusiona el contexto de aplicación y de petición en `AppContext` (con `ctx.has_request`, `ctx.request`, `ctx.url_adapter`, `ctx._get_session()`, `ctx._after_request_functions`).
- **Evitar ciclos de referencia**: la vista estática se registra con `weakref.ref` (ver issue #3761).
- **Seguridad en el manejo de errores**: `finalize_request` en modo `from_error_handler` nunca propaga fallos secundarios, para no enmascarar el error original.
- **Robustez en *teardown***: `_CollectErrors` garantiza que se ejecuten todos los callbacks y luego se agrupen y relancen los errores (`raise_any`).