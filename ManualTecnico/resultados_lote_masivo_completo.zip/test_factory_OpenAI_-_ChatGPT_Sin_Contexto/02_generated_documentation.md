DOCUMENTACIÓN TÉCNICA  
Archivo: tests/test_factory.py (nombre sugerido)

1. Propósito general  
El archivo contiene un conjunto de pruebas unitarias escritas con pytest para verificar el correcto funcionamiento de la aplicación Flask creada en el paquete flaskr. Las pruebas se centran en dos aspectos:
• La correcta configuración de la aplicación cuando se invoca la factoría create_app.  
• La respuesta del endpoint /hello mediante el cliente de pruebas de Flask.

2. Dependencias  
• flaskr.create_app – Fábrica de aplicación que devuelve una instancia de Flask.  
• pytest – Framework de pruebas utilizado para ejecutar las funciones de test.  
• client – Fixture de pytest (declarada normalmente en conftest.py) que expone el test client de Flask.

3. Componentes principales

3.1 Importaciones  
from flaskr import create_app – Importa la función factoría que instanciará la aplicación en cada prueba.

3.2 Función: test_config()  
Objetivo: comprobar que la factoría respeta o no la configuración de prueba (TESTING) según se le pase un diccionario de configuración.  
Pasos que ejecuta:  
a. Llama a create_app() sin argumentos y verifica que la propiedad testing de la instancia retornada sea False.  
b. Llama a create_app({"TESTING": True}) y verifica que la propiedad testing sea True.  
Cobertura: garantiza que la aplicación hereda correctamente los parámetros pasados por el usuario y que el modo de pruebas no queda activado por omisión.

3.3 Función: test_hello(client)  
Objetivo: validar el endpoint /hello.  
Parámetros:  
• client – fixture que envuelve app.test_client() y permite realizar peticiones HTTP internas.  
Pasos que ejecuta:  
a. Realiza una petición GET a /hello.  
b. Comprueba que el cuerpo de la respuesta (response.data) sea exactamente b"Hello, World!".  
Cobertura: asegura que la ruta está registrada y devuelve el mensaje esperado.

4. Flujo de ejecución de las pruebas  
1. pytest localiza las funciones cuyo nombre empieza por test_.  
2. Para test_config:  
   • Invoca create_app dos veces con distintos parámetros y realiza las aserciones.  
3. Para test_hello:  
   • Construye la app mediante la fixture client.  
   • Efectúa la petición GET y evalúa la respuesta.

5. Cómo ejecutar las pruebas  
En la raíz del proyecto:  
$ pytest  
pytest descubrirá el archivo, generará la aplicación con la configuración adecuada y reportará el resultado de las aserciones.

6. Puntos de extensión  
• Añadir más pruebas de configuración (por ejemplo, DATABASE, DEBUG).  
• Probar otros endpoints expuestos por flaskr.  
• Incluir pruebas negativas (comportamiento cuando /hello no está disponible o devuelve código ≠ 200).

7. Conclusión  
El archivo valida la creación de la aplicación en distintos contextos de configuración y comprueba un endpoint básico, sirviendo como primera línea de defensa ante regresiones en la factoría o en la ruta /hello.