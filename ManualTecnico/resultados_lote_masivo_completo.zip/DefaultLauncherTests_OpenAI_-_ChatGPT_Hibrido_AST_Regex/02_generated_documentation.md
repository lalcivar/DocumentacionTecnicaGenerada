# DefaultLauncherTests — Documentación técnica

## 1. Resumen ejecutivo
`DefaultLauncherTests` es una suite de pruebas de integración que valida el comportamiento de la implementación por defecto del `Launcher` de JUnit Platform en múltiples escenarios de descubrimiento y ejecución de pruebas.  
La clase cubre casos límite (errores de `TestEngine`, fallos de configuración, modo *dry-run*, cancelación, etc.) y proporciona utilidades auxiliares para verificar que los eventos y excepciones se emitan correctamente.

## 2. Especificación de constructores y métodos

> Notas generales  
> • Todos los métodos son *package-private* (visibilidad por defecto) salvo que se indique lo contrario.  
> • Los métodos anotados con `@Test`, `@ParameterizedTest` o similares son casos de prueba; devuelven `void` y no lanzan excepciones verificadas.  
> • Las utilidades auxiliares y sobrecargas de `execute()` retornan un valor compuesto (`ReportedData`) con la información capturada durante la ejecución de la prueba.

### Constructor implícito
| Firma | Descripción |
|-------|-------------|
| `DefaultLauncherTests()` | Constructor por defecto generado por el compilador. No realiza inicialización adicional. |

---

### Constantes de clase
| Nombre | Tipo | Valor | Propósito |
|--------|------|-------|-----------|
| `FOO` | `String` | `"DefaultLauncherTests.foo"` | Clave de propiedad usada en pruebas de parámetros de configuración. |
| `BAR` | `String` | `"DefaultLauncherTests.bar"` | Valor asociado a la propiedad `FOO`. |
| `noOp` | `Runnable` | `() -> {}` | Acción vacía utilizada en pruebas de ejecución de test. |

---

### Métodos de prueba (por orden de aparición)

| Método | @param | @return | @throws | Descripción |
|--------|--------|---------|---------|-------------|
| `constructLauncherWithoutAnyEngines()` | — | `void` | — | Verifica que el `Launcher` lanza una `PreconditionViolationException` cuando se crea sin motores de prueba. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | — | `void` | — | Asegura que se detectan IDs duplicados de `TestEngine` al construir el `Launcher`. |
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | — | `void` | — | Comprueba que un motor sin pruebas genera un `TestPlan` con un único nodo raíz. |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | — | `void` | — | Valida el tratamiento de un motor cuyo método `discover()` devuelve `null`. |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)` | `throwableClass` `Class<? extends Throwable>` — requerido | `void` | — | Ejercita el escenario donde el motor lanza un `Throwable` durante la fase de descubrimiento. |
| `reportsEngineExecutionFailuresWithoutPriorEvents()` | — | `void` | — | Garantiza que los fallos de ejecución sin eventos previos se propaguen correctamente. |
| `reportsEngineExecutionFailuresForSkippedEngine()` | — | `void` | — | Verifica que se propaga la excepción incluso si el motor marca su descriptor como *skipped*. |
| `reportsEngineExecutionFailuresForStartedEngine()` | — | `void` | — | Similar al anterior, pero tras un evento `executionStarted`. |
| `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` | — | `void` | — | Comprueba propagación de fallo después de un `successful()` reportado. |
| `reportsEngineExecutionFailuresForFailedFinishedEngine()` | — | `void` | — | Valida el tratamiento cuando la ejecución ya finalizó con fallo y luego lanza una excepción adicional. |
| `reportsSkippedEngines()` | — | `void` | — | Asegura que un motor completamente omitido emite únicamente eventos `executionSkipped`. |
| `reportsFinishedEngines()` | — | `void` | — | Verifica la correcta secuencia de eventos `executionStarted` / `executionFinished` con estado `SUCCESSFUL`. |
| `discoverTestPlanForSingleEngine()` | — | `void` | — | Descubre y valida un `TestPlan` compuesto por un único motor con dos pruebas. |
| `discoverTestPlanForMultipleEngines()` | — | `void` | — | Descubre un plan con dos motores independientes y verifica su estructura. |
| `launcherAppliesPostDiscoveryFilters()` | — | `void` | — | Comprueba que los filtros de post-descubrimiento se aplican y podan correctamente el árbol de descriptores. |
| `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()` | — | `void` | — | Valida que se pasa un mapa de parámetros vacío cuando no se configuran propiedades. |
| `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()` | — | `void` | — | Verifica que se propagan los parámetros de configuración especificados. |
| `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | — | `void` | — | Comprueba que los parámetros se resuelven a partir de `System.getProperty` si no se proveen explícitamente. |
| `withAdditionalListener()` | — | `void` | — | Garantiza que los `TestExecutionListener` adicionales reciben los eventos esperados. |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | — | `void` | — | Valida que los descriptores excluidos se eliminen del `TestPlan`. |
| `reportsDynamicTestDescriptorsCorrectly()` | — | `void` | — | Comprueba el manejo de descriptores dinámicos registrados en tiempo de ejecución. |
| `launcherCanExecuteTestPlanExactlyOnce()` | — | `void` | — | Asegura que un mismo `TestPlan` no puede ejecutarse más de una vez. |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | — | `void` | — | Verifica la advertencia al usar el prefijo `junit-` en motores de terceros. |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` | — | `void` | — | Asegura la excepción cuando un motor externo intenta usar el ID `junit-jupiter`. |
| `thirdPartyEngineClaimingToBeVintageResultsInException()` | — | `void` | — | Idem para el ID `junit-vintage`. |
| `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | — | `void` | — | Verifica el modo *dry-run*: todos los eventos se reportan pero las pruebas no se ejecutan. |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | — | `void` | — | Comprueba que los `LauncherDiscoveryListener` reciben llamadas a `selectorProcessed`. |
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)` | `listener` `LogRecordListener` — requerido | `void` | — | Prueba que los problemas críticos de descubrimiento provocan fallo de ejecución y se registran los no críticos. |
| `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)` | `listener` `LogRecordListener` — requerido | `void` | — | Valida que los problemas no críticos solo se registran y no detienen la ejecución. |
| `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)` | `listener` `LogRecordListener` — requerido | `void` | — | Verifica que se registran todas las incidencias cuando el descubrimiento falla con excepción. |
| `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)` | `listener` `LogRecordListener` — requerido | `void` | — | Asegura el registro de incidencias no críticas cuando la ejecución falla. |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | — | `void` | — | Comprueba el fallo cuando un selector `UniqueId` con prefijo de motor no puede resolverse. |
| `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` | — | `void` | — | Valida que se ignoran selectores sin prefijo de motor que no se resuelvan. |
| `reportsEngineExecutionFailureForSelectorResolutionFailure()` | — | `void` | — | Verifica la propagación de la excepción al fallar la resolución de un selector. |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` | — | `void` | — | Comprueba que se puede ajustar el umbral de severidad crítica mediante parámetros de configuración. |
| `failsIfCriticalSeverityIsConfiguredIncorrectly()` | — | `void` | — | Garantiza que un valor de severidad inválido provoca excepción. |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | — | `void` | — | Asegura que las incidencias críticas causen fallo en fase de descubrimiento si así se configura. |
| `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)` | `phase` `String` — requerido<br>`listener` `LogRecordListener` — requerido | `void` | — | Verifica que las incidencias no críticas se registran una única vez, independientemente de la fase. |
| `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()` | — | `void` | — | Garantiza excepción al indicar una fase de fallo inválida. |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | — | `void` | — | Comprueba el comportamiento cuando se cancela la ejecución mediante `CancellationToken`. |

---

### Métodos auxiliares y sobrecargas

#### `assertDiscoveryFailed`
| Firma | @param | @return | @throws |
|-------|--------|---------|---------|
| `private void assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)` | `testEngine` `TestEngine` — requerido<br>`inOrder` `InOrder` — requerido<br>`discoveryListener` `LauncherDiscoveryListener` — requerido | `void` | — |
Descripción: Verifica que el resultado de descubrimiento esté marcado como `FAILED` y la excepción contenga el mensaje adecuado.

#### `execute` (sobrecarga 1)
| Firma | @param | @return | @throws |
|-------|--------|---------|---------|
| `private static ReportedData execute(TestEngine engine)` | `engine` `TestEngine` — requerido | `ReportedData` | — |
Descripción: Ejecuta el ciclo completo *discover → execute* con configuración y oyente por defecto.

#### `execute` (sobrecarga 2)
| Firma | @param | @return | @throws |
|-------|--------|---------|---------|
| `private static ReportedData execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)` | `engine` `TestEngine` — requerido<br>`discoveryConfigurer` `UnaryOperator<LauncherDiscoveryRequestBuilder>` — requerido | `ReportedData` | — |
Descripción: Permite ajustar el `LauncherDiscoveryRequestBuilder` antes de ejecutar.

#### `execute` (sobrecarga 3)
| Firma | @param | @return | @throws |
|-------|--------|---------|---------|
| `private static ReportedData execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)` | `engine` `TestEngine` — requerido<br>`discoveryConfigurer` `UnaryOperator<LauncherDiscoveryRequestBuilder>` — requerido<br>`executionConfigurer` `UnaryOperator<LauncherExecutionRequestBuilder>` — requerido | `ReportedData` | — |
Descripción: Sobrecarga más flexible que permite modificar tanto la fase de descubrimiento como la de ejecución.

#### `findFirstDiscoveryIssueLogRecord`
| Firma | @param | @return | @throws |
|-------|--------|---------|---------|
| `private static LogRecord findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)` | `listener` `LogRecordListener` — requerido<br>`level` `Level` — requerido | `LogRecord` | `NoSuchElementException` si no se encuentra ningún registro coincidente |
Descripción: Devuelve el primer `LogRecord` correspondiente a incidencias de descubrimiento con el nivel indicado.

---

### Tipo interno `ReportedData`
`record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier, TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)`
| Componente | Tipo | Descripción |
|------------|------|-------------|
| `testPlan` | `TestPlan` | Plan de pruebas resultante del descubrimiento. |
| `testIdentifier` | `TestIdentifier` | Identificador reportado en el primer evento `executionStarted`. |
| `testExecutionResult` | `TestExecutionResult` | Resultado final asociado al identificador anterior. |
| `startTime` | `Instant` | Marca temporal del primer evento `executionStarted`. |
| `finishTime` | `Instant` | Marca temporal del evento `executionFinished` correspondiente. |

---

## 3. Ejemplo de uso

```java
import org.junit.platform.launcher.*;
import org.junit.platform.launcher.core.*;

public class LauncherSample {

    public static void main(String[] args) {
        // 1️⃣ Creamos un TestEngine (real o stub)
        TestEngine engine = new DemoHierarchicalTestEngine("sample-engine");
        ((DemoHierarchicalTestEngine) engine).addTest("simpleTest", () -> System.out.println("executed"));

        // 2️⃣ Construimos el Launcher con dicho motor
        Launcher launcher = LauncherFactoryForTestingPurposesOnly
                .createLauncher(engine);

        // 3️⃣ Descubrimos un TestPlan a partir de un selector
        LauncherDiscoveryRequest discoveryRequest = LauncherDiscoveryRequestBuilder.request()
                .selectors(DiscoverySelectors.selectPackage("any"))
                .build();
        TestPlan testPlan = launcher.discover(discoveryRequest);

        // 4️⃣ Ejecutamos el plan y escuchamos los eventos
        SummaryGeneratingListener listener = new SummaryGeneratingListener();
        launcher.execute(LauncherExecutionRequestBuilder.request(testPlan)
                .listeners(listener)
                .build());

        // 5️⃣ Imprimimos un resumen
        listener.getSummary().printTo(System.out);
    }
}
```

@author JUnit Platform contributors