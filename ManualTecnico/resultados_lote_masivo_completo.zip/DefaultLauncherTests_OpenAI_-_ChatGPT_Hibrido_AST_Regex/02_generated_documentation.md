# Documentación técnica – `DefaultLauncherTests`

## 1. Resumen ejecutivo  
La clase `DefaultLauncherTests` valida el comportamiento de la implementación por defecto de `org.junit.platform.launcher.Launcher` a través de un conjunto extenso de pruebas de integración y utilidades auxiliares.  
Verifica escenarios de descubrimiento y ejecución de tests, manejo de fallos, filtros, problemas de descubrimiento y parámetros de configuración, simulando motores (`TestEngine`) reales y defectuosos.

---

## 2. Especificación de métodos y constructores  

**Convenciones**  
• Todas las filas marcadas como `–` indican que el elemento no aplica.  
• El modificador de acceso real (package-private en su mayoría) se conserva exactamente como en el código.  
• Las pruebas anotadas con `@Test` o `@ParameterizedTest` nunca retornan valores; los errores se capturan internamente mediante aserciones.  

> IMPORTANTE: Se documentan absolutamente **todos** los métodos presentes en la clase, incluidos sobrecargas y utilidades privadas.

### Leyenda de tablas
| Columna | Significado |
|---------|-------------|
| `@param` | Nombre del parámetro |
| `Tipo` | Tipo Java exacto |
| `Req.` | ¿Parámetro obligatorio? Sí/No |
| `Descripción` | Breve propósito |
| `@return` | Tipo devuelto |
| `@throws` | Excepción declarada (propagada fuera del método) |

---

### constructLauncherWithoutAnyEngines()
| @param | Tipo | Req. | Descripción |
|--------|------|------|-------------|
| – | – | – | – |
| @return | `void` – No retorna valor |
| @throws | – | – |

---

### constructLauncherWithMultipleTestEnginesWithDuplicateIds()
| @param | Tipo | Req. | Descripción |
| – | – | – | – |
| @return | `void` |
| @throws | – |

---

### discoverEmptyTestPlanWithEngineWithoutAnyTests()
| @param | Tipo | Req. | Descripción |
| – | – | – | – |
| @return | `void` |
| @throws | – |

---

### discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()
| @param | Tipo | Req. |
| – | – | – |
| @return | `void` |
| @throws | – |

---

### discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class\<? extends Throwable> throwableClass)
| @param | Tipo | Req. | Descripción |
| throwableClass | `Class<? extends Throwable>` | Sí | Tipo de excepción a simular durante la fase de descubrimiento |
| @return | `void` |
| @throws | – |

---

### assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)
| @param | Tipo | Req. | Descripción |
| testEngine | `TestEngine` | Sí | Motor de pruebas que provocó la falla |
| inOrder | `org.mockito.InOrder` | Sí | Verificador en orden de Mockito |
| discoveryListener | `LauncherDiscoveryListener` | Sí | Oyente utilizado para comprobar eventos |
| @return | `void` |
| @throws | – |

---

### reportsEngineExecutionFailuresWithoutPriorEvents()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsEngineExecutionFailuresForSkippedEngine()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsEngineExecutionFailuresForStartedEngine()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsEngineExecutionFailuresForFailedFinishedEngine()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsSkippedEngines()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsFinishedEngines()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### discoverTestPlanForSingleEngine()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### discoverTestPlanForMultipleEngines()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### launcherAppliesPostDiscoveryFilters()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### withoutConfigurationParameters_LookupFallsBackToSystemProperty()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### withAdditionalListener()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsDynamicTestDescriptorsCorrectly()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### launcherCanExecuteTestPlanExactlyOnce()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### thirdPartyEngineClaimingToBeJupiterResultsInException()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### thirdPartyEngineClaimingToBeVintageResultsInException()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### assertImposter(String id)
| @param | Tipo | Req. | Descripción |
| id | `String` | Sí | ID del motor impostor |
| @return | `void` |
| @throws | – |

---

### dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### notifiesDiscoveryListenersOfProcessedSelectors()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)
| @param | Tipo | Req. | Descripción |
| listener | `LogRecordListener` | Sí | Inyección JUnit Jupiter para capturar logs |
| @return | `void` |
| @throws | – |

---

### logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)
| @param | listener | `LogRecordListener` | Sí | Captura de logs |
| @return | `void` |
| @throws | – |

---

### logsAllIssuesForDiscoveryFailure(LogRecordListener listener)
| @param | listener | `LogRecordListener` | Sí |
| @return | `void` |
| @throws | – |

---

### logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)
| @param | listener | `LogRecordListener` | Sí |
| @return | `void` |
| @throws | – |

---

### reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsEngineExecutionFailureForSelectorResolutionFailure()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### allowsConfiguringCriticalDiscoveryIssueSeverity()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### failsIfCriticalSeverityIsConfiguredIncorrectly()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)
| @param | Tipo | Req. | Descripción |
| phase | `String` | Sí | Fase en la que se fuerza el fallo (`discovery`/`execution`) |
| listener | `LogRecordListener` | Sí | Captura de logs |
| @return | `void` |
| @throws | – |

---

### failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()
| @param | – | – | – |
| @return | `void` |
| @throws | – |

---

### execute(TestEngine engine)
| @param | Tipo | Req. | Descripción |
| engine | `TestEngine` | Sí | Motor a instrumentar |
| @return | `ReportedData` | Encapsula `TestPlan`, `TestIdentifier`, `TestExecutionResult` y metadatos de tiempo |
| @throws | – |

---

### execute(TestEngine engine, UnaryOperator\<LauncherDiscoveryRequestBuilder> discoveryConfigurer)
| @param | engine | `TestEngine` | Sí | Motor bajo prueba |
| discoveryConfigurer | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Configurador extra de descubrimiento |
| @return | `ReportedData` |
| @throws | – |

---

### execute(TestEngine engine, UnaryOperator\<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator\<LauncherExecutionRequestBuilder> executionConfigurer)
| @param | engine | `TestEngine` | Sí |
| discoveryConfigurer | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí |
| executionConfigurer | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Ajustes adicionales antes de la ejecución |
| @return | `ReportedData` |
| @throws | – |

---

### findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)
| @param | listener | `LogRecordListener` | Sí | Fuente de registros |
| level | `Level` | Sí | Nivel de log a buscar |
| @return | `LogRecord` | Primer registro coincidente |
| @throws | `NoSuchElementException` | Si no se encuentra ningún registro |

---

### ReportedData(...) – record constructor
Constructor implícito generado por el compilador Java para el record `ReportedData`.
| @param | Tipo | Req. | Descripción |
| testPlan | `TestPlan` | Sí | Plan de pruebas resultante |
| testIdentifier | `TestIdentifier` | Sí | Identificador principal del motor |
| testExecutionResult | `TestExecutionResult` | Sí | Resultado asociado |
| startTime | `Instant` | Sí | Marca temporal de inicio |
| finishTime | `Instant` | Sí | Marca temporal de fin |
| @return | Instancia `ReportedData` |
| @throws | – |

---

## 3. Ejemplo de uso  

A continuación se muestra un uso típico del *helper* `execute(...)` para lanzar un motor stub y obtener la información reportada:

```java
import static org.junit.platform.engine.TestExecutionResult.successful;
import org.junit.platform.engine.support.descriptor.EngineDescriptor;
import org.junit.platform.engine.*;

TestEngine stubEngine = new TestEngineStub("demo-engine") {
    @Override
    public TestDescriptor discover(EngineDiscoveryRequest request, UniqueId id) {
        return new EngineDescriptor(id, "DemoEngine");
    }

    @Override
    public void execute(ExecutionRequest request) {
        EngineExecutionListener l = request.getEngineExecutionListener();
        TestDescriptor root = request.getRootTestDescriptor();
        l.executionStarted(root);
        l.executionFinished(root, successful());
    }
};

// Obtiene ReportedData con toda la información relevante
DefaultLauncherTests.ReportedData data =
        DefaultLauncherTests.execute(stubEngine);

// Assertions de ejemplo
assert data.testPlan().containsTests();
assert data.testExecutionResult().getStatus() == TestExecutionResult.Status.SUCCESSFUL;
```

Este fragmento ilustra cómo instanciar un `TestEngine` minimalista, delegar la ejecución a los métodos auxiliares de `DefaultLauncherTests` y, posteriormente, analizar los resultados devueltos.