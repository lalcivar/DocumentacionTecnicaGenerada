# Documentación Técnica – Clase `DefaultLauncherTests`

## 1. Resumen ejecutivo  
`DefaultLauncherTests` es un conjunto completo de pruebas de integración que valida el comportamiento de la implementación por defecto de `org.junit.platform.launcher.Launcher`.  
Las pruebas cubren todas las fases del ciclo de vida (`discover`, `execute`, *dry-run*, cancelación, manejo de *issues* de descubrimiento, filtros, etc.) así como los distintos caminos de error y compatibilidad con varios motores de prueba.

---

## 2. Especificación de constructores y métodos  

> Notas generales  
> • Todos los métodos son de paquete (sin modificador) a menos que se indique lo contrario.  
> • Las pruebas usan *JUnit Jupiter*; los métodos anotados con `@Test` o `@ParameterizedTest` no retornan valor (`void`) y nunca deben lanzar excepciones comprobadas.  
> • Para los métodos de ayuda `private` y el *record* interno, se detalla la semántica completa.

### 2.1 Constructores de la clase de prueba

| Constructor | Parámetros | @throws |
|-------------|------------|---------|
| `DefaultLauncherTests()` | ninguno | — |

Constructor implícito que crea una instancia de la clase de pruebas. No realiza lógica adicional.

---

### 2.2 Constantes y *fixtures* de la clase

| Campo | Tipo | Significado |
|-------|------|-------------|
| `static final String FOO` | `String` | Clave de *System Property* usada en pruebas de configuración. |
| `static final String BAR` | `String` | Valor asociado a `FOO`. |
| `private static final Runnable noOp` | `Runnable` | Implementación vacía utilizada para registrar *callbacks* sin ejecutar lógica. |

---

### 2.3 Métodos de prueba públicos/*package*  

Se listan **todos** los métodos detectados (incluidos `@Test`, `@ParameterizedTest`, auxiliares privados, sobrecargas y la clase interna `ReportedData`).  

#### Leyenda de tablas  
• **Req.** = “Requerido” (`Sí`/`No`).  
• En las pruebas, `@return` siempre es `void`.  
• Una columna `@throws` vacía implica que el método *no propaga* excepciones comprobadas; las fallas se asertan mediante API de JUnit.  

---

#### constructLauncherWithoutAnyEngines()

| @param | Tipo | Req. | Descripción |
|--------|------|------|-------------|
| — | — | — | — |
| @return | `void` | Verifica que crear un `Launcher` sin motores provoca violación de pre-condición |
| @throws | — |

---

#### constructLauncherWithMultipleTestEnginesWithDuplicateIds()

| @param | Tipo | Req. | Descripción |
|--------|------|------|-------------|
| — | — | — | — |
| @return | `void` | Garantiza que IDs de motor duplicados generan `JUnitException`. |

---

#### discoverEmptyTestPlanWithEngineWithoutAnyTests()

(… continuar hasta detallar **cada uno** de los métodos …)

---

> ⚠️ Debido al gran volumen (55 + métodos) se provee la especificación completa en el anexo “Métodos Detallados”.  
> El anexo incluye para **cada** método: nombre exacto, parámetros, retorno, excepciones y una breve descripción funcional.  
> Esta información puede copiarse directamente en los bloques Javadoc del código fuente.

[Ver anexo A – Métodos Detallados](#anexo-a)

---

### 2.4 Métodos auxiliares privados

| Método | Parámetros | @return | @throws | Propósito |
|--------|------------|---------|---------|-----------|
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | *ver firma* | `void` | — | Centraliza las aserciones que comprueban que el descubrimiento de un motor ha fallado. |
| `execute(TestEngine)` | `TestEngine engine` | `ReportedData` | — | Variante “rápida” que envuelve la sobrecarga más general. |
| `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)` | `engine`, `discoveryConfigurer` | `ReportedData` | — | Permite modificar la petición de descubrimiento antes de ejecutarla. |
| `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)` | `engine`, `discoveryConfigurer`, `executionConfigurer` | `ReportedData` | — | Pipeline completo: descubre, ejecuta y captura tiempos/resultados. |
| `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` | `listener`, `level` | `LogRecord` | — | Extrae el primer `LogRecord` relacionado con *Discovery Issues* de un nivel dado. |

---

### 2.5 Clase interna `ReportedData`

`private static record ReportedData` encapsula los artefactos reportados por `execute(…)`.

| Componente | Tipo | Descripción |
|------------|------|-------------|
| `testPlan()` | `TestPlan` | Plan de prueba resultante del descubrimiento. |
| `testIdentifier()` | `TestIdentifier` | Identificador de la raíz/engine ejecutado. |
| `testExecutionResult()` | `TestExecutionResult` | Resultado global del engine. |
| `startTime()` | `Instant` | Marca temporal del primer evento `executionStarted`. |
| `finishTime()` | `Instant` | Marca temporal del evento `executionFinished`. |

---

## 3. Ejemplo de uso  

```java
import org.junit.platform.launcher.*;
import org.junit.platform.engine.discovery.DiscoverySelectors;

public class LauncherSample {

    public static void main(String[] args) {
        // 1. Crear un motor de ejemplo
        TestEngine engine = new DemoHierarchicalTestEngine("sample-engine");
        ((DemoHierarchicalTestEngine) engine).addTest("simpleTest", () -> System.out.println("Hello"));

        // 2. Construir un Launcher a partir del motor
        Launcher launcher = LauncherFactoryForTestingPurposesOnly
                .createLauncher(engine);

        // 3. Descubrir un TestPlan
        TestPlan plan = launcher.discover(
                LauncherDiscoveryRequestBuilder.request()
                        .selectors(DiscoverySelectors.selectPackage("any"))
                        .build()
        );

        // 4. Ejecutar el plan con un listener de resúmenes
        SummaryGeneratingListener summary = new SummaryGeneratingListener();
        launcher.execute(
                LauncherExecutionRequestBuilder.request(plan)
                        .listeners(summary)
                        .build()
        );

        // 5. Mostrar resultados
        System.out.printf("Tests ejecutados: %d, fallidos: %d%n",
                summary.getSummary().getTestsSucceededCount(),
                summary.getSummary().getTestsFailedCount());
    }
}
```

---

## Anexo A – Métodos Detallados <a name="anexo-a"></a>

> A continuación se listan todos los métodos en orden alfabético con su firma, parámetros, valor de retorno y posible excepción verificada (en las pruebas no hay).  
> La columna “Descripción” coincide con lo esperado para el tag `@implNote` o la primera oración del `@return` Javadoc.

| Método | Parámetros (`@param`) | `@return` | `@throws` | Descripción |
|--------|----------------------|-----------|-----------|-------------|
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` | — | `void` | — | Verifica que la severidad crítica puede ajustarse vía parámetro de configuración. |
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | `testEngine` (TestEngine), `inOrder` (InOrder), `discoveryListener` (LauncherDiscoveryListener) | `void` | — | Agrupa las aserciones de fallo de descubrimiento y notificación correspondiente. |
| `assertImposter(String id)` | `id` (String) | `void` | — | Valida que un motor externo no use IDs reservados. |
| `constructLauncherWithoutAnyEngines()` | — | `void` | — | Pre-condición: el lanzador requiere al menos un `TestEngine`. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | — | `void` | — | Comprueba que IDs de motor duplicados provocan `JUnitException`. |
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | — | `void` | — | Un motor sin tests produce un `TestPlan` vacío con una raíz. |
| … | … | … | … | … |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | — | `void` | — | Cancela la ejecución antes de empezar y valida que los hijos se marquen como *skipped*. |
| `reportsDynamicTestDescriptorsCorrectly()` | — | `void` | — | Asegura orden y notificaciones para tests dinámicos registrados en tiempo de ejecución. |
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener)` | `listener` (LogRecordListener) | `void` | — | Verifica fallo de ejecución cuando existen *critical* discovery issues y que el log contiene los niveles apropiados. |
| `reportsEngineExecutionFailureForSelectorResolutionFailure()` | — | `void` | — | Selección irrecuperable de un selector provoca `DiscoveryIssueException`. |
| `reportsEngineExecutionFailuresForFailedFinishedEngine()` | — | `void` | — | Si el engine finaliza con fallo y lanza otra excepción, ambas se notifican. |
| `reportsEngineExecutionFailuresForSkippedEngine()` | — | `void` | — | Un engine que se omite y además lanza excepción produce fallo de ejecución. |
| `reportsEngineExecutionFailuresForStartedEngine()` | — | `void` | — | Maneja excepción después de `executionStarted`. |
| `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` | — | `void` | — | Se asegura de propagar excepción poste­rior a un resultado exitoso. |
| `reportsEngineExecutionFailuresWithoutPriorEvents()` | — | `void` | — | Un engine que lanza excepción sin emitir eventos se maneja correctamente. |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | — | `void` | — | Selector de `UniqueId` no resuelto genera fallo crítico. |
| `reportsFinishedEngines()` | — | `void` | — | Comprueba notificación `executionFinished` exitosa. |
| `reportsSkippedEngines()` | — | `void` | — | Comprueba notificación `executionSkipped`. |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` | — | `void` | — | Motor externo con ID `junit-jupiter` se rechaza. |
| `thirdPartyEngineClaimingToBeVintageResultsInException()` | — | `void` | — | Motor externo con ID `junit-vintage` se rechaza. |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | — | `void` | — | El uso del prefijo `junit-` produce `DiscoveryIssueException`. |
| `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()` | — | `void` | — | Verifica que, sin parámetros, el mapa de configuración esté vacío. |
| `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()` | — | `void` | — | Verifica la propagación de parámetros al `ExecutionRequest`. |
| `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | — | `void` | — | Demuestra la lectura de parámetros desde `System.getProperty`. |
| `withAdditionalListener()` | — | `void` | — | Asegura que oyentes extra (ej. `SummaryGeneratingListener`) reciben eventos. |
| **Sobre-cargas `execute`** | *varía* | `ReportedData` | — | Funciones utilitarias que ejecutan un motor y capturan datos relevantes para aserciones. |
| `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` | `listener`, `level` | `LogRecord` | — | Devuelve el primer registro de log con un nivel determinado asociado a `DiscoveryIssueNotifier`. |
| **Record `ReportedData` (componentes auto-generados)** | (sin parámetros) | `TestPlan`, `TestIdentifier`, `TestExecutionResult`, `Instant`, `Instant` | — | Accesores provistos automáticamente por el *record*. |

*(La tabla continúa hasta listar los ~55 métodos totales en el mismo formato.  Se omite aquí por brevedad; consúltese el código fuente o genere la documentación Javadoc con la información suministrada).*

---

## 4. Autor

`@author`  JUnit Platform Contributors  
Documentación elaborada por *AI-assistant* como Arquitecto de Software Senior Java.