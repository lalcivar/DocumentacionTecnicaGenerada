# Documentación Técnica

## `generador_documentacion.py` — Generador automático de manuales técnicos mediante IA

---

## 1. Descripción general

Este script de Python implementa un **generador automático de documentación técnica**. Su función es leer el contenido de un archivo de código fuente Java, enviarlo a un modelo de lenguaje (LLM) a través de la API de **OpenRouter** (usando el SDK oficial de OpenAI como cliente compatible), y guardar la respuesta del modelo —un manual técnico redactado en español— en un archivo Markdown local.

El flujo completo es:

```
Archivo .java  →  Lectura local  →  Petición al LLM  →  Respuesta en texto  →  Archivo .md
```

**Caso de uso concreto:** documentar la clase `ResultPrinter` del framework JUnit (`main/java/junit/textui/ResultPrinter.java`), generando el archivo `MANUAL_TECNICO_JUNIT.md`.

---

## 2. Dependencias

| Dependencia | Tipo | Propósito |
|---|---|---|
| `openai` (`>=1.0`) | Librería externa | Cliente HTTP para consumir APIs compatibles con el estándar OpenAI Chat Completions. |
| Conexión a Internet | Requisito de entorno | Necesaria para alcanzar el endpoint de OpenRouter. |
| Archivo Java de entrada | Requisito de entorno | Debe existir en la ruta relativa indicada. |

Instalación:

```bash
pip install openai
```

---

## 3. Componentes principales

### 3.1 Importación

```python
from openai import OpenAI
```

Se importa la clase `OpenAI`, que encapsula la configuración de conexión y expone los recursos de la API (`chat`, `completions`, `embeddings`, etc.).

---

### 3.2 Configuración del cliente (ámbito global)

```python
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="sk-or-v1-..."
)
```

**Tipo:** instancia de `OpenAI` definida a nivel de módulo (variable global).

**Parámetros:**

| Parámetro | Valor | Descripción |
|---|---|---|
| `base_url` | `https://openrouter.ai/api/v1` | Redirige las peticiones desde los servidores de OpenAI hacia **OpenRouter**, un enrutador que expone múltiples modelos (Google, Anthropic, Meta, etc.) bajo una interfaz unificada compatible con OpenAI. |
| `api_key` | Clave `sk-or-v1-...` | Credencial de autenticación de OpenRouter, incrustada directamente en el código fuente. |

**Responsabilidad:** mantener la sesión reutilizable para todas las llamadas a la API dentro del módulo.

> ⚠️ **Advertencia de seguridad:** la clave de API está escrita literalmente en el código (*hardcoded*). Esto expone la credencial a cualquier persona con acceso al archivo o al repositorio. Ver la sección 7 (Mejoras recomendadas).

---

### 3.3 Función `generar_documentacion()`

```python
def generar_documentacion():
```

**Firma:** `generar_documentacion() -> None`

**Parámetros:** ninguno (toda la configuración está codificada internamente).

**Valor de retorno:** `None`. La función produce **efectos secundarios**: escritura de un archivo en disco y mensajes por consola.

**Responsabilidad:** orquestar el proceso completo de documentación. Internamente se divide en tres etapas:

#### Etapa 1 — Lectura del código fuente

```python
ruta_java = "main/java/junit/textui/ResultPrinter.java"

with open(ruta_java, 'r', encoding='utf-8') as f:
    codigo = f.read()
```

- Define una **ruta relativa fija** al archivo Java objetivo. Se resuelve respecto al directorio de trabajo actual (CWD) desde el que se ejecuta el script.
- Abre el archivo en modo lectura de texto con codificación `UTF-8`.
- Carga el contenido completo en la variable `codigo` (cadena de texto).
- El uso de `with` garantiza el cierre del descriptor de archivo incluso si ocurre una excepción.
- Imprime una traza informativa indicando qué archivo se está procesando.

#### Etapa 2 — Solicitud al modelo de lenguaje

```python
response = client.chat.completions.create(
  model="google/gemini-2.0-flash-001",
  messages=[
    {"role": "system", "content": "Eres un experto en ingeniería de software..."},
    {"role": "user",   "content": codigo}
  ]
)
```

| Elemento | Detalle |
|---|---|
| `model` | `google/gemini-2.0-flash-001` — modelo de Google servido vía OpenRouter, elegido por su velocidad y amplia ventana de contexto para análisis de código. |
| Mensaje `system` | **Prompt de sistema.** Fija el rol ("experto en ingeniería de software") y la tarea: generar un manual técnico **en español** que explique el propósito de la clase, sus métodos y su integración en el sistema. |
| Mensaje `user` | Contiene el código Java completo leído en la etapa 1, sin preprocesamiento. |
| `response` | Objeto `ChatCompletion` con metadatos (uso de tokens, id, modelo) y la lista `choices` de respuestas generadas. |

Esta llamada es **síncrona y bloqueante**: el script espera hasta recibir la respuesta completa del servidor.

#### Etapa 3 — Persistencia del resultado

```python
manual_contenido = response.choices[0].message.content

with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
    m.write(manual_contenido)
```

- Extrae el texto de la primera (y única) alternativa generada: `choices[0].message.content`.
- Escribe el contenido en `MANUAL_TECNICO_JUNIT.md` en el directorio de trabajo actual.
- El modo `"w"` **sobrescribe** el archivo si ya existe.
- Finalmente, imprime mensajes de confirmación para el usuario.

---

### 3.4 Punto de entrada

```python
generar_documentacion()
```

La función se invoca directamente al final del módulo, a nivel superior. Esto significa que el script **se ejecuta automáticamente al ser importado**, además de al ejecutarse directamente.

---

## 4. Artefactos de entrada y salida

| | Nombre | Formato | Descripción |
|---|---|---|---|
| **Entrada** | `main/java/junit/textui/ResultPrinter.java` | Texto / Java | Código fuente a documentar. Debe existir antes de la ejecución. |
| **Salida** | `MANUAL_TECNICO_JUNIT.md` | Markdown | Manual técnico en español generado por el LLM. |
| **Salida** | Consola (`stdout`) | Texto | Mensajes de progreso y confirmación. |

---

## 5. Ejecución

```bash
# Desde el directorio que contiene la carpeta "main/"
python generador_documentacion.py
```

Salida esperada:

```
--- Procesando código de: main/java/junit/textui/ResultPrinter.java ---

¡Documentación generada con éxito!
Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```

---

## 6. Limitaciones y consideraciones

1. **Sin manejo de errores.** No hay bloques `try/except`. Fallan con excepción no capturada:
   - `FileNotFoundError` si la ruta del `.java` no existe.
   - Errores de red/autenticación (`APIConnectionError`, `AuthenticationError`, `RateLimitError`) al llamar a OpenRouter.
   - `AttributeError`/`IndexError` si la respuesta viene vacía o bloqueada por filtros de contenido.
2. **Valores codificados (*hardcoded*).** Ruta de entrada, nombre de salida, modelo y clave de API no son configurables sin editar el código.
3. **Procesa un único archivo.** No recorre directorios ni admite lotes.
4. **Límite de contexto.** Archivos Java muy extensos pueden exceder la ventana de contexto del modelo o incrementar el costo por tokens.
5. **Costo y latencia.** Cada ejecución consume cuota de la cuenta de OpenRouter.
6. **No determinista.** Sin fijar `temperature`, el contenido generado puede variar entre ejecuciones.
7. **Credencial expuesta.** La clave visible en el código debe considerarse **comprometida** y ser revocada/rotada.

---

## 7. Mejoras recomendadas

| Área | Recomendación |
|---|---|
| Seguridad | Mover la clave a una variable de entorno: `api_key=os.getenv("OPENROUTER_API_KEY")`. Revocar la clave actual. |
| Parametrización | Recibir ruta de entrada, ruta de salida y modelo como argumentos de la función o vía `argparse`. |
| Robustez | Envolver E/S y llamada a la API en `try/except` con mensajes claros y códigos de salida. |
| Escalabilidad | Usar `pathlib.Path.rglob("*.java")` para documentar árboles de directorios completos. |
| Reproducibilidad | Especificar `temperature=0.2` y `max_tokens` explícitos. |
| Buenas prácticas | Proteger el punto de entrada con `if __name__ == "__main__":`. |
| Trazabilidad | Sustituir `print` por el módulo `logging`. |

### Ejemplo refactorizado (fragmento)

```python
import os
import argparse
from pathlib import Path
from openai import OpenAI

PROMPT_SISTEMA = (
    "Eres un experto en ingeniería de software. Genera un manual técnico "
    "detallado en español para el código proporcionado."
)

def generar_documentacion(ruta_entrada: Path, ruta_salida: Path,
                          modelo: str = "google/gemini-2.0-flash-001") -> None:
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=os.environ["OPENROUTER_API_KEY"],
    )
    codigo = ruta_entrada.read_text(encoding="utf-8")
    respuesta = client.chat.completions.create(
        model=modelo,
        temperature=0.2,
        messages=[
            {"role": "system", "content": PROMPT_SISTEMA},
            {"role": "user", "content": codigo},
        ],
    )
    ruta_salida.write_text(respuesta.choices[0].message.content, encoding="utf-8")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Genera documentación técnica con IA.")
    parser.add_argument("entrada", type=Path)
    parser.add_argument("-o", "--salida", type=Path, default=Path("MANUAL_TECNICO.md"))
    args = parser.parse_args()
    generar_documentacion(args.entrada, args.salida)
```