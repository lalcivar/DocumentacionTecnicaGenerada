# Documentación Técnica

## Archivo: `generar_documentacion.py` (script de generación automática de documentación)

---

## 1. Descripción general

Este script de Python implementa un **generador automático de documentación técnica** que utiliza un modelo de lenguaje (LLM) accedido a través de la API de **OpenRouter** (compatible con el SDK oficial de OpenAI).

El flujo general del programa es:

1. Lee el contenido de un archivo fuente **Java** ubicado en una ruta predefinida.
2. Envía ese código a un modelo de IA (`google/gemini-2.0-flash-001`) junto con instrucciones para que actúe como un experto en ingeniería de software.
3. Recibe la respuesta del modelo (un manual técnico redactado en español).
4. Guarda el resultado en un archivo Markdown llamado `MANUAL_TECNICO_JUNIT.md`.

En resumen: **transforma código fuente Java en un manual técnico legible en formato Markdown, de forma automatizada.**

---

## 2. Dependencias

| Dependencia | Tipo | Uso |
|---|---|---|
| `openai` | Librería externa (pip) | Cliente HTTP para comunicarse con la API de OpenRouter mediante la interfaz compatible con OpenAI |
| `open()` / `with` | Nativo de Python | Lectura y escritura de archivos |

Instalación requerida:

```bash
pip install openai
```

---

## 3. Componentes principales

### 3.1. Configuración del cliente (`client`)

```python
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="sk-or-v1-..."
)
```

**Propósito:** Crear una instancia global del cliente de comunicación con el servicio de IA.

| Parámetro | Descripción |
|---|---|
| `base_url` | Redirige las peticiones del SDK de OpenAI hacia el endpoint de **OpenRouter**, que funciona como pasarela (*gateway*) hacia múltiples modelos de distintos proveedores. |
| `api_key` | Credencial de autenticación del usuario en OpenRouter. |

**Ámbito:** variable de nivel de módulo, accesible desde cualquier función del archivo.

---

### 3.2. Función `generar_documentacion()`

```python
def generar_documentacion():
```

**Firma:** `generar_documentacion() -> None`

**Parámetros:** ninguno (todas las rutas y configuraciones están codificadas internamente).

**Valor de retorno:** ninguno. Los resultados se producen como *efectos secundarios*: escritura de archivo en disco y mensajes en consola.

**Responsabilidad:** orquestar el proceso completo de documentación. Internamente se divide en tres etapas:

#### Etapa 1 — Lectura del código fuente

```python
ruta_java = "main/java/junit/textui/ResultPrinter.java"
with open(ruta_java, 'r', encoding='utf-8') as f:
    codigo = f.read()
```

- Define la ruta **fija** (*hardcoded*) del archivo Java a analizar.
- Abre el archivo en modo lectura con codificación UTF-8.
- Carga el contenido completo en la variable `codigo` (tipo `str`).
- El uso del gestor de contexto `with` garantiza el cierre del descriptor de archivo.
- Imprime un mensaje de traza indicando qué archivo se está procesando.

#### Etapa 2 — Solicitud al modelo de IA

```python
response = client.chat.completions.create(
  model="google/gemini-2.0-flash-001",
  messages=[
    {"role": "system", "content": "Eres un experto en ingeniería de software..."},
    {"role": "user",   "content": codigo}
  ]
)
```

- **`model`**: identificador del modelo en OpenRouter. Se eligió *Gemini 2.0 Flash* por su balance entre velocidad, costo y capacidad de análisis de código.
- **Mensaje `system`**: define el *rol* y las instrucciones del modelo (*prompt* de sistema). Indica que debe generar un manual técnico detallado **en español**, explicando el propósito de la clase, sus métodos y su integración en el sistema.
- **Mensaje `user`**: contiene el código Java leído como entrada a documentar.
- El resultado es un objeto de respuesta tipo `ChatCompletion`.

#### Etapa 3 — Persistencia del resultado

```python
manual_contenido = response.choices[0].message.content
with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
    m.write(manual_contenido)
```

- Extrae el texto generado desde la primera opción de respuesta (`choices[0]`).
- Escribe el contenido en el archivo `MANUAL_TECNICO_JUNIT.md` (modo `"w"`, sobrescribe si ya existe).
- Finalmente imprime mensajes de confirmación para el usuario.

---

### 3.3. Punto de entrada

```python
generar_documentacion()
```

La función se invoca **directamente a nivel de módulo**, por lo que el script se ejecuta inmediatamente al importarse o correrse.

---

## 4. Flujo de ejecución

```
Inicio
  │
  ├─► Instanciar cliente OpenAI → OpenRouter
  │
  ├─► Leer archivo Java (ResultPrinter.java)
  │      └─ Imprimir traza "Procesando código de: ..."
  │
  ├─► Enviar petición al modelo google/gemini-2.0-flash-001
  │      ├─ Mensaje system: instrucciones de documentación
  │      └─ Mensaje user: código Java
  │
  ├─► Extraer respuesta (texto Markdown)
  │
  ├─► Escribir MANUAL_TECNICO_JUNIT.md
  │
  └─► Imprimir confirmación → Fin
```

---

## 5. Entradas y salidas

| Elemento | Tipo | Detalle |
|---|---|---|
| **Entrada** | Archivo | `main/java/junit/textui/ResultPrinter.java` (debe existir, relativo al directorio de ejecución) |
| **Entrada** | Red | Llamada HTTPS a `https://openrouter.ai/api/v1/chat/completions` |
| **Salida** | Archivo | `MANUAL_TECNICO_JUNIT.md` en el directorio de trabajo actual |
| **Salida** | Consola | Mensajes de progreso y confirmación |

---

## 6. Requisitos de ejecución

- Python 3.7 o superior.
- Paquete `openai` instalado (versión ≥ 1.0, por el uso de la interfaz `client.chat.completions.create`).
- Conexión a Internet activa.
- Clave de API válida de OpenRouter con crédito disponible.
- El archivo Java de entrada debe existir en la ruta esperada.

---

## 7. Limitaciones y consideraciones

1. **Clave de API expuesta en el código.** 🔴 *Riesgo de seguridad crítico.* La credencial está escrita literalmente en el archivo fuente. Debe revocarse y migrarse a una variable de entorno:

   ```python
   import os
   client = OpenAI(
       base_url="https://openrouter.ai/api/v1",
       api_key=os.environ["OPENROUTER_API_KEY"]
   )
   ```

2. **Rutas codificadas (*hardcoded*).** Tanto el archivo de entrada como el de salida son fijos. El script no es reutilizable para otros archivos sin modificar el código.

3. **Sin manejo de errores.** No se capturan excepciones de:
   - `FileNotFoundError` (archivo Java inexistente),
   - errores de red o de autenticación de la API,
   - respuestas vacías (`choices` sin elementos).

4. **Sin control del tamaño del *prompt*.** Si el archivo Java excede la ventana de contexto del modelo, la petición fallará o se truncará.

5. **Ejecución automática al importar.** La llamada directa a `generar_documentacion()` impide reutilizar el módulo como librería.

6. **Resultado no determinista.** Al depender de un LLM, la documentación generada puede variar entre ejecuciones.

---

## 8. Mejoras recomendadas

| Mejora | Descripción |
|---|---|
| Variables de entorno | Mover la API key fuera del código fuente |
| Parametrización | Recibir rutas de entrada/salida vía `argparse` o parámetros de función |
| Guardia `__main__` | Envolver la invocación en `if __name__ == "__main__":` |
| Manejo de excepciones | Bloques `try/except` para E/S y llamadas de red |
| Procesamiento por lotes | Recorrer directorios con `glob`/`pathlib` para documentar múltiples archivos |
| Registro (*logging*) | Sustituir `print()` por el módulo `logging` |
| Reintentos | Implementar *retry* con *backoff* para fallos transitorios de la API |

---

## 9. Ejemplo de uso

```bash
# Desde la raíz del proyecto, donde existe main/java/junit/textui/ResultPrinter.java
python generar_documentacion.py
```

Salida esperada en consola:

```
--- Procesando código de: main/java/junit/textui/ResultPrinter.java ---

¡Documentación generada con éxito!
Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```