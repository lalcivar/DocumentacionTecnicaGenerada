# Documentación Técnica

## `generador_documentacion.py`

---

## 1. Descripción general

Este script en Python es una **herramienta de generación automática de documentación técnica** que utiliza un modelo de lenguaje de gran escala (LLM) a través de la API de [OpenRouter](https://openrouter.ai).

Su flujo de trabajo es el siguiente:

1. Lee el contenido de un archivo fuente Java ubicado en una ruta fija del proyecto.
2. Envía ese código a un modelo de IA (`google/gemini-2.0-flash-001`) acompañado de instrucciones (*system prompt*) que le indican actuar como experto en ingeniería de software.
3. Recibe como respuesta un manual técnico redactado en español.
4. Persiste el resultado en un archivo Markdown llamado `MANUAL_TECNICO_JUNIT.md`.

En resumen: **automatiza la tarea de documentar código legado**, convirtiendo un archivo `.java` en un manual técnico legible en formato Markdown.

---

## 2. Dependencias

| Dependencia | Tipo | Propósito |
|---|---|---|
| `openai` | Librería externa (pip) | Cliente HTTP compatible con la especificación de la API de OpenAI; se reutiliza para consumir OpenRouter. |
| Módulo `io` integrado (`open`) | Estándar | Lectura del archivo Java y escritura del archivo Markdown. |

Instalación requerida:

```bash
pip install openai
```

---

## 3. Componentes principales

### 3.1 Importaciones

```python
from openai import OpenAI
```

Se importa únicamente la clase `OpenAI`, que actúa como cliente para realizar peticiones al endpoint de *chat completions*.

---

### 3.2 Configuración del cliente (`client`)

```python
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="sk-or-v1-..."
)
```

**Tipo:** instancia de `OpenAI` (variable global del módulo).

**Descripción:** Objeto cliente que encapsula la comunicación con el servicio de IA.

| Parámetro | Valor | Función |
|---|---|---|
| `base_url` | `https://openrouter.ai/api/v1` | Redirige las peticiones al *gateway* de OpenRouter en lugar de los servidores de OpenAI. Esto permite acceder a modelos de múltiples proveedores (Google, Anthropic, Meta, etc.) con la misma interfaz. |
| `api_key` | Clave `sk-or-v1-...` | Credencial de autenticación del usuario en OpenRouter. |

> ⚠️ **Advertencia de seguridad:** la clave de API está escrita directamente en el código (*hardcoded*). Esto constituye una mala práctica: si el archivo se versiona en Git o se comparte, la credencial queda expuesta y puede ser revocada o utilizada por terceros. Véase la sección 6 (Recomendaciones).

---

### 3.3 Función `generar_documentacion()`

```python
def generar_documentacion():
    ...
```

**Firma:** `generar_documentacion() -> None`

**Parámetros:** ninguno.

**Valor de retorno:** ninguno (`None`). Sus efectos son laterales: escritura de archivo y salida por consola.

**Responsabilidad:** orquestar las tres etapas del proceso (lectura → inferencia → escritura).

#### Etapa A — Lectura del código fuente

```python
ruta_java = "main/java/junit/textui/ResultPrinter.java"

with open(ruta_java, 'r', encoding='utf-8') as f:
    codigo = f.read()
```

- La ruta de entrada está **fijada en el código** (valor constante local), apuntando a la clase `ResultPrinter` del framework JUnit.
- Se abre en modo lectura (`'r'`) con codificación **UTF-8** explícita, lo que evita errores de decodificación con caracteres acentuados o especiales.
- El uso de `with` garantiza el cierre del descriptor de archivo incluso ante excepciones.
- El contenido completo se carga en memoria en la variable `codigo` (tipo `str`).

#### Etapa B — Petición al modelo de IA

```python
response = client.chat.completions.create(
  model="google/gemini-2.0-flash-001",
  messages=[
    {"role": "system", "content": "Eres un experto en ingeniería de software..."},
    {"role": "user", "content": codigo}
  ]
)
```

| Elemento | Detalle |
|---|---|
| `model` | `google/gemini-2.0-flash-001`. Modelo seleccionado por su amplia ventana de contexto y velocidad, adecuado para analizar archivos de código extensos. |
| Mensaje `system` | Define el **rol y la tarea**: generar un manual técnico detallado **en español**, explicando el propósito de la clase, sus métodos y su integración en el sistema. |
| Mensaje `user` | Contiene el código Java íntegro leído en la etapa A, sin preprocesamiento ni truncado. |

La respuesta es un objeto de tipo `ChatCompletion`, del cual interesa `response.choices[0].message.content`.

#### Etapa C — Persistencia del resultado

```python
manual_contenido = response.choices[0].message.content
with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
    m.write(manual_contenido)
```

- Se extrae el texto de la **primera** alternativa generada (`choices[0]`).
- Se escribe en `MANUAL_TECNICO_JUNIT.md` en modo `"w"`, lo que **sobrescribe** el archivo si ya existe.
- Nuevamente se fuerza `encoding="utf-8"` para preservar tildes y símbolos del texto en español.

#### Etapa D — Retroalimentación al usuario

Se emiten mensajes informativos por consola:
- Antes de la llamada: `--- Procesando código de: {ruta_java} ---`
- Al finalizar: confirmación de éxito y nombre del archivo generado.

---

### 3.4 Invocación a nivel de módulo

```python
generar_documentacion()
```

La función se ejecuta inmediatamente al importar o ejecutar el archivo. **No existe** la guarda `if __name__ == "__main__":`, por lo que el script no puede importarse como módulo sin desencadenar la llamada a la API.

---

## 4. Entradas y salidas

| | Recurso | Detalle |
|---|---|---|
| **Entrada** | `main/java/junit/textui/ResultPrinter.java` | Archivo de código fuente a documentar. Ruta relativa al directorio de ejecución. |
| **Entrada** | API de OpenRouter | Servicio remoto; requiere conexión a Internet y saldo/cuota disponible. |
| **Salida** | `MANUAL_TECNICO_JUNIT.md` | Manual técnico en Markdown, generado en el directorio de trabajo actual. |
| **Salida** | `stdout` | Mensajes de progreso y confirmación. |

---

## 5. Flujo de ejecución (resumen)

```
Inicio
  │
  ├─> Instanciar cliente OpenAI (base_url = OpenRouter)
  │
  ├─> generar_documentacion()
  │     ├─ Abrir y leer ResultPrinter.java  ──> codigo : str
  │     ├─ Imprimir aviso de procesamiento
  │     ├─ POST /chat/completions (system + user)
  │     │     └─ Modelo: google/gemini-2.0-flash-001
  │     ├─ Extraer choices[0].message.content
  │     ├─ Escribir MANUAL_TECNICO_JUNIT.md (sobrescribe)
  │     └─ Imprimir mensaje de éxito
  │
Fin
```

---

## 6. Limitaciones y recomendaciones de mejora

| # | Problema detectado | Recomendación |
|---|---|---|
| 1 | **API key en texto plano** | Mover la clave a una variable de entorno (`os.getenv("OPENROUTER_API_KEY")`) o a un archivo `.env` gestionado con `python-dotenv`, e incluirlo en `.gitignore`. La clave expuesta debería **revocarse**. |
| 2 | **Ruta de entrada y salida fijas** | Parametrizar mediante argumentos de función o CLI (`argparse` / `sys.argv`) para documentar cualquier archivo. |
| 3 | **Ausencia de manejo de errores** | Envolver en bloques `try/except` para capturar `FileNotFoundError`, `UnicodeDecodeError` y errores de la API (`openai.APIError`, `RateLimitError`, timeouts). |
| 4 | **Sin validación de la respuesta** | Verificar que `response.choices` no esté vacío y que `content` no sea `None` antes de escribir. |
| 5 | **Falta la guarda `__main__`** | Añadir `if __name__ == "__main__": generar_documentacion()` para permitir la importación segura del módulo. |
| 6 | **Riesgo de exceder el contexto** | Para archivos muy grandes, fragmentar el código (*chunking*) y consolidar las respuestas parciales. |
| 7 | **Procesa un solo archivo** | Iterar con `pathlib.Path.rglob("*.java")` para documentar un proyecto completo. |
| 8 | **Sobrescritura silenciosa** | Comprobar la existencia del archivo de salida o versionar el nombre con marca temporal. |
| 9 | **Parámetros del modelo no configurados** | Considerar fijar `temperature` (baja, p. ej. 0.2) para obtener documentación más determinista y consistente. |

---

## 7. Ejemplo de versión refactorizada (orientativa)

```python
import os
import sys
from pathlib import Path
from openai import OpenAI, APIError

SYSTEM_PROMPT = (
    "Eres un experto en ingeniería de software. Tu tarea es generar un manual "
    "técnico detallado en español para el código Java proporcionado. Explica el "
    "propósito de la clase, sus métodos y cómo se integra en el sistema."
)

def crear_cliente() -> OpenAI:
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        raise RuntimeError("Falta la variable de entorno OPENROUTER_API_KEY")
    return OpenAI(base_url="https://openrouter.ai/api/v1", api_key=api_key)

def generar_documentacion(ruta_java: Path, ruta_salida: Path,
                          modelo: str = "google/gemini-2.0-flash-001") -> None:
    if not ruta_java.is_file():
        raise FileNotFoundError(f"No se encontró el archivo: {ruta_java}")

    codigo = ruta_java.read_text(encoding="utf-8")
    print(f"--- Procesando: {ruta_java} ---")

    client = crear_cliente()
    try:
        response = client.chat.completions.create(
            model=modelo,
            temperature=0.2,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": codigo},
            ],
        )
    except APIError as e:
        print(f"[ERROR] Fallo en la API: {e}", file=sys.stderr)
        return

    contenido = response.choices[0].message.content if response.choices else None
    if not contenido:
        print("[ERROR] La IA no devolvió contenido.", file=sys.stderr)
        return

    ruta_salida.write_text(contenido, encoding="utf-8")
    print(f"¡Documentación generada en '{ruta_salida}'!")

if __name__ == "__main__":
    generar_documentacion(
        Path("main/java/junit/textui/ResultPrinter.java"),
        Path("MANUAL_TECNICO_JUNIT.md"),
    )
```