# Documentación Técnica - Script de Generación de Manual con IA

**Archivo:** `main.py` / `generador_documentacion.py`
**Versión:** 1.0
**Lenguaje:** Python 3.x
**Dependencia principal:** `openai` SDK

### 1. Descripción General

Este script es una herramienta de automatización que utiliza Inteligencia Artificial Generativa para crear documentación técnica. Su función es leer el código fuente de un archivo Java específico, enviarlo a un Modelo de Lenguaje Grande (LLM) a través de una API y guardar la respuesta generada por la IA como un manual técnico en formato Markdown.

El proceso es completamente automático: extrae, analiza y documenta sin intervención manual.

### 2. Objetivo del Archivo

Automatizar la tarea de documentar código legacy del framework JUnit, específicamente la clase `ResultPrinter.java`, generando un manual en español que explique su propósito, métodos e integración dentro del sistema.

### 3. Componentes Principales

El archivo se compone de 3 bloques lógicos principales:

| Componente | Descripción |
| :--- | :--- |
| **1. Configuración del Cliente IA** | Inicialización del cliente para la comunicación con el LLM. |
| **2. Función `generar_documentacion()`** | Núcleo lógico que orquesta todo el flujo: lectura, solicitud a la IA y escritura. |
| **3. Bloque de Ejecución** | Llamada directa a la función para iniciar el proceso al ejecutar el script. |

#### 3.1. Configuración del Cliente IA

```python
client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key="sk-or-v1-...")
```

*   **Librería:** Utiliza la librería oficial `openai` de Python.
*   **Proveedor:** No se conecta directamente a OpenAI, sino a **OpenRouter**, un gateway que permite acceder a múltiples modelos con una API unificada.
*   **Modelo Configurado:** `google/gemini-2.0-flash-001`, seleccionado por su alta capacidad para el análisis y comprensión de código.
*   **Autenticación:** Mediante `api_key`.

> **Alerta de Seguridad:** La API Key se encuentra expuesta directamente en el código fuente (hardcodeada). Esto representa una vulnerabilidad crítica. Se recomienda revocarla inmediatamente y gestionarla mediante variables de entorno `os.getenv()` o un archivo `.env`.

#### 3.2. Función Principal: `generar_documentacion()`

Es el corazón del script y se divide en tres fases secuenciales:

**Fase A: Lectura del Código Fuente**
```python
ruta_java = "main/java/junit/textui/ResultPrinter.java"
with open(ruta_java, 'r', encoding='utf-8') as f:
    codigo = f.read()
```
Lee el contenido completo del archivo Java objetivo y lo almacena en la variable `codigo` como una cadena de texto. La ruta está definida de forma estática.

**Fase B: Solicitud a la IA (Prompt Engineering)**
```python
response = client.chat.completions.create(...)
```
Realiza una llamada a la API de chat completions con dos mensajes clave:
*   **System Prompt (Rol del Sistema):** Instruye a la IA para que actúe como `experto en ingeniería de software` y genere un `manual técnico detallado en español`, especificando que debe explicar el propósito de la clase, sus métodos y su integración.
*   **User Prompt (Contenido):** Envía el código Java completo leído en la fase anterior como contexto para el análisis.

**Fase C: Persistencia del Resultado**
```python
manual_contenido = response.choices[0].message.content
with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
    m.write(manual_contenido)
```
Extrae el texto generado por la IA desde la respuesta y lo escribe en un nuevo archivo de salida llamado `MANUAL_TECNICO_JUNIT.md` en el directorio raíz del proyecto.

#### 3.3. Bloque de Ejecución

```python
generar_documentacion()
```
Invocación directa de la función. Al ejecutar el archivo con `python script.py`, el proceso se inicia automáticamente sin necesidad de pasar argumentos por línea de comandos.

### 4. Flujo de Ejecución

1.  Inicio del script -> Configuración del cliente OpenRouter.
2.  Llamada a `generar_documentacion()`.
3.  Lectura de `ResultPrinter.java` desde disco.
4.  Envío del código + instrucciones a Gemini 2.0 Flash vía OpenRouter.
5.  Recepción de la documentación generada.
6.  Creación / Sobrescritura de `MANUAL_TECNICO_JUNIT.md`.
7.  Mensaje de confirmación por consola.

### 5. Entradas y Salidas

*   **Entrada:** Archivo `main/java/junit/textui/ResultPrinter.java` (debe existir previamente).
*   **Salida:** Archivo `MANUAL_TECNICO_JUNIT.md` con el manual técnico en formato Markdown y mensajes de estado en consola.

### 6. Dependencias y Requisitos

Para su ejecución se requiere:
```bash
pip install openai
```
Y conectividad a internet para acceder a `https://openrouter.ai/api/v1`.

### 7. Limitaciones y Mejoras Recomendadas

1.  **Manejo de Errores:** Actualmente no posee bloques `try/except`. Fallará si el archivo Java no existe o si la API no responde.
2.  **Parametrización:** La ruta de entrada y salida están hardcodeadas. Se recomienda parametrizarlas para reutilizar el script con otros archivos.
3.  **Seguridad:** Externalizar la `api_key` a una variable de entorno.
