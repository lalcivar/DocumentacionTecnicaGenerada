# Documentación Técnica - Generador Automático de Manual con IA

### 1. Información General

| Atributo | Detalle |
| :--- | :--- |
| **Lenguaje** | Python 3.x |
| **Propósito** | Automatizar la generación de un manual técnico para un archivo Java utilizando un Modelo de Lenguaje Grande (LLM) |
| **Dependencia Principal** | Librería `openai` |
| **Modelo de IA Utilizado** | `google/gemini-2.0-flash-001` vía OpenRouter |
| **Archivo de Entrada** | `main/java/junit/textui/ResultPrinter.java` |
| **Archivo de Salida** | `MANUAL_TECNICO_JUNIT.md` |

### 2. Descripción General

Este script es una herramienta de **documentación asistida por IA**. Su función es leer el código fuente de una clase Java específica del framework JUnit, enviarlo a un modelo de inteligencia artificial para su análisis y generar de forma automática un manual técnico detallado en español en formato Markdown.

El proceso es completamente automático: no requiere intervención del usuario una vez ejecutado, se encarga de la lectura del archivo, la comunicación con la API, y el guardado del resultado.

### 3. Componentes Principales

El archivo se compone de tres bloques lógicos principales:

#### 3.1. Importación y Configuración del Cliente
```python
from openai import OpenAI
client = OpenAI(...)
```
*   **Librería `openai`:** Se utiliza como cliente estándar para interactuar con APIs compatibles con OpenAI.
*   **Objeto `client`:** Es la instancia central que gestiona la conexión con el servicio de IA.
    *   `base_url`: Se configura para apuntar a `https://openrouter.ai/api/v1`. OpenRouter actúa como un gateway que permite acceder a múltiples modelos (en este caso Gemini) usando la misma interfaz de OpenAI.
    *   `api_key`: Clave de autenticación para consumir el servicio.

> **Nota de Seguridad:** La API Key se encuentra hardcodeada en el código. Se recomienda como buena práctica moverla a una variable de entorno `os.getenv("OPENROUTER_API_KEY")` para evitar exponer credenciales.

#### 3.2. Función Principal `generar_documentacion()`
Es el núcleo del script. No recibe parámetros ni retorna valores, encapsula todo el flujo de trabajo. Se divide en 3 etapas internas:

**a) Lectura del Código Fuente:**
```python
ruta_java = "main/java/junit/textui/ResultPrinter.java"
with open(ruta_java, 'r', encoding='utf-8') as f:
    codigo = f.read()
```
Lee el contenido completo del archivo Java objetivo y lo almacena en la variable `codigo` como una cadena de texto.

**b) Solicitud a la IA:**
```python
response = client.chat.completions.create(...)
```
Realiza una llamada a la API de chat completions con dos mensajes:
*   **System Prompt (Rol `system`):** Define el comportamiento de la IA. Le ordena actuar como un "experto en ingeniería de software" y generar un manual técnico detallado en español, explicando el propósito de la clase, sus métodos y su integración en el sistema.
*   **User Prompt (Rol `user`):** Contiene el código Java leído en el paso anterior, que es el material a analizar.

**c) Generación y Guardado del Manual:**
```python
manual_contenido = response.choices[0].message.content
with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
    m.write(manual_contenido)
```
Extrae el texto generado por el modelo desde la respuesta y lo escribe en un nuevo archivo Markdown `MANUAL_TECNICO_JUNIT.md`.

#### 3.3. Punto de Ejecución
```python
generar_documentacion()
```
Llamada directa a la función al final del script, lo que provoca que el proceso se ejecute automáticamente al correr el archivo con `python script.py`.

### 4. Flujo de Ejecución

```
INICIO -> [1. Configurar Cliente OpenRouter] -> [2. Leer ResultPrinter.java] -> [3. Enviar Código + Prompt a Gemini 2.0 Flash] -> [4. Recibir Documentación Generada] -> [5. Guardar como MANUAL_TECNICO_JUNIT.md] -> FIN
```

### 5. Requisitos y Consideraciones

**Requisitos Previos:**
1.  Tener instalada la librería: `pip install openai`
2.  Existencia del archivo de entrada en la ruta especificada.
3.  Conexión a internet y una API Key válida de OpenRouter.

**Limitaciones Actuales:**
*   No posee manejo de errores `try/except` para casos como archivo no encontrado o fallo en la API.
*   La ruta del archivo Java y el modelo están fijos en el código, no son parametrizables.
*   No valida si la respuesta de la IA fue exitosa antes de intentar guardarla.

**Mejora Sugerida:** Parametrizar la función para que pueda recibir cualquier ruta de archivo y modelo como argumentos, y añadir manejo de excepciones.