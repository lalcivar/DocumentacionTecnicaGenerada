# Documentación Técnica - Generador Automático de Documentación con IA

### 1. Descripción General

Este archivo Python es un script de automatización que utiliza Inteligencia Artificial Generativa para generar documentación técnica de forma automática. Su función principal es leer el código fuente de un archivo Java específico, enviarlo a un Modelo de Lenguaje Grande (LLM) a través de una API y guardar el manual técnico generado en un nuevo archivo Markdown.

El script actúa como un puente entre un repositorio de código local y el modelo `google/gemini-2.0-flash-001` consumido a través de la plataforma OpenRouter.

### 2. Propósito y Funcionalidad

El objetivo del script es automatizar la tarea de documentar código legacy. En este caso concreto, está configurado para analizar la clase `ResultPrinter.java` del framework JUnit y producir un archivo `MANUAL_TECNICO_JUNIT.md` que explique en español el propósito de la clase, sus métodos y su integración dentro del sistema.

### 3. Dependencias y Requisitos

| Dependencia | Descripción |
| :--- | :--- |
| `openai` | Librería oficial de OpenAI en Python. Se utiliza por su compatibilidad con cualquier API que siga el estándar OpenAI, como OpenRouter. |
| `Python 3.x` | Intérprete de Python. |
| **API Key de OpenRouter** | Clave de autenticación para consumir el servicio. |
| **Archivo de entrada** | Requiere que exista el archivo `main/java/junit/textui/ResultPrinter.java` en la ruta relativa especificada. |

> **Nota de Seguridad:** El código contiene una API Key hardcodeada directamente en el fuente. Esto representa una vulnerabilidad crítica. Se recomienda revocarla inmediatamente y gestionarla mediante variables de entorno `os.getenv()` o un archivo `.env`.

### 4. Componentes Principales

El archivo se compone de 3 bloques lógicos principales:

#### A. Configuración del Cliente API
```python
client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key="...")
```
Inicializa el cliente de la API. No apunta directamente a OpenAI, sino que redirige las peticiones a `https://openrouter.ai/api/v1`, lo que permite utilizar modelos de diferentes proveedores como Google, Anthropic o Meta con la misma interfaz.

**Parámetros clave:**
*   `base_url`: Endpoint de OpenRouter.
*   `api_key`: Token de autenticación.
*   `model` (definido más adelante): `google/gemini-2.0-flash-001`, seleccionado por su capacidad de análisis de código y ventana de contexto amplia.

#### B. Función Principal `generar_documentacion()`
Es el núcleo del script y encapsula todo el flujo de trabajo. No recibe parámetros ni retorna valores, opera mediante efectos secundarios (lectura/escritura de archivos y llamadas a la API).

Se divide en 3 etapas internas:

1.  **Lectura del Código Fuente:** Abre y lee el contenido completo del archivo Java en modo `utf-8` y lo almacena en la variable `codigo`.
2.  **Solicitud a la IA (Prompt Engineering):** Construye una petición `chat.completions.create` con dos mensajes:
    *   `role: system`: Define el rol de la IA como "experto en ingeniería de software" e instruye que genere un manual técnico detallado en español.
    *   `role: user`: Envía el código Java completo como contexto para ser analizado.
3.  **Persistencia del Resultado:** Extrae el contenido de la respuesta `response.choices[0].message.content` y lo escribe en un nuevo archivo de salida `MANUAL_TECNICO_JUNIT.md`.

#### C. Punto de Entrada del Script
```python
generar_documentacion()
```
Llamada directa a la función principal al final del archivo. Hace que el script se ejecute automáticamente al ser invocado con `python nombre_archivo.py`.

### 5. Flujo de Ejecución

```
INICIO -> [1. Configurar Cliente OpenRouter] -> [2. Ejecutar generar_documentacion()]
   |
   +-> [2.1 Leer ResultPrinter.java] -> [2.2 Enviar código a Gemini 2.0 Flash]
   |
   +-> [2.3 Recibir manual técnico] -> [2.4 Guardar como MANUAL_TECNICO_JUNIT.md]
   |
FIN -> Mensaje de éxito en consola
```

**Entradas y Salidas:**
*   **Entrada:** `main/java/junit/textui/ResultPrinter.java` (Archivo Java)
*   **Salida:** `MANUAL_TECNICO_JUNIT.md` (Archivo Markdown con la documentación) + Logs en consola.

### 6. Consideraciones y Posibles Mejoras

1.  **Manejo de Errores:** Actualmente no posee bloques `try/except`. Fallará si el archivo Java no existe, si no hay conexión a internet o si la API Key es inválida. Se recomienda implementar manejo de excepciones.
2.  **Parametrización:** La ruta del archivo de entrada y salida, así como el modelo, están hardcodeados. Podrían convertirse en parámetros de la función para hacer el script reutilizable.
3.  **Seguridad:** Migrar la `api_key` a una variable de entorno: `api_key=os.getenv("OPENROUTER_API_KEY")`.
