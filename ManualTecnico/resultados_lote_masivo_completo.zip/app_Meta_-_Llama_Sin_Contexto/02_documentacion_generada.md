# Documentación Técnica - `flask/app.py`

## 1. Descripción General

**Archivo:** `flask/app.py`  
**Clase Principal:** `Flask`  
**Herencia:** `Flask(App)` -> Hereda de `sansio.app.App`  
**Propósito:** Implementa el objeto central de la aplicación Flask. Actúa como aplicación **WSGI**, registro central de vistas, reglas de URL, configuración, manejo de plantillas, sesiones, contextos y ciclo de vida de la petición.

Este archivo es el núcleo del framework. Es el responsable de:
1.  Crear y configurar la aplicación.
2.  Gestionar el enrutamiento y despacho de peticiones.
3.  Administrar los contextos de aplicación y de petición.
4.  Convertir valores de retorno de vistas en objetos `Response`.
5.  Manejar excepciones y errores HTTP.
6.  Exponer la interfaz WSGI para servidores web.

> Una instancia se crea típicamente como `app = Flask(__name__)` y centraliza toda la lógica de la aplicación.

---

### 2. Dependencias Principales

| Librería | Uso en el archivo |
| :--- | :--- |
| `werkzeug` | Base para enrutamiento `MapAdapter, Rule`, objetos `Request/Response`, manejo de excepciones `HTTPException` y servidor de desarrollo `run_simple`. |
| `click` | Gestión del grupo de comandos CLI `self.cli`. |
| `jinja2` | Creación del entorno de plantillas `Environment` vía `create_jinja_environment`. |
| `itsdangerous` | A través de `SecureCookieSessionInterface` para sesiones firmadas. |
| `flask.sansio.app.App` | Clase base que contiene la lógica independiente de I/O: registro de rutas, blueprints, configuración y callbacks. |
| `flask.ctx.AppContext` | Manejo de contextos de aplicación/petición. |
| `flask.globals` | Proxies globales `request, session, g, app_ctx, _cv_app`. |

### 3. Componentes Globales y Funciones Auxiliares

#### 3.1 Variables de Tipado
```python
T_shell_context_processor, T_teardown, T_template_filter...
```
`TypeVar` genéricos para tipar decoradores como `@app.shell_context_processor`, `@app.teardown_request`, `@app.template_filter`.

#### 3.2 Funciones Auxiliares

| Función | Descripción |
| :--- | :--- |
| `_make_timedelta(value)` | Normaliza un valor de configuración. Si recibe un `int`, lo convierte a `timedelta(seconds=value)`. Si ya es `timedelta` o `None`, lo retorna sin cambios. Usado para `PERMANENT_SESSION_LIFETIME`. |
| `remove_ctx(f)` | Decorador de compatibilidad. Elimina el primer argumento `ctx: AppContext` si un método sobreescrito en una subclase aún usa la firma antigua. Emite `DeprecationWarning` para Flask 4.0. |
| `add_ctx(f)` | Decorador inverso. Inyecta automáticamente `app_ctx._get_current_object()` como primer argumento al llamar a `super().metodo()` desde la clase base, permitiendo compatibilidad entre firmas nuevas y antiguas. |

---

### 4. Clase `Flask`

#### 4.1 Configuración por Defecto `default_config`

Diccionario inmutable `ImmutableDict` con la configuración inicial de toda app Flask:

| Clave | Valor por Defecto | Descripción |
| :--- | :--- | :--- |
| `DEBUG` | `None` | Activa modo depuración. |
| `TESTING` | `False` | Activa modo testing, propaga excepciones. |
| `SECRET_KEY` | `None` | Clave para firmar sesiones y cookies. |
| `PERMANENT_SESSION_LIFETIME` | `31 days` | Duración de sesiones permanentes. |
| `SERVER_NAME` | `None` | Nombre y puerto del servidor, necesario para generar URLs fuera de petición. |
| `SESSION_COOKIE_*` | Varios | Configuración de seguridad de la cookie de sesión. |
| `MAX_CONTENT_LENGTH` | `None` | Tamaño máximo del contenido de la petición. |
| `PREFERRED_URL_SCHEME` | `http` | Esquema preferido para `url_for` fuera de petición. |

#### 4.2 Atributos de Clase

*   `request_class: type[Request] = Request`: Clase usada para instanciar el objeto `request`.
*   `response_class: type[Response] = Response`: Clase usada para instanciar el objeto `response`.
*   `session_interface: SessionInterface = SecureCookieSessionInterface()`: Interfaz que gestiona cómo se guardan/cargan las sesiones.

#### 4.3 Constructor `__init__`

```python
Flask(import_name, static_url_path, static_folder, static_host, host_matching, 
      subdomain_matching, template_folder, instance_path, instance_relative_config, root_path)
```

Delega la mayor parte de la inicialización a `super().__init__()` de `sansio.app.App`. Su lógica propia es:
1.  Crea el grupo CLI: `self.cli = cli.AppGroup()`.
2.  Registra automáticamente la ruta para archivos estáticos ` /<static_url_path>/<path:filename>` -> `send_static_file` si `has_static_folder` es True. Usa `weakref` para evitar ciclos de referencia.

#### 4.4 Métodos Principales por Categoría

##### A. Gestión de Recursos y Archivos Estáticos
| Método | Descripción |
| :--- | :--- |
| `get_send_file_max_age(filename)` | Determina el `max_age` de caché para `send_file`. Lee `SEND_FILE_MAX_AGE_DEFAULT` del config. |
| `send_static_file(filename)` | View function que sirve archivos desde `static_folder` usando `send_from_directory`. |
| `open_resource(resource, mode, encoding)` | Abre un archivo relativo a `root_path` solo en modo lectura. |
| `open_instance_resource(resource, mode, encoding)` | Abre un archivo relativo a `instance_path`, permite lectura y escritura. |

##### B. Plantillas y URLs
| Método | Descripción |
| :--- | :--- |
| `create_jinja_environment()` | Crea y configura el `Environment` de Jinja2. Inyecta globales `url_for, get_flashed_messages, config, request, session, g` y configura `autoescape` y `auto_reload`. |
| `create_url_adapter(request)` | Crea un `MapAdapter` de Werkzeug para hacer matching/building de URLs. Gestiona `TRUSTED_HOSTS`, `SERVER_NAME`, `host_matching` y `subdomain_matching`. |
| `update_template_context(ctx, context)` | Inyecta variables de context processors al contexto de la plantilla. |
| `url_for(endpoint, _anchor, _method, _scheme, _external, **values)` | Implementación central de `flask.url_for`. Genera URLs internas o externas, maneja endpoints relativos a blueprints `.endpoint` y delega errores a `handle_url_build_error`. |

##### C. Ciclo de Vida de la Petición
Este es el flujo más crítico del archivo:

`wsgi_app` -> `full_dispatch_request` -> `preprocess_request` -> `dispatch_request` -> `finalize_request` -> `process_response`

| Método | Descripción |
| :--- | :--- |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y `before_request_funcs`. Si alguno retorna un valor no-`None`, corta el despacho y lo usa como respuesta. |
| `dispatch_request(ctx)` | Hace el matching de la URL. Si es `OPTIONS` y `provide_automatic_options` es True, retorna `make_default_options_response`. Si no, invoca la view function `self.view_functions[rule.endpoint]`. |
| `full_dispatch_request(ctx)` | Orquestador. Dispara señal `request_started`, llama a `preprocess_request` y `dispatch_request`, captura excepciones y las delega a `handle_user_exception`, finalmente llama a `finalize_request`. |
| `finalize_request(ctx, rv, from_error_handler)` | Convierte `rv` a `Response` con `make_response`, luego llama a `process_response` y dispara `request_finished`. |
| `process_response(ctx, response)` | Ejecuta `after_request_funcs` en orden inverso y guarda la sesión con `session_interface.save_session`. |
| `do_teardown_request(ctx, exc)` | Ejecuta `teardown_request_funcs` y envía señal `request_tearing_down`. Se llama al hacer `pop` del contexto. |
| `do_teardown_appcontext(ctx, exc)` | Ejecuta `teardown_appcontext_funcs` y envía señal `appcontext_tearing_down`. |
| `make_response(rv)` | Normaliza cualquier tipo de retorno de una vista `str, bytes, dict, list, tuple, Response, WSGI callable` a una instancia de `self.response_class`. |
| `make_default_options_response(ctx)` | Genera respuesta automática para peticiones `OPTIONS` con el header `Allow`. |

##### D. Manejo de Errores
| Método | Descripción |
| :--- | :--- |
| `handle_http_exception(ctx, e)` | Busca un handler registrado para el código HTTP de `e`. Si no existe, retorna la excepción misma. Ignora `RoutingException`. |
| `handle_user_exception(ctx, e)` | Punto de entrada para excepciones de usuario. Si es `HTTPException` delega a `handle_http_exception`, si no busca handler. Si no hay handler, hace `raise`. |
| `handle_exception(ctx, e)` | Handler de último recurso. Genera un `500 InternalServerError`, envía señal `got_request_exception`, loguea el error y busca handler para `500`. Respeta `PROPAGATE_EXCEPTIONS`. |
| `log_exception(ctx, exc_info)` | Loguea la excepción con `self.logger.error` incluyendo path y método. |
| `raise_routing_exception(request)` | En modo `debug`, convierte un `RequestRedirect` que descartaría datos de formulario en un error `FormDataRoutingRedirect` para alertar al desarrollador. |

##### E. Contextos, Testing y WSGI
| Método | Descripción |
| :--- | :--- |
| `app_context()` | Crea un `AppContext` para usar con `with app.app_context():`. |
| `request_context(environ)` | Crea un `AppContext` desde un `environ` WSGI. |
| `test_request_context(*args, **kwargs)` | Crea un `AppContext` de prueba usando `EnvironBuilder` de Werkzeug. Ideal para tests. |
| `wsgi_app(environ, start_response)` | **Aplicación WSGI real.** Crea el contexto, hace `push()`, llama a `full_dispatch_request`, maneja excepciones y hace `pop()`. Es el método que debe ser envuelto por middlewares. |
| `__call__(environ, start_response)` | Wrapper que delega a `wsgi_app`. Es lo que invoca el servidor WSGI. |
| `test_client(use_cookies, **kwargs)` | Factory para `FlaskClient` para tests de integración. |
| `test_cli_runner(**kwargs)` | Factory para `FlaskCliRunner` para testear comandos CLI. |
| `make_shell_context()` | Ejecuta todos los `shell_context_processors` y retorna el dict para `flask shell`. |

##### F. Utilidades y Soporte Async
| Método | Descripción |
| :--- | :--- |
| `ensure_sync(func)` | Si `func` es `async def`, la envuelve con `async_to_sync` para que pueda ejecutarse en workers WSGI síncronos. |
| `async_to_sync(func)` | Convierte una corrutina en función síncrona usando `asgiref.sync.async_to_sync`. Requiere extra `async`. |
| `run(host, port, debug, load_dotenv, **options)` | Inicia el servidor de desarrollo `werkzeug.serving.run_simple`. Gestiona `FLASK_RUN_FROM_CLI`, carga `.env`, resuelve `SERVER_NAME` y configura `use_reloader/debugger`. **No usar en producción.** |

#### 4.5 Método Especial `__init_subclass__`
Mecanismo de compatibilidad hacia atrás. Detecta si una subclase de `Flask` sobreescribe métodos del ciclo de vida sin el nuevo parámetro `ctx: AppContext`. Si es así, emite un `DeprecationWarning` y envuelve el método con `remove_ctx`/`add_ctx` para mantener compatibilidad hasta Flask 4.0.

---

### 5. Flujo de una Petición WSGI

```
Servidor WSGI -> app(environ, start_response)
      |
      v
  wsgi_app() -> ctx = request_context(environ) -> ctx.push()
      |
      v
  full_dispatch_request(ctx)
      |-- request_started.send()
      |-- preprocess_request() [before_request]
      |-- dispatch_request() [view_function]
      |-- (si hay excepción) -> handle_user_exception() / handle_exception()
      |
      v
  finalize_request() -> make_response() -> process_response() [after_request + save_session] -> request_finished.send()
      |
      v
  response(environ, start_response) -> ctx.pop() -> do_teardown_request() -> do_teardown_appcontext()
```

### 6. Ejemplo de Uso

```python
from flask import Flask
app = Flask(__name__)

@app.route("/hello/<name>")
def hello(name):
    return {"message": f"Hola {name}"} # dict -> make_response lo convierte a JSON

if __name__ == "__main__":
    app.run(debug=True)
```

