# Documentación Técnica - `flask/app.py` - Clase `Flask`

## 1. Información General

| Atributo | Detalle |
| :--- | :--- |
| **Archivo** | `flask/app.py` |
| **Clase Principal** | `Flask` |
| **Herencia** | `sansio.app.App` -> `Flask` |
| **Propósito** | Implementación central de la aplicación WSGI de Flask. Actúa como registro central de vistas, rutas, configuración, plantillas y gestión del ciclo de vida de la petición. |
| **Protocolo** | WSGI - `Callable[WSGIEnvironment, StartResponse]` |
| **Versión** | Flask 3.x |

Este archivo es el núcleo del framework Flask. Define el objeto aplicación que se instancia como `app = Flask(__name__)` y que orquesta todo el comportamiento del framework.

---

## 2. Descripción General

El archivo implementa una aplicación WSGI completa. Sus responsabilidades son:

1.  **Registro Central:** Almacena y gestiona view functions, reglas de URL (`url_map`), configuración, blueprints, manejadores de error y procesadores de contexto.
2.  **Gestión de Contextos:** Administra `AppContext` y `RequestContext` para exponer los proxies globales `current_app`, `request`, `session` y `g`.
3.  **Ciclo de Vida de la Petición:** Implementa el pipeline completo `wsgi_app -> full_dispatch_request -> dispatch_request -> finalize_request`.
4.  **Integración WSGI/Werkzeug:** Delega el ruteo a `werkzeug.routing`, las peticiones/respuestas a `werkzeug.wrappers` y el servidor de desarrollo a `werkzeug.serving`.
5.  **Soporte Asíncrono:** Permite vistas `async def` mediante `ensure_sync` y `async_to_sync` con `asgiref`.
6.  **Utilidades:** Servir archivos estáticos, gestión de plantillas Jinja2, CLI con Click y clientes de testing.

---

## 3. Dependencias Principales

*   **Estándar:** `os`, `sys`, `inspect`, `weakref`, `timedelta`, `urllib.parse`
*   **Werkzeug:** `Headers`, `ImmutableDict`, `HTTPException`, `MapAdapter`, `Rule`, `BaseResponse`, `get_host`
*   **Internas de Flask:** `cli`, `ctx.AppContext`, `globals`, `helpers`, `sansio.app.App`, `sessions`, `signals`, `templating.Environment`, `wrappers.Request/Response`
*   **Externas:** `click` para CLI, `asgiref` opcional para async

---

## 4. Componentes Principales

### 4.1 Funciones de Utilidad y Compatibilidad

#### ` _make_timedelta(value: timedelta | int | None) -> timedelta | None`
Convierte un valor entero en segundos a `timedelta`. Normaliza la configuración de tiempos de vida como `PERMANENT_SESSION_LIFETIME`.

#### `remove_ctx(f)` y `add_ctx(f)` - Decoradores de Compatibilidad
Mecanismo de retrocompatibilidad para Flask 4.0. Gestionan la migración de la firma de métodos que ahora requieren `ctx: AppContext` como primer parámetro.

*   `remove_ctx`: Elimina el argumento `ctx` si un método sobreescrito en una subclase aún usa la firma antigua.
*   `add_ctx`: Inyecta automáticamente `app_ctx._get_current_object()` si el método base es llamado sin `ctx`.
*   `__init_subclass__` detecta métodos sobreescritos con firma antigua, emite `DeprecationWarning` y los envuelve automáticamente.

### 4.2 Clase `Flask(App)`

Es el objeto central de la aplicación.

#### Atributos de Clase

| Atributo | Tipo | Descripción |
| :--- | :--- | :--- |
| `default_config` | `ImmutableDict` | Configuración por defecto. Incluye `DEBUG`, `SECRET_KEY`, `SERVER_NAME`, `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, `PREFERRED_URL_SCHEME`, etc. |
| `request_class` | `type[Request]` | Clase usada para instanciar objetos de petición. Por defecto `flask.wrappers.Request`. |
| `response_class` | `type[Response]` | Clase usada para respuestas. Por defecto `flask.wrappers.Response`. |
| `session_interface` | `SessionInterface` | Interfaz de sesión. Por defecto `SecureCookieSessionInterface`. |
| `cli` | `click.AppGroup` | Grupo de comandos Click para `flask run` y comandos personalizados. |

#### Constructor `__init__()`

```python
Flask(import_name, static_url_path, static_folder, static_host, host_matching, 
      subdomain_matching, template_folder, instance_path, instance_relative_config, root_path)
```

Delega la inicialización a `super().__init__()` de `sansio.app.App` y registra automáticamente la ruta para archivos estáticos:
`{static_url_path}/<path:filename>` -> `endpoint="static"` si `has_static_folder` es True. Usa `weakref` para evitar ciclos de referencia.

---

## 5. Métodos Principales por Categoría

### A. Gestión de Recursos y Plantillas

| Método | Descripción |
| :--- | :--- |
| `get_send_file_max_age(filename)` | Determina el `max_age` de caché para `send_file` desde `SEND_FILE_MAX_AGE_DEFAULT`. |
| `send_static_file(filename)` | View function para servir archivos de `static_folder` vía `send_from_directory`. |
| `open_resource(resource, mode, encoding)` | Abre un archivo relativo a `root_path` solo en modo lectura. |
| `open_instance_resource(resource, mode, encoding)` | Abre un archivo relativo a `instance_path`, permite escritura. |
| `create_jinja_environment()` | Crea el `Environment` de Jinja2, inyecta globales `url_for`, `config`, `request`, `session`, `g` y configura `auto_reload` y `autoescape`. |
| `update_template_context(ctx, context)` | Inyecta variables de context processors de la app y blueprints en el contexto de la plantilla. |

### B. Ruteo y URLs

| Método | Descripción |
| :--- | :--- |
| `create_url_adapter(request)` | Crea un `MapAdapter` de Werkzeug. Si hay `request`, lo vincula al `environ`; si no, usa `SERVER_NAME` y `APPLICATION_ROOT` para construir URLs fuera de petición. |
| `raise_routing_exception(request)` | En modo `debug`, convierte `RequestRedirect` en `FormDataRoutingRedirect` para evitar pérdida de datos en POST. No intercepta 307/308. |
| `url_for(endpoint, _anchor, _method, _scheme, _external, **values)` | Genera URLs. Resuelve endpoints relativos `.nombre` a blueprints, maneja URLs internas/externas y delega a `url_adapter.build()`. |

### C. Ciclo de Vida de la Petición - Pipeline WSGI

Este es el flujo más crítico:

```
wsgi_app(environ) -> request_context() -> ctx.push()
  -> full_dispatch_request()
    -> request_started signal
    -> preprocess_request() -> before_request_funcs
    -> dispatch_request() -> view_function(**view_args)
    -> handle_user_exception() si hay error
  -> finalize_request() -> process_response() -> after_request_funcs + save_session
  -> request_finished signal
  -> ctx.pop() -> do_teardown_request() + do_teardown_appcontext()
```

| Método | Descripción |
| :--- | :--- |
| `wsgi_app(environ, start_response)` | **Entry point WSGI real.** Crea el contexto, hace `push()`, llama a `full_dispatch_request` y garantiza `pop()` incluso con excepciones. Permite ser envuelto por middlewares. |
| `__call__(environ, start_response)` | Wrapper que delega a `wsgi_app`. Es lo que llama el servidor WSGI. |
| `full_dispatch_request(ctx)` | Orquesta el dispatch completo con manejo de excepciones y señales `request_started`. |
| `dispatch_request(ctx)` | Hace el match de la URL, maneja `OPTIONS` automático y ejecuta la `view_function`. |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y `before_request_funcs`. Si alguno retorna valor no-None, corta el dispatch. |
| `process_response(ctx, response)` | Ejecuta `after_request_funcs` en orden inverso y guarda la sesión. |
| `finalize_request(ctx, rv, from_error_handler)` | Convierte `rv` a `Response` vía `make_response` y llama a `process_response`. |
| `make_response(rv)` | Normaliza el valor de retorno de la vista a `Response`. Soporta `str`, `bytes`, `dict/list` -> JSON, `tuple (body, status, headers)`, `Response` y callables WSGI. |
| `make_default_options_response(ctx)` | Genera respuesta `OPTIONS` con header `Allow`. |

### D. Manejo de Errores

| Método | Descripción |
| :--- | :--- |
| `handle_http_exception(ctx, e)` | Busca handler registrado para `HTTPException` por código y MRO. Si no hay, retorna la excepción. Ignora `RoutingException`. |
| `handle_user_exception(ctx, e)` | Punto de entrada para excepciones de usuario. Delega a `handle_http_exception` si es `HTTPException`, sino busca handler. Si no hay handler, hace `raise`. |
| `handle_exception(ctx, e)` | Para excepciones no manejadas. Envía señal `got_request_exception`, loguea, respeta `PROPAGATE_EXCEPTIONS` y retorna `InternalServerError(500)` pasando por su handler si existe. |
| `log_exception(ctx, exc_info)` | Loguea la excepción con `self.logger.error` incluyendo `path` y `method`. |

### E. Teardown y Contextos

| Método | Descripción |
| :--- | :--- |
| `do_teardown_request(ctx, exc)` | Ejecuta funciones `teardown_request` y envía señal `request_tearing_down`. Usa `_CollectErrors` para ejecutar todos aunque uno falle. |
| `do_teardown_appcontext(ctx, exc)` | Ejecuta `teardown_appcontext_funcs` y señal `appcontext_tearing_down`. |
| `app_context()` | Crea un `AppContext` para uso manual con `with app.app_context():`. |
| `request_context(environ)` | Crea `AppContext` desde un `environ` WSGI. No debe usarse directamente. |
| `test_request_context(*args, **kwargs)` | Crea contexto de prueba usando `EnvironBuilder` de Werkzeug. Ideal para tests. |

### F. Utilidades de Desarrollo y Testing

| Método | Descripción |
| :--- | :--- |
| `run(host, port, debug, load_dotenv, **options)` | Inicia servidor de desarrollo con `werkzeug.serving.run_simple`. Carga `.env`, resuelve `host/port` desde `SERVER_NAME`, ignora llamadas si `FLASK_RUN_FROM_CLI=true`. **No usar en producción.** |
| `test_client(use_cookies, **kwargs)` | Crea `FlaskClient` para tests de integración. Soporta `with` blocks. |
| `test_cli_runner(**kwargs)` | Crea `FlaskCliRunner` para testear comandos Click. |
| `make_shell_context()` | Retorna dict para `flask shell` ejecutando `shell_context_processors`. |
| `ensure_sync(func)` / `async_to_sync(func)` | Convierte vistas `async def` a síncronas para workers WSGI usando `asgiref`. |

---

## 6. Flujo de Configuración

La clase define `default_config` con 24 claves. Las más relevantes son `SECRET_KEY`, `PERMANENT_SESSION_LIFETIME=31 días`, `SESSION_COOKIE_*`, `SERVER_NAME`, `APPLICATION_ROOT="/"`, `MAX_CONTENT_LENGTH` y `PREFERRED_URL_SCHEME="http"`. Esta configuración es inmutable y se fusiona con la configuración cargada por el usuario.

## 7. Conclusión

El archivo `flask/app.py` es el **orquestador monolítico** de Flask. Aunque hereda gran parte de la lógica de registro de `sansio.app.App`, esta clase concreta añade toda la integración específica de WSGI/Werkzeug, el manejo de contextos, el pipeline síncrono/asíncrono y las utilidades de desarrollo. Cualquier extensión o aplicación Flask interactúa directa o indirectamente con esta clase como punto central de control.