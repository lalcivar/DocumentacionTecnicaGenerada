# Documentación Técnica - `flask/app.py`

**Archivo:** `src/flask/app.py`  
**Módulo:** `Flask` - Clase principal de la aplicación  
**Framework:** Flask 3.x  
**Lenguaje:** Python 3.10+  
**Dependencia Base:** `werkzeug`, `jinja2`, `click`, `itsdangerous`

---

### 1. Descripción General

Este archivo define la clase central `Flask`, que implementa el protocolo **WSGI** y actúa como el núcleo de cualquier aplicación Flask. Es el registro central para:

* Definición de rutas y vistas `view_functions` y `url_map`.
* Gestión del ciclo de vida de la petición `request/response`.
* Configuración, manejo de sesiones, plantillas Jinja2 y archivos estáticos.
* Contextos de aplicación y de petición `AppContext`.
* Sistema de señales, manejo de errores y herramientas de testing y CLI.

Hereda de `sansio.app.App`, donde reside la lógica agnóstica al framework WSGI/SGI, mientras que esta clase añade la implementación específica para WSGI síncrono, Werkzeug y el servidor de desarrollo.

> En términos simples: este archivo es el que permite hacer `app = Flask(__name__)` y que `app` sea un callable WSGI ejecutable por cualquier servidor web.

### 2. Dependencias Principales

| Librería | Uso en el archivo |
| :--- | :--- |
| `werkzeug` | Routing `MapAdapter, Rule, BuildError`, Wrappers `Request/Response`, manejo de excepciones `HTTPException`, servidor `run_simple` |
| `jinja2` | Creación del entorno de plantillas vía `create_jinja_environment` |
| `click` | Grupo de comandos CLI `self.cli = cli.AppGroup()` |
| `flask.sansio.app.App` | Clase base con lógica común de configuración, blueprints y registro |
| `flask.ctx.AppContext` | Gestión de contextos de aplicación y petición |
| `flask.sessions` | Interfaz de sesión por defecto `SecureCookieSessionInterface` |
| `flask.signals` | Señales `request_started`, `request_finished`, `got_request_exception`, etc. |

### 3. Componentes Globales y Utilidades

#### 3.1 TypeVars
Define tipos genéricos para decoradores: `T_shell_context_processor`, `T_teardown`, `T_template_filter`, `T_template_global`, `T_template_test`. Permiten tipado estático para los decoradores de la app.

#### 3.2 `def _make_timedelta(value)`
Función helper que normaliza valores de configuración de tiempo. Convierte un `int` en segundos a `timedelta`. Si ya es `timedelta` o `None`, lo retorna sin cambios. Usada para `PERMANENT_SESSION_LIFETIME`.

#### 3.3 `def remove_ctx(f)` y `def add_ctx(f)`
Wrappers de compatibilidad y deprecación. A partir de Flask 3.2, métodos como `handle_exception`, `dispatch_request`, `finalize_request`, etc., reciben `ctx: AppContext` como primer argumento.

* `remove_ctx`: Elimina el argumento `ctx` si un método sobreescrito en una subclase aún usa la firma antigua. Emite `DeprecationWarning`.
* `add_ctx`: Inyecta automáticamente el `AppContext` actual cuando se llama a `super().metodo()` desde una subclase antigua.

Gestionados en `__init_subclass__` para mantener retrocompatibilidad hasta Flask 4.0.

### 4. Clase Principal: `class Flask(App)`

#### 4.1 Atributos de Clase

```python
default_config: ImmutableDict
request_class: type[Request] = Request
response_class: type[Response] = Response
session_interface: SessionInterface = SecureCookieSessionInterface()
```

`default_config` define la configuración por defecto de toda app Flask:

| Clave | Valor por defecto | Descripción |
| :--- | :--- | :--- |
| `DEBUG` | `None` | Activa modo debug |
| `TESTING` | `False` | Modo testing |
| `SECRET_KEY` | `None` | Clave para firmar sesiones |
| `PERMANENT_SESSION_LIFETIME` | `31 days` | Duración sesión permanente |
| `SERVER_NAME` | `None` | Nombre del servidor para URLs externas |
| `APPLICATION_ROOT` | `/` | Raíz de la aplicación |
| `SESSION_COOKIE_*` | Varios | Configuración de cookies |
| `MAX_CONTENT_LENGTH` | `None` | Límite de tamaño de petición |
| `TEMPLATES_AUTO_RELOAD` | `None` | Auto-recarga de plantillas |

#### 4.2 Inicialización

**`__init_subclass__`**: Hook de metaclase que detecta si una subclase sobreescribe métodos con la firma antigua sin `ctx` y aplica los wrappers de compatibilidad.

**`__init__(import_name, static_url_path, static_folder, ...)`**: Constructor principal.
1. Llama a `super().__init__()` de `sansio.app.App` para configurar `root_path`, `instance_path`, `template_folder`.
2. Inicializa el grupo CLI `self.cli`.
3. Si `has_static_folder` es True, registra automáticamente la ruta `"{static_url_path}/<path:filename>"` con endpoint `static` que apunta a `send_static_file`.

### 5. Métodos Principales por Categoría

#### A. Gestión de Recursos y Archivos Estáticos
* `get_send_file_max_age(filename)`: Determina el `max_age` de caché para `send_file` desde `SEND_FILE_MAX_AGE_DEFAULT`.
* `send_static_file(filename)`: View function para servir archivos de `static_folder` vía `send_from_directory`.
* `open_resource(resource, mode, encoding)`: Abre un archivo relativo a `root_path` solo en lectura.
* `open_instance_resource(resource, mode, encoding)`: Abre un archivo relativo a `instance_path`, permite escritura.

#### B. Plantillas y Contexto
* `create_jinja_environment()`: Crea el `Environment` de Jinja2, configura `autoescape`, `auto_reload` e inyecta globales `url_for`, `config`, `request`, `session`, `g`.
* `update_template_context(ctx, context)`: Inyecta variables de context processors de la app y del blueprint activo.
* `make_shell_context()`: Construye el diccionario para `flask shell` ejecutando todos los `shell_context_processors`.

#### C. Routing y URLs
* `create_url_adapter(request)`: Crea un `MapAdapter` de Werkzeug. Si hay `request`, lo vincula al `environ`; si no, usa `SERVER_NAME` para construir URLs fuera de petición.
* `url_for(endpoint, _anchor, _method, _scheme, _external, **values)`: Implementación central de `flask.url_for`. Maneja endpoints relativos a blueprints `.endpoint`, inyección de defaults y manejo de `BuildError`.
* `raise_routing_exception(request)`: En modo debug, convierte un `RequestRedirect` con body en `FormDataRoutingRedirect` para evitar pérdida de datos.

#### D. Ciclo de Vida de la Petición - WSGI Core
Este es el flujo más crítico:

1.  `wsgi_app(environ, start_response)` / `__call__`: Punto de entrada WSGI. Crea `AppContext`, hace `ctx.push()`, llama a `full_dispatch_request` y garantiza `ctx.pop(error)` incluso con excepciones.
2.  `full_dispatch_request(ctx)`: Orquesta el flujo completo. Emite `request_started`, llama a `preprocess_request`, luego a `dispatch_request` y captura excepciones vía `handle_user_exception`. Finalmente llama a `finalize_request`.
3.  `preprocess_request(ctx)`: Ejecuta `url_value_preprocessors` y `before_request_funcs`. Si alguno retorna valor no-None, corta el flujo.
4.  `dispatch_request(ctx)`: Hace el matching de la URL. Si `routing_exception` existe la lanza. Si es `OPTIONS` y `provide_automatic_options`, retorna `make_default_options_response`. Si no, invoca la view function `view_functions[endpoint]`.
5.  `finalize_request(ctx, rv, from_error_handler)`: Convierte `rv` a `Response` con `make_response`, ejecuta `process_response` y emite `request_finished`.
6.  `process_response(ctx, response)`: Ejecuta `after_request_funcs` en orden inverso y guarda la sesión `session_interface.save_session`.
7.  `do_teardown_request(ctx, exc)` y `do_teardown_appcontext(ctx, exc)`: Ejecutados al hacer `pop` del contexto. Llaman a funciones `teardown_*` y emiten señales `request_tearing_down` y `appcontext_tearing_down`.

#### E. Manejo de Errores
* `handle_http_exception(ctx, e)`: Busca handler registrado para el código HTTP. Si no hay, retorna la excepción.
* `handle_user_exception(ctx, e)`: Punto central. Si es `HTTPException` delega a `handle_http_exception`, si no busca handler. Si no hay handler, hace `raise`.
* `handle_exception(ctx, e)`: Para excepciones no manejadas. Emite `got_request_exception`, respeta `PROPAGATE_EXCEPTIONS`, loguea y retorna `InternalServerError` 500. Si hay handler para 500, lo usa.
* `log_exception(ctx, exc_info)`: Loguea `Exception on {path} [{method}]` en `self.logger`.

#### F. Helpers de Respuesta y Async
* `make_response(rv)`: Normaliza el retorno de una vista a `Response`. Soporta `str, bytes, dict, list, tuple, Response, WSGI callable, generador`. Desempaqueta tuplas `(body, status, headers)`.
* `make_default_options_response(ctx)`: Genera respuesta `OPTIONS` con header `Allow`.
* `ensure_sync(func)` / `async_to_sync(func)`: Permite usar `async def` views en servidor WSGI síncrono. Usa `asgiref.sync.async_to_sync` si está instalado.

#### G. Desarrollo y Testing
* `run(host, port, debug, load_dotenv, **options)`: Servidor de desarrollo. Carga `.env`, resuelve `host/port` desde `SERVER_NAME`, ignora la llamada si viene de `flask run` CLI y delega a `werkzeug.serving.run_simple`.
* `test_client(use_cookies, **kwargs)`: Factory para `FlaskClient` para tests de integración.
* `test_cli_runner(**kwargs)`: Factory para `FlaskCliRunner` para testear comandos CLI.
* `app_context()` / `request_context(environ)` / `test_request_context(*args, **kwargs)`: Factories para crear y manipular contextos manualmente, esenciales para testing y scripts.

### 6. Flujo de Ejecución Resumido

```
WSGI Server -> Flask.__call__ -> Flask.wsgi_app
    -> AppContext.push()
    -> full_dispatch_request
        -> request_started signal
        -> preprocess_request (before_request)
        -> dispatch_request (view function)
        -> handle_user_exception (si hay error)
        -> finalize_request -> make_response -> process_response (after_request)
        -> request_finished signal
    -> AppContext.pop()
        -> do_teardown_request
        -> do_teardown_appcontext
    -> Response(environ, start_response)
```

### 7. Conclusión

El archivo es el corazón del framework Flask. No solo define la clase `Flask`, sino que implementa todo el contrato WSGI, el dispatcher de peticiones, el sistema de contextos y la integración con Werkzeug, Jinja2 y Click. Cualquier extensión, blueprint o comando CLI de Flask depende directa o indirectamente de la lógica contenida en esta clase.