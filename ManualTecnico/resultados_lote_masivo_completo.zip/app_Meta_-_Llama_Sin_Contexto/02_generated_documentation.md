# Documentación Técnica - `flask/app.py`

### 1. Información General

| Atributo | Detalle |
| :--- | :--- |
| **Archivo** | `flask/app.py` |
| **Módulo** | `flask` |
| **Clase Principal** | `Flask` |
| **Herencia** | `Flask(App)` -> Hereda de `sansio.app.App` |
| **Tipo de Aplicación** | Aplicación WSGI |
| **Framework** | Flask 3.x |
| **Dependencia Base** | Werkzeug |

### 2. Descripción General

Este archivo es el **núcleo del framework Flask**. Implementa la clase central `Flask`, que actúa simultáneamente como:

1.  **Aplicación WSGI:** Es el objeto callable que el servidor WSGI invoca para atender cada petición HTTP. Implementa la interfaz `__call__(environ, start_response)`.
2.  **Registro Central:** Centraliza el registro de vistas, reglas de URL, configuración, manejo de plantillas Jinja2, gestión de sesiones, manejo de errores y extensiones.
3.  **Gestor de Contextos:** Administra el ciclo de vida del `AppContext` y `RequestContext`, que permiten acceder a proxies globales como `current_app`, `request`, `session` y `g`.
4.  **Orquestador del Ciclo de Petición:** Define todo el flujo de una petición: `preprocess -> dispatch -> postprocess -> teardown`.

En resumen, este archivo convierte una instancia `app = Flask(__name__)` en una aplicación web completa, capaz de enrutar peticiones, renderizar plantillas y devolver respuestas HTTP.

### 3. Dependencias Principales

*   **Werkzeug:** Para enrutamiento `routing`, objetos `Request/Response`, manejo de excepciones `HTTPException` y servidor de desarrollo `run_simple`.
*   **Jinja2:** A través de `templating.Environment` para el renderizado de plantillas.
*   **Click:** Para la integración de la interfaz de línea de comandos `self.cli`.
*   **Módulos Internos de Flask:** `ctx`, `globals`, `helpers`, `sessions`, `signals`, `wrappers`, `sansio.app`.

### 4. Componentes Principales

El archivo se compone de 3 bloques lógicos:

#### 4.1. TypeVars y Utilidades de Compatibilidad

```python
T_shell_context_processor, T_teardown, T_template_filter...
```

Definiciones de tipos genéricos para el tipado estático de decoradores.

#### 4.2. Funciones Auxiliares

| Función | Descripción |
| :--- | :--- |
| `_make_timedelta(value)` | Normaliza un valor de configuración a `timedelta`. Convierte `int` en segundos a `timedelta`, si ya es `timedelta` o `None` lo retorna sin cambios. Usado para `PERMANENT_SESSION_LIFETIME`. |
| `remove_ctx(f)` | Decorador de compatibilidad. Elimina el primer argumento `ctx: AppContext` si un método sobreescrito en una subclase aún usa la firma antigua. Emite `DeprecationWarning` para Flask 4.0. |
| `add_ctx(f)` | Decorador inverso. Inyecta automáticamente el `AppContext` actual `app_ctx._get_current_object()` cuando se llama a un método base desde una subclase con firma antigua. |

#### 4.3. Clase `Flask(App)`

Es el componente central del archivo. Contiene más de 30 métodos y atributos.

### 5. Documentación Detallada de la Clase `Flask`

#### 5.1. Atributos de Clase y Configuración

```python
default_config: ImmutableDict
request_class: type[Request] = Request
response_class: type[Response] = Response
session_interface: SessionInterface = SecureCookieSessionInterface()
```

*   **`default_config`:** Diccionario inmutable con la configuración por defecto de toda aplicación Flask. Incluye claves críticas como `DEBUG`, `SECRET_KEY`, `SERVER_NAME`, `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, `PREFERRED_URL_SCHEME`, etc.
*   **`request_class` / `response_class`:** Clases factorizables que permiten personalizar los objetos de petición y respuesta.
*   **`session_interface`:** Estrategia de manejo de sesiones. Por defecto usa cookies seguras firmadas.

#### 5.2. Constructor e Inicialización

**`__init_subclass__(cls)`**
Método de metaprogramación que detecta si una subclase sobreescribe métodos del ciclo de vida sin el nuevo parámetro `ctx: AppContext`. Si es así, lanza un `DeprecationWarning` y aplica los wrappers `remove_ctx`/`add_ctx` para mantener compatibilidad.

**`__init__(import_name, static_url_path, static_folder, ...)`**
Inicializa la aplicación. Parámetros clave:
*   `import_name`: Nombre del paquete/módulo. Usado para localizar recursos, `root_path` y `instance_path`.
*   `static_folder` / `static_url_path` / `static_host`: Configuración de archivos estáticos. Si `has_static_folder` es True, registra automáticamente la ruta `/static/<path:filename>` con `send_static_file`.
*   `template_folder`, `instance_path`, `root_path`, `host_matching`, `subdomain_matching`.
*   Inicializa `self.cli = cli.AppGroup()` para comandos `flask`.

#### 5.3. Gestión de Recursos y Plantillas

| Método | Descripción |
| :--- | :--- |
| `get_send_file_max_age(filename)` | Determina el `Cache-Control: max-age` para `send_file`. Lee `SEND_FILE_MAX_AGE_DEFAULT` del config. |
| `send_static_file(filename)` | View function para servir archivos de `static_folder`. Usa `helpers.send_from_directory`. |
| `open_resource(resource, mode, encoding)` | Abre un archivo relativo a `root_path` solo en modo lectura. |
| `open_instance_resource(resource, mode, encoding)` | Abre un archivo relativo a `instance_path`. Permite escritura. Ideal para bases de datos SQLite o uploads. |
| `create_jinja_environment()` | Crea y configura el `Environment` de Jinja2. Inyecta globales: `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g`. Configura `autoescape` y `auto_reload` según `TEMPLATES_AUTO_RELOAD`. |

#### 5.4. Enrutamiento y URLs

| Método | Descripción |
| :--- | :--- |
| `create_url_adapter(request)` | Crea un `MapAdapter` de Werkzeug para hacer `match` y `build` de URLs. Maneja `TRUSTED_HOSTS`, `SERVER_NAME`, `APPLICATION_ROOT`, `host_matching` y `subdomain_matching`. |
| `raise_routing_exception(request)` | Intercepta `RequestRedirect` en modo `debug` para evitar perder datos de formularios en redirecciones con slash. Lanza `FormDataRoutingRedirect`. |
| `url_for(endpoint, _anchor, _method, _scheme, _external, **values)` | Implementación central de `flask.url_for`. Genera URLs internas o externas. Maneja endpoints relativos a Blueprints `.endpoint`, inyección de defaults y delega en `handle_url_build_error` si falla. |

#### 5.5. Ciclo de Vida de la Petición - WSGI

Este es el flujo más importante del archivo:

```
wsgi_app(environ, start_response) -> request_context() -> ctx.push()
    -> full_dispatch_request(ctx)
        -> request_started signal
        -> preprocess_request(ctx) [before_request, url_value_preprocessors]
        -> dispatch_request(ctx) [route matching + view function]
        -> handle_user_exception() si hay error
        -> finalize_request() [make_response + process_response + request_finished signal]
    -> handle_exception() si hay error no capturado
    -> ctx.pop() [do_teardown_request + do_teardown_appcontext]
```

| Método | Rol en el ciclo |
| :--- | :--- |
| `wsgi_app(environ, start_response)` | **Entry Point WSGI.** Crea el contexto, ejecuta `full_dispatch_request` y garantiza el `pop()` del contexto incluso con errores. Soporta `werkzeug.debug.preserve_context`. |
| `__call__(environ, start_response)` | Wrapper que delega en `wsgi_app`. Permite aplicar middlewares WSGI. |
| `full_dispatch_request(ctx)` | Orquesta el dispatch completo. Marca `_got_first_request`, envía señal `request_started`, llama a `preprocess` y `dispatch`, captura excepciones. |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y `before_request_funcs` de la app y blueprints. Si alguno retorna valor no-None, corta el flujo. |
| `dispatch_request(ctx)` | Hace el matching de la URL. Si `provide_automatic_options` y método es `OPTIONS`, retorna `make_default_options_response`. Si no, invoca `view_functions[endpoint](**view_args)`. |
| `finalize_request(ctx, rv, from_error_handler)` | Convierte `rv` a `Response` con `make_response`, ejecuta `process_response` y envía señal `request_finished`. |
| `process_response(ctx, response)` | Ejecuta `after_request_funcs` en orden inverso y guarda la sesión con `session_interface.save_session`. |
| `do_teardown_request(ctx, exc)` | Ejecuta `teardown_request_funcs` y envía señal `request_tearing_down`. Usa `_CollectErrors` para ejecutar todos los callbacks aunque uno falle. |
| `do_teardown_appcontext(ctx, exc)` | Ejecuta `teardown_appcontext_funcs` y envía señal `appcontext_tearing_down`. |

#### 5.6. Manejo de Errores

| Método | Descripción |
| :--- | :--- |
| `handle_http_exception(ctx, e)` | Busca un handler registrado para el código HTTP. Si no existe, retorna la excepción. Ignora `RoutingException`. |
| `handle_user_exception(ctx, e)` | Punto de entrada para cualquier excepción en la vista. Si es `HTTPException` delega en `handle_http_exception`, si no busca handler. Si no hay handler, hace `raise`. Maneja `TRAP_BAD_REQUEST_ERRORS`. |
| `handle_exception(ctx, e)` | Handler de último recurso. Genera un `500 InternalServerError`, envía señal `got_request_exception`, loguea el error y busca handler para 500. Respeta `PROPAGATE_EXCEPTIONS`. |
| `log_exception(ctx, exc_info)` | Loguea la excepción con `self.logger.error` incluyendo `path` y `method`. |

#### 5.7. Utilidades de Respuesta y Async

| Método | Descripción |
| :--- | :--- |
| `make_response(rv)` | **Normalizador de respuestas.** Convierte el valor retornado por la vista a `Response`. Soporta: `str`, `bytes`, `dict/list` -> JSON, `tuple (body, status, headers)`, `Response`, `WSGI callable`, `Iterator` -> streaming. |
| `make_default_options_response(ctx)` | Genera respuesta automática para `OPTIONS` con header `Allow`. |
| `ensure_sync(func)` | Si la función es `async def`, la convierte a síncrona vía `async_to_sync`. Si no, la retorna tal cual. |
| `async_to_sync(func)` | Usa `asgiref.sync.async_to_sync` para ejecutar corrutinas en workers WSGI síncronos. Requiere extra `async`. |

#### 5.8. Contextos y Testing

| Método | Descripción |
| :--- | :--- |
| `app_context()` | Crea un `AppContext` para usar con `with app.app_context():`. Expone `current_app` y `g`. |
| `request_context(environ)` | Crea un `AppContext` a partir de un `environ` WSGI. Expone `request` y `session`. |
| `test_request_context(*args, **kwargs)` | Crea un contexto de petición falso usando `EnvironBuilder` de Werkzeug. Ideal para tests sin hacer request real. |
| `test_client(use_cookies, **kwargs)` | Factory para `FlaskClient`. Permite testear rutas sin servidor. |
| `test_cli_runner(**kwargs)` | Factory para `FlaskCliRunner`. Permite testear comandos CLI. |
| `update_template_context(ctx, context)` | Inyecta variables de context processors al contexto de Jinja2. |
| `make_shell_context()` | Retorna dict para `flask shell` ejecutando todos los `shell_context_processors`. |

#### 5.9. Servidor de Desarrollo

**`run(host, port, debug, load_dotenv, **options)`**
Inicia el servidor de desarrollo de Werkzeug `run_simple`. No debe usarse en producción.
*   Ignora la llamada si `FLASK_RUN_FROM_CLI=true`.
*   Carga `.env` y `.flaskenv` si `load_dotenv=True`.
*   Resuelve `host` y `port` desde `SERVER_NAME` si no se proveen.
*   Configura `use_reloader`, `use_debugger` y `threaded=True` por defecto.

