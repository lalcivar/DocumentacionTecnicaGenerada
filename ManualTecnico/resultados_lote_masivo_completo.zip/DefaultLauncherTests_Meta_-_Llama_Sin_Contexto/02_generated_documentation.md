# Documentación Técnica - Clase `DefaultLauncherTests`

### 1. Información General

| Atributo | Detalle |
| :--- | :--- |
| **Nombre de la Clase** | `DefaultLauncherTests` |
| **Paquete** | `org.junit.platform.launcher.core` |
| **Tipo** | Clase de Pruebas Unitarias y de Integración |
| **Clase Bajo Prueba** | `org.junit.platform.launcher.core.DefaultLauncher` |
| **Framework** | JUnit Platform 1.0+ / JUnit Jupiter |
| **Anotaciones** | `@NullMarked`, `@TrackLogRecords`, `@SetSystemProperty` |
| **Versión** | `@since 1.0` |
| **Licencia** | Eclipse Public License v2.0 |

> **Nota:** Aunque el nombre sugiere ser la clase `DefaultLauncher`, el código proporcionado corresponde a su **suite de tests**. Su objetivo es validar el comportamiento de `DefaultLauncher`, que es la implementación por defecto de la interfaz `Launcher` de JUnit Platform, encargada de descubrir y ejecutar tests.

---

### 2. Descripción General

`DefaultLauncherTests` es una clase de prueba exhaustiva que verifica el ciclo de vida completo del `Launcher` de JUnit Platform. Actúa como una especificación ejecutable del comportamiento esperado de `DefaultLauncher`.

**Responsabilidades que valida:**

1.  **Descubrimiento (Discovery):** Creación de un `TestPlan` a partir de `DiscoverySelectors` y `TestEngines`. Valida casos de éxito, fallo, motores vacíos, motores nulos y manejo de excepciones.
2.  **Filtrado (Filtering):** Aplicación correcta de `PostDiscoveryFilter` y poda de descriptores que no cumplen los filtros.
3.  **Ejecución (Execution):** Orquestación de la ejecución del `TestPlan`, notificación a `TestExecutionListener` y `LauncherDiscoveryListener`, y manejo de fallos durante la ejecución.
4.  **Gestión de Configuración y Estado:** Propagación de `ConfigurationParameters`, manejo de `CancellationToken`, modo `dry-run` y validación de IDs de motores reservados.
5.  **Gestión de Issues:** Tratamiento de `DiscoveryIssue` con diferentes severidades `INFO`, `WARNING`, `ERROR` y su reporte/logging según la fase configurada `discovery` o `execution`.

Utiliza extensivamente **Mockito** para simular `TestEngine` y `TestExecutionListener`, **AssertJ** y **JUnit Jupiter Assertions** para las aserciones, y `TestEngineSpy` / `TestEngineStub` como dobles de prueba.

### 3. Constantes y Atributos Principales

```java
static final String FOO = "DefaultLauncherTests.foo";
static final String BAR = "DefaultLauncherTests.bar";
private static final Runnable noOp = () -> {};
```
*   `FOO` / `BAR`: Claves/valores utilizados para probar la resolución de parámetros de configuración vía `SystemProperty`.
*   `noOp`: Tarea vacía utilizada para crear tests jerárquicos de demostración `DemoHierarchicalTestEngine` sin lógica de ejecución.

### 4. Métodos Principales

Todos los métodos son casos de prueba anotados con `@Test` o `@ParameterizedTest`. Se agrupan por funcionalidad:

#### 4.1. Validación de Construcción y Descubrimiento Básico

| Método | Descripción |
| :--- | :--- |
| `constructLauncherWithoutAnyEngines()` | Verifica que se lance `PreconditionViolationException` si se intenta crear un `Launcher` sin ningún `TestEngine` registrado. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | Valida que se lance `JUnitException` si existen múltiples motores con el mismo ID. |
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | Comprueba que el descubrimiento con un motor sin tests genere un `TestPlan` con solo la raíz del motor. |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | Valida el manejo de fallo cuando un `TestEngine` retorna `null` en `discover()`. Debe reportar `EngineDiscoveryResult.Status.FAILED`. |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()` | Prueba parametrizada `Error` y `RuntimeException` que verifica que una excepción en la fase de descubrimiento se encapsule y se reporte como fallo de ejecución. |
| `discoverTestPlanForSingleEngine()` | Valida el descubrimiento correcto de 2 tests para un solo motor usando `selectPackage`. |
| `discoverTestPlanForMultipleEngines()` | Valida el descubrimiento con múltiples motores usando `selectUniqueId`. |

#### 4.2. Filtrado y Poda del TestPlan

| Método | Descripción |
| :--- | :--- |
| `launcherAppliesPostDiscoveryFilters()` | Verifica que los `PostDiscoveryFilter` se apliquen en orden y filtren correctamente los descriptores. |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | Comprueba que los contenedores vacíos después del filtrado sean podados del `TestPlan` final. |

#### 4.3. Ejecución y Reporte de Eventos

| Método | Descripción |
| :--- | :--- |
| `reportsEngineExecutionFailuresWithoutPriorEvents()` | Valida que si `TestEngine.execute()` lanza una excepción sin eventos previos, se notifique `executionFinished` con estado fallido. |
| `reportsEngineExecutionFailuresForSkippedEngine()` / `ForStartedEngine()` / `ForSuccessfullyFinishedEngine()` / `ForFailedFinishedEngine()` | Suite de 4 tests que cubre todos los estados previos del motor `SKIPPED`, `STARTED`, `FINISHED_SUCCESSFUL`, `FINISHED_FAILED` antes de una excepción. Valida el manejo de excepciones suprimidas. |
| `reportsSkippedEngines()` | Verifica que un motor que reporta `executionSkipped` notifique correctamente a `TestExecutionListener`. |
| `reportsFinishedEngines()` | Verifica el flujo feliz `executionStarted` -> `executionFinished(successful)`. |
| `reportsDynamicTestDescriptorsCorrectly()` | Valida el registro y ejecución de tests dinámicos `dynamicTestRegistered` y la correcta construcción de la jerarquía de `TestIdentifier`. |
| `launcherCanExecuteTestPlanExactlyOnce()` | Garantiza que un `TestPlan` solo pueda ser ejecutado una vez, lanzando `PreconditionViolationException` en el segundo intento. |
| `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | Valida el modo `DRY_RUN_PROPERTY_NAME=true`: los tests se reportan como `SKIPPED` con mensaje `dry-run mode is enabled` y no se ejecuta su lógica. |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | Verifica que si un `CancellationToken` es cancelado, no se invoque `engine.execute()` y los hijos se reporten como `ABORTED` / `SKIPPED`. |

#### 4.4. Configuración y Listeners

| Método | Descripción |
| :--- | :--- |
| `withoutConfigurationParameters_...()` / `withConfigurationParameters_...()` | Verifican que los `ConfigurationParameters` se propaguen correctamente al `ExecutionRequest` del motor. |
| `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | Valida el fallback a `System.getProperty()` cuando no hay parámetros explícitos. |
| `withAdditionalListener()` | Comprueba que un `SummaryGeneratingListener` adicional reciba los eventos y genere un resumen correcto. |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | Valida que los `LauncherDiscoveryListener` registrados en la configuración, en el launcher y en el request reciban el evento `selectorProcessed`. |

#### 4.5. Validación de Seguridad y Discovery Issues

| Método | Descripción |
| :--- | :--- |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | Valida que un motor de terceros con prefijo `junit-` genere un `DiscoveryIssueException` de tipo `WARNING`. |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` / `...Vintage...()` | Valida que un motor no pueda suplantar los IDs reservados `junit-jupiter` y `junit-vintage`. |
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()` | Valida que issues `ERROR` fallen la ejecución y `WARNING` solo se logueen. |
| `logsNonCriticalIssuesForRegularEngineExecution()` | Valida que issues `INFO` se logueen con nivel `INFO` sin fallar la ejecución. |
| `logsAllIssuesForDiscoveryFailure()` / `logsNonCriticalIssuesForExecutionFailure()` | Validan el logging diferenciado según la fase donde ocurre el fallo. |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | Valida que un `UniqueId` no resuelto con prefijo del motor genere un fallo crítico. |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` / `failsIfCriticalSeverityIsConfiguredIncorrectly()` | Validan la configuración `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME`. |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | Valida la configuración `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery`. |

### 5. Métodos Auxiliares Privados

| Método | Descripción |
| :--- | :--- |
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | Helper que verifica que se haya notificado `engineDiscoveryStarted` y `engineDiscoveryFinished` con estado `FAILED`. |
| `assertImposter(String id)` | Helper para validar la suplantación de IDs reservados. |
| `execute(TestEngine, ...)` | Tres sobrecargas que encapsulan el flujo `discover` -> `execute` con mocks de `TestExecutionListener`, capturando `TestPlan`, `TestIdentifier`, `TestExecutionResult` y timestamps. Es el método central para simplificar los tests de ejecución. |
| `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` | Recupera el primer `LogRecord` de `DiscoveryIssueNotifier` para un nivel dado. |

### 6. Estructura Interna

*   **Record `ReportedData`:** `record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier, TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)` - DTO inmutable para transportar los resultados de la ejecución en los tests de `DiscoveryIssue`.

