# Documentación Técnica - `DefaultLauncherTests`

### 1. Información General

| Atributo | Detalle |
| :--- | :--- |
| **Clase** | `DefaultLauncherTests` |
| **Paquete** | `org.junit.platform.launcher.core` |
| **Tipo** | Clase de Pruebas Unitarias / Integración |
| **Clase bajo prueba** | `org.junit.platform.launcher.core.DefaultLauncher` |
| **Framework** | JUnit 5 (Jupiter), Mockito, AssertJ |
| **Anotación de clase** | `@NullMarked` |
| **Desde** | `1.0` |
| **Licencia** | Eclipse Public License v2.0 |
| **Visibilidad** | package-private `class` |

#### 1.1 Descripción General
`DefaultLauncherTests` es la suite de pruebas exhaustiva para `DefaultLauncher`, la implementación por defecto de la interfaz `Launcher` de JUnit Platform.

Su objetivo no es contener lógica de negocio, sino **validar el ciclo de vida completo del Launcher**: construcción, descubrimiento `discover()` y ejecución `execute()` de un `TestPlan` a través de uno o más `TestEngine`.

Garantiza que el `DefaultLauncher` gestione correctamente:
* El registro y validación de `TestEngine`.
* La creación y filtrado del `TestPlan`.
* La propagación de parámetros de configuración y listeners.
* El manejo robusto de errores en fase de descubrimiento y ejecución.
* El sistema de `DiscoveryIssue` con severidades y fases de fallo configurables.
* Funcionalidades avanzadas como `dry-run`, cancelación y tests dinámicos.

### 2. Dependencias y Configuración

La clase utiliza un entorno de pruebas aislado mediante `LauncherFactoryForTestingPurposesOnly.createLauncher()` para evitar el `ServiceLoader` y poder inyectar `TestEngine` falsos `TestEngineStub`, `TestEngineSpy`, `DemoHierarchicalTestEngine`.

**Dependencias clave:**
* `org.junit.platform.engine` - API de `TestEngine`, `TestDescriptor`, `ExecutionRequest`.
* `org.junit.platform.launcher` - `TestPlan`, `TestIdentifier`, `LauncherDiscoveryRequestBuilder`.
* `Mockito` - Para verificar interacciones con `TestExecutionListener` y `LauncherDiscoveryListener`.
* `AssertJ` y `JUnit Jupiter Assertions` - Para aserciones.

**Constantes:**
* `FOO = "DefaultLauncherTests.foo"` y `BAR = "DefaultLauncherTests.bar"`: Usadas para probar la resolución de parámetros de configuración vía `SystemProperty`.
* `noOp = () -> {}`: Tarea vacía para crear tests jerárquicos de prueba.

### 3. Métodos Principales

Los métodos se agrupan por funcionalidad validada. Todos son métodos de prueba anotados con `@Test` o `@ParameterizedTest`.

#### 3.1 Validación de Construcción del Launcher
| Método | Descripción |
| :--- | :--- |
| `constructLauncherWithoutAnyEngines()` | Verifica que se lance `PreconditionViolationException` si se intenta crear un Launcher sin ningún `TestEngine`. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | Verifica que se lance `JUnitException` si se registran dos engines con el mismo ID. |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | Valida que un engine de terceros que use el prefijo reservado `junit-` genere un `DiscoveryIssue` de tipo WARNING. |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` / `thirdPartyEngineClaimingToBeVintageResultsInException()` | Verifica que un engine que intente suplantar `junit-jupiter` o `junit-vintage` sea rechazado con `JUnitException`. |

#### 3.2 Fase de Descubrimiento - `discover()`
| Método | Descripción |
| :--- | :--- |
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | Comprueba que un engine sin tests genere un `TestPlan` con solo el nodo raíz. |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | Valida el manejo de fallo cuando `TestEngine.discover()` retorna `null`. Debe reportar `EngineDiscoveryResult.Status.FAILED`. |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()` | Prueba parametrizada que simula que el engine lanza `Error` o `RuntimeException` durante el descubrimiento. Verifica que el fallo se encapsule y se reporte al `TestExecutionListener`. |
| `discoverTestPlanForSingleEngine()` / `discoverTestPlanForMultipleEngines()` | Validan la correcta construcción del `TestPlan` y su jerarquía de `UniqueId` para uno y múltiples engines. |
| `launcherCanExecuteTestPlanExactlyOnce()` | Asegura que un `TestPlan` descubierto solo pueda ser ejecutado una vez. Un segundo `execute()` debe fallar. |

#### 3.3 Fase de Ejecución - `execute()` y Reporte de Eventos
| Método | Descripción |
| :--- | :--- |
| `reportsEngineExecutionFailuresWithoutPriorEvents()` y variantes `ForSkippedEngine`, `ForStartedEngine`, `ForSuccessfullyFinishedEngine`, `ForFailedFinishedEngine()` | Suite que verifica que si un `TestEngine` lanza una excepción durante `execute()`, el `DefaultLauncher` siempre reporte `executionFinished` con un `TestExecutionResult` fallido, independientemente del estado previo del engine. Incluye manejo de excepciones suprimidas. |
| `reportsSkippedEngines()` / `reportsFinishedEngines()` | Verifican la correcta notificación de `executionSkipped` y `executionFinished` al listener. |
| `reportsDynamicTestDescriptorsCorrectly()` | Valida el flujo completo de tests dinámicos: `dynamicTestRegistered` -> `executionStarted` -> `executionFinished` y la correcta construcción de la jerarquía de `TestIdentifier` en el `TestPlan`. |
| `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | Verifica el modo `DRY_RUN_PROPERTY_NAME=true`: los tests deben ser reportados como `SKIPPED` con el mensaje `JUnit Platform dry-run mode is enabled` y nunca ejecutados. |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | Valida que si un `CancellationToken` es cancelado antes de la ejecución, el engine no se ejecuta y sus hijos se reportan como `ABORTED` / `SKIPPED`. |

#### 3.4 Filtrado y Configuración
| Método | Descripción |
| :--- | :--- |
| `launcherAppliesPostDiscoveryFilters()` | Comprueba que los `PostDiscoveryFilter` se apliquen correctamente en cascada para filtrar el `TestPlan`. |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | Verifica que los contenedores que quedan vacíos después del filtrado sean podados del `TestPlan`. |
| `withoutConfigurationParameters_...` / `withConfigurationParameters_...` / `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | Validan la propagación de `ConfigurationParameters` al `ExecutionRequest` y el fallback a `System.getProperty()`. |
| `withAdditionalListener()` | Verifica que listeners adicionales `SummaryGeneratingListener` reciban correctamente los eventos. |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | Asegura que todos los `LauncherDiscoveryListener` registrados (en config, en launcher y en request) reciban el evento `selectorProcessed`. |

#### 3.5 Gestión de `DiscoveryIssue`
Este es el bloque más extenso. Valida el sistema de severidad y fase de fallo configurable.

| Método | Descripción |
| :--- | :--- |
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()` | Si hay un `Severity.ERROR`, la ejecución debe fallar con `DiscoveryIssueException` y los `WARNING` deben solo loguearse. |
| `logsNonCriticalIssuesForRegularEngineExecution()` / `logsNonCriticalIssuesForExecutionFailure()` / `logsAllIssuesForDiscoveryFailure()` | Verifican que los issues no críticos `INFO`, `WARNING` se logueen con el nivel correcto `Level.INFO`, `Level.WARNING`, `Level.SEVERE` y no provoquen fallo si no superan el umbral crítico. |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` | Valida la configuración `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME`. Si se configura a `info`, un issue `INFO` debe provocar fallo. |
| `failsIfCriticalSeverityIsConfiguredIncorrectly()` | Verifica que un valor inválido para la severidad crítica lance `JUnitException`. |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` / `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()` / `logsNonCriticalIssuesOnlyOnce()` | Validan la propiedad `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME` (`discovery` vs `execution`) que determina en qué fase debe fallar el launcher ante un issue crítico. |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` / `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` / `reportsEngineExecutionFailureForSelectorResolutionFailure()` | Validan el manejo de selectores `UniqueId` no resueltos o con error de resolución. |

### 4. Métodos Auxiliares Privados

| Método | Descripción |
| :--- | :--- |
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | Helper para verificar que se notificó `engineDiscoveryStarted` y `engineDiscoveryFinished` con estado `FAILED`. |
| `assertImposter(String id)` | Helper para validar el rechazo de engines impostores. |
| `execute(TestEngine, ...)` (3 sobrecargas) | Método central de utilidad. Crea un Launcher, ejecuta `discover()` y `execute()` capturando `TestPlan`, `TestIdentifier`, `TestExecutionResult` y timestamps. Retorna un `ReportedData`. Es usado por la mayoría de pruebas de `DiscoveryIssue`. |
| `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` | Busca el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con un nivel específico. |
| `ReportedData` (record) | DTO interno que encapsula `TestPlan`, `TestIdentifier`, `TestExecutionResult`, `startTime` y `finishTime` para aserciones. |

### 5. Conclusión
`DefaultLauncherTests` actúa como **contrato de especificación** para `DefaultLauncher`. No solo prueba el camino feliz, sino que garantiza la resiliencia del Platform Launcher ante engines defectuosos, configuraciones erróneas y condiciones de borde, asegurando que el reporte de eventos hacia `TestExecutionListener` sea siempre consistente y predecible según la especificación de JUnit Platform.
