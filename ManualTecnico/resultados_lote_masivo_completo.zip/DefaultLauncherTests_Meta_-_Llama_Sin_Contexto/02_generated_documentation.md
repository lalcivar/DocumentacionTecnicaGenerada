# Documentación Técnica - Clase `DefaultLauncherTests`

### 1. Información General

| Atributo | Valor |
| :--- | :--- |
| **Nombre de la Clase** | `DefaultLauncherTests` |
| **Paquete** | `org.junit.platform.launcher.core` |
| **Tipo** | Clase de Pruebas Unitarias y de Integración |
| **Clase Bajo Prueba** | `org.junit.platform.launcher.core.DefaultLauncher` |
| **Framework** | JUnit Platform 5 (Jupiter) |
| **Anotaciones** | `@NullMarked`, `@since 1.0` |
| **Licencia** | Eclipse Public License v2.0 |
| **Dependencias de Test** | Mockito, AssertJ, JUnit Jupiter, `TestEngineStub`, `DemoHierarchicalTestEngine` |

### 2. Descripción General

`DefaultLauncherTests` es la suite de pruebas exhaustiva para validar el comportamiento de `DefaultLauncher`, que es la implementación por defecto de la interfaz `Launcher` de JUnit Platform.

Su responsabilidad no es contener lógica de negocio, sino **verificar el contrato del Launcher** en sus dos fases principales:

1.  **Fase de Descubrimiento (`discover`):** Cómo el Launcher descubre los `TestDescriptor` a partir de `DiscoverySelectors` y `TestEngines` registrados.
2.  **Fase de Ejecución (`execute`):** Cómo el Launcher orquesta la ejecución del `TestPlan` descubierto, notifica a los `TestExecutionListener` y maneja errores, cancelaciones y modos especiales como `dry-run`.

La clase garantiza la robustez del Launcher frente a casos de error, configuraciones inválidas, motores defectuosos y el manejo correcto de `DiscoveryIssue`.

### 3. Estructura y Componentes

#### 3.1 Constantes y Atributos
```java
static final String FOO = "DefaultLauncherTests.foo";
static final String BAR = "DefaultLauncherTests.bar";
private static final Runnable noOp = () -> {};
```
Utilizadas para pruebas de parámetros de configuración y como tareas vacías para crear tests jerárquicos de prueba.

#### 3.2 Métodos Principales

Los métodos se agrupan por funcionalidad. Todos son métodos de prueba anotados con `@Test` o `@ParameterizedTest`.

##### A. Validación de Construcción del Launcher
Verifican las precondiciones al crear una instancia del Launcher.

| Método | Descripción |
| :--- | :--- |
| `constructLauncherWithoutAnyEngines()` | Verifica que se lance una violación de precondición si se intenta crear un Launcher sin ningún `TestEngine`. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | Verifica que se lance `JUnitException` si se registran dos motores con el mismo ID. |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | Valida que un motor de terceros que use el prefijo reservado `junit-` genere un `DiscoveryIssue` de tipo WARNING. |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` / `thirdPartyEngineClaimingToBeVintageResultsInException()` | Verifica que un motor que intente suplantar los IDs `junit-jupiter` o `junit-vintage` sea rechazado con excepción. |

##### B. Fase de Descubrimiento - `discover()`

| Método | Descripción |
| :--- | :--- |
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | Comprueba que un motor sin tests genere un `TestPlan` con solo la raíz del engine. |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | Valida el manejo de fallo cuando un `TestEngine` retorna `null` en `discover()`. Debe reportar `EngineDiscoveryResult.Status.FAILED`. |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase()` | Verifica que si el motor lanza `Error` o `RuntimeException` durante el descubrimiento, se capture el error y se reporte correctamente al `LauncherDiscoveryListener` y posteriormente en la ejecución. |
| `discoverTestPlanForSingleEngine()` / `discoverTestPlanForMultipleEngines()` | Prueban el descubrimiento correcto de tests para uno y múltiples motores usando selectores `selectPackage` y `selectUniqueId`. |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | Verifica que todos los `LauncherDiscoveryListener` registrados (en config, en launcher y en request) sean notificados del evento `selectorProcessed`. |

##### C. Fase de Ejecución - `execute()` y Manejo de Fallos

| Método | Descripción |
| :--- | :--- |
| `reportsEngineExecutionFailuresWithoutPriorEvents()` | Verifica que si un motor lanza una excepción sin haber notificado eventos previos, el Launcher reporte `executionStarted` y `executionFinished` con estado FAILED. |
| `reportsEngineExecutionFailuresForSkippedEngine()` / `ForStartedEngine()` / `ForSuccessfullyFinishedEngine()` / `ForFailedFinishedEngine()` | Suite de pruebas que valida que, independientemente del estado previo reportado por el motor (skipped, started, finished), cualquier excepción lanzada por `engine.execute()` sea capturada y reportada como fallo del engine, preservando la causa original y excepciones suprimidas. |
| `reportsSkippedEngines()` / `reportsFinishedEngines()` | Casos de éxito donde se verifica la correcta notificación de `executionSkipped` y `executionFinished` con `successful()`. |
| `launcherCanExecuteTestPlanExactlyOnce()` | Garantiza que un `TestPlan` solo pueda ser ejecutado una vez; un segundo intento debe lanzar violación de precondición. |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | Valida la integración con `CancellationToken`: si se cancela antes de ejecutar, el motor no se ejecuta y sus hijos se reportan como `ABORTED` / `Skipped`. |

##### D. Filtros y Configuración

| Método | Descripción |
| :--- | :--- |
| `launcherAppliesPostDiscoveryFilters()` | Comprueba que los `PostDiscoveryFilter` se apliquen correctamente para filtrar descriptores después del descubrimiento. |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | Verifica que los contenedores que quedan vacíos tras aplicar los filtros sean podados del `TestPlan`. |
| `withoutConfigurationParameters_...` / `withConfigurationParameters_...` / `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | Validan que los `ConfigurationParameters` se propaguen correctamente al `ExecutionRequest` y que exista fallback a `System.getProperty`. |
| `withAdditionalListener()` | Verifica que se puedan añadir `TestExecutionListener` adicionales (ej. `SummaryGeneratingListener`) al ejecutar. |

##### E. Funcionalidades Avanzadas

| Método | Descripción |
| :--- | :--- |
| `reportsDynamicTestDescriptorsCorrectly()` | Valida el registro y reporte correcto de tests dinámicos (`dynamicTestRegistered`) creados durante la ejecución. |
| `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | Verifica el modo `dry-run` (`DRY_RUN_PROPERTY_NAME=true`): se deben reportar todos los eventos pero los tests se marcan como `Skipped` sin ejecutar su lógica. |
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining()` | Prueba el sistema de `DiscoveryIssue`: issues con severidad `ERROR` deben fallar la ejecución, mientras que `WARNING` solo se loguean. |
| `logsNonCriticalIssuesForRegularEngineExecution()` / `logsAllIssuesForDiscoveryFailure()` / `logsNonCriticalIssuesForExecutionFailure()` | Validan el logueo de issues no críticos en diferentes escenarios de éxito y fallo. |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` / `failsIfCriticalSeverityIsConfiguredIncorrectly()` | Verifican que la severidad crítica sea configurable vía `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME` y que un valor inválido lance `JUnitException`. |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` / `logsNonCriticalIssuesOnlyOnce()` | Prueban la propiedad `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME` que permite configurar si el fallo por issues críticos ocurre en fase `discovery` o `execution`. |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` / `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` / `reportsEngineExecutionFailureForSelectorResolutionFailure()` | Validan el manejo de selectores `UniqueId` no resueltos y fallos de resolución. |

#### 3.3 Métodos Auxiliares Privados

| Método | Descripción |
| :--- | :--- |
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | Helper para verificar que un `LauncherDiscoveryListener` recibió los eventos `engineDiscoveryStarted` y `engineDiscoveryFinished` con estado `FAILED`. |
| `assertImposter(String id)` | Helper para validar el rechazo de motores impostores. |
| `execute(TestEngine, ...)` | Métodos sobrecargados que encapsulan el flujo completo `discover` + `execute` con mocks de `TestExecutionListener`, capturando `TestPlan`, `TestIdentifier`, `TestExecutionResult` y timestamps. Retorna el `record ReportedData`. |
| `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` | Busca el primer `LogRecord` emitido por `DiscoveryIssueNotifier` para un nivel dado. |

### 4. Dependencias Clave

*   **JUnit Platform Engine:** `TestEngine`, `TestDescriptor`, `EngineDescriptor`, `DiscoverySelector`, `DiscoveryIssue`.
*   **JUnit Platform Launcher:** `LauncherFactory`, `LauncherDiscoveryRequestBuilder`, `LauncherExecutionRequestBuilder`, `TestPlan`, `TestIdentifier`.
*   **Mocks y Fakes:** `TestEngineStub`, `TestEngineSpy`, `DemoHierarchicalTestEngine`, `PostDiscoveryFilterStub` y Mockito para verificar interacciones con listeners.
*   **Aserciones:** AssertJ (`assertThat`) y JUnit Jupiter (`assertThrows`, `assertAll`).

### 5. Conclusión

`DefaultLauncherTests` actúa como **especificación ejecutable** de `DefaultLauncher`. No aporta funcionalidad productiva, pero es crítica para asegurar que el Launcher cumpla con el contrato de JUnit Platform: descubrimiento determinista, ejecución aislada por engine, manejo robusto de errores, soporte para filtros, listeners, cancelación y diagnóstico vía `DiscoveryIssue`. Su alta cobertura garantiza que cualquier regresión en el núcleo del Launcher sea detectada inmediatamente.
