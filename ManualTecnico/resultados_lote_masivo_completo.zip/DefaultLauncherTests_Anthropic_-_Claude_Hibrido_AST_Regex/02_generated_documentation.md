# Documentación Técnica — `org.junit.platform.launcher.core.DefaultLauncherTests`

> **Nota sobre `@author`:** el código fuente provisto **no declara** la etiqueta `@author`; únicamente declara `@since 1.0` a nivel de tipo (clase anotada con `@NullMarked`). Esta documentación respeta ese hecho y no atribuye autoría inexistente.

---

## 1. Resumen ejecutivo

`DefaultLauncherTests` es la suite de pruebas unitarias/integración del `Launcher` por defecto del JUnit Platform (`org.junit.platform.launcher.core`). Verifica el ciclo completo de *discovery* y *execution*: construcción del launcher con cero/múltiples motores, propagación y traducción de fallos de motores (`TestEngine`) a eventos de ejecución, aplicación de `PostDiscoveryFilter`, notificación de `LauncherDiscoveryListener` y `TestExecutionListener`, gestión de `DiscoveryIssue` (severidad crítica, fase de fallo, logging), modo *dry-run*, IDs reservados (`junit-`) y cancelación vía `CancellationToken`.

La clase se apoya intensivamente en dobles de prueba del propio platform (`TestEngineStub`, `TestEngineSpy`, `TestDescriptorStub`, `PostDiscoveryFilterStub`, `DemoHierarchicalTestEngine`, `FaultyTestEngines`) y en Mockito/AssertJ. Incluye un *helper* estático reutilizable `execute(...)` que centraliza el flujo `discover → execute → verificación ordenada de eventos`, devolviendo un `record ReportedData` con el `TestPlan`, el `TestIdentifier` raíz, el `TestExecutionResult` y las marcas temporales de inicio/fin.

---

## 2. Especificación de métodos y constructores

### 2.0 Miembros de tipo (campos y constructor implícito)

| Miembro | Tipo | Modificadores | Descripción |
|---|---|---|---|
| `FOO` | `String` | `static final` | Clave de propiedad de sistema (`"DefaultLauncherTests.foo"`) usada por `@SetSystemProperty`. |
| `BAR` | `String` | `static final` | Valor esperado (`"DefaultLauncherTests.bar"`) de la propiedad `FOO`. |
| `noOp` | `Runnable` | `private static final` | Lambda vacía (`run()` sin cuerpo) usada como ejecutable de tests sintéticos en `DemoHierarchicalTestEngine`. |

#### `DefaultLauncherTests()` — constructor implícito por defecto

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return:** instancia de `DefaultLauncherTests`. No está declarado explícitamente en el código; el compilador genera el constructor por defecto *package-private*, invocado por el motor JUnit Jupiter una vez por método de prueba (ciclo de vida `PER_METHOD`).
- **@throws:** ninguna declarada.

---

### 2.1 Pruebas de construcción del launcher

#### `constructLauncherWithoutAnyEngines()`

Verifica que un `Launcher` creado sin motores viola la precondición al invocar `discover(...)`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si el mensaje de la violación de precondición no contiene `"Cannot create Launcher without at least one TestEngine"`.

#### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`

Comprueba que dos `DemoHierarchicalTestEngine` con el mismo ID (`"dummy id"`) provocan `JUnitException` durante el *discovery*.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si no se lanza `JUnitException` o si el mensaje no contiene `"multiple engines with the same ID"`.

#### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`

Valida que un motor sin tests produce un `TestPlan` con exactamente una raíz (el descriptor de motor).

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si `testPlan.getRoots()` no tiene tamaño 1.

---

### 2.2 Pruebas de fallos en la fase de *discovery*

#### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`

Verifica que un motor que devuelve `null` como descriptor raíz se traduce en un `EngineDiscoveryResult.Status.FAILED` notificado al `LauncherDiscoveryListener`, manteniendo una raíz en el `TestPlan`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si el `TestPlan` no contiene una raíz o si la verificación delegada en `assertDiscoveryFailed()` falla.

**Método interno (clase anónima `TestEngineStub("some-engine-id")`):**

##### `discover(EngineDiscoveryRequest, UniqueId)` — anónimo en `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `discoveryRequest` | `EngineDiscoveryRequest` | Sí (ignorado) |
| 2 | `uniqueId` | `UniqueId` | Sí (ignorado) |

- **@return** `TestDescriptor` — siempre `null` (anotado con `@SuppressWarnings("DataFlowIssue")`), simulando un motor defectuoso.
- **@throws** ninguna.

---

#### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable>)`

`@ParameterizedTest` con `@ValueSource(classes = { Error.class, RuntimeException.class })`. Comprueba que una excepción (chequeada o no) lanzada en `discover()` produce: (a) una raíz con el display name del ID del motor, (b) eventos ordenados `launcherDiscoveryStarted → engineDiscoveryStarted → engineDiscoveryFinished(FAILED) → launcherDiscoveryFinished`, y (c) en ejecución, un `TestExecutionResult` con mensaje `"TestEngine with ID 'my-engine-id' failed to discover tests"`.

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `throwableClass` | `Class<? extends Throwable>` | Sí (inyectado por `@ValueSource`) |

- **@return** `void`
- **@throws AssertionError** si el orden de notificaciones, el display name o el mensaje del fallo no coinciden.

**Método interno (clase anónima `TestEngineStub("my-engine-id")`):**

##### `discover(EngineDiscoveryRequest, UniqueId)` — anónimo en `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(...)`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `discoveryRequest` | `EngineDiscoveryRequest` | Sí (ignorado) |
| 2 | `uniqueId` | `UniqueId` | Sí (ignorado) |

- **@return** `TestDescriptor` — `null` solo si la reflexión para instanciar `throwableClass` falla (bloque `catch (Exception ignored)`).
- **@throws Throwable** (relanzado como *unchecked* mediante `ExceptionUtils.throwAsUncheckedException`) — instancia de `throwableClass` construida con el constructor `(String)` y mensaje `"ignored"`.

---

#### `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)`

Helper privado de aserción: verifica en orden `engineDiscoveryStarted(UniqueId.forEngine(id))` y `engineDiscoveryFinished(...)`, capturando el `EngineDiscoveryResult` y comprobando estado `FAILED`, presencia de *throwable* y su mensaje.

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `testEngine` | `TestEngine` | Sí — fuente del ID esperado |
| 2 | `inOrder` | `InOrder` | Sí — verificador ordenado de Mockito |
| 3 | `discoveryListener` | `LauncherDiscoveryListener` | Sí — mock a verificar |

- **@return** `void`
- **@throws AssertionError** si el estado no es `FAILED`, no hay *throwable*, o el mensaje difiere de `"TestEngine with ID '<id>' failed to discover tests"`.
- **@throws org.mockito.exceptions.base.MockitoAssertionError** si las interacciones esperadas no ocurrieron en el orden indicado.

---

### 2.3 Pruebas de fallos y eventos en la fase de ejecución

Todas comparten la firma sin parámetros, retorno `void` y `@throws AssertionError` ante incumplimiento de las verificaciones de Mockito/AssertJ.

| Método de prueba | Escenario del motor anónimo | Aserción principal |
|---|---|---|
| `reportsEngineExecutionFailuresWithoutPriorEvents()` | `execute()` lanza `rootCause` sin emitir eventos | `executionFinished` con mensaje `"TestEngine with ID 'TestEngineStub' failed to execute tests"` y causa `rootCause` |
| `reportsEngineExecutionFailuresForSkippedEngine()` | `executionSkipped(engineDescriptor, "not today")` y luego lanza `rootCause` | Igual que el anterior; el *skip* no suprime el fallo |
| `reportsEngineExecutionFailuresForStartedEngine()` | `executionStarted(engineDescriptor)` y luego lanza `rootCause` | Igual que el anterior |
| `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` | `executionStarted` + `executionFinished(successful())` y luego lanza `rootCause` | Igual que el anterior |
| `reportsEngineExecutionFailuresForFailedFinishedEngine()` | `executionStarted` + `executionFinished(failed(originalFailure))` y luego lanza `rootCause` | Fallo con `hasSuppressedException(originalFailure)` y causa `rootCause` |
| `reportsSkippedEngines()` | Solo `executionSkipped(engineDescriptor, "not today")` | `executionSkipped(TestIdentifier, "not today")`; cero `executionStarted`/`executionFinished` |
| `reportsFinishedEngines()` | `executionStarted` + `executionFinished(successful())` | `executionStarted(any())` y `executionFinished(any(), successful())` |

**Métodos internos (clases anónimas `TestEngineStub`) de los siete casos anteriores:**

##### `execute(ExecutionRequest)` — anónimo (7 implementaciones)

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `request` | `ExecutionRequest` | Sí — provee `getRootTestDescriptor()` y `getEngineExecutionListener()` |

- **@return** `void`
- **@throws RuntimeException** (`rootCause`) en las cinco variantes `reportsEngineExecutionFailures*`; ninguna en `reportsSkippedEngines()` y `reportsFinishedEngines()`.

---

### 2.4 Pruebas de *discovery* y filtrado del `TestPlan`

#### `discoverTestPlanForSingleEngine()`

Un `DemoHierarchicalTestEngine("myEngine")` con dos tests produce una raíz con dos hijos, accesibles tanto por `UniqueId` del identificador raíz como por `UniqueId.parse("[engine:myEngine]")`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si los tamaños de raíces/hijos no son 1 y 2 respectivamente.

#### `discoverTestPlanForMultipleEngines()`

Dos motores con selección por `selectUniqueId(...)` generan dos raíces, cada una con un hijo.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si no hay 2 raíces o si cada motor no expone exactamente 1 hijo.

#### `launcherAppliesPostDiscoveryFilters()`

Aplica dos `PostDiscoveryFilterStub` (inclusión por contenido `"test"` y `"1"` en el `UniqueId`) y verifica que solo sobrevive `test1`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si el motor no queda con un único hijo o si `getTestIdentifier(test1.getUniqueId())` es `null`.

**Lambdas internas:**

| Lambda | Firma funcional | @param | @return |
|---|---|---|---|
| Predicado de `includeWithUniqueIdContainsTest` | `Function<TestDescriptor, FilterResult>` | `descriptor` : `TestDescriptor` | `FilterResult.includedIf(uniqueId.contains("test"))` |
| Descripción de `includeWithUniqueIdContainsTest` | `Supplier<String>` | — | `"filter1"` |
| Predicado de `includeWithUniqueIdContains1` | `Function<TestDescriptor, FilterResult>` | `descriptor` : `TestDescriptor` | `FilterResult.includedIf(uniqueId.contains("1"))` |
| Descripción de `includeWithUniqueIdContains1` | `Supplier<String>` | — | `"filter2"` |

#### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`

Un filtro que solo incluye contenedores deja el contenedor sin hijos y, tras el *pruning*, el motor queda sin hijos visibles.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si existe más de una raíz o si `getChildren(engineIdentifier)` no está vacío.

**Métodos internos:**

##### `discover(EngineDiscoveryRequest, UniqueId)` — anónimo `TestEngineSpy` en `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `discoveryRequest` | `EngineDiscoveryRequest` | Sí — delegado a `super.discover(...)` |
| 2 | `uniqueId` | `UniqueId` | Sí — raíz de la jerarquía construida |

- **@return** `TestDescriptor` — `TestDescriptorStub` raíz con un contenedor `[container:a]` que contiene un test `[test:b]`.
- **@throws** ninguna.

##### `getType()` — anónimo `TestDescriptorStub` (contenedor) en `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `TestDescriptor.Type` — `Type.CONTAINER`.
- **@throws** ninguna.

##### Lambda del filtro

| Lambda | Firma | @param | @return |
|---|---|---|---|
| `(PostDiscoveryFilter) testDescriptor -> ...` | `PostDiscoveryFilter#apply` | `testDescriptor` : `TestDescriptor` | `FilterResult.includedIf(testDescriptor.isContainer())` |

---

### 2.5 Pruebas de parámetros de configuración y listeners

#### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si `configurationParameters.get("key")` está presente.
- **@throws NullPointerException** (vía `requireNonNull`) si `TestEngineSpy.requestForExecution` es `null`, es decir, si el motor no fue ejecutado.

#### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si `"key"` no está presente o su valor no es `"value"`.
- **@throws NullPointerException** si `requestForExecution` es `null`.

#### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`

Anotado con `@SetSystemProperty(key = FOO, value = BAR)`; verifica el *fallback* a propiedades de sistema.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** con mensajes `"foo should have been picked up via system property"` / `"foo property"` si el *lookup* falla.
- **@throws NullPointerException** si `requestForExecution` es `null`.

#### `withAdditionalListener()`

Registra un `SummaryGeneratingListener` en la petición de ejecución y valida el resumen (1 contenedor, 1 test) del `TestEngineSpy`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si el resumen es `null` o los contadores no son 1.

---

### 2.6 Pruebas de tests dinámicos, ejecución única e IDs reservados

#### `reportsDynamicTestDescriptorsCorrectly()`

Valida la jerarquía padre/hijo en el `TestPlan` y el orden exacto de eventos para un descriptor `CONTAINER_AND_TEST` que registra un test dinámico.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si los `parentIdObject` no coinciden o si la secuencia `testPlanExecutionStarted → executionStarted(engine) → executionStarted(c&t) → dynamicTestRegistered → executionStarted(dynamic) → executionFinished(dynamic) → executionFinished(c&t) → executionFinished(engine) → testPlanExecutionFinished` no se cumple.

**Métodos internos (clase anónima `TestEngineSpy("engine")`):**

##### `discover(EngineDiscoveryRequest, UniqueId)` — anónimo en `reportsDynamicTestDescriptorsCorrectly()`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `discoveryRequest` | `EngineDiscoveryRequest` | Sí |
| 2 | `uniqueId` | `UniqueId` | Sí |

- **@return** `TestDescriptor` — raíz `TestDescriptorStub` con un hijo `containerAndTestId`.
- **@throws** ninguna.

##### `getType()` — anónimo `TestDescriptorStub(containerAndTestId, "c&t")`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `TestDescriptor.Type` — `Type.CONTAINER_AND_TEST`.
- **@throws** ninguna.

##### `execute(ExecutionRequest)` — anónimo en `reportsDynamicTestDescriptorsCorrectly()`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `request` | `ExecutionRequest` | Sí |

- **@return** `void` — emite `executionStarted`, `dynamicTestRegistered`, y los correspondientes `executionFinished(successful())` en cascada tras delegar en `super.execute(request)`.
- **@throws** ninguna.

#### `launcherCanExecuteTestPlanExactlyOnce()`

Verifica que `discover` y `execute` se invocan una sola vez sobre el motor mockeado y que reejecutar el mismo `LauncherExecutionRequest` viola la precondición `"TestPlan must only be executed once"`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si los conteos de invocación o el mensaje de precondición no coinciden.

**Lambda interna:**

| Lambda | Firma | @param | @return |
|---|---|---|---|
| `invocation -> { ... }` en `when(engine.discover(any(), any())).thenAnswer(...)` | `org.mockito.stubbing.Answer<Object>` | `invocation` : `InvocationOnMock` | `new EngineDescriptor(uniqueId, uniqueId.toString())` con `uniqueId = invocation.getArgument(1)` |

#### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`

Un motor de terceros con ID `"junit-using-reserved-prefix"` provoca `DiscoveryIssueException` durante el *discovery*.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si no se lanza `DiscoveryIssueException` o si el mensaje no contiene el aviso `[WARNING] Third-party TestEngine implementations are forbidden to use the reserved 'junit-' prefix for their ID`.

#### `thirdPartyEngineClaimingToBeJupiterResultsInException()`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void` — delega en `assertImposter("junit-jupiter")`.
- **@throws AssertionError** propagada desde `assertImposter(String)`.

#### `thirdPartyEngineClaimingToBeVintageResultsInException()`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void` — delega en `assertImposter("junit-vintage")`.
- **@throws AssertionError** propagada desde `assertImposter(String)`.

#### `assertImposter(String)`

Helper privado: crea un `TestEngineStub` con el ID reservado indicado y verifica que `discover(...)` lanza `JUnitException` con el mensaje formateado `"Third-party TestEngine '%s' is forbidden to use the reserved '%s' TestEngine ID."`.

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `id` | `String` | Sí — ID reservado a suplantar (`junit-jupiter`, `junit-vintage`) |

- **@return** `void`
- **@throws AssertionError** si no se lanza `JUnitException` o el mensaje no coincide exactamente.

---

### 2.7 Pruebas de *dry-run*, listeners de *discovery* y cancelación

#### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`

Con `DRY_RUN_PROPERTY_NAME = "true"`, verifica que los contenedores se inician/finalizan y los tests se reportan como *skipped* con el motivo `"JUnit Platform dry-run mode is enabled"`, sin ejecutar el cuerpo del test (que lanzaría `RuntimeException("boom")`).

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si la secuencia de eventos no coincide o si existen interacciones adicionales (`verifyNoMoreInteractions`).

**Lambda interna:**

| Lambda | Firma | @param | @return / @throws |
|---|---|---|---|
| `(__, ___) -> { throw new RuntimeException("boom"); }` | Ejecutable de `DemoHierarchicalTestDescriptor` | `__`, `___` (ignorados) | **@throws RuntimeException** `"boom"` — nunca debe invocarse en modo *dry-run* |

#### `notifiesDiscoveryListenersOfProcessedSelectors()`

Comprueba que un `selectorProcessed(...)` emitido por el motor llega a los tres canales de registro de listeners: `LauncherConfig`, `Launcher#registerLauncherDiscoveryListeners` y la propia `LauncherDiscoveryRequest`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** (agregada por `assertAll`) si alguno de los tres listeners no recibió `selectorProcessed(engineId, selector, unresolved())`.

**Métodos internos:**

##### `discover(EngineDiscoveryRequest, UniqueId)` — anónimo `TestEngineStub("some-engine-id")` en `notifiesDiscoveryListenersOfProcessedSelectors()`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `discoveryRequest` | `EngineDiscoveryRequest` | Sí — fuente de selectores y del `DiscoveryListener` |
| 2 | `uniqueId` | `UniqueId` | Sí |

- **@return** `TestDescriptor` — `EngineDescriptor(uniqueId, uniqueId.getLastSegment().getValue())`.
- **@throws** ninguna.

| Lambda interna | Firma | @param | @return |
|---|---|---|---|
| `selector -> discoveryRequest.getDiscoveryListener().selectorProcessed(...)` | `Consumer<DiscoverySelector>` | `selector` : `DiscoverySelector` | `void` |

#### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`

Con un `CancellationToken` ya cancelado, verifica que `TestEngine#execute` **nunca** se invoca y que el launcher reporta: inicio del motor, *skip* del contenedor con razón `"Execution cancelled"`, finalización del motor con estado `ABORTED` y cierre del `TestPlan`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si `execute` fue invocado, si la secuencia de eventos difiere o si hay interacciones adicionales.

**Método interno:**

##### `discover(EngineDiscoveryRequest, UniqueId)` — anónimo `TestEngineStub("engine-id")` (envuelto en `spy(...)`)

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `discoveryRequest` | `EngineDiscoveryRequest` | Sí (ignorado) |
| 2 | `uniqueId` | `UniqueId` | Sí |

- **@return** `TestDescriptor` — `EngineDescriptor("Engine")` con un `[container:1]` que contiene `[test:1]`.
- **@throws** ninguna.

**Lambdas de `argThat(...)`:**

| Lambda | Firma | @param | @return |
|---|---|---|---|
| `d -> d.getUniqueIdObject().equals(UniqueId.forEngine("engine-id"))` (×2) | `ArgumentMatcher<TestIdentifier>` | `d` : `TestIdentifier` | `boolean` |
| `d -> d.getUniqueIdObject().getLastSegment().getType().equals("container")` | `ArgumentMatcher<TestIdentifier>` | `d` : `TestIdentifier` | `boolean` |
| `result -> result.getStatus() == ABORTED` | `ArgumentMatcher<TestExecutionResult>` | `result` : `TestExecutionResult` | `boolean` |

---

### 2.8 Pruebas de `DiscoveryIssue` (severidad, fase y logging)

#### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener)`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí — inyectado por la extensión de *fixtures* |

- **@return** `void`
- **@throws AssertionError** si el resultado no es `FAILED` con `DiscoveryIssueException` que contenga `"(1) [ERROR] error"`, si el log `WARNING` no contiene `"(1) [WARNING] warning"`, si el display name no es `"Engine"`, si los tags no son exactamente `custom-tag`, o si el instante del log no está entre `startTime()` y `finishTime()`.
- **@throws java.util.NoSuchElementException** desde `orElseThrow()` si no hay *throwable* o no existe el `LogRecord` buscado.

**Métodos internos:**

##### `discover(EngineDiscoveryRequest, UniqueId)` — anónimo `TestEngineStub("engine-id")`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `discoveryRequest` | `EngineDiscoveryRequest` | Sí |
| 2 | `uniqueId` | `UniqueId` | Sí |

- **@return** `TestDescriptor` — `EngineDescriptor` anónimo; emite previamente un `DiscoveryIssue` `ERROR` y otro `WARNING`.
- **@throws** ninguna.

##### `getTags()` — anónimo `EngineDescriptor`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `Set<TestTag>` — `Set.of(TestTag.create("custom-tag"))`.
- **@throws** ninguna.

---

#### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener)`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí |

- **@return** `void`
- **@throws AssertionError** si el estado no es `SUCCESSFUL` o si el log `INFO` no contiene `"(1) [INFO] info"` dentro de la ventana temporal.

**Métodos internos (anónimo `TestEngineStub("engine-id")`):**

| Método | @param | @return | @throws |
|---|---|---|---|
| `discover(EngineDiscoveryRequest, UniqueId)` | `discoveryRequest` : `EngineDiscoveryRequest`; `uniqueId` : `UniqueId` | `EngineDescriptor(uniqueId, "Engine")` tras emitir `DiscoveryIssue` `INFO` | — |
| `execute(ExecutionRequest)` | `request` : `ExecutionRequest` | `void` — `executionStarted` + `executionFinished(successful())` | — |

---

#### `logsAllIssuesForDiscoveryFailure(LogRecordListener)`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí |

- **@return** `void`
- **@throws AssertionError** si el display name no es `"engine-id"`, si el fallo no es `"TestEngine with ID 'engine-id' failed to discover tests"` con causa `"boom"`, o si no se registran ambos logs (`SEVERE` crítico e `INFO` no crítico).

**Método interno:**

##### `discover(EngineDiscoveryRequest, UniqueId)` — anónimo en `logsAllIssuesForDiscoveryFailure(...)`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `discoveryRequest` | `EngineDiscoveryRequest` | Sí |
| 2 | `uniqueId` | `UniqueId` | Sí |

- **@return** `TestDescriptor` — inalcanzable.
- **@throws RuntimeException** `"boom"`, tras emitir issues `ERROR` e `INFO`.

---

#### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener)`

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí |

- **@return** `void`
- **@throws AssertionError** si el fallo no es `"TestEngine with ID 'engine-id' failed to execute tests"` con causa `"boom"`, o si el log `INFO` no se emite en la ventana temporal.

**Métodos internos (anónimo `TestEngineStub("engine-id")`):**

| Método | @param | @return | @throws |
|---|---|---|---|
| `discover(EngineDiscoveryRequest, UniqueId)` | `discoveryRequest`, `uniqueId` | `EngineDescriptor(uniqueId, "Engine")` tras issue `INFO` | — |
| `execute(ExecutionRequest)` | `request` : `ExecutionRequest` (ignorado) | — | **@throws RuntimeException** `"boom"` |

---

#### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`

Usa `createEngineThatCannotResolveAnything("some-engine")` y un `selectUniqueId(UniqueId.forEngine("some-engine"))`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si el estado no es `FAILED` con `DiscoveryIssueException` que contenga `"(1) [ERROR] <selector> could not be resolved"`.

#### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si el estado no es `SUCCESSFUL` (el selector dirigido a otro motor debe ignorarse).

#### `reportsEngineExecutionFailureForSelectorResolutionFailure()`

Usa `createEngineThatFailsToResolveAnything("some-engine", new RuntimeException("boom"))` con `selectClass(Object.class)`.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si el estado no es `FAILED` o si el mensaje no contiene `"<selector> resolution failed"` y `"Cause: java.lang.RuntimeException: boom"`.

#### `allowsConfiguringCriticalDiscoveryIssueSeverity()`

Configura `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME = "info"` para elevar un issue `INFO` a crítico.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si el estado no es `FAILED` con `DiscoveryIssueException` que contenga `"(1) [INFO] info"`.

**Método interno:** `discover(EngineDiscoveryRequest, UniqueId)` del `TestEngineStub("engine-id")` anónimo — **@param** `discoveryRequest`, `uniqueId`; **@return** `EngineDescriptor(uniqueId, "Engine")` tras emitir issue `INFO`; sin excepciones.

#### `failsIfCriticalSeverityIsConfiguredIncorrectly()`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si no se lanza `JUnitException` con *root cause* `"Invalid DiscoveryIssue.Severity 'wrong' set via the '<prop>' configuration parameter."`.

**Métodos internos (anónimo `TestEngineStub("engine-id")`):** `discover(EngineDiscoveryRequest, UniqueId)` (emite issue `INFO`, devuelve `EngineDescriptor`) y `execute(ExecutionRequest)` (emite `executionStarted` + `executionFinished(successful())`, retorno `void`).

#### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`

Con `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME = "discovery"`, el fallo debe surgir en la fase de *discovery*.

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si no se lanza `DiscoveryIssueException` con mensaje `"TestEngine with ID 'engine-id' encountered a critical issue during test discovery"` y `"(1) [ERROR] error"`.

**Método interno:** `discover(EngineDiscoveryRequest, UniqueId)` — emite issue `ERROR` y devuelve `EngineDescriptor(uniqueId, "Engine")`.

#### `logsNonCriticalIssuesOnlyOnce(String, LogRecordListener)`

`@ParameterizedTest` con `@ValueSource(strings = { "discovery", "execution" })`. Garantiza idempotencia del logging: un único `LogRecord` de nivel `WARNING` emitido por `DiscoveryIssueNotifier`.

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `phase` | `String` | Sí — valor del parámetro `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME` |
| 2 | `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí |

- **@return** `void`
- **@throws AssertionError** si el número de registros `WARNING` no es exactamente 1.

**Métodos internos (anónimo `TestEngineStub("engine-id")`):** `discover(EngineDiscoveryRequest, UniqueId)` (issue `WARNING` + `EngineDescriptor`) y `execute(ExecutionRequest)` (`executionStarted` + `executionFinished(successful())`).

#### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

- **@return** `void`
- **@throws AssertionError** si no se lanza `JUnitException` con *root cause* `"Invalid LauncherPhase 'wrong' set via the '<prop>' configuration parameter."`.

---

### 2.9 Helpers estáticos y tipo anidado

#### `execute(TestEngine)` — sobrecarga 1/3

Atajo que ejecuta el flujo estándar sin personalizar la petición de *discovery*.

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `engine` | `TestEngine` | Sí |

- **@return** `ReportedData` — datos capturados del ciclo `discover`/`execute`.
- **@throws AssertionError / MockitoAssertionError** propagadas desde la sobrecarga de tres argumentos.
- **@throws NullPointerException** si no se capturaron marcas temporales.

#### `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)` — sobrecarga 2/3

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `engine` | `TestEngine` | Sí |
| 2 | `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí (puede ser `identity()`) |

- **@return** `ReportedData`
- **@throws** igual que la sobrecarga 3/3 (delegación directa con `identity()` como configurador de ejecución).

#### `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)` — sobrecarga 3/3

Núcleo del *fixture*: crea un `TestExecutionListener` mockeado que registra `startTime`/`finishTime` vía `doAnswer`, construye la petición de *discovery* con `enableImplicitConfigurationParameters(false)`, `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME = "execution"` y `DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME = "logging"`, ejecuta el plan y verifica en orden `testPlanExecutionStarted → executionStarted → executionFinished → testPlanExecutionFinished` sin interacciones adicionales.

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `engine` | `TestEngine` | Sí — motor bajo prueba |
| 2 | `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí — personaliza selectores/parámetros |
| 3 | `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí — añade listeners/`CancellationToken` |

- **@return** `ReportedData` con `testPlan`, `testIdentifier` raíz capturado, `testExecutionResult`, `startTime` y `finishTime`.
- **@throws AssertionError / MockitoAssertionError** si la secuencia de eventos esperada no se cumple o hay interacciones extra.
- **@throws NullPointerException** si `startTime.get()` o `finishTime.get()` son `null` (`requireNonNull`).
- **@throws JUnitException / DiscoveryIssueException** propagadas desde `launcher.discover(...)` o `launcher.execute(...)` según la configuración aplicada.

**Lambdas internas:**

| Lambda | Firma | @param | @return |
|---|---|---|---|
| `invocation -> { startTime.set(Instant.now()); return null; }` | `Answer<Object>` | `invocation` : `InvocationOnMock` | `null` |
| `invocation -> { finishTime.set(Instant.now()); return null; }` | `Answer<Object>` | `invocation` : `InvocationOnMock` | `null` |

#### `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)`

Obtiene el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con el nivel indicado.

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `listener` | `LogRecordListener` | Sí |
| 2 | `level` | `java.util.logging.Level` | Sí |

- **@return** `LogRecord` — primer registro coincidente.
- **@throws java.util.NoSuchElementException** (`orElseThrow()`) si no existe ningún registro para ese nivel.

#### `record ReportedData`

Tipo anidado `private record` que agrupa los datos observados de un ciclo de ejecución.

##### `ReportedData(TestPlan, TestIdentifier, TestExecutionResult, Instant, Instant)` — constructor canónico

| @param | Nombre | Tipo | Requerido |
|---|---|---|---|
| 1 | `testPlan` | `TestPlan` | Sí |
| 2 | `testIdentifier` | `TestIdentifier` | Sí |
| 3 | `testExecutionResult` | `TestExecutionResult` | Sí |
| 4 | `startTime` | `Instant` | Sí |
| 5 | `finishTime` | `Instant` | Sí |

- **@return** instancia inmutable de `ReportedData`.
- **@throws** ninguna.

##### Accesores generados

| Método | @param | @return |
|---|---|---|
| `testPlan()` | — | `TestPlan` descubierto |
| `testIdentifier()` | — | `TestIdentifier` raíz capturado en `executionStarted` |
| `testExecutionResult()` | — | `TestExecutionResult` capturado en `executionFinished` |
| `startTime()` | — | `Instant` del primer `executionStarted` |
| `finishTime()` | — | `Instant` del primer `executionFinished` |

Adicionalmente, el compilador genera `equals(Object)`, `hashCode()` y `toString()` con semántica de valor sobre los cinco componentes.

---

## 3. Ejemplo de uso

El siguiente caso reproduce el patrón real de la clase: se crea un `TestEngine` que emite un `DiscoveryIssue` crítico, se descubre el plan y se ejecuta, verificando que el fallo se reporta como resultado de ejecución del motor y que el issue no crítico se registra en el log.

```java
package org.junit.platform.launcher.core;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.platform.engine.TestExecutionResult.Status;
import static org.junit.platform.launcher.LauncherConstants.DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;
import static org.junit.platform.launcher.core.LauncherFactoryForTestingPurposesOnly.createLauncher;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.junit.platform.engine.DiscoveryIssue;
import org.junit.platform.engine.DiscoveryIssue.Severity;
import org.junit.platform.engine.EngineDiscoveryRequest;
import org.junit.platform.engine.TestDescriptor;
import org.junit.platform.engine.TestExecutionResult;
import org.junit.platform.engine.UniqueId;
import org.junit.platform.engine.support.descriptor.EngineDescriptor;
import org.junit.platform.fakes.TestEngineStub;
import org.junit.platform.launcher.TestExecutionListener;
import org.mockito.ArgumentCaptor;

class LauncherUsageExample {

    @Test
    void criticalDiscoveryIssueIsReportedAsEngineExecutionFailure() {
        // 1. Motor que emite un DiscoveryIssue de severidad ERROR durante el discovery.
        var engine = new TestEngineStub("demo-engine") {
            @Override
            public TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId) {
                discoveryRequest.getDiscoveryListener() //
                        .issueEncountered(uniqueId, DiscoveryIssue.create(Severity.ERROR, "configuración inválida"));
                return new EngineDescriptor(uniqueId, "Demo Engine");
            }
        };

        // 2. Launcher aislado (sin ServiceLoader) con el motor bajo prueba.
        var launcher = createLauncher(engine);
        TestExecutionListener executionListener = mock(TestExecutionListener.class);

        // 3. Discovery: el fallo se aplaza a la fase de ejecución.
        var discoveryRequest = request() //
                .enableImplicitConfigurationParameters(false) //
                .configurationParameter(DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME, "execution") //
                .configurationParameter(DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME, "logging") //
                .build();
        var testPlan = launcher.discover(discoveryRequest);

        // 4. Ejecución única del TestPlan.
        var executionRequest = LauncherExecutionRequestBuilder.request(testPlan) //
                .listeners(executionListener) //
                .build();
        launcher.execute(executionRequest);

        // 5. Verificación ordenada de eventos y del resultado del motor.
        var resultCaptor = ArgumentCaptor.forClass(TestExecutionResult.class);
        var inOrder = inOrder(executionListener);
        inOrder.verify(executionListener).testPlanExecutionStarted(any());
        inOrder.verify(executionListener).executionStarted(any());
        inOrder.verify(executionListener).executionFinished(any(), resultCaptor.capture());
        inOrder.verify(executionListener).testPlanExecutionFinished(any());
        inOrder.verifyNoMoreInteractions();

        assertThat(resultCaptor.getValue().getStatus()).isEqualTo(Status.FAILED);
        assertThat(resultCaptor.getValue().getThrowable().orElseThrow()) //
                .isInstanceOf(DiscoveryIssueException.class) //
                .hasMessageStartingWith(
                    "TestEngine with ID 'demo-engine' encountered a critical issue during test discovery") //
                .hasMessageContaining("(1) [ERROR] configuración inválida");

        // 6. Un TestPlan solo puede ejecutarse una vez: una segunda llamada viola la precondición.
    }
}
```