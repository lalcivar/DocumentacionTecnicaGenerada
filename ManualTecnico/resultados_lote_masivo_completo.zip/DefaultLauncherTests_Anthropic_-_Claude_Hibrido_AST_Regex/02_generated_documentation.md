# Documentación Técnica — `DefaultLauncherTests`

**Paquete:** `org.junit.platform.launcher.core`
**Modificadores:** `class` (visibilidad de paquete), anotada con `@NullMarked`
**Javadoc de clase presente en el fuente:** `@since 1.0`
**`@author`:** no declarado explícitamente en el código fuente. El encabezado de licencia indica *“the original author or authors”* (JUnit Platform / Eclipse Public License v2.0).

---

## 1. Resumen ejecutivo

`DefaultLauncherTests` es la suite de pruebas unitarias de la implementación interna por defecto del `Launcher` de JUnit Platform (`org.junit.platform.launcher.core`). Verifica el ciclo completo de *discovery* y *execution*: construcción del launcher con cero, uno o múltiples `TestEngine`, propagación y encapsulamiento de fallos de los motores, aplicación de `PostDiscoveryFilter`, poda de descriptores, resolución de parámetros de configuración (incluido el *fallback* a propiedades del sistema), modo *dry-run*, notificación de `LauncherDiscoveryListener`/`TestExecutionListener`, gestión de `DiscoveryIssue` (severidad crítica y fase de fallo) y cancelación mediante `CancellationToken`.

La clase se apoya en motores falsos (`TestEngineStub`, `TestEngineSpy`, `DemoHierarchicalTestEngine`, `FaultyTestEngines`), en dobles de prueba de Mockito y en el *fixture* `@TrackLogRecords` para inspeccionar los `LogRecord` emitidos por `DiscoveryIssueNotifier`. Define además helpers estáticos de orquestación (`execute(...)`) y un *record* interno `ReportedData` que agrega el resultado observado de una ejecución.

---

## 2. Especificación de miembros

### 2.1 Campos declarados

| Campo | Tipo | Modificadores | Descripción |
|---|---|---|---|
| `FOO` | `String` | `static final` | Clave de parámetro de configuración/propiedad de sistema (`"DefaultLauncherTests.foo"`). Usada como constante de compilación en `@SetSystemProperty`. |
| `BAR` | `String` | `static final` | Valor asociado a `FOO` (`"DefaultLauncherTests.bar"`). |
| `noOp` | `Runnable` | `private static final` | Lambda vacía utilizada como cuerpo de los tests registrados en `DemoHierarchicalTestEngine`. |

#### Método funcional implícito: `noOp.run()`

Implementación lambda del método `run()` de `Runnable`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | Descripción |
|---|---|
| `void` | No ejecuta lógica alguna (cuerpo vacío). |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

---

### 2.2 Constructor

#### `DefaultLauncherTests()`

Constructor por defecto implícito generado por el compilador (no declarado en el fuente). JUnit Jupiter lo invoca por reflexión para crear una instancia por método de prueba (ciclo de vida `PER_METHOD`).

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @throws | Condición |
|---|---|
| — | No declara excepciones. |

---

### 2.3 Métodos de prueba (`@Test` / `@ParameterizedTest`)

> Convención aplicada a todos los métodos de prueba: son `void`, de visibilidad de paquete, sin valor de retorno, y pueden finalizar con `AssertionError` cuando una aserción (`assertThat`, `assertEquals`, `assertAll`, `verify`, …) no se satisface. Se detallan adicionalmente las excepciones *esperadas y capturadas* dentro del cuerpo.

---

#### `constructLauncherWithoutAnyEngines()`

Verifica que un `Launcher` creado sin ningún `TestEngine` viola su precondición al invocar `discover(...)`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros |

| @return | Descripción |
|---|---|
| `void` | — |

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se produce la violación de precondición o el mensaje no contiene `"Cannot create Launcher without at least one TestEngine"`. |

---

#### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`

Comprueba que dos `DemoHierarchicalTestEngine` con el mismo ID provocan `JUnitException` durante el *discovery*.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | Descripción |
|---|---|
| `void` | — |

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se lanza `JUnitException` o el mensaje no contiene `"multiple engines with the same ID"`. |

*Excepción capturada internamente:* `JUnitException` (mediante `assertThrows`).

---

#### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`

Verifica que un motor sin pruebas produce un `TestPlan` con exactamente una raíz (el descriptor del motor).

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si `testPlan.getRoots()` no tiene tamaño 1. |

---

#### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`

Comprueba que un motor que devuelve `null` como descriptor raíz se traduce en un fallo de *discovery* reportado al `LauncherDiscoveryListener`, manteniendo una raíz en el `TestPlan`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el plan no contiene una raíz o si `assertDiscoveryFailed(...)` no se cumple. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)` — subclase anónima de `TestEngineStub("some-engine-id")`

Sobrescritura que retorna `null` deliberadamente (anotada `@SuppressWarnings("DataFlowIssue")`).

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Petición de descubrimiento (ignorada). |
| `uniqueId` | `UniqueId` | Sí | ID único del motor (ignorado). |

| @return | Descripción |
|---|---|
| `TestDescriptor` | Siempre `null`, simulando un contrato roto del motor. |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

---

#### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable>)`

Prueba parametrizada (`@ValueSource(classes = { Error.class, RuntimeException.class })`). Verifica que un `Throwable` lanzado en la fase de descubrimiento genera un descriptor de error, se notifica en orden a los listeners de *discovery* y se reporta como fallo de ejecución del motor.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `throwableClass` | `Class<? extends Throwable>` | Sí | Tipo de `Throwable` a instanciar (vía constructor `String`) y lanzar dentro de `discover(...)`. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el nombre del nodo raíz no es `"my-engine-id"`, si el orden de notificaciones difiere, o si el resultado de ejecución no contiene el mensaje `"TestEngine with ID 'my-engine-id' failed to discover tests"`. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)` — subclase anónima de `TestEngineStub("my-engine-id")`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Petición de descubrimiento (ignorada). |
| `uniqueId` | `UniqueId` | Sí | ID único del motor (ignorado). |

| @return | Descripción |
|---|---|
| `TestDescriptor` | `null` únicamente si la reflexión falla (rama `catch (Exception ignored)`). |

| @throws | Condición |
|---|---|
| `Throwable` (del tipo `throwableClass`) | Relanzado sin comprobación mediante `ExceptionUtils.throwAsUncheckedException(...)` tras instanciarlo con el mensaje `"ignored"`. |

---

#### `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)`

Helper privado de aserción: valida que el ciclo `engineDiscoveryStarted` → `engineDiscoveryFinished` se notificó en orden y que el `EngineDiscoveryResult` capturado tiene estado `FAILED` con el mensaje canónico de fallo de descubrimiento.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testEngine` | `TestEngine` | Sí | Motor cuyo ID se usa para construir `UniqueId.forEngine(...)` y el mensaje esperado. |
| `inOrder` | `InOrder` | Sí | Verificador de orden de Mockito previamente creado. |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | Mock del listener sobre el que se verifican las invocaciones. |

| @return | Descripción |
|---|---|
| `void` | — |

| @throws | Condición |
|---|---|
| `AssertionError` | Si el estado no es `EngineDiscoveryResult.Status.FAILED`, si no hay `Throwable` presente o si su mensaje no coincide. |
| `org.mockito.exceptions.base.MockitoAssertionError` | Si las invocaciones no ocurrieron en el orden verificado. |

---

#### `reportsEngineExecutionFailuresWithoutPriorEvents()`

Verifica que una excepción lanzada en `execute(...)` sin eventos previos se reporta como `executionStarted`/`executionFinished` con un fallo envolvente cuya causa es la excepción original.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el mensaje no es `"TestEngine with ID 'TestEngineStub' failed to execute tests"` o la causa no es la instancia `rootCause`. |

##### Método anónimo: `execute(ExecutionRequest)` — subclase anónima de `TestEngineStub`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Petición de ejecución (ignorada). |

| @return | `void` (nunca retorna normalmente) |
|---|---|

| @throws | Condición |
|---|---|
| `RuntimeException` | Siempre; instancia `rootCause` con mensaje `"something went horribly wrong"`. |

---

#### `reportsEngineExecutionFailuresForSkippedEngine()`

Igual al anterior, pero el motor notifica primero `executionSkipped` sobre su descriptor raíz antes de fallar.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se reporta el fallo envolvente con causa `rootCause`. |

##### Método anónimo: `execute(ExecutionRequest)` — subclase anónima de `TestEngineStub`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del `rootTestDescriptor` y del `EngineExecutionListener`. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `RuntimeException` | Siempre, tras invocar `executionSkipped(engineDescriptor, "not today")`. |

---

#### `reportsEngineExecutionFailuresForStartedEngine()`

Verifica el mismo contrato cuando el motor ya había notificado `executionStarted` del descriptor raíz.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se reporta el fallo envolvente con causa `rootCause`. |

##### Método anónimo: `execute(ExecutionRequest)` — subclase anónima de `TestEngineStub`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener de ejecución. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `RuntimeException` | Siempre, tras `executionStarted(engineDescriptor)`. |

---

#### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`

Verifica el contrato cuando el motor había cerrado su descriptor raíz con `successful()` antes de lanzar la excepción.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se reporta el fallo envolvente con causa `rootCause`. |

##### Método anónimo: `execute(ExecutionRequest)` — subclase anónima de `TestEngineStub`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener de ejecución. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `RuntimeException` | Siempre, tras `executionStarted` + `executionFinished(..., successful())`. |

---

#### `reportsEngineExecutionFailuresForFailedFinishedEngine()`

Verifica que, si el motor ya había reportado un fallo (`originalFailure`) y luego lanza `rootCause`, el resultado final envuelve `rootCause` como causa y `originalFailure` como excepción suprimida.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si falta la excepción suprimida `originalFailure` o la causa no es `rootCause`. |

##### Método anónimo: `execute(ExecutionRequest)` — subclase anónima de `TestEngineStub`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener de ejecución. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `RuntimeException` | Siempre (`rootCause`), tras `executionFinished(..., TestExecutionResult.failed(originalFailure))`. |

---

#### `reportsSkippedEngines()`

Comprueba que un motor que omite su propio descriptor raíz genera únicamente `executionSkipped` y ningún `executionStarted`/`executionFinished`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se invoca `executionSkipped(..., "not today")` o si se invocan los métodos de inicio/fin. |

##### Método anónimo: `execute(ExecutionRequest)` — subclase anónima de `TestEngineStub`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

---

#### `reportsFinishedEngines()`

Verifica la propagación correcta de `executionStarted` y `executionFinished(successful())` emitidos por el motor.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si los eventos no llegan al `TestExecutionListener` con resultado `successful()`. |

##### Método anónimo: `execute(ExecutionRequest)` — subclase anónima de `TestEngineStub`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

---

#### `discoverTestPlanForSingleEngine()`

Valida la jerarquía del `TestPlan` para un único motor con dos tests, accediendo a los hijos por `UniqueId` del identificador raíz y por `UniqueId.parse("[engine:myEngine]")`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no hay exactamente 1 raíz o 2 hijos. |

---

#### `discoverTestPlanForMultipleEngines()`

Valida que una petición con `selectUniqueId(...)` para pruebas de dos motores produce dos raíces, cada una con un hijo.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el número de raíces o hijos no coincide. |

---

#### `launcherAppliesPostDiscoveryFilters()`

Verifica que los `PostDiscoveryFilter` registrados en la petición se combinan en conjunción lógica, dejando únicamente `test1` en el plan.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el motor conserva más de un hijo o si `test1` no está presente. |

##### Lambdas internas

| Lambda | Tipo funcional | Entrada | Salida |
|---|---|---|---|
| Predicado de `includeWithUniqueIdContainsTest` | `Function<TestDescriptor, FilterResult>` (argumento de `PostDiscoveryFilterStub`) | `descriptor` (`TestDescriptor`) | `FilterResult.includedIf(uniqueId.contains("test"))` |
| Proveedor de descripción | `Supplier<String>` | — | `"filter1"` |
| Predicado de `includeWithUniqueIdContains1` | `Function<TestDescriptor, FilterResult>` | `descriptor` (`TestDescriptor`) | `FilterResult.includedIf(uniqueId.contains("1"))` |
| Proveedor de descripción | `Supplier<String>` | — | `"filter2"` |

---

#### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`

Comprueba que, sin parámetros de configuración, el `ExecutionRequest` recibido por `TestEngineSpy` no resuelve la clave `"key"`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si `configurationParameters.get("key")` está presente. |
| `NullPointerException` | Si `engine.requestForExecution` es `null` (`requireNonNull`). |

---

#### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`

Comprueba que un parámetro `key=value` definido en la petición de descubrimiento llega al `ExecutionRequest`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si la clave no está presente o su valor no es `"value"`. |
| `NullPointerException` | Si `engine.requestForExecution` es `null`. |

---

#### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`

Anotado con `@SetSystemProperty(key = FOO, value = BAR)`. Verifica el *fallback* de los parámetros de configuración a propiedades del sistema.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si `FOO` no se resuelve (`"foo should have been picked up via system property"`) o su valor difiere de `BAR`. |
| `NullPointerException` | Si `engine.requestForExecution` es `null`. |

---

#### `withAdditionalListener()`

Valida que un `SummaryGeneratingListener` registrado en la petición de ejecución recibe eventos y produce un resumen con 1 contenedor y 1 test.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el resumen es `null` o los contadores no son 1. |

---

#### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`

Verifica la poda de ramas: un filtro que solo incluye contenedores elimina el test hoja y, en consecuencia, el contenedor vacío desaparece del plan.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el plan no tiene 1 raíz o si la raíz conserva hijos. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)` — subclase anónima de `TestEngineSpy`

Construye una jerarquía motor → contenedor → test delegando primero en `super.discover(...)`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Petición delegada a `super.discover(...)`. |
| `uniqueId` | `UniqueId` | Sí | Base para construir los `UniqueId` de contenedor y test. |

| @return | Descripción |
|---|---|
| `TestDescriptor` | `TestDescriptorStub` raíz del motor con un contenedor y un test descendiente. |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

##### Método anónimo: `getType()` — subclase anónima de `TestDescriptorStub` (contenedor `"a"`)

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | Descripción |
|---|---|
| `TestDescriptor.Type` | Siempre `Type.CONTAINER`. |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

##### Lambda interna: filtro de *post-discovery*

| Entrada | Tipo | Salida |
|---|---|---|
| `testDescriptor` | `TestDescriptor` | `FilterResult.includedIf(testDescriptor.isContainer())` |

---

#### `reportsDynamicTestDescriptorsCorrectly()`

Verifica el registro y la jerarquía de tests dinámicos (`dynamicTestRegistered`) sobre un nodo `CONTAINER_AND_TEST`, comprobando el orden exacto de todos los eventos y la relación padre/hijo en el `TestPlan`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si los `parentId` no corresponden o si el orden de eventos difiere del esperado. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)` — subclase anónima de `TestEngineSpy(engineId...)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Delegada a `super.discover(...)`. |
| `uniqueId` | `UniqueId` | Sí | ID del descriptor raíz del motor. |

| @return | Descripción |
|---|---|
| `TestDescriptor` | Raíz con un hijo de tipo `CONTAINER_AND_TEST` identificado por `containerAndTestId`. |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

##### Método anónimo: `getType()` — subclase anónima de `TestDescriptorStub(containerAndTestId, "c&t")`

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | Descripción |
|---|---|
| `TestDescriptor.Type` | Siempre `Type.CONTAINER_AND_TEST`. |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

##### Método anónimo: `execute(ExecutionRequest)` — misma subclase anónima de `TestEngineSpy`

Emite la secuencia completa de eventos, registrando un test dinámico (`dynamicTestId`) como hijo del nodo `CONTAINER_AND_TEST`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Delegada a `super.execute(...)`; fuente del listener y del descriptor raíz. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

---

#### `launcherCanExecuteTestPlanExactlyOnce()`

Verifica que `discover(...)` y `execute(...)` invocan el motor una sola vez y que reejecutar el mismo `LauncherExecutionRequest` viola la precondición `"TestPlan must only be executed once"`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si los conteos de invocación no son 1 o si no se produce la violación de precondición. |

##### Lambda interna: `Answer` de `engine.discover(any(), any())`

| Entrada | Tipo | Salida |
|---|---|---|
| `invocation` | `InvocationOnMock` | `EngineDescriptor` construido con el `UniqueId` del argumento de índice 1. |

---

#### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`

Comprueba que un motor de terceros con prefijo reservado `junit-` provoca `DiscoveryIssueException` con severidad `WARNING`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se lanza `DiscoveryIssueException` o el mensaje no contiene el texto sobre el prefijo reservado. |

---

#### `thirdPartyEngineClaimingToBeJupiterResultsInException()`

Delegación a `assertImposter("junit-jupiter")`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Propagado desde `assertImposter(String)`. |

---

#### `thirdPartyEngineClaimingToBeVintageResultsInException()`

Delegación a `assertImposter("junit-vintage")`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Propagado desde `assertImposter(String)`. |

---

#### `assertImposter(String)`

Helper privado: verifica que un `TestEngineStub` con un ID reservado produce `JUnitException` con el mensaje canónico que incluye el nombre de clase del impostor y el ID.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `id` | `String` | Sí | ID reservado a suplantar (p. ej. `"junit-jupiter"`, `"junit-vintage"`). |

| @return | Descripción |
|---|---|
| `void` | — |

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se lanza `JUnitException` o el mensaje no coincide exactamente con el formato esperado. |

---

#### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`

Verifica que con `DRY_RUN_PROPERTY_NAME=true` se reportan todos los eventos estructurales y los tests se omiten con el motivo `"JUnit Platform dry-run mode is enabled"`, sin ejecutar su cuerpo (que lanzaría `RuntimeException("boom")`).

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el orden de eventos difiere o se producen interacciones adicionales (`verifyNoMoreInteractions`). |

##### Lambda interna: cuerpo ejecutable del `DemoHierarchicalTestDescriptor`

| Entrada | Tipo | Descripción |
|---|---|---|
| `__` | (parámetro ignorado del contrato de ejecución de `DemoHierarchicalTestDescriptor`) | No utilizado. |
| `___` | (segundo parámetro ignorado) | No utilizado. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `RuntimeException` | Siempre (`"boom"`); su no invocación es precisamente lo que valida el test. |

---

#### `notifiesDiscoveryListenersOfProcessedSelectors()`

Verifica que `selectorProcessed` se propaga a los tres canales de registro de listeners: `LauncherConfig`, registro programático en el `Launcher` y petición de descubrimiento.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` (agregado por `assertAll`) | Si alguno de los tres listeners no recibe `selectorProcessed(engineId, selector, unresolved())`. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)` — subclase anónima de `TestEngineStub("some-engine-id")`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente de los selectores y del `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID del motor usado al notificar y al construir el `EngineDescriptor`. |

| @return | Descripción |
|---|---|
| `TestDescriptor` | `EngineDescriptor` con nombre igual al valor del último segmento del `UniqueId`. |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

##### Lambda interna: consumidor de selectores

| Entrada | Tipo | Efecto |
|---|---|---|
| `selector` | `DiscoverySelector` | Invoca `discoveryRequest.getDiscoveryListener().selectorProcessed(uniqueId, selector, unresolved())`. |

---

#### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener)`

Verifica que los `DiscoveryIssue` de severidad `ERROR` se reportan como fallo de ejecución del motor (`DiscoveryIssueException`), mientras que los `WARNING` se registran como `LogRecord` de nivel `WARNING` dentro de la ventana temporal de ejecución.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí (inyectado) | Proporcionado por la extensión `@TrackLogRecords`; captura los registros de log. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el plan no contiene tests, si el nombre/tags del identificador no coinciden, si el estado no es `FAILED`, o si el `LogRecord` no cumple mensaje/instante esperados. |
| `NoSuchElementException` | Si no existe `Throwable` (`orElseThrow`) o no hay `LogRecord` de nivel `WARNING`. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)` — subclase anónima de `TestEngineStub("engine-id")`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `DiscoveryListener` para emitir incidencias. |
| `uniqueId` | `UniqueId` | Sí | ID usado al emitir incidencias y crear el `EngineDescriptor`. |

| @return | Descripción |
|---|---|
| `TestDescriptor` | `EngineDescriptor` anónimo con nombre `"Engine"` tras emitir una incidencia `ERROR` y otra `WARNING`. |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

##### Método anónimo: `getTags()` — subclase anónima de `EngineDescriptor`

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | Descripción |
|---|---|
| `Set<TestTag>` | `Set.of(TestTag.create("custom-tag"))`. |

| @throws | Condición |
|---|---|
| — | No lanza excepciones. |

---

#### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener)`

Verifica que una incidencia `INFO` no impide una ejecución `SUCCESSFUL` y se registra como `LogRecord` de nivel `INFO`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí (inyectado) | Captura de logs vía `@TrackLogRecords`. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el estado no es `SUCCESSFUL` o el log no contiene `"(1) [INFO] info"`. |
| `NoSuchElementException` | Si no existe `LogRecord` de nivel `INFO`. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID del motor. |

| @return | `TestDescriptor` — `EngineDescriptor` con nombre `"Engine"` tras emitir incidencia `INFO`. |
|---|---|

| @throws | — |
|---|---|

##### Método anónimo: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del listener de ejecución y del descriptor raíz. |

| @return | `void` — emite `executionStarted` y `executionFinished(successful())`. |
|---|---|

| @throws | — |
|---|---|

---

#### `logsAllIssuesForDiscoveryFailure(LogRecordListener)`

Verifica que, cuando el motor falla con excepción durante el descubrimiento, todas las incidencias acumuladas se registran: las críticas en `SEVERE` y las no críticas en `INFO`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí (inyectado) | Captura de logs vía `@TrackLogRecords`. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el nombre del identificador no es `"engine-id"`, si el mensaje de fallo o la causa `"boom"` no coinciden, o si faltan los `LogRecord` esperados. |
| `NoSuchElementException` | Si no existe `Throwable` o `LogRecord` en los niveles consultados. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID usado al emitir las incidencias `ERROR` e `INFO`. |

| @return | `TestDescriptor` — nunca retorna normalmente. |
|---|---|

| @throws | Condición |
|---|---|
| `RuntimeException` | Siempre (`"boom"`), después de emitir ambas incidencias. |

---

#### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener)`

Verifica que, ante un fallo de ejecución, las incidencias no críticas de descubrimiento siguen registrándose en nivel `INFO`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí (inyectado) | Captura de logs vía `@TrackLogRecords`. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el mensaje de fallo no es `"TestEngine with ID 'engine-id' failed to execute tests"` con causa `"boom"`, o si falta el log `INFO`. |
| `NoSuchElementException` | Si no existe `Throwable` o `LogRecord` de nivel `INFO`. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID del motor. |

| @return | `TestDescriptor` — `EngineDescriptor` `"Engine"` tras emitir incidencia `INFO`. |
|---|---|

| @throws | — |
|---|---|

##### Método anónimo: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Ignorada. |

| @return | `void` — nunca retorna normalmente. |
|---|---|

| @throws | Condición |
|---|---|
| `RuntimeException` | Siempre (`"boom"`). |

---

#### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`

Verifica que un `UniqueIdSelector` con prefijo del propio motor que no puede resolverse genera una incidencia crítica `ERROR` reportada como fallo de ejecución.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el estado no es `FAILED` o el mensaje no contiene `"(1) [ERROR] <selector> could not be resolved"`. |
| `NoSuchElementException` | Si no hay `Throwable` presente. |

##### Lambda interna: configurador de descubrimiento

| Entrada | Tipo | Salida |
|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | `request.selectors(selector)` |

---

#### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`

Verifica que un `UniqueIdSelector` dirigido a otro motor se ignora silenciosamente (estado `SUCCESSFUL`).

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el estado no es `SUCCESSFUL`. |

##### Lambda interna: configurador de descubrimiento

| Entrada | Tipo | Salida |
|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | `request.selectors(selector)` |

---

#### `reportsEngineExecutionFailureForSelectorResolutionFailure()`

Verifica que un fallo de resolución de selector (motor creado con `createEngineThatFailsToResolveAnything`) se convierte en `DiscoveryIssueException` con la causa original incluida en el mensaje.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el estado no es `FAILED` o faltan los fragmentos `"resolution failed"` / `"Cause: java.lang.RuntimeException: boom"`. |
| `NoSuchElementException` | Si no hay `Throwable` presente. |

##### Lambda interna: configurador de descubrimiento

| Entrada | Tipo | Salida |
|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | `request.selectors(selector)` |

---

#### `allowsConfiguringCriticalDiscoveryIssueSeverity()`

Verifica que `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME=info` eleva las incidencias `INFO` a críticas, provocando un resultado `FAILED`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el estado no es `FAILED` o el mensaje no contiene `"(1) [INFO] info"`. |
| `NoSuchElementException` | Si no hay `Throwable` presente. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)` — `TestEngineStub("engine-id")`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID del motor. |

| @return | `TestDescriptor` — `EngineDescriptor` `"Engine"` tras emitir incidencia `INFO`. |
|---|---|

| @throws | — |
|---|---|

##### Lambda interna: configurador de descubrimiento

| Entrada | Tipo | Salida |
|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | `request.configurationParameter(CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME, "info")` |

---

#### `failsIfCriticalSeverityIsConfiguredIncorrectly()`

Verifica que un valor inválido de severidad crítica produce `JUnitException` con causa raíz descriptiva.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se lanza `JUnitException` o la causa raíz no es `"Invalid DiscoveryIssue.Severity 'wrong' set via the '<prop>' configuration parameter."`. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID del motor. |

| @return | `TestDescriptor` — `EngineDescriptor` `"Engine"` tras emitir incidencia `INFO`. |
|---|---|

| @throws | — |
|---|---|

##### Método anónimo: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del listener y descriptor raíz. |

| @return | `void` — emite inicio y fin exitoso del descriptor raíz. |
|---|---|

| @throws | — |
|---|---|

##### Lambda interna: configurador de descubrimiento

| Entrada | Tipo | Salida |
|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | `request.configurationParameter(CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME, "wrong")` |

---

#### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`

Verifica que con `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery` las incidencias críticas abortan inmediatamente la fase de descubrimiento con `DiscoveryIssueException`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se lanza `DiscoveryIssueException` o el mensaje no contiene `"(1) [ERROR] error"`. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID del motor. |

| @return | `TestDescriptor` — `EngineDescriptor` `"Engine"` tras emitir incidencia `ERROR`. |
|---|---|

| @throws | — |
|---|---|

##### Lambda interna: configurador de descubrimiento

| Entrada | Tipo | Salida |
|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | `request.configurationParameter(DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME, "discovery")` |

---

#### `logsNonCriticalIssuesOnlyOnce(String, LogRecordListener)`

Prueba parametrizada (`@ValueSource(strings = { "discovery", "execution" })`). Garantiza que las incidencias no críticas se registran exactamente una vez, independientemente de la fase de fallo configurada.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `phase` | `String` | Sí | Valor para `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME`: `"discovery"` o `"execution"`. |
| `listener` | `LogRecordListener` | Sí (inyectado) | Captura de logs vía `@TrackLogRecords`. |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el número de `LogRecord` de nivel `WARNING` emitidos por `DiscoveryIssueNotifier` no es exactamente 1. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `DiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID del motor. |

| @return | `TestDescriptor` — `EngineDescriptor` `"Engine"` tras emitir incidencia `WARNING`. |
|---|---|

| @throws | — |
|---|---|

##### Método anónimo: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del listener y descriptor raíz. |

| @return | `void` — emite inicio y fin exitoso. |
|---|---|

| @throws | — |
|---|---|

##### Lambda interna: configurador de descubrimiento

| Entrada | Tipo | Salida |
|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | `request.configurationParameter(DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME, phase)` |

---

#### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`

Verifica que un valor inválido de la fase de fallo produce `JUnitException` con causa raíz `"Invalid LauncherPhase 'wrong' …"`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si no se lanza `JUnitException` o la causa raíz no coincide. |

##### Lambda interna: configurador de descubrimiento

| Entrada | Tipo | Salida |
|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | `request.configurationParameter(DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME, "wrong")` |

---

#### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`

Verifica que, con un `CancellationToken` ya cancelado, el motor **no** se ejecuta (`verify(engine, never()).execute(any())`), el descriptor del motor se inicia y finaliza con estado `ABORTED`, y sus hijos se reportan como omitidos con el motivo `"Execution cancelled"`.

| @param | Tipo | Requerido |
|---|---|---|
| — | — | — |

| @return | `void` |
|---|---|

| @throws | Condición |
|---|---|
| `AssertionError` | Si el motor se ejecuta, si el orden de eventos difiere o si hay interacciones adicionales. |

##### Método anónimo: `discover(EngineDiscoveryRequest, UniqueId)` — subclase anónima de `TestEngineStub("engine-id")` (envuelta en `spy(...)`)

Construye la jerarquía motor → contenedor → test mediante `TestDescriptorStub`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | No utilizada. |
| `uniqueId` | `UniqueId` | Sí | Base de los `UniqueId` del `EngineDescriptor`, contenedor y test. |

| @return | `TestDescriptor` — `EngineDescriptor` `"Engine"` con un contenedor que contiene un test. |
|---|---|

| @throws | — |
|---|---|

##### Lambdas internas de verificación (`argThat`)

| Lambda | Entrada | Predicado |
|---|---|---|
| Matcher de identificador de motor | `TestIdentifier d` | `d.getUniqueIdObject().equals(UniqueId.forEngine("engine-id"))` |
| Matcher de contenedor omitido | `TestIdentifier d` | último segmento de tipo `"container"` |
| Matcher de resultado abortado | `TestExecutionResult result` | `result.getStatus() == ABORTED` |

---

### 2.4 Métodos helper estáticos

#### `execute(TestEngine)`

Sobrecarga de conveniencia: ejecuta el motor con configuradores identidad para descubrimiento y ejecución.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Motor bajo prueba. |

| @return | Descripción |
|---|---|
| `ReportedData` | Datos observados: `TestPlan`, `TestIdentifier` raíz, `TestExecutionResult` y marcas temporales de inicio/fin. |

| @throws | Condición |
|---|---|
| `AssertionError` / `MockitoAssertionError` | Propagados desde la sobrecarga de tres argumentos. |
| `NullPointerException` | Si no se registraron las marcas de tiempo. |
| `RuntimeException` / `JUnitException` / `DiscoveryIssueException` | Propagados desde `launcher.discover(...)` o `launcher.execute(...)`. |

---

#### `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)`

Sobrecarga que permite personalizar la petición de descubrimiento, dejando la de ejecución sin cambios.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Motor bajo prueba. |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Transformación aplicada al builder de descubrimiento (selectores, parámetros de configuración). |

| @return | Descripción |
|---|---|
| `ReportedData` | Resultado agregado de la ejecución. |

| @throws | Condición |
|---|---|
| `AssertionError` / `MockitoAssertionError` | Propagados desde la sobrecarga de tres argumentos. |
| `NullPointerException` | Si no se registraron las marcas de tiempo. |
| `RuntimeException` / `JUnitException` / `DiscoveryIssueException` | Propagados por el launcher. |

---

#### `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)`

Método central de orquestación. Crea un `TestExecutionListener` mock instrumentado con `doAnswer` para capturar los instantes de `executionStarted`/`executionFinished`, construye el launcher con el motor indicado, aplica ambos configuradores, ejecuta el plan y verifica la secuencia canónica de eventos (`testPlanExecutionStarted` → `executionStarted` → `executionFinished` → `testPlanExecutionFinished`) sin interacciones adicionales.

Parámetros de configuración fijados por defecto: `enableImplicitConfigurationParameters(false)`, `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=execution`, `DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME=logging`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Motor a registrar en el launcher. |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Transformación del builder de descubrimiento. |
| `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Transformación del builder de ejecución (listeners adicionales, `CancellationToken`). |

| @return | Descripción |
|---|---|
| `ReportedData` | `TestPlan` descubierto, `TestIdentifier` capturado, `TestExecutionResult` capturado y los `Instant` de inicio y fin (no nulos). |

| @throws | Condición |
|---|---|
| `MockitoAssertionError` | Si la secuencia de eventos verificada no se cumple o existen interacciones no verificadas. |
| `NullPointerException` | Si `startTime` o `finishTime` siguen siendo `null` al construir `ReportedData` (`requireNonNull`). |
| `JUnitException` / `DiscoveryIssueException` / `RuntimeException` | Propagados desde `discover(...)` o `execute(...)` del launcher. |

##### Lambdas internas: `Answer` de captura temporal

| Lambda | Entrada | Efecto | Retorno |
|---|---|---|---|
| Answer de `executionStarted(any())` | `invocation` (`InvocationOnMock`) | `startTime.set(Instant.now())` | `null` |
| Answer de `executionFinished(any(), any())` | `invocation` (`InvocationOnMock`) | `finishTime.set(Instant.now())` | `null` |

---

#### `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)`

Obtiene el primer `LogRecord` emitido por `DiscoveryIssueNotifier` con el nivel indicado.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Listener de registros inyectado por `@TrackLogRecords`. |
| `level` | `Level` | Sí | Nivel de log a filtrar (`SEVERE`, `WARNING`, `INFO`, …). |

| @return | Descripción |
|---|---|
| `LogRecord` | Primer registro coincidente. |

| @throws | Condición |
|---|---|
| `NoSuchElementException` | Si no existe ningún registro del nivel solicitado (`orElseThrow()`). |

---

### 2.5 Tipo interno: `record ReportedData`

`private record ReportedData(TestPlan testPlan, TestIdentifier testIdentifier, TestExecutionResult testExecutionResult, Instant startTime, Instant finishTime)`

Agrupa de forma inmutable los datos observados durante una ejecución realizada por los helpers `execute(...)`.

#### Constructor canónico `ReportedData(TestPlan, TestIdentifier, TestExecutionResult, Instant, Instant)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testPlan` | `TestPlan` | Sí | Plan de pruebas resultante del descubrimiento. |
| `testIdentifier` | `TestIdentifier` | Sí | Identificador capturado en `executionStarted`. |
| `testExecutionResult` | `TestExecutionResult` | Sí | Resultado capturado en `executionFinished`. |
| `startTime` | `Instant` | Sí | Instante del evento `executionStarted`. |
| `finishTime` | `Instant` | Sí | Instante del evento `executionFinished`. |

| @throws | Condición |
|---|---|
| — | El constructor canónico generado no realiza validaciones adicionales. |

#### Accesores generados

| Método | @return | @throws |
|---|---|---|
| `testPlan()` | `TestPlan` — plan descubierto. | — |
| `testIdentifier()` | `TestIdentifier` — identificador raíz observado. | — |
| `testExecutionResult()` | `TestExecutionResult` — resultado de ejecución observado. | — |
| `startTime()` | `Instant` — marca temporal de inicio. | — |
| `finishTime()` | `Instant` — marca temporal de fin. | — |

> Adicionalmente, el compilador genera `equals(Object)`, `hashCode()` y `toString()` con la semántica estándar de *records*; ninguno está declarado explícitamente en el fuente.

---

## 3. Ejemplo de uso

El siguiente ejemplo reproduce el patrón de uso real de la clase: registrar un motor instrumentado, descubrir el plan con parámetros de configuración controlados y ejecutarlo verificando los eventos reportados, tal como lo hace el helper `execute(TestEngine, UnaryOperator, UnaryOperator)`.

```java
package org.junit.platform.launcher.core;

import static java.util.function.UnaryOperator.identity;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.platform.launcher.LauncherConstants.DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;
import static org.junit.platform.launcher.core.LauncherFactoryForTestingPurposesOnly.createLauncher;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.junit.platform.engine.DiscoveryIssue;
import org.junit.platform.engine.DiscoveryIssue.Severity;
import org.junit.platform.engine.EngineDiscoveryRequest;
import org.junit.platform.engine.ExecutionRequest;
import org.junit.platform.engine.TestDescriptor;
import org.junit.platform.engine.TestExecutionResult;
import org.junit.platform.engine.UniqueId;
import org.junit.platform.engine.support.descriptor.EngineDescriptor;
import org.junit.platform.fakes.TestEngineStub;
import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.TestIdentifier;
import org.mockito.ArgumentCaptor;

class DefaultLauncherUsageExample {

	@Test
	void ejecutaUnMotorYVerificaLaSecuenciaDeEventos() {

		// 1) Motor de prueba que emite una incidencia no crítica y finaliza con éxito.
		var engine = new TestEngineStub("demo-engine") {

			@Override
			public TestDescriptor discover(EngineDiscoveryRequest discoveryRequest, UniqueId uniqueId) {
				discoveryRequest.getDiscoveryListener() //
						.issueEncountered(uniqueId, DiscoveryIssue.create(Severity.INFO, "solo informativo"));
				return new EngineDescriptor(uniqueId, "Demo Engine");
			}

			@Override
			public void execute(ExecutionRequest request) {
				var listener = request.getEngineExecutionListener();
				var root = request.getRootTestDescriptor();
				listener.executionStarted(root);
				listener.executionFinished(root, TestExecutionResult.successful());
			}
		};

		// 2) Launcher con el motor registrado (fábrica de uso exclusivo en pruebas).
		var launcher = createLauncher(engine);

		// 3) Descubrimiento con parámetros explícitos (sin configuración implícita).
		var discoveryRequest = request() //
				.enableImplicitConfigurationParameters(false) //
				.configurationParameter(DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME, "execution") //
				.configurationParameter(DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME, "logging") //
				.build();

		var testPlan = launcher.discover(discoveryRequest);
		assertThat(testPlan.getRoots()).hasSize(1);

		// 4) Ejecución única del plan con un listener observable.
		TestExecutionListener executionListener = mock(TestExecutionListener.class);
		var executionRequest = LauncherExecutionRequestBuilder.request(testPlan) //
				.listeners(executionListener) //
				.build();

		launcher.execute(executionRequest);

		// 5) Verificación del orden canónico de eventos y del resultado final.
		var identifier = ArgumentCaptor.forClass(TestIdentifier.class);
		var result = ArgumentCaptor.forClass(TestExecutionResult.class);

		var inOrder = inOrder(executionListener);
		inOrder.verify(executionListener).testPlanExecutionStarted(any());
		inOrder.verify(executionListener).executionStarted(identifier.capture());
		inOrder.verify(executionListener).executionFinished(any(), result.capture());
		inOrder.verify(executionListener).testPlanExecutionFinished(any());
		inOrder.verifyNoMoreInteractions();

		assertThat(identifier.getValue().getDisplayName()).isEqualTo("Demo Engine");
		assertThat(result.getValue().getStatus()).isEqualTo(TestExecutionResult.Status.SUCCESSFUL);

		// 6) Un segundo intento de ejecutar el mismo plan viola la precondición del Launcher.
		//    (equivalente a launcherCanExecuteTestPlanExactlyOnce())
		identity(); // referencia al operador identidad usado por los helpers execute(...)
	}
}
```

**Notas operativas**

- `LauncherFactoryForTestingPurposesOnly.createLauncher(...)` deshabilita el *service loading* de motores y listeners, garantizando aislamiento determinista.
- Un `LauncherExecutionRequest` solo puede ejecutarse una vez; reutilizarlo provoca la violación de precondición `"TestPlan must only be executed once"`.
- Para inspeccionar los `LogRecord` de `DiscoveryIssueNotifier` es necesario inyectar un `LogRecordListener` mediante `@TrackLogRecords`, como hacen los tests de la clase documentada.