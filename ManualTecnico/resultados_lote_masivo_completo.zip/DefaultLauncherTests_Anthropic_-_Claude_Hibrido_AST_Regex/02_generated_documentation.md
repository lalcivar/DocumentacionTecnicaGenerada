# Documentación Técnica — `org.junit.platform.launcher.core.DefaultLauncherTests`

---

## 1. Resumen ejecutivo

`DefaultLauncherTests` es una clase de pruebas (JUnit Jupiter) de nivel de paquete que verifica el contrato funcional de la implementación por defecto del `Launcher` del JUnit Platform, obtenida mediante `LauncherFactoryForTestingPurposesOnly.createLauncher(...)`. Cubre los ciclos completos de *discovery* y *execution*: validación de precondiciones (ausencia de motores, IDs duplicados, IDs reservados `junit-`), construcción del `TestPlan`, aplicación de `PostDiscoveryFilter`, propagación de `ConfigurationParameters`, notificación de `LauncherDiscoveryListener`/`TestExecutionListener`, gestión de `DiscoveryIssue` (severidad crítica y fase de fallo), modo *dry-run* y cancelación mediante `CancellationToken`.

La clase se apoya intensivamente en dobles de prueba (`TestEngineStub`, `TestEngineSpy`, `TestDescriptorStub`, `PostDiscoveryFilterStub`, `DemoHierarchicalTestEngine`) y en Mockito (`mock`, `spy`, `verify`, `InOrder`, `ArgumentCaptor`), además de un *record* interno `ReportedData` y un conjunto de métodos auxiliares estáticos (`execute(...)`, `findFirstDiscoveryIssueLogRecord(...)`) que centralizan el flujo de descubrimiento + ejecución y la captura de eventos reportados.

---

## 2. Especificación de métodos y constructores

### 2.0 Declaración de tipo y miembros estáticos

| Elemento | Modificadores | Tipo | Descripción |
|---|---|---|---|
| `DefaultLauncherTests` | `class` (package-private), `@NullMarked` | — | Clase contenedora de los casos de prueba. |
| `FOO` | `static final` | `String` | Clave de propiedad de sistema: `"DefaultLauncherTests.foo"`. Usada como constante de anotación en `@SetSystemProperty`. |
| `BAR` | `static final` | `String` | Valor de propiedad de sistema: `"DefaultLauncherTests.bar"`. |
| `noOp` | `private static final` | `Runnable` | Lambda vacía reutilizada como cuerpo de los tests registrados en `DemoHierarchicalTestEngine`. Su método funcional `run()` no ejecuta ninguna instrucción. |

#### Constructor implícito `DefaultLauncherTests()`

No existe constructor declarado en el código fuente; el compilador genera el **constructor por defecto sin argumentos**, que es el utilizado por el motor de JUnit Jupiter para instanciar la clase una vez por método de prueba (ciclo de vida `PER_METHOD`).

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: nueva instancia de `DefaultLauncherTests`.
- **@throws**: ninguna declarada.

---

### 2.1 Pruebas de construcción y validación del `Launcher`

#### `constructLauncherWithoutAnyEngines()`

Verifica que invocar `discover(...)` sobre un `Launcher` creado sin ningún `TestEngine` produce una violación de precondición con el mensaje *"Cannot create Launcher without at least one TestEngine"*.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si `assertPreconditionViolationFor(...)` no detecta la violación o el mensaje no contiene el texto esperado.

#### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`

Comprueba que registrar dos `DemoHierarchicalTestEngine` con el mismo ID (`"dummy id"`) provoca una `JUnitException` con el mensaje *"multiple engines with the same ID"* al ejecutar `discover(...)`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si no se lanza `JUnitException` o el mensaje no coincide.

#### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`

Valida que un motor sin tests produce un `TestPlan` con exactamente una raíz (el descriptor del motor).

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si `testPlan.getRoots()` no contiene un único elemento.

---

### 2.2 Pruebas de fallos en la fase de *discovery*

#### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`

Verifica el comportamiento defensivo del `Launcher` cuando un motor devuelve `null` como descriptor raíz: el `TestPlan` conserva una raíz sintética y el `LauncherDiscoveryListener` recibe el fallo de descubrimiento.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el `TestPlan` no tiene una raíz o si no se notificó el fallo (`assertDiscoveryFailed`).

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)` (subclase anónima de `TestEngineStub("some-engine-id")`)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Petición de descubrimiento; ignorada por esta implementación. |
| `uniqueId` | `UniqueId` | Sí | ID raíz asignado al motor; ignorado. |

- **@return** `TestDescriptor` — siempre `null` (anotado con `@SuppressWarnings("DataFlowIssue")` para simular un motor defectuoso).
- **@throws**: ninguna.

#### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable>)`

`@ParameterizedTest` con `@ValueSource(classes = { Error.class, RuntimeException.class })`. Comprueba que, si el motor lanza un `Error` o una `RuntimeException` durante el descubrimiento, el `Launcher` crea un descriptor de error cuyo *display name* es el ID del motor, notifica al `LauncherDiscoveryListener` en orden (`launcherDiscoveryStarted` → fallo → `launcherDiscoveryFinished`) y, durante la ejecución, reporta `executionStarted`/`executionFinished` con un `Throwable` cuyo mensaje es *"TestEngine with ID 'my-engine-id' failed to discover tests"*.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `throwableClass` | `Class<? extends Throwable>` | Sí | Tipo de excepción a instanciar reflexivamente (vía constructor `String`) y lanzar dentro del motor. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el `TestPlan`, el orden de notificaciones o el mensaje del resultado de ejecución no son los esperados.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)` (subclase anónima de `TestEngineStub("my-engine-id")`)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Ignorada. |
| `uniqueId` | `UniqueId` | Sí | Ignorado. |

- **@return** `TestDescriptor` — `null` únicamente si la creación reflexiva de la excepción falla (bloque `catch (Exception ignored)`).
- **@throws** `Throwable` (sin comprobar, vía `ExceptionUtils.throwAsUncheckedException`) — la instancia de `throwableClass` creada con el mensaje `"ignored"`.

#### `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)`

Método auxiliar `private` que verifica, mediante un verificador ordenado de Mockito, la secuencia `engineDiscoveryStarted(UniqueId.forEngine(id))` → `engineDiscoveryFinished(id, result)` y que el `EngineDiscoveryResult` capturado tenga estado `FAILED` y un `Throwable` con el mensaje *"TestEngine with ID '&lt;id&gt;' failed to discover tests"*.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testEngine` | `TestEngine` | Sí | Motor cuyo ID se usa para construir el `UniqueId` esperado y el mensaje de fallo. |
| `inOrder` | `InOrder` | Sí | Verificador ordenado de Mockito asociado al listener. |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | Mock sobre el que se verifican las invocaciones. |

- **@return**: `void`.
- **@throws** `AssertionError` — si falta alguna invocación, el estado no es `FAILED`, el `Throwable` está ausente o su mensaje difiere.

---

### 2.3 Pruebas de reporte de fallos y eventos de ejecución del motor

Todas comparten la misma firma (sin parámetros, `void`) y lanzan `AssertionError` ante incumplimiento de las verificaciones de Mockito/AssertJ.

#### `reportsEngineExecutionFailuresWithoutPriorEvents()`

El motor lanza una `RuntimeException` sin emitir ningún evento previo. Se verifica que el `Launcher` sintetiza `executionStarted` y `executionFinished` con un `Throwable` *"TestEngine with ID 'TestEngineStub' failed to execute tests"* cuya causa es la excepción original.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Petición de ejecución; no se utiliza. |

- **@return**: `void`.
- **@throws** `RuntimeException` — `rootCause` (*"something went horribly wrong"*), lanzada incondicionalmente.

#### `reportsEngineExecutionFailuresForSkippedEngine()`

El motor marca su descriptor raíz como *skipped* (`"not today"`) y después falla. Se verifica que el fallo se reporta igualmente como `executionStarted`/`executionFinished`.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del `rootTestDescriptor` y del `EngineExecutionListener`. |

- **@return**: `void`.
- **@throws** `RuntimeException` — `rootCause`, tras invocar `executionSkipped(engineDescriptor, "not today")`.

#### `reportsEngineExecutionFailuresForStartedEngine()`

El motor emite `executionStarted` sobre su raíz y luego falla; se verifica el reporte del fallo con la causa encadenada.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener de ejecución. |

- **@return**: `void`.
- **@throws** `RuntimeException` — `rootCause`, tras `executionStarted(engineDescriptor)`.

#### `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()`

El motor completa su raíz con `successful()` y después falla; el `Launcher` debe reemplazar/reportar el fallo.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener. |

- **@return**: `void`.
- **@throws** `RuntimeException` — `rootCause`, tras `executionStarted` + `executionFinished(..., successful())`.

#### `reportsEngineExecutionFailuresForFailedFinishedEngine()`

El motor finaliza su raíz con `TestExecutionResult.failed(originalFailure)` y luego lanza `rootCause`. Se verifica que el `Throwable` final tiene `originalFailure` como **excepción suprimida** y `rootCause` como **causa**.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener. |

- **@return**: `void`.
- **@throws** `RuntimeException` — `rootCause`, tras reportar `failed(originalFailure)`.

#### `reportsSkippedEngines()`

Verifica que un motor que únicamente invoca `executionSkipped(root, "not today")` produce un `executionSkipped(TestIdentifier, "not today")` y **ningún** `executionStarted`/`executionFinished`.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener. |

- **@return**: `void`.
- **@throws**: ninguna.

#### `reportsFinishedEngines()`

Verifica la propagación normal de `executionStarted` y `executionFinished(successful())`.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener. |

- **@return**: `void`.
- **@throws**: ninguna.

---

### 2.4 Pruebas de construcción del `TestPlan` y filtrado

#### `discoverTestPlanForSingleEngine()`

Registra dos tests en `DemoHierarchicalTestEngine("myEngine")` y verifica que el `TestPlan` tiene una raíz con dos hijos, accesibles tanto por `UniqueId` del identificador raíz como por `UniqueId.parse("[engine:myEngine]")`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si la jerarquía descubierta no coincide.

#### `discoverTestPlanForMultipleEngines()`

Descubre con dos selectores `selectUniqueId(...)` sobre dos motores distintos y verifica dos raíces, cada una con un hijo.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el número de raíces o de hijos por motor es incorrecto.

#### `launcherAppliesPostDiscoveryFilters()`

Aplica dos `PostDiscoveryFilterStub` combinados (uniqueId contiene `"test"` y contiene `"1"`) y verifica que solo `test1` sobrevive.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el filtrado no deja exactamente un descendiente o `test1` no está en el plan.

**Lambdas internas (métodos funcionales anónimos):**

| Lambda | Tipo funcional | Parámetro | Retorno |
|---|---|---|---|
| `descriptor -> FilterResult.includedIf(descriptor.getUniqueId().toString().contains("test"))` | `Predicate`/función de filtrado de `PostDiscoveryFilterStub` | `descriptor` (`TestDescriptor`, requerido) | `FilterResult` incluido si el `UniqueId` contiene `"test"`. |
| `() -> "filter1"` | `Supplier<String>` (descripción del filtro) | — | `"filter1"`. |
| `descriptor -> FilterResult.includedIf(descriptor.getUniqueId().toString().contains("1"))` | Función de filtrado | `descriptor` (`TestDescriptor`, requerido) | `FilterResult` incluido si el `UniqueId` contiene `"1"`. |
| `() -> "filter2"` | `Supplier<String>` | — | `"filter2"`. |

#### `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()`

Verifica la poda (*pruning*) posterior al filtrado: con un filtro que solo incluye contenedores, el contenedor queda sin tests y por tanto se elimina, dejando la raíz del motor sin hijos.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si la raíz no queda vacía.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)` (subclase anónima de `TestEngineSpy`)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Delegada a `super.discover(...)` para registrar la invocación en el *spy*. |
| `uniqueId` | `UniqueId` | Sí | Base para construir el descriptor de motor, el contenedor `container:a` y el test `test:b`. |

- **@return** `TestDescriptor` — descriptor de motor con un contenedor que a su vez contiene un test.
- **@throws**: ninguna.

##### Método anónimo interno: `getType()` (subclase anónima de `TestDescriptorStub` para `containerDescriptor`)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return** `TestDescriptor.Type` — constante `Type.CONTAINER`.
- **@throws**: ninguna.

##### Lambda interna: filtro `(PostDiscoveryFilter) testDescriptor -> FilterResult.includedIf(testDescriptor.isContainer())`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testDescriptor` | `TestDescriptor` | Sí | Descriptor evaluado por el filtro post-discovery. |

- **@return** `FilterResult` — incluido si el descriptor es contenedor.
- **@throws**: ninguna.

---

### 2.5 Pruebas de parámetros de configuración y listeners adicionales

#### `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()`

Verifica que, sin parámetros configurados, `ConfigurationParameters.get("key")` no está presente en la `ExecutionRequest` capturada por `TestEngineSpy.requestForExecution`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el valor está presente.
- **@throws** `NullPointerException` — propagada por `requireNonNull(engine.requestForExecution)` si el motor nunca fue ejecutado.

#### `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()`

Verifica que `configurationParameter("key", "value")` llega hasta la `ExecutionRequest`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el parámetro no está presente o su valor no es `"value"`.
- **@throws** `NullPointerException` — vía `requireNonNull(...)`.

#### `withoutConfigurationParameters_LookupFallsBackToSystemProperty()`

Anotado con `@SetSystemProperty(key = FOO, value = BAR)`. Verifica el *fallback* de resolución de parámetros a propiedades de sistema.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si `FOO` no se resuelve o su valor no es `BAR`.
- **@throws** `NullPointerException` — vía `requireNonNull(...)`.

#### `withAdditionalListener()`

Registra un `SummaryGeneratingListener` en la petición de ejecución y valida que el resumen reporta 1 contenedor y 1 test encontrados (comportamiento de `TestEngineSpy`).

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el resumen es nulo o los contadores no son 1.

---

### 2.6 Pruebas de tests dinámicos, ejecución única y IDs reservados

#### `reportsDynamicTestDescriptorsCorrectly()`

Comprueba el registro y reporte ordenado de un test dinámico bajo un descriptor `CONTAINER_AND_TEST`, incluyendo la correcta relación padre-hijo en el `TestPlan` (`getParentIdObject()`).

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si la jerarquía o el orden de eventos no coinciden.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)` (subclase anónima de `TestEngineSpy(engineId...)`)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Delegada a `super.discover(...)`. |
| `uniqueId` | `UniqueId` | Sí | ID raíz del motor. |

- **@return** `TestDescriptor` — descriptor de motor con un hijo `containerAndTestId`.
- **@throws**: ninguna.

##### Método anónimo interno: `getType()` (subclase anónima de `TestDescriptorStub` para `containerAndTestId`)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return** `TestDescriptor.Type` — `Type.CONTAINER_AND_TEST`.
- **@throws**: ninguna.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Delegada a `super.execute(...)`; provee el descriptor raíz y el `EngineExecutionListener`. |

- **@return**: `void`.
- **@throws**: ninguna. Emite la secuencia: inicio del motor, inicio del *container&test*, `dynamicTestRegistered`, inicio/fin del test dinámico, fin del *container&test* y fin del motor.

#### `launcherCanExecuteTestPlanExactlyOnce()`

Usa un `mock(TestEngine.class)` con `discover` *stubbed* para devolver un `EngineDescriptor`. Verifica que `discover` y `execute` del motor se invocan una sola vez y que reejecutar la misma `LauncherExecutionRequest` provoca una violación de precondición con mensaje *"TestPlan must only be executed once"*.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si los contadores de invocaciones o el mensaje de precondición no coinciden.

##### Lambda interna (`Answer`): `invocation -> new EngineDescriptor(uniqueId, uniqueId.toString())`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `invocation` | `InvocationOnMock` | Sí | Invocación interceptada; se extrae el argumento de índice 1 (`UniqueId`). |

- **@return** `EngineDescriptor` — descriptor raíz construido con el `UniqueId` recibido.
- **@throws**: ninguna.

#### `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()`

Verifica que un motor de terceros con ID `"junit-using-reserved-prefix"` genera `DiscoveryIssueException` con severidad `WARNING` indicando que el prefijo `junit-` está reservado.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si no se lanza la excepción esperada o el mensaje no contiene el texto indicado.

#### `thirdPartyEngineClaimingToBeJupiterResultsInException()`

Delega en `assertImposter("junit-jupiter")`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — propagada desde `assertImposter`.

#### `thirdPartyEngineClaimingToBeVintageResultsInException()`

Delega en `assertImposter("junit-vintage")`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — propagada desde `assertImposter`.

#### `assertImposter(String)`

Auxiliar `private`. Crea un `TestEngineStub` con el ID reservado indicado y verifica que `discover(...)` lanza `JUnitException` con el mensaje *"Third-party TestEngine '&lt;FQCN&gt;' is forbidden to use the reserved '&lt;id&gt;' TestEngine ID."*.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `id` | `String` | Sí | ID reservado a suplantar (`"junit-jupiter"` o `"junit-vintage"`). |

- **@return**: `void`.
- **@throws** `AssertionError` — si no se lanza `JUnitException` o el mensaje difiere.

---

### 2.7 Pruebas de *dry-run*, listeners de descubrimiento y cancelación

#### `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`

Activa `DRY_RUN_PROPERTY_NAME=true` y verifica el orden exacto de eventos: el test (cuyo cuerpo lanzaría `RuntimeException("boom")`) se reporta como `executionSkipped` con el motivo *"JUnit Platform dry-run mode is enabled"* y nunca se ejecuta.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el orden de eventos difiere o existen interacciones adicionales (`verifyNoMoreInteractions`).

##### Lambda interna del `DemoHierarchicalTestDescriptor`: `(__, ___) -> { throw new RuntimeException("boom"); }`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `__` | (primer parámetro del contrato de ejecución de `DemoHierarchicalTestDescriptor`) | Sí | Ignorado (nombre comodín). |
| `___` | (segundo parámetro del mismo contrato) | Sí | Ignorado (nombre comodín). |

- **@return**: `void`.
- **@throws** `RuntimeException` — `"boom"`; nunca debe lanzarse en modo *dry-run*.

#### `notifiesDiscoveryListenersOfProcessedSelectors()`

Valida que los `LauncherDiscoveryListener` registrados por tres vías distintas (en el `LauncherConfig`, en el `Launcher` mediante `registerLauncherDiscoveryListeners`, y en la propia `LauncherDiscoveryRequest`) reciben `selectorProcessed(engineId, selector, unresolved())`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — agrupada por `assertAll`, si alguno de los tres listeners no fue notificado.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)` (subclase anónima de `TestEngineStub("some-engine-id")`)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente de los selectores (`getSelectorsByType(DiscoverySelector.class)`) y del `EngineDiscoveryListener`. |
| `uniqueId` | `UniqueId` | Sí | ID raíz usado al notificar y al construir el `EngineDescriptor`. |

- **@return** `TestDescriptor` — `EngineDescriptor` cuyo nombre es el valor del último segmento del `UniqueId`.
- **@throws**: ninguna.

###### Lambda interna: `selector -> discoveryRequest.getDiscoveryListener().selectorProcessed(uniqueId, selector, unresolved())`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `selector` | `DiscoverySelector` | Sí | Selector sobre el que se notifica el resultado `unresolved()`. |

- **@return**: `void`.
- **@throws**: ninguna.

#### `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()`

Con un `CancellationToken` ya cancelado, verifica que el motor (envuelto en `spy`) **nunca** recibe `execute(...)`, que los hijos del descriptor de motor se reportan como `executionSkipped("Execution cancelled")` y que el motor finaliza con estado `ABORTED`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si `execute` fue invocado o si la secuencia de eventos no coincide.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)` (subclase anónima de `TestEngineStub("engine-id")`, espiada)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Ignorada. |
| `uniqueId` | `UniqueId` | Sí | Base de la jerarquía `Engine → container:1 → test:1`. |

- **@return** `TestDescriptor` — `EngineDescriptor` con un contenedor que contiene un test.
- **@throws**: ninguna.

##### Lambdas internas de verificación (`argThat`)

| Lambda | @param | Retorno |
|---|---|---|
| `d -> d.getUniqueIdObject().equals(UniqueId.forEngine("engine-id"))` | `d` (`TestIdentifier`, requerido) | `boolean` — verdadero si el identificador es la raíz del motor. |
| `d -> d.getUniqueIdObject().getLastSegment().getType().equals("container")` | `d` (`TestIdentifier`, requerido) | `boolean` — verdadero si el último segmento es de tipo `container`. |
| `result -> result.getStatus() == ABORTED` | `result` (`TestExecutionResult`, requerido) | `boolean` — verdadero si el estado es `ABORTED`. |

---

### 2.8 Pruebas de `DiscoveryIssue`: severidad crítica, fase de fallo y *logging*

#### `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener)`

Un motor emite un `DiscoveryIssue` `ERROR` y otro `WARNING`. Se verifica que el error se convierte en fallo de ejecución (`DiscoveryIssueException`), que el descriptor del motor conserva su *display name* y sus `TestTag` personalizados, y que el *warning* se registra como `LogRecord` de nivel `WARNING` dentro del intervalo `[startTime, finishTime]`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí (inyectado por la extensión) | Captura los registros de log emitidos durante la prueba. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el estado, el tipo de excepción, los mensajes, las etiquetas o el instante del log no coinciden.
- **@throws** `NoSuchElementException` — si no existe `LogRecord` de nivel `WARNING` (vía `orElseThrow()` en `findFirstDiscoveryIssueLogRecord`).

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del `EngineDiscoveryListener` para emitir incidencias. |
| `uniqueId` | `UniqueId` | Sí | Origen de las incidencias y del `EngineDescriptor`. |

- **@return** `TestDescriptor` — `EngineDescriptor` anónimo con nombre `"Engine"`.
- **@throws**: ninguna.

##### Método anónimo interno: `getTags()` (subclase anónima de `EngineDescriptor`)

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return** `Set<TestTag>` — `Set.of(TestTag.create("custom-tag"))`.
- **@throws**: ninguna.

#### `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener)`

Un motor emite una incidencia `INFO` y ejecuta correctamente. Se verifica resultado `SUCCESSFUL` y el log `INFO` correspondiente.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí | Captura de registros de log. |

- **@return**: `void`.
- **@throws** `AssertionError`; `NoSuchElementException` si falta el `LogRecord`.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del listener de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | ID raíz. |

- **@return** `TestDescriptor` — `EngineDescriptor(uniqueId, "Engine")`.
- **@throws**: ninguna.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del `EngineExecutionListener`. |

- **@return**: `void`.
- **@throws**: ninguna. Emite `executionStarted` + `executionFinished(successful())`.

#### `logsAllIssuesForDiscoveryFailure(LogRecordListener)`

Un motor emite incidencias `ERROR` e `INFO` y después lanza `RuntimeException("boom")`. Se verifica el fallo de descubrimiento reportado en ejecución y que **ambas** incidencias se registran (niveles `SEVERE` e `INFO`).

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí | Captura de registros de log. |

- **@return**: `void`.
- **@throws** `AssertionError`; `NoSuchElementException` si falta alguno de los dos `LogRecord`.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del listener de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | Origen de las incidencias. |

- **@return** `TestDescriptor` — nunca retorna.
- **@throws** `RuntimeException` — `"boom"`.

#### `logsNonCriticalIssuesForExecutionFailure(LogRecordListener)`

El descubrimiento emite una incidencia `INFO` y la ejecución falla con `RuntimeException("boom")`. Se verifica el mensaje *"failed to execute tests"* y el log `INFO`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí | Captura de registros de log. |

- **@return**: `void`.
- **@throws** `AssertionError`; `NoSuchElementException` si falta el `LogRecord`.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del listener de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | Origen de la incidencia `INFO`. |

- **@return** `TestDescriptor` — `EngineDescriptor(uniqueId, "Engine")`.
- **@throws**: ninguna.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Ignorada. |

- **@return**: `void`.
- **@throws** `RuntimeException` — `"boom"`.

#### `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()`

Usa `createEngineThatCannotResolveAnything("some-engine")` y un `selectUniqueId` con el prefijo del propio motor; se espera fallo crítico *"could not be resolved"*.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el estado no es `FAILED` o el mensaje no coincide.

##### Lambda interna: `request -> request.selectors(selector)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | Sí | Builder a configurar. |

- **@return** `LauncherDiscoveryRequestBuilder` — builder con el selector añadido.

#### `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()`

Un `selectUniqueId` dirigido a otro motor (`"some-other-engine"`) no debe producir incidencia: resultado `SUCCESSFUL`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el estado no es `SUCCESSFUL`.

##### Lambda interna: `request -> request.selectors(selector)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | Sí | Builder a configurar. |

- **@return** `LauncherDiscoveryRequestBuilder`.

#### `reportsEngineExecutionFailureForSelectorResolutionFailure()`

Con `createEngineThatFailsToResolveAnything("some-engine", new RuntimeException("boom"))` y `selectClass(Object.class)`, se espera `DiscoveryIssueException` con *"resolution failed"* y la causa `java.lang.RuntimeException: boom`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el estado o los mensajes no coinciden.

##### Lambda interna: `request -> request.selectors(selector)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | Sí | Builder a configurar. |

- **@return** `LauncherDiscoveryRequestBuilder`.

#### `allowsConfiguringCriticalDiscoveryIssueSeverity()`

Configura `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME=info`, de modo que una incidencia `INFO` pasa a ser crítica y produce `FAILED` con `DiscoveryIssueException`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el estado o el mensaje no coinciden.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del listener de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | Origen de la incidencia `INFO`. |

- **@return** `TestDescriptor` — `EngineDescriptor(uniqueId, "Engine")`.
- **@throws**: ninguna.

##### Lambda interna: `request -> request.configurationParameter(CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME, "info")`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | Sí | Builder a configurar. |

- **@return** `LauncherDiscoveryRequestBuilder`.

#### `failsIfCriticalSeverityIsConfiguredIncorrectly()`

Verifica que un valor inválido (`"wrong"`) para la severidad crítica provoca `JUnitException` con causa raíz *"Invalid DiscoveryIssue.Severity 'wrong' set via the '…' configuration parameter."*.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si no se lanza `JUnitException` o el mensaje raíz difiere.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del listener de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | Origen de la incidencia `INFO`. |

- **@return** `TestDescriptor` — `EngineDescriptor(uniqueId, "Engine")`.
- **@throws**: ninguna.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener de ejecución. |

- **@return**: `void`.
- **@throws**: ninguna. Emite inicio y fin exitoso del motor.

##### Lambda interna: `request -> request.configurationParameter(CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME, "wrong")`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | Sí | Builder a configurar. |

- **@return** `LauncherDiscoveryRequestBuilder`.

#### `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()`

Con `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=discovery`, una incidencia `ERROR` debe interrumpir la fase de descubrimiento lanzando `DiscoveryIssueException`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si no se lanza `DiscoveryIssueException` o el mensaje no coincide.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del listener de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | Origen de la incidencia `ERROR`. |

- **@return** `TestDescriptor` — `EngineDescriptor(uniqueId, "Engine")`.
- **@throws**: ninguna.

##### Lambda interna: `request -> request.configurationParameter(DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME, "discovery")`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | Sí | Builder a configurar. |

- **@return** `LauncherDiscoveryRequestBuilder`.

#### `logsNonCriticalIssuesOnlyOnce(String, LogRecordListener)`

`@ParameterizedTest` con `@ValueSource(strings = { "discovery", "execution" })`. Garantiza que una incidencia `WARNING` se registra exactamente **una** vez, independientemente de la fase configurada para el fallo.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `phase` | `String` | Sí | Valor de `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME` (`"discovery"` o `"execution"`). |
| `listener` | `LogRecordListener` (`@TrackLogRecords`) | Sí | Captura de registros de log. |

- **@return**: `void`.
- **@throws** `AssertionError` — si el número de `LogRecord` de nivel `WARNING` para `DiscoveryIssueNotifier` no es 1.

##### Método anónimo interno: `discover(EngineDiscoveryRequest, UniqueId)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `discoveryRequest` | `EngineDiscoveryRequest` | Sí | Fuente del listener de descubrimiento. |
| `uniqueId` | `UniqueId` | Sí | Origen de la incidencia `WARNING`. |

- **@return** `TestDescriptor` — `EngineDescriptor(uniqueId, "Engine")`.
- **@throws**: ninguna.

##### Método anónimo interno: `execute(ExecutionRequest)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `ExecutionRequest` | Sí | Fuente del descriptor raíz y del listener de ejecución. |

- **@return**: `void`.
- **@throws**: ninguna. Emite inicio y fin exitoso del motor.

##### Lambda interna: `request -> request.configurationParameter(DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME, phase)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | Sí | Builder a configurar con la fase paramétrica. |

- **@return** `LauncherDiscoveryRequestBuilder`.

#### `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()`

Verifica que un valor inválido para la fase de fallo produce `JUnitException` con causa raíz *"Invalid LauncherPhase 'wrong' set via the '…' configuration parameter."*.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Sin parámetros. |

- **@return**: `void`.
- **@throws** `AssertionError` — si no se lanza `JUnitException` o el mensaje raíz difiere.

##### Lambda interna: `request -> request.configurationParameter(DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME, "wrong")`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `LauncherDiscoveryRequestBuilder` | Sí | Builder a configurar. |

- **@return** `LauncherDiscoveryRequestBuilder`.

---

### 2.9 Métodos auxiliares estáticos

#### `execute(TestEngine)`

Sobrecarga de conveniencia: delega en `execute(engine, identity())`, sin personalizar la `LauncherDiscoveryRequest`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Motor a registrar en el `Launcher`. |

- **@return** `ReportedData` — datos capturados (plan, identificador, resultado, instantes de inicio y fin).
- **@throws** `AssertionError` — propagada desde las verificaciones internas.
- **@throws** `NullPointerException` — si no se capturaron instantes de inicio/fin.
- **@throws** `JUnitException` / `DiscoveryIssueException` — propagadas desde `discover(...)` o `execute(...)` según configuración.

#### `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)`

Sobrecarga que permite personalizar el *builder* de descubrimiento; delega en la variante de tres argumentos con `identity()` como configurador de ejecución.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Motor a registrar. |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Transformación aplicada al builder de descubrimiento (selectores, parámetros, etc.). |

- **@return** `ReportedData`.
- **@throws** `AssertionError`, `NullPointerException`, `JUnitException` / `DiscoveryIssueException` — según lo descrito arriba.

#### `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)`

Método central del *harness*. Crea un `TestExecutionListener` mockeado instrumentado con `doAnswer` para registrar los instantes de `executionStarted` y `executionFinished`; construye la `LauncherDiscoveryRequest` con `enableImplicitConfigurationParameters(false)`, `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME=execution` y `DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME=logging`; descubre, ejecuta y verifica en orden estricto la secuencia `testPlanExecutionStarted` → `executionStarted` → `executionFinished` → `testPlanExecutionFinished` sin interacciones adicionales.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `engine` | `TestEngine` | Sí | Motor bajo prueba. |
| `discoveryConfigurer` | `UnaryOperator<LauncherDiscoveryRequestBuilder>` | Sí | Personalización del builder de descubrimiento. |
| `executionConfigurer` | `UnaryOperator<LauncherExecutionRequestBuilder>` | Sí | Personalización del builder de ejecución (listeners adicionales, `CancellationToken`, etc.). |

- **@return** `ReportedData` — agregado con el `TestPlan`, el `TestIdentifier` capturado, el `TestExecutionResult` capturado y los `Instant` de inicio y fin.
- **@throws** `AssertionError` — si la secuencia de eventos verificada no se cumple o existen interacciones no verificadas.
- **@throws** `NullPointerException` — vía `requireNonNull(startTime.get())` / `requireNonNull(finishTime.get())` si los eventos de ejecución nunca ocurrieron.
- **@throws** `JUnitException` / `DiscoveryIssueException` — propagadas desde el `Launcher`.

##### Lambdas internas (`Answer` de Mockito)

| Lambda | @param | Retorno | Efecto |
|---|---|---|---|
| `invocation -> { startTime.set(Instant.now()); return null; }` | `invocation` (`InvocationOnMock`, requerido) | `null` | Registra el instante del primer `executionStarted`. |
| `invocation -> { finishTime.set(Instant.now()); return null; }` | `invocation` (`InvocationOnMock`, requerido) | `null` | Registra el instante del `executionFinished`. |

#### `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)`

Obtiene el primer `LogRecord` emitido por la categoría `DiscoveryIssueNotifier` con el nivel indicado.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `listener` | `LogRecordListener` | Sí | Listener que acumula los registros de log de la prueba. |
| `level` | `Level` | Sí | Nivel de log a filtrar (`SEVERE`, `WARNING`, `INFO`, …). |

- **@return** `LogRecord` — primer registro coincidente.
- **@throws** `NoSuchElementException` — si no existe ningún registro para la categoría y nivel dados (`orElseThrow()`).

---

### 2.10 Tipo interno: `record ReportedData`

Contenedor inmutable (`private record`) de los datos observados durante un ciclo de descubrimiento + ejecución.

#### Constructor canónico `ReportedData(TestPlan, TestIdentifier, TestExecutionResult, Instant, Instant)`

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `testPlan` | `TestPlan` | Sí | Plan de pruebas resultante del descubrimiento. |
| `testIdentifier` | `TestIdentifier` | Sí | Identificador capturado en el primer `executionStarted`. |
| `testExecutionResult` | `TestExecutionResult` | Sí | Resultado capturado en `executionFinished`. |
| `startTime` | `Instant` | Sí | Instante del evento `executionStarted`. |
| `finishTime` | `Instant` | Sí | Instante del evento `executionFinished`. |

- **@return**: nueva instancia de `ReportedData`.
- **@throws**: ninguna declarada.

#### Accesores generados

| Método | @param | @return | @throws |
|---|---|---|---|
| `testPlan()` | — | `TestPlan` — plan descubierto. | Ninguna. |
| `testIdentifier()` | — | `TestIdentifier` — identificador del motor reportado. | Ninguna. |
| `testExecutionResult()` | — | `TestExecutionResult` — resultado de ejecución del motor. | Ninguna. |
| `startTime()` | — | `Instant` — marca temporal de inicio. | Ninguna. |
| `finishTime()` | — | `Instant` — marca temporal de fin. | Ninguna. |

> **Nota**: el *record* también hereda las implementaciones generadas por el compilador de `equals(Object)`, `hashCode()` y `toString()`, cuyo contrato es el estándar de `java.lang.Record` (comparación y representación basadas en los cinco componentes declarados).

---

## 3. Ejemplo de uso

Caso de uso real derivado estrictamente de los elementos presentes en el código fuente: construcción de un `Launcher` de pruebas con `DemoHierarchicalTestEngine`, descubrimiento con filtro *post-discovery*, ejecución con `SummaryGeneratingListener` y `TestExecutionListener` mockeado, y verificación del plan resultante.

```java
package org.junit.platform.launcher.core;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectPackage;
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;
import static org.junit.platform.launcher.core.LauncherFactoryForTestingPurposesOnly.createLauncher;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.junit.platform.engine.CancellationToken;
import org.junit.platform.engine.FilterResult;
import org.junit.platform.engine.UniqueId;
import org.junit.platform.engine.support.hierarchical.DemoHierarchicalTestEngine;
import org.junit.platform.launcher.PostDiscoveryFilter;
import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;

class LauncherUsageExample {

    @Test
    void discoverFilterAndExecuteWithSummary() {
        // 1. Motor de pruebas de demostración con dos tests "no-op"
        var engine = new DemoHierarchicalTestEngine("myEngine");
        var test1 = engine.addTest("test1", () -> { });
        engine.addTest("test2", () -> { });

        var launcher = createLauncher(engine);

        // 2. Filtro post-discovery: solo descriptores cuyo UniqueId contenga "1"
        PostDiscoveryFilter onlyFirstTest = descriptor -> FilterResult.includedIf(
            descriptor.getUniqueId().toString().contains("1"));

        // 3. Fase de descubrimiento
        var discoveryRequest = request()
                .selectors(selectPackage("any"))
                .filters(onlyFirstTest)
                .configurationParameter(
                    LauncherDiscoveryRequestBuilder.DEFAULT_DISCOVERY_LISTENER_CONFIGURATION_PROPERTY_NAME,
                    "logging")
                .build();

        var testPlan = launcher.discover(discoveryRequest);

        assertThat(testPlan.getChildren(UniqueId.forEngine("myEngine"))).hasSize(1);
        assertThat(testPlan.getTestIdentifier(test1.getUniqueId())).isNotNull();

        // 4. Fase de ejecución (un TestPlan solo puede ejecutarse una vez)
        var summaryListener = new SummaryGeneratingListener();
        TestExecutionListener auditListener = mock(TestExecutionListener.class);
        var cancellationToken = CancellationToken.create();

        var executionRequest = LauncherExecutionRequestBuilder.request(testPlan)
                .listeners(summaryListener, auditListener)
                .cancellationToken(cancellationToken)
                .build();

        launcher.execute(executionRequest);

        // 5. Verificación de eventos y del resumen
        var inOrder = inOrder(auditListener);
        inOrder.verify(auditListener).testPlanExecutionStarted(testPlan);
        inOrder.verify(auditListener).testPlanExecutionFinished(testPlan);

        assertThat(summaryListener.getSummary().getTestsSucceededCount()).isEqualTo(1);
        assertThat(summaryListener.getSummary().getTestsFailedCount()).isZero();
    }
}
```

---

### Notas de arquitectura

- **Patrón *harness* centralizado**: la triple sobrecarga de `execute(...)` implementa un patrón de *template* parametrizado por dos `UnaryOperator` (descubrimiento y ejecución), eliminando duplicación en los 10+ tests orientados a `DiscoveryIssue`.
- **Doble canal de severidad**: los tests distinguen explícitamente las incidencias *críticas* (convertidas en `DiscoveryIssueException`) de las *no críticas* (registradas vía `DiscoveryIssueNotifier` con niveles `SEVERE`/`WARNING`/`INFO`), controladas respectivamente por `CRITICAL_DISCOVERY_ISSUE_SEVERITY_PROPERTY_NAME` y `DISCOVERY_ISSUE_FAILURE_PHASE_PROPERTY_NAME`.
- **Invariantes verificadas del `Launcher`**: al menos un `TestEngine`, unicidad de IDs, prohibición del prefijo `junit-` para terceros, ejecución única por `TestPlan`, y aislamiento de fallos del motor (siempre traducidos a eventos `executionStarted`/`executionFinished` sintetizados).