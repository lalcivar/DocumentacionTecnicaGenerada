# Documentación Técnica — Generador de Manual Técnico vía LLM (OpenRouter)

---

## 1. Resumen ejecutivo

Este módulo es un **script de automatización documental** que lee un archivo de código fuente Java desde el sistema de archivos local y lo envía a un modelo de lenguaje (`google/gemini-2.0-flash-001`) a través del endpoint compatible con OpenAI de **OpenRouter**. La respuesta generada por el modelo —un manual técnico en español— se persiste en disco como un archivo Markdown (`MANUAL_TECNICO_JUNIT.md`).

El script está diseñado para ejecución directa (no como librería importable): la invocación a `generar_documentacion()` ocurre a nivel de módulo, por lo que la lógica se dispara automáticamente al importar o ejecutar el archivo.

---

## 2. Inventario de elementos detectados

| Elemento | Tipo | Ámbito | Documentado en |
|----------|------|--------|----------------|
| `OpenAI` | Clase importada (dependencia externa `openai`) | Módulo | §2.1 |
| `client` | Variable global / instancia de cliente | Módulo | §2.1 |
| `generar_documentacion()` | Función pública sin argumentos | Módulo | §2.2 |
| `generar_documentacion()` (llamada final) | Sentencia de ejecución a nivel de módulo | Módulo | §2.3 |

> **Nota de cobertura:** el código fuente provisto **no contiene** clases definidas localmente, métodos de instancia, decoradores, funciones anidadas, callbacks ni workers de hilos. La única unidad de código ejecutable definida es `generar_documentacion()`, documentada de forma exhaustiva a continuación.

---

### 2.1. Configuración de módulo: `client`

Instancia única (patrón *singleton de facto*) del cliente HTTP del SDK de OpenAI, reconfigurado para apuntar al gateway de OpenRouter.

```python
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key="sk-or-v1-...",
)
```

**Parámetros de construcción utilizados**

| Parámetro | Tipo | Requerido | Valor en el código | Descripción |
|-----------|------|-----------|--------------------|-------------|
| `base_url` | `str` | No (default: API de OpenAI) | `"https://openrouter.ai/api/v1"` | Redirige todas las peticiones del SDK al gateway de OpenRouter, que expone una API compatible con el esquema de OpenAI. |
| `api_key` | `str` | Sí (o vía variable de entorno) | Token literal `sk-or-v1-...` | Credencial de autenticación Bearer para OpenRouter. |

**Atributos de ámbito global**

| Nombre | Tipo | Mutabilidad | Descripción |
|--------|------|-------------|-------------|
| `client` | `openai.OpenAI` | Inmutable en el flujo actual | Cliente compartido consumido por `generar_documentacion()`. Se evalúa en tiempo de importación del módulo. |

> ⚠️ **Hallazgo crítico de seguridad:** la `api_key` está *hardcodeada* en el código fuente. Esto expone la credencial en control de versiones, logs y artefactos de build. Ver §4 para la mitigación recomendada.

---

### 2.2. `generar_documentacion()`

Función orquestadora del pipeline completo: **lectura → inferencia → escritura**. No recibe argumentos ni devuelve valor; opera enteramente por efectos secundarios (E/S de archivos, E/S de red y salida por `stdout`).

#### Docstring propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en Markdown a partir de un archivo Java local.

    Lee el contenido del archivo Java definido en la constante local
    ``ruta_java``, lo envía como mensaje de usuario a un modelo de lenguaje
    alojado en OpenRouter y persiste la respuesta en el archivo
    ``MANUAL_TECNICO_JUNIT.md`` dentro del directorio de trabajo actual.

    El prompt de sistema instruye al modelo para producir un manual técnico
    detallado en español que explique el propósito de la clase, sus métodos
    y su integración en el sistema.

    La función no recibe parámetros: tanto la ruta de entrada como el nombre
    del archivo de salida y el identificador del modelo están codificados
    de forma literal en el cuerpo de la función.

    Args:
        None: La función no acepta argumentos.

    Returns:
        None: La función no retorna valor. Sus resultados se materializan
            como efectos secundarios:

            * Creación o sobrescritura de ``MANUAL_TECNICO_JUNIT.md``.
            * Mensajes informativos de progreso impresos en ``stdout``.

    Raises:
        FileNotFoundError: Si la ruta
            ``main/java/junit/textui/ResultPrinter.java`` no existe
            relativa al directorio de trabajo actual.
        IsADirectoryError: Si la ruta de entrada apunta a un directorio.
        PermissionError: Si el proceso carece de permisos de lectura sobre
            el archivo Java o de escritura en el directorio de salida.
        UnicodeDecodeError: Si el archivo Java no puede decodificarse con
            el códec ``utf-8``.
        OSError: Ante cualquier otro fallo de entrada/salida del sistema
            operativo durante la lectura o la escritura.
        openai.AuthenticationError: Si la ``api_key`` configurada es
            inválida, está revocada o carece de crédito.
        openai.RateLimitError: Si se excede la cuota o el límite de
            peticiones del proveedor.
        openai.APIConnectionError: Si no se puede establecer conexión con
            ``https://openrouter.ai/api/v1``.
        openai.NotFoundError: Si el identificador de modelo
            ``google/gemini-2.0-flash-001`` no está disponible en el
            proveedor.
        openai.BadRequestError: Si el payload excede la ventana de contexto
            del modelo o es rechazado por el proveedor.
        IndexError: Si la respuesta del proveedor llega con la lista
            ``choices`` vacía.
        TypeError: Si ``message.content`` es ``None`` (respuesta filtrada o
            truncada) y se intenta escribir en el archivo de salida.

    Example:
        >>> generar_documentacion()
        --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
        <BLANKLINE>
        ¡Documentación generada con éxito!
        Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
    """
```

#### Parámetros de entrada

| Nombre | Tipo | Requerido | Default | Descripción |
|--------|------|-----------|---------|-------------|
| — | — | — | — | La función no declara parámetros formales. Toda su configuración es interna (literales) o externa (variable global `client`). |

#### Dependencias implícitas (acoplamiento)

| Dependencia | Origen | Tipo de acoplamiento | Impacto |
|-------------|--------|----------------------|---------|
| `client` | Variable global del módulo | Fuerte (global) | Dificulta el testeo unitario; requiere *monkeypatching* para aislar la llamada de red. |
| `ruta_java` | Literal local `"main/java/junit/textui/ResultPrinter.java"` | Fuerte (hardcode) | La función solo puede procesar un único archivo. |
| `"MANUAL_TECNICO_JUNIT.md"` | Literal local | Fuerte (hardcode) | El destino es fijo y se **sobrescribe** en cada ejecución (modo `"w"`). |
| `"google/gemini-2.0-flash-001"` | Literal local | Fuerte (hardcode) | Cambiar de modelo exige modificar el código. |
| Directorio de trabajo (CWD) | Entorno del proceso | Implícito | Las rutas son **relativas**; el script falla si se ejecuta desde otro directorio. |

#### Variables locales

| Nombre | Tipo | Descripción |
|--------|------|-------------|
| `ruta_java` | `str` | Ruta relativa del archivo Java de entrada. |
| `f` | `TextIOWrapper` | Handle de lectura gestionado por `with` (cierre garantizado). |
| `codigo` | `str` | Contenido textual completo del archivo Java; se usa como `content` del mensaje `user`. |
| `response` | `openai.types.chat.ChatCompletion` | Objeto de respuesta del proveedor. |
| `manual_contenido` | `str \| None` | Texto Markdown extraído de `response.choices[0].message.content`. |
| `m` | `TextIOWrapper` | Handle de escritura gestionado por `with`. |

#### Valores de retorno

| Tipo de retorno | Valor | Descripción |
|-----------------|-------|-------------|
| `None` | `None` (implícito) | No hay sentencia `return`. El resultado útil es el archivo `MANUAL_TECNICO_JUNIT.md`. |

#### Manejo de excepciones (`Raises`)

| Excepción | Etapa del flujo | Condición de disparo | Tratamiento en el código |
|-----------|-----------------|----------------------|--------------------------|
| `FileNotFoundError` | Lectura (`open(..., 'r')`) | La ruta Java no existe desde el CWD | **No capturada** → propaga y aborta |
| `IsADirectoryError` | Lectura | La ruta es un directorio | **No capturada** |
| `PermissionError` | Lectura / Escritura | Permisos insuficientes | **No capturada** |
| `UnicodeDecodeError` | Lectura | Bytes no válidos en UTF-8 | **No capturada** |
| `OSError` | Lectura / Escritura | Error genérico de E/S (disco lleno, descriptor inválido) | **No capturada** |
| `openai.AuthenticationError` | Inferencia | API key inválida/revocada (HTTP 401) | **No capturada** |
| `openai.RateLimitError` | Inferencia | Cuota o rate limit excedido (HTTP 429) | **No capturada** |
| `openai.APIConnectionError` | Inferencia | Fallo de red/DNS/TLS contra OpenRouter | **No capturada** |
| `openai.NotFoundError` | Inferencia | Modelo inexistente para la cuenta (HTTP 404) | **No capturada** |
| `openai.BadRequestError` | Inferencia | Payload inválido o contexto excedido (HTTP 400) | **No capturada** |
| `openai.APIStatusError` | Inferencia | Cualquier otro código HTTP de error | **No capturada** |
| `IndexError` | Post-procesado | `response.choices` vacío | **No capturada** |
| `TypeError` | Escritura | `manual_contenido is None` pasado a `m.write()` | **No capturada** |

> **Diagnóstico:** la función **no implementa ningún bloque `try/except`**. Cualquiera de las excepciones anteriores aborta el proceso con *traceback*, sin escritura parcial ni mensaje amigable. Ver §4.

#### Flujo de ejecución

```
generar_documentacion()
 │
 ├─ 1. ruta_java ← "main/java/junit/textui/ResultPrinter.java"
 ├─ 2. open(ruta_java, 'r', utf-8) ──▶ codigo = f.read()
 ├─ 3. print("--- Procesando código de: ... ---")
 ├─ 4. client.chat.completions.create(
 │        model="google/gemini-2.0-flash-001",
 │        messages=[{system: prompt_rol}, {user: codigo}])
 ├─ 5. manual_contenido ← response.choices[0].message.content
 ├─ 6. open("MANUAL_TECNICO_JUNIT.md", 'w', utf-8) ──▶ m.write(manual_contenido)
 └─ 7. print(mensajes de confirmación)
```

#### Especificación del *prompt*

| Rol | Contenido | Propósito |
|-----|-----------|-----------|
| `system` | *"Eres un experto en ingeniería de software… generar un manual técnico detallado en español para el código Java proporcionado. Explica el propósito de la clase, sus métodos y cómo se integra en el sistema."* | Define la persona, el idioma de salida y el alcance del documento. |
| `user` | Contenido íntegro de `codigo` | Carga útil a analizar. |

---

### 2.3. Invocación a nivel de módulo

```python
generar_documentacion()
```

| Característica | Valor |
|----------------|-------|
| Ámbito | Módulo (top-level) |
| Guardia `if __name__ == "__main__":` | **Ausente** |
| Efecto | El pipeline se ejecuta tanto al correr el script (`python script.py`) como al **importarlo** desde otro módulo, generando llamadas de red y escrituras de disco no deseadas. |

---

## 3. Ejemplo de uso

### 3.1. Caso de uso real (ejecución desde CLI)

```python
# ============================================================
# Preparación del entorno
# ============================================================
#   $ pip install openai
#
# Estructura de directorios esperada (relativa al CWD):
#
#   ./
#   ├── generar_doc.py
#   └── main/
#       └── java/
#           └── junit/
#               └── textui/
#                   └── ResultPrinter.java
#
# Ejecución:
#   $ cd /ruta/al/proyecto
#   $ python generar_doc.py
#
# Salida esperada en stdout:
#   --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
#
#   ¡Documentación generada con éxito!
#   Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
#
# Artefacto producido:
#   ./MANUAL_TECNICO_JUNIT.md
# ============================================================
```

### 3.2. Invocación programática con verificación del artefacto

```python
import os

# Importar el módulo DISPARA la ejecución (no hay guardia __main__),
# por lo que la llamada explícita es redundante en el diseño actual.
from generar_doc import generar_documentacion

SALIDA = "MANUAL_TECNICO_JUNIT.md"

generar_documentacion()  # Segunda ejecución: sobrescribe el archivo

assert os.path.exists(SALIDA), "El manual no fue generado."
print(f"Tamaño del manual: {os.path.getsize(SALIDA)} bytes")

with open(SALIDA, "r", encoding="utf-8") as fh:
    print(fh.read()[:500])  # Vista previa de los primeros 500 caracteres
```

### 3.3. Ejecución defensiva (envoltorio con manejo de errores)

```python
import openai
from generar_doc import generar_documentacion

try:
    generar_documentacion()

except FileNotFoundError as exc:
    print(f"[E/S] Archivo Java no encontrado: {exc}. "
          f"Verifica el directorio de trabajo actual.")

except UnicodeDecodeError as exc:
    print(f"[E/S] El archivo no es UTF-8 válido: {exc}")

except openai.AuthenticationError:
    print("[API] Credencial de OpenRouter inválida o sin crédito.")

except openai.RateLimitError:
    print("[API] Límite de peticiones excedido. Reintenta más tarde.")

except openai.APIConnectionError as exc:
    print(f"[RED] No se pudo contactar a OpenRouter: {exc}")

except openai.BadRequestError as exc:
    print(f"[API] Petición rechazada (¿contexto excedido?): {exc}")

except (IndexError, TypeError):
    print("[API] Respuesta vacía o sin contenido textual utilizable.")
```

---

## 4. Observaciones de ingeniería y refactorización sugerida

| # | Hallazgo | Severidad | Recomendación |
|---|----------|-----------|---------------|
| 1 | `api_key` *hardcodeada* en el fuente | **Crítica** | Migrar a `os.environ["OPENROUTER_API_KEY"]` y **rotar la credencial expuesta de inmediato**. |
| 2 | Ausencia de `if __name__ == "__main__":` | Alta | Añadir la guardia para permitir importación segura del módulo. |
| 3 | Cero manejo de excepciones | Alta | Envolver E/S e inferencia en `try/except` con mensajes accionables y códigos de salida. |
| 4 | Rutas y nombre de modelo *hardcodeados* | Media | Parametrizar vía `argparse` o firma de función: `generar_documentacion(ruta_entrada, ruta_salida, modelo)`. |
| 5 | Rutas relativas dependientes del CWD | Media | Resolver con `pathlib.Path(__file__).parent / ...`. |
| 6 | `manual_contenido` puede ser `None` | Media | Validar antes de escribir: `if not manual_contenido: raise ValueError(...)`. |
| 7 | Sobrescritura silenciosa del archivo de salida | Baja | Versionar la salida (timestamp) o pedir confirmación. |
| 8 | Sin control de tamaño de entrada | Baja | Verificar longitud del `codigo` frente a la ventana de contexto del modelo antes de enviar. |
| 9 | Ausencia de *type hints* y docstring | Baja | Anotar firma (`-> None`) e incorporar el docstring de §2.2. |

### Firma refactorizada propuesta

```python
from pathlib import Path

def generar_documentacion(
    ruta_entrada: Path,
    ruta_salida: Path = Path("MANUAL_TECNICO_JUNIT.md"),
    modelo: str = "google/gemini-2.0-flash-001",
) -> Path:
    """Genera un manual técnico Markdown a partir de un archivo fuente.

    Args:
        ruta_entrada (Path): Ruta al archivo de código a documentar.
        ruta_salida (Path): Ruta destino del Markdown generado.
            Por defecto ``MANUAL_TECNICO_JUNIT.md``.
        modelo (str): Identificador del modelo en OpenRouter.

    Returns:
        Path: Ruta absoluta del archivo de manual generado.

    Raises:
        FileNotFoundError: Si ``ruta_entrada`` no existe.
        ValueError: Si el proveedor devuelve una respuesta sin contenido.
        openai.APIError: Ante cualquier fallo del proveedor de inferencia.
    """
```