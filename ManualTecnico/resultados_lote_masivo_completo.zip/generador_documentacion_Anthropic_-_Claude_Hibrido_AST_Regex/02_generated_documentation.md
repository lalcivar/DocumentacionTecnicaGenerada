# Documentación Técnica — Módulo generador de manuales técnicos vía OpenRouter

---

## 1. Resumen ejecutivo

Script de automatización que lee un archivo de código fuente Java desde el sistema de archivos local y delega su análisis a un modelo de lenguaje (`google/gemini-2.0-flash-001`) expuesto a través del endpoint compatible con OpenAI de OpenRouter. El resultado devuelto por el modelo se persiste como un manual técnico en formato Markdown (`MANUAL_TECNICO_JUNIT.md`) en el directorio de trabajo actual.

El módulo es **ejecutable por efecto secundario**: la invocación `generar_documentacion()` se realiza en el ámbito global, por lo que la importación del archivo dispara inmediatamente la lectura del fichero, la llamada remota a la API y la escritura en disco.

---

## 2. Inventario de dependencias y objetos de módulo

### 2.1 Dependencias externas

| Dependencia | Tipo | Uso en el código |
|---|---|---|
| `openai` | Paquete PyPI (SDK oficial) | Se importa la clase `OpenAI` para instanciar el cliente HTTP. |
| `open` / `print` | Builtins de Python | E/S de ficheros y trazas por consola. |

### 2.2 Objeto a nivel de módulo: `client`

| Atributo | Valor | Descripción |
|---|---|---|
| Tipo | `openai.OpenAI` | Cliente HTTP síncrono reutilizable. |
| `base_url` | `"https://openrouter.ai/api/v1"` | Redirige las peticiones al gateway de OpenRouter en lugar de la API nativa de OpenAI. |
| `api_key` | Literal embebido en el código | Credencial de autenticación Bearer. |

> **Advertencia de seguridad (hallazgo de auditoría):** la `api_key` está escrita en texto plano (*hardcoded*) dentro del código fuente. Esta credencial debe considerarse comprometida y ser revocada; su valor debería externalizarse a una variable de entorno (p. ej. `os.environ["OPENROUTER_API_KEY"]`) o a un gestor de secretos.

### 2.3 Constantes implícitas (valores mágicos)

| Valor | Ubicación | Rol |
|---|---|---|
| `"main/java/junit/textui/ResultPrinter.java"` | Variable local `ruta_java` | Ruta relativa del fichero de entrada. |
| `"google/gemini-2.0-flash-001"` | Argumento `model` | Identificador del modelo en OpenRouter. |
| `"MANUAL_TECNICO_JUNIT.md"` | Llamada a `open()` | Nombre del fichero de salida. |
| `"utf-8"` | Argumentos `encoding` | Codificación de lectura y escritura. |

---

## 3. Especificación de funciones y métodos

### 3.1 Inventario completo de funciones detectadas

El análisis estático del código fuente provisto arroja **una (1) única unidad funcional definida por el usuario**. No existen clases, métodos de instancia, métodos de clase, decoradores, funciones anidadas, callbacks ni *workers* de hilos en este módulo.

| # | Nombre | Ámbito | Tipo | Anidada | Decoradores |
|---|---|---|---|---|---|
| 1 | `generar_documentacion()` | Módulo (global) | Función | No | Ninguno |

---

### 3.2 `generar_documentacion()`

**Firma:** `generar_documentacion()`

**Propósito:** Orquesta el pipeline completo de documentación en tres fases: (1) lectura del fichero Java objetivo, (2) solicitud de análisis al modelo de lenguaje mediante `client.chat.completions.create()`, y (3) escritura del Markdown resultante en disco. Emite trazas informativas por `stdout`.

#### Parámetros de entrada

| Nombre | Tipo | Requerido | Valor por defecto | Descripción |
|---|---|---|---|---|
| — | — | — | — | La función no acepta parámetros posicionales ni por palabra clave. Toda su configuración está codificada internamente. |

#### Variables locales relevantes

| Nombre | Tipo | Descripción |
|---|---|---|
| `ruta_java` | `str` | Ruta relativa al archivo Java a analizar. |
| `f` | `TextIOWrapper` | Manejador de lectura gestionado por el bloque `with`. |
| `codigo` | `str` | Contenido íntegro del archivo Java, usado como mensaje `user`. |
| `response` | `ChatCompletion` | Objeto de respuesta devuelto por el SDK de OpenAI. |
| `manual_contenido` | `str` | Texto extraído de `response.choices[0].message.content`. |
| `m` | `TextIOWrapper` | Manejador de escritura del fichero Markdown. |

#### Valor de retorno

| Tipo | Descripción |
|---|---|
| `None` | La función no posee sentencia `return`; devuelve implícitamente `None`. Su utilidad reside en sus efectos secundarios. |

#### Efectos secundarios

| Efecto | Detalle |
|---|---|
| Lectura de disco | Abre en modo `'r'` el fichero indicado por `ruta_java`. |
| Petición de red | Invoca `POST /chat/completions` contra `https://openrouter.ai/api/v1`. |
| Escritura de disco | Crea o **sobrescribe** `MANUAL_TECNICO_JUNIT.md` (modo `"w"`). |
| Salida estándar | Imprime la traza de procesamiento y el mensaje de confirmación final. |

#### Excepciones (`Raises`)

Ninguna excepción es capturada ni relanzada explícitamente; todas se propagan al llamador.

| Excepción | Origen en el código | Condición de activación |
|---|---|---|
| `FileNotFoundError` | `open(ruta_java, 'r', ...)` | La ruta `main/java/junit/textui/ResultPrinter.java` no existe relativa al CWD. |
| `IsADirectoryError` | `open(ruta_java, 'r', ...)` | La ruta apunta a un directorio. |
| `PermissionError` | `open(...)` (lectura y escritura) | Falta de permisos de lectura sobre el `.java` o de escritura en el CWD. |
| `UnicodeDecodeError` | `f.read()` | El fichero de entrada no es decodificable como UTF-8. |
| `OSError` | `m.write(...)` | Fallo de E/S genérico (disco lleno, ruta inválida). |
| `openai.AuthenticationError` | `client.chat.completions.create()` | Clave de API inválida, revocada o sin permisos. |
| `openai.RateLimitError` | `client.chat.completions.create()` | Límite de cuota/créditos de OpenRouter excedido. |
| `openai.APIConnectionError` | `client.chat.completions.create()` | Imposibilidad de alcanzar el host (DNS, red, timeout). |
| `openai.BadRequestError` | `client.chat.completions.create()` | Modelo inexistente o contexto excedido por el tamaño de `codigo`. |
| `openai.APIStatusError` | `client.chat.completions.create()` | Cualquier respuesta HTTP 4xx/5xx no especializada. |
| `IndexError` | `response.choices[0]` | La respuesta no contiene elementos en `choices`. |
| `TypeError` | `m.write(manual_contenido)` | `message.content` es `None` (p. ej. respuesta filtrada o vacía). |

#### Docstring propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en Markdown a partir de un archivo Java.

    Lee el código fuente ubicado en `main/java/junit/textui/ResultPrinter.java`,
    lo envía al modelo `google/gemini-2.0-flash-001` a través del cliente
    OpenRouter configurado a nivel de módulo y persiste la respuesta en el
    fichero `MANUAL_TECNICO_JUNIT.md` del directorio de trabajo actual.

    La función no recibe argumentos: la ruta de entrada, el modelo, el prompt
    de sistema y el nombre del fichero de salida están codificados
    internamente. El fichero de salida se sobrescribe sin confirmación.

    Returns:
        None: La función opera exclusivamente mediante efectos secundarios
            (E/S de disco, petición de red y trazas por `stdout`).

    Raises:
        FileNotFoundError: Si la ruta del archivo Java no existe.
        PermissionError: Si no hay permisos de lectura o escritura.
        UnicodeDecodeError: Si el archivo de entrada no es UTF-8 válido.
        openai.AuthenticationError: Si la clave de API es inválida.
        openai.RateLimitError: Si se excede la cuota del proveedor.
        openai.APIConnectionError: Si falla la conexión con OpenRouter.
        openai.BadRequestError: Si el modelo es inválido o se supera la
            ventana de contexto.
        IndexError: Si la respuesta del modelo no contiene `choices`.
        TypeError: Si el contenido del mensaje devuelto es `None`.

    Example:
        >>> generar_documentacion()
        --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
        <BLANKLINE>
        ¡Documentación generada con éxito!
        Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
    """
```

---

## 4. Flujo de ejecución

```
[Import del módulo]
        │
        ├─► Instanciación de `client` (OpenAI → base_url OpenRouter)
        │
        └─► Llamada global a generar_documentacion()
                   │
                   ├─ 1. open(ruta_java) ─► codigo: str
                   ├─ 2. print(traza de inicio)
                   ├─ 3. client.chat.completions.create(model, messages=[system, user])
                   ├─ 4. response.choices[0].message.content ─► manual_contenido
                   ├─ 5. open("MANUAL_TECNICO_JUNIT.md", "w").write(manual_contenido)
                   └─ 6. print(confirmación)
```

### Estructura del payload `messages`

| Índice | `role` | `content` | Función |
|---|---|---|---|
| 0 | `system` | Instrucción fija: actuar como experto en ingeniería de software y producir un manual técnico en español. | Fija el rol, el idioma y el formato de salida. |
| 1 | `user` | Variable `codigo` (contenido del `.java`). | Aporta el material a analizar. |

---

## 5. Ejemplo de uso

### 5.1 Ejecución directa (comportamiento actual del script)

```bash
# Estructura mínima esperada en el directorio de trabajo:
# .
# ├── generar_doc.py
# └── main/java/junit/textui/ResultPrinter.java

pip install openai
python generar_doc.py
```

Salida esperada en consola:

```text
--- Procesando código de: main/java/junit/textui/ResultPrinter.java ---

¡Documentación generada con éxito!
Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```

### 5.2 Uso programático con manejo de errores

Dado que la función no recibe parámetros y se autoejecuta al importar, el consumo programático seguro requiere invocarla dentro de un bloque controlado y situar el proceso en el directorio raíz adecuado:

```python
import os
import sys

import openai

# El import dispara la ejecución automática de generar_documentacion().
# Para un control explícito, se recomienda importar únicamente el símbolo
# tras neutralizar la llamada global, o ejecutar el script como subproceso.
from generar_doc import generar_documentacion

PROYECTO_JAVA = "/ruta/al/repositorio/junit"


def main() -> int:
    """Ejecuta la generación del manual con control de errores y CWD."""
    os.chdir(PROYECTO_JAVA)  # `ruta_java` es relativa al CWD

    try:
        generar_documentacion()
    except FileNotFoundError as exc:
        print(f"[ERROR] Archivo de entrada no encontrado: {exc}", file=sys.stderr)
        return 1
    except openai.AuthenticationError:
        print("[ERROR] Clave de API inválida o revocada.", file=sys.stderr)
        return 2
    except openai.RateLimitError:
        print("[ERROR] Cuota de OpenRouter agotada.", file=sys.stderr)
        return 3
    except openai.APIConnectionError as exc:
        print(f"[ERROR] Fallo de conexión con OpenRouter: {exc}", file=sys.stderr)
        return 4
    except (IndexError, TypeError):
        print("[ERROR] Respuesta del modelo vacía o malformada.", file=sys.stderr)
        return 5

    ruta_salida = os.path.join(os.getcwd(), "MANUAL_TECNICO_JUNIT.md")
    print(f"Manual disponible en: {ruta_salida}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

---

## 6. Observaciones técnicas y recomendaciones

| Hallazgo | Severidad | Recomendación |
|---|---|---|
| Credencial `api_key` embebida en el código | **Crítica** | Revocar la clave y cargarla desde variable de entorno o `.env`. |
| Ejecución en el ámbito global (`generar_documentacion()` sin guarda) | Alta | Encapsular bajo `if __name__ == "__main__":` para permitir la importación sin efectos secundarios. |
| Parámetros fijos (`ruta_java`, `model`, fichero de salida) | Media | Promover a parámetros de función con valores por defecto o a argumentos CLI (`argparse`). |
| Ausencia de manejo de excepciones | Media | Envolver la llamada a la API y la E/S en bloques `try/except` con reintentos exponenciales para errores transitorios. |
| Sobrescritura silenciosa del fichero de salida | Baja | Validar existencia previa o versionar el nombre con *timestamp*. |
| Sin validación del tamaño de `codigo` frente a la ventana de contexto | Baja | Fragmentar (*chunking*) ficheros extensos antes del envío. |
| Función sin anotaciones de tipo ni docstring | Baja | Añadir `-> None` y el docstring propuesto en la sección 3.2. |