# Documentación Técnica - Generador de Manual con IA

## 1. Resumen Ejecutivo

Este módulo es un script de automatización que utiliza un Modelo de Lenguaje Grande (LLM) a través de la API compatible con OpenAI de OpenRouter para generar documentación técnica. Su propósito es leer el código fuente del archivo Java `main/java/junit/textui/ResultPrinter.java`, enviarlo al modelo `google/gemini-2.0-flash-001` con una instrucción de sistema especializada y persistir la respuesta generada como un manual técnico en formato Markdown (`MANUAL_TECNICO_JUNIT.md`).

El script opera a nivel de módulo, configurando un cliente global de `OpenAI` y ejecutando de forma procedural la función principal `generar_documentacion()` al ser invocado.

## 2. Especificación de Funciones y Métodos

Análisis estático del código fuente: se ha detectado **1 única función** definida. No se detectaron métodos de clase, funciones auxiliares, decoradores ni funciones anidadas/locales.

### 2.1. `generar_documentacion()`

Función principal y único punto de entrada lógico del script. Orquesta el flujo completo de lectura, inferencia y escritura.

#### Docstring Propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico para un archivo Java usando un LLM vía OpenRouter.

    Lee el contenido del archivo `main/java/junit/textui/ResultPrinter.java`,
    lo envía al modelo `google/gemini-2.0-flash-001` a través del cliente
    global `client` de OpenAI y guarda la documentación generada en el
    archivo `MANUAL_TECNICO_JUNIT.md` en el directorio de ejecución.

    El prompt del sistema instruye al modelo para actuar como experto en
    ingeniería de software y generar un manual detallado en español que
    explique el propósito de la clase, sus métodos y su integración en el
    sistema.

    Args:
        Ninguno. La función no recibe parámetros. Opera sobre rutas de
        archivo hardcodeadas y el cliente global `client`.

    Returns:
        None: La función no retorna ningún valor. Su efecto es secundario
        (side-effect) mediante operaciones de I/O y salida por consola.

    Raises:
        FileNotFoundError: Si el archivo de origen
            `main/java/junit/textui/ResultPrinter.java` no existe.
        OSError: Si ocurre un error de I/O al leer el archivo de origen o al
            escribir `MANUAL_TECNICO_JUNIT.md` (ej. permisos insuficientes).
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con
            `utf-8`.
        openai.AuthenticationError: Si la `api_key` provista al cliente es
            inválida o ha expirado.
        openai.APIConnectionError: Si falla la conexión con
            `https://openrouter.ai/api/v1`.
        openai.RateLimitError: Si se excede la cuota de peticiones de la API.
        openai.APIStatusError: Para cualquier otro error con código de estado
            HTTP 4xx o 5xx devuelto por la API.
        AttributeError / IndexError: Si la respuesta de la API tiene una
            estructura inesperada y `response.choices[0].message.content`
            no es accesible.

    Example:
        >>> generar_documentacion()
        --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
        ¡Documentación generada con éxito!
        Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
    """
```

#### Especificación Tabular

**Parámetros de Entrada**

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | La función no acepta argumentos. Utiliza valores hardcodeados internos. |

**Valores de Retorno**

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor. Realiza efectos secundarios: imprime en `stdout` y crea/sobrescribe un archivo en disco. |

**Manejo de Excepciones (`Raises`)**

| Excepción | Condición de Lanzamiento |
| :--- | :--- |
| `FileNotFoundError` | Cuando `open(ruta_java, 'r')` no encuentra la ruta `main/java/junit/textui/ResultPrinter.java`. |
| `OSError` | Error genérico de sistema de archivos al leer o escribir. |
| `UnicodeDecodeError` | Fallo al decodificar el archivo Java con `encoding='utf-8'`. |
| `openai.AuthenticationError` | `api_key` inválida, revocada o malformada. |
| `openai.APIConnectionError` | Fallo de red o imposibilidad de alcanzar `base_url`. |
| `openai.RateLimitError` | Límite de tasa (rate limit) excedido en OpenRouter. |
| `openai.APIStatusError` | Cualquier otra respuesta de error de la API (ej. modelo no encontrado, `400`, `500`). |

**Dependencias Globales**

| Nombre | Tipo | Descripción |
| :--- | :--- | :--- |
| `client` | `openai.OpenAI` | Cliente global instanciado a nivel de módulo. Configurado con `base_url="https://openrouter.ai/api/v1"` y una `api_key` hardcodeada. Es utilizado por `generar_documentacion()` para la llamada `client.chat.completions.create()`. |

> **Nota de Seguridad:** La `api_key` se encuentra expuesta directamente en el código fuente. Se recomienda externalizarla a variables de entorno (`os.getenv`) o a un gestor de secretos.

## 3. Ejemplo de Uso

El script está diseñado para ejecución directa. No requiere instanciación de clases ni paso de parámetros.

**Ejecución como script principal:**

```python
# main.py (código documentado)
from openai import OpenAI

client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="sk-or-v1-..." # Recomendado: os.environ.get("OPENROUTER_API_KEY")
)

def generar_documentacion():
    """Ver docstring completo en la sección 2.1."""
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    print(f"--- Procesando código de: {ruta_java} ---")
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {"role": "system", "content": "Eres un experto en ingeniería de software..."},
        {"role": "user", "content": codigo}
      ]
    )
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    print("\n¡Documentación generada con éxito!")

# Caso de uso real: Ejecución directa
if __name__ == "__main__":
    try:
        generar_documentacion()
        # Salida esperada en consola:
        # --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
        # ¡Documentación generada con éxito!
        # Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
    except FileNotFoundError:
        print("Error: No se encontró el archivo ResultPrinter.java. Verifique la ruta.")
    except Exception as e:
        print(f"Error al generar la documentación: {e}")
```

**Requisitos previos para el ejemplo:**
1.  `pip install openai`
2.  Existencia del archivo en la ruta relativa `main/java/junit/textui/ResultPrinter.java`.
3.  Conectividad a internet y una `api_key` válida de OpenRouter.