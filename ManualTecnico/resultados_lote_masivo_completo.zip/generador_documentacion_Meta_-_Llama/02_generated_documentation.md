# Documentación Técnica - Generador de Manual Técnico con IA

## 1. Resumen Ejecutivo

Este script automatiza la generación de documentación técnica para código fuente Java utilizando un Modelo de Lenguaje Grande (LLM) a través de la API de OpenRouter. Lee el contenido del archivo `main/java/junit/textui/ResultPrinter.java`, lo envía al modelo `google/gemini-2.0-flash-001` con una instrucción de sistema especializada y persiste la respuesta generada en un archivo Markdown denominado `MANUAL_TECNICO_JUNIT.md`.

---

## 2. Especificación de Funciones y Métodos

Análisis estático del código fuente provisto. Se detectó **una (1) única función** a nivel de módulo. No se detectaron clases, métodos de clase, decoradores ni funciones anidadas/locales.

### 2.1 `generar_documentacion()`

Función principal y único punto de lógica del script. Orquesta el flujo completo de lectura de archivo, inferencia con IA y escritura del manual técnico.

#### Docstring Propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando la API de OpenRouter.

    Lee el código fuente desde una ruta fija, lo envía al modelo
    `google/gemini-2.0-flash-001` para su análisis y guarda el contenido
    de la respuesta en un archivo Markdown de salida.

    La función utiliza el cliente global `client` configurado con `base_url`
    y `api_key` para autenticarse contra OpenRouter. No recibe parámetros
    y no retorna valores; su efecto es la creación de un archivo en el
    sistema de ficheros y la impresión de logs en consola.

    Args:
        Ninguno.

    Returns:
        None: Esta función no retorna ningún valor. El resultado se
            materializa como un efecto secundario (creación de archivo).

    Raises:
        FileNotFoundError: Si el archivo en `ruta_java`
            (`main/java/junit/textui/ResultPrinter.java`) no existe.
        IOError / OSError: Si ocurre un error durante la lectura del archivo
            de entrada o la escritura del archivo `MANUAL_TECNICO_JUNIT.md`.
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con `utf-8`.
        openai.AuthenticationError: Si la `api_key` provista en el cliente global
            es inválida o ha expirado.
        openai.APIConnectionError: Si falla la conexión de red hacia `https://openrouter.ai/api/v1`.
        openai.RateLimitError: Si se excede la cuota de peticiones de la API.
        openai.APIStatusError: Para cualquier otro error de estado HTTP devuelto por la API.
        AttributeError / IndexError: Si la respuesta de la API tiene una estructura
            inesperada y `response.choices[0].message.content` no es accesible.
    """
```

#### Especificación Detallada

**Parámetros de Entrada**

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :---: | :--- |
| *Ninguno* | - | - | La función no acepta parámetros. Opera sobre variables locales fijas (`ruta_java`) y el cliente global `client`. |

**Valores de Retorno**

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor. Produce efectos secundarios: 1) Imprime estado en `stdout` y 2) Crea/sobrescribe el archivo `MANUAL_TECNICO_JUNIT.md`. |

**Manejo de Excepciones (`Raises`)**

| Excepción | Condición que la provoca |
| :--- | :--- |
| `FileNotFoundError` | La ruta `main/java/junit/textui/ResultPrinter.java` no existe o es inaccesible. |
| `OSError` / `IOError` | Fallo de permisos de lectura/escritura o disco lleno al operar con los archivos. |
| `UnicodeDecodeError` | El archivo Java contiene caracteres no válidos para la codificación `utf-8`. |
| `openai.AuthenticationError` | `api_key` hardcodeada es inválida, revocada o malformada. |
| `openai.APIConnectionError` | Timeout o fallo de red al conectar con `base_url`. |
| `openai.RateLimitError` | Límite de tasa (rate limit) excedido en OpenRouter. |
| `openai.APIStatusError` | Cualquier otro error 4xx/5xx devuelto por el endpoint `chat.completions.create`. |

**Dependencias Globales**

| Nombre | Tipo | Descripción |
| :--- | :--- | :--- |
| `client` | `openai.OpenAI` | Cliente global instanciado a nivel de módulo. Configurado con `base_url="https://openrouter.ai/api/v1"` y `api_key`. Es consumido directamente por `generar_documentacion()`. |

> **Nota de Análisis:** No se detectaron funciones auxiliares, métodos de clase, decoradores ni funciones anidadas/locales (callbacks/workers) en el código fuente provisto. La cobertura de documentación es del 100% (1/1 funciones).

---

## 3. Ejemplo de Uso

El script está diseñado para ser ejecutado como un proceso autónomo. La invocación se realiza a nivel de módulo sin necesidad de importar.

**Requisitos previos:**
```bash
pip install openai
```

**Estructura de archivos esperada:**
```
.
├── main.py # Script documentado
└── main/java/junit/textui/ResultPrinter.java # Archivo de entrada
```

**Ejecución directa:**

```python
# main.py
from openai import OpenAI

client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="sk-or-v1-..." # Se recomienda usar variables de entorno
)

def generar_documentacion():
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    print(f"--- Procesando código de: {ruta_java} ---")
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {"role": "system", "content": "Eres un experto en ingeniería de software..."},
        {"role": "user", "content": codigo}
      ]
    )
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    print("\n¡Documentación generada con éxito!")

# Punto de entrada del script
if __name__ == "__main__":
    generar_documentacion()
```

**Ejecución desde terminal:**
```bash
python main.py
# Salida esperada:
# --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
#
# ¡Documentación generada con éxito!
# Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```

Tras la ejecución, se generará el archivo `MANUAL_TECNICO_JUNIT.md` en el directorio raíz con el manual técnico en español.
