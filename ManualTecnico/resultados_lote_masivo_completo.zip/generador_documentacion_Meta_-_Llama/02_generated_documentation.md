# Documentación Técnica - Generador de Manual Técnico con IA

## 1. Resumen Ejecutivo

Este módulo es un script de automatización que utiliza la API de OpenRouter para generar documentación técnica de código fuente Java. Su propósito es leer el archivo `main/java/junit/textui/ResultPrinter.java`, enviar su contenido al modelo `google/gemini-2.0-flash-001` mediante el cliente de OpenAI y persistir la respuesta generada por la IA en un archivo Markdown denominado `MANUAL_TECNICO_JUNIT.md`.

El script opera de forma procedural y está diseñado para una ejecución directa sin parametrización, actuando como una utilidad de una sola tarea para la ingeniería inversa y documentación asistida por IA.

---

## 2. Especificación de Funciones y Métodos

> **Análisis estático del código fuente:** Se ha detectado **1 única función** a nivel de módulo: `generar_documentacion()`. No se detectaron métodos de clase, funciones auxiliares adicionales, decoradores ni funciones anidadas/locales (callbacks, workers, etc.) en el código provisto.

### 2.1. `generar_documentacion()`

Función principal que orquesta el flujo completo de lectura, consulta a la IA y escritura del manual técnico.

#### Docstring (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando IA.

    Lee el contenido del archivo Java ubicado en `main/java/junit/textui/ResultPrinter.java`,
    lo envía como prompt a la API de OpenRouter utilizando el modelo
    `google/gemini-2.0-flash-001` y guarda la respuesta generada en el archivo
    `MANUAL_TECNICO_JUNIT.md`.

    La función utiliza el cliente global `client` (instancia de `openai.OpenAI`)
    configurado con `base_url="https://openrouter.ai/api/v1"`. No recibe
    argumentos y no retorna valores; su efecto es la creación/escritura de un
    archivo en el sistema de ficheros y la impresión de logs en consola.

    Returns:
        None: Esta función no retorna ningún valor. El resultado se persiste
            directamente en el sistema de archivos.

    Raises:
        FileNotFoundError: Si el archivo de origen `main/java/junit/textui/ResultPrinter.java`
            no existe en la ruta especificada.
        IOError: Si ocurre un error durante la lectura del archivo Java o la
            escritura del archivo `MANUAL_TECNICO_JUNIT.md` (ej. permisos insuficientes).
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con `utf-8`.
        openai.AuthenticationError: Si la `api_key` provista al cliente es inválida o ha expirado.
        openai.RateLimitError: Si se excede la cuota de peticiones de la API de OpenRouter.
        openai.APIConnectionError: Si falla la conexión de red con `https://openrouter.ai/api/v1`.
        openai.APIStatusError: Para cualquier otro error de estado HTTP retornado por la API.
    """
```

#### Parámetros de Entrada

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :---: | :--- |
| *N/A* | *N/A* | *N/A* | La función no recibe parámetros de entrada. Opera sobre rutas de archivo hardcodeadas y el cliente global `client`. |

#### Valor de Retorno

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor. El producto de la ejecución es un efecto secundario: la creación del archivo `MANUAL_TECNICO_JUNIT.md` y salida por `stdout`. |

#### Manejo de Excepciones (Raises)

| Excepción | Condición que la provoca |
| :--- | :--- |
| `FileNotFoundError` | Cuando `open(ruta_java, 'r')` no encuentra el archivo `main/java/junit/textui/ResultPrinter.java`. |
| `IOError` / `OSError` | Error de E/S al leer el archivo de origen o al escribir `MANUAL_TECNICO_JUNIT.md`. |
| `UnicodeDecodeError` | El contenido del archivo Java contiene caracteres no válidos para la codificación `utf-8`. |
| `openai.AuthenticationError` | La `api_key` configurada en el cliente global es incorrecta, revocada o malformada. |
| `openai.RateLimitError` | Se ha superado el límite de tasa (rate limit) del modelo `google/gemini-2.0-flash-001`. |
| `openai.APIConnectionError` | Fallo de conectividad o timeout al intentar alcanzar `base_url`. |
| `openai.APIStatusError` | La API responde con un código de estado 4xx/5xx no contemplado anteriormente. |

#### Dependencias Globales

| Nombre | Tipo | Descripción |
| :--- | :--- | :--- |
| `client` | `openai.OpenAI` | Cliente global instanciado a nivel de módulo. Requerido por `generar_documentacion()` para ejecutar `client.chat.completions.create()`. |

---

## 3. Ejemplo de Uso

El siguiente bloque muestra el caso de uso real y único del script: ejecución directa para generar el manual técnico. Se requiere que el archivo Java exista en la ruta relativa y que la variable `api_key` sea válida.

```python
from openai import OpenAI

# 1. Configuración del cliente (requerido a nivel de módulo)
# Nota: En producción, se recomienda cargar la api_key desde variables de entorno.
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="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", 
)

def generar_documentacion():
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    print(f"--- Procesando código de: {ruta_java} ---")
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {
          "role": "system", 
          "content": "Eres un experto en ingeniería de software. Tu tarea es generar un manual técnico detallado "
          "en español para el código Java proporcionado. Explica el propósito de la clase, sus métodos y cómo se "
          "integra en el sistema."
        },
        {"role": "user", "content": codigo}
      ]
    )
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    print("\n¡Documentación generada con éxito!")
    print("Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.")

# 2. Ejecución del caso de uso
if __name__ == "__main__":
    try:
        generar_documentacion()
        print("Proceso finalizado. Verifique el archivo MANUAL_TECNICO_JUNIT.md")
    except FileNotFoundError:
        print("Error: No se encontró el archivo ResultPrinter.java en la ruta especificada.")
    except Exception as e:
        print(f"Error durante la generación de la documentación: {e}")
```