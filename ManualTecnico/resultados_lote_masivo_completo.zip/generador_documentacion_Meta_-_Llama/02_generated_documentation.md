# Documentación Técnica - Generador de Manual Técnico con IA

## 1. Resumen Ejecutivo

Este módulo es un script de automatización que utiliza la API de OpenRouter para generar documentación técnica de forma autónoma. Su propósito es leer el código fuente de un archivo Java específico (`junit/textui/ResultPrinter.java`), enviarlo a un modelo de lenguaje grande (`google/gemini-2.0-flash-001`) con un prompt de ingeniería de software y persistir la respuesta generada como un manual técnico en formato Markdown (`MANUAL_TECNICO_JUNIT.md`).

El script opera de manera procedural y sin parametrización, ejecutando un flujo ETL simple: lectura de archivo local -> inferencia remota vía API -> escritura de archivo local.

---

## 2. Especificación de Funciones y Métodos

Análisis estático del código fuente provisto. Se detectó **1 única función** a nivel de módulo. No se detectaron clases, métodos de clase, decoradores ni funciones anidadas/locales.

### 2.1. Nivel de Módulo

El módulo inicializa una instancia global del cliente de OpenAI y ejecuta la lógica principal al ser importado/ejecutado.

**Variable Global: `client`**

Instancia del cliente `OpenAI` configurada para consumir la API de OpenRouter.

```python
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="sk-or-v1-..."
)
```
> **Nota de Seguridad:** La `api_key` se encuentra hardcodeada en el código fuente, lo cual constituye una mala práctica de seguridad. Se recomienda externalizarla a variables de entorno.

### 2.2. Función Principal: `generar_documentacion()`

Función orquestadora que ejecuta el flujo completo de generación de documentación.

#### Docstring Propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando IA.

    Lee el contenido del archivo Java ubicado en `main/java/junit/textui/ResultPrinter.java`,
    lo envía como contexto a la API de OpenRouter utilizando el modelo
    `google/gemini-2.0-flash-001` y guarda la respuesta generada por el
    modelo en un archivo Markdown local.

    El proceso consta de tres etapas: 1) Lectura del archivo fuente,
    2) Solicitud de completado de chat a la IA con un prompt de sistema
    especializado y 3) Escritura del resultado en disco.

    Args:
        Ninguno. La función no acepta parámetros. La ruta del archivo de
        entrada y salida, el modelo y el prompt están hardcodeados dentro
        de su implementación.

    Returns:
        None: La función no retorna ningún valor. Su efecto es colateral
        (side-effect): crea/sobrescribe el archivo `MANUAL_TECNICO_JUNIT.md`
        en el directorio de ejecución e imprime mensajes de estado por
        salida estándar.

    Raises:
        FileNotFoundError: Si el archivo de origen `main/java/junit/textui/ResultPrinter.java`
            no existe en la ruta especificada.
        OSError: Si ocurre un error de E/S durante la lectura del archivo Java
            o la escritura del archivo Markdown (ej. permisos insuficientes).
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con `utf-8`.
        openai.AuthenticationError: Si la `api_key` provista es inválida o ha expirado.
        openai.RateLimitError: Si se excede la cuota de peticiones de la API de OpenRouter.
        openai.APIConnectionError: Si falla la conexión de red hacia `https://openrouter.ai/api/v1`.
        openai.APIStatusError: Para cualquier otro error devuelto por la API con código de estado 4xx o 5xx.
        IndexError: Si la respuesta de la API no contiene `choices` (respuesta vacía o malformada).
        AttributeError: Si la estructura de `response.choices[0].message.content` no es la esperada.
    """
```

#### Tablas de Especificación para `generar_documentacion()`

**Parámetros de Entrada**

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | La función no define parámetros formales. Todas las dependencias son internas y hardcodeadas. |

**Valor de Retorno**

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor. Realiza operaciones de E/S y llamadas a API como efectos colaterales. |

**Manejo de Excepciones (`Raises`)**

| Tipo de Excepción | Condición que la Provoca |
| :--- | :--- |
| `FileNotFoundError` | Cuando `open(ruta_java, 'r')` no encuentra el archivo `main/java/junit/textui/ResultPrinter.java`. |
| `OSError` | Error genérico de sistema de archivos al leer o escribir (`MANUAL_TECNICO_JUNIT.md`). |
| `UnicodeDecodeError` | Si el contenido del archivo Java contiene caracteres no válidos para `utf-8`. |
| `openai.AuthenticationError` | Autenticación fallida contra OpenRouter debido a `api_key` inválida. |
| `openai.RateLimitError` | Límite de tasa (rate limit) excedido en la API. |
| `openai.APIConnectionError` | Fallo de conectividad de red o timeout hacia `base_url`. |
| `openai.APIStatusError` | La API retorna un error HTTP no contemplado en los casos anteriores. |
| `IndexError` / `AttributeError` | Si `response.choices` está vacío o la respuesta no contiene el atributo `message.content`. |

#### Funciones Anidadas / Locales y Auxiliares

Tras el análisis exhaustivo del código, se certifica que **no existen funciones anidadas, callbacks, workers de hilos, decoradores ni funciones auxiliares** dentro de `generar_documentacion()` ni en el resto del módulo. La totalidad de la lógica reside en el cuerpo secuencial de dicha función.

---

## 3. Ejemplo de Uso

El script está diseñado para ser ejecutado directamente. No requiere importación como librería, aunque puede ser adaptado para ello.

**Requisitos previos:**
```bash
pip install openai
```

**Ejecución directa como script:**

El siguiente bloque replica el caso de uso real implementado en el código. Asegúrese de que la estructura de directorios contenga el archivo Java de origen.

```python
from openai import OpenAI

# 1. Configuración del cliente (Recomendado: usar variable de entorno)
# import os
# api_key = os.environ.get("OPENROUTER_API_KEY")
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="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", 
)

def generar_documentacion():
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    print(f"--- Procesando código de: {ruta_java} ---")
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {
          "role": "system", 
          "content": "Eres un experto en ingeniería de software. Tu tarea es generar un manual técnico detallado "
          "en español para el código Java proporcionado. Explica el propósito de la clase, sus métodos y cómo se "
          "integra en el sistema."
        },
        {"role": "user", "content": codigo}
      ]
    )
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    print("\n¡Documentación generada con éxito!")
    print("Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.")

# 2. Invocación de la función principal
if __name__ == "__main__":
    try:
        generar_documentacion()
    except FileNotFoundError:
        print("Error: No se encontró el archivo ResultPrinter.java. Verifique la ruta.")
    except Exception as e:
        print(f"Error durante la generación de documentación: {e}")
```

**Salida esperada en consola:**
```
--- Procesando código de: main/java/junit/textui/ResultPrinter.java ---

¡Documentación generada con éxito!
Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```
