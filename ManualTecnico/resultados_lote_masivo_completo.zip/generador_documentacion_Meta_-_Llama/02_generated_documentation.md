# Documentación Técnica - Generador de Manual Técnico con IA

## 1. Resumen Ejecutivo

Este módulo es un script de automatización que utiliza la API de OpenRouter para generar documentación técnica a partir de código fuente Java. Su propósito es leer el archivo `main/java/junit/textui/ResultPrinter.java`, enviar su contenido al modelo `google/gemini-2.0-flash-001` con un prompt de ingeniería de software y persistir la respuesta generada por la IA en un archivo Markdown local denominado `MANUAL_TECNICO_JUNIT.md`.

El script opera a nivel de módulo mediante la inicialización de un cliente `OpenAI` configurado para OpenRouter y la ejecución directa de su única función principal.

---

## 2. Especificación de Funciones y Métodos

Análisis estático del código fuente provisto. Se detectó **1 función** a nivel de módulo. No se detectaron clases, métodos de clase, decoradores ni funciones anidadas/locales.

### 2.1. `generar_documentacion()`

Función principal y único punto de lógica del script. Orquesta el flujo completo de E/S de archivos y la llamada a la API de chat completions.

#### Docstring Propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando IA.

    Lee el contenido del archivo Java ubicado en `main/java/junit/textui/ResultPrinter.java`,
    lo envía como contexto al modelo `google/gemini-2.0-flash-001` a través del cliente
    de OpenRouter y guarda la documentación generada en `MANUAL_TECNICO_JUNIT.md`.

    La función no recibe parámetros y no retorna valores; su efecto es la creación
    de un archivo en el sistema de ficheros y la impresión de logs por consola.

    Raises:
        FileNotFoundError: Si el archivo en `ruta_java` no existe.
        OSError: Si ocurre un error de lectura/escritura durante las operaciones
            con `open()` para el archivo de entrada o salida.
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con `utf-8`.
        openai.APIError: Si la llamada a `client.chat.completions.create` falla
            por errores de autenticación, rate limit, conexión o error del servidor
            de OpenRouter.
        IndexError: Si la respuesta de la API no contiene `choices` o está vacía.
        AttributeError: Si la estructura de `response.choices[0].message.content`
            no es la esperada.

    Examples:
        >>> generar_documentacion()
        --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
        ¡Documentación generada con éxito!
        Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
    """
```

#### Especificación Detallada

**Firma:** `generar_documentacion() -> None`

**Parámetros de Entrada**

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | La función no acepta parámetros. Opera sobre variables locales hardcodeadas (`ruta_java`). |

**Valores de Retorno**

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna ningún valor. El resultado se materializa como efecto secundario: creación del archivo `MANUAL_TECNICO_JUNIT.md` y salida por `stdout`. |

**Manejo de Excepciones (Raises)**

| Excepción | Condición en la que se lanza |
| :--- | :--- |
| `FileNotFoundError` | Cuando `open(ruta_java, 'r')` no encuentra el archivo `main/java/junit/textui/ResultPrinter.java`. |
| `OSError` / `IOError` | Fallo de permisos, disco lleno o error de E/S al leer el archivo Java o al escribir `MANUAL_TECNICO_JUNIT.md`. |
| `UnicodeDecodeError` | Si el contenido del archivo Java contiene caracteres no válidos para la codificación `utf-8`. |
| `openai.AuthenticationError` | Si el `api_key` provisto al cliente `OpenAI` es inválido, expirado o revocado. |
| `openai.RateLimitError` | Si se excede la cuota de peticiones del modelo `google/gemini-2.0-flash-001` en OpenRouter. |
| `openai.APIConnectionError` | Si falla la conexión de red hacia `https://openrouter.ai/api/v1`. |
| `openai.APIError` | Error genérico del servidor de OpenRouter o del proveedor del modelo. |
| `IndexError` / `AttributeError` | Si `response.choices` está vacío o `response.choices[0].message.content` es `None`. |

**Dependencias y Variables de Módulo Relacionadas**

| Elemento | Tipo | Descripción |
| :--- | :--- | :--- |
| `client` | `openai.OpenAI` | Instancia global del cliente configurada con `base_url="https://openrouter.ai/api/v1"` y `api_key` hardcodeada. Es consumida directamente por `generar_documentacion()`. |

> **Nota de Auditoría:** No se detectaron funciones auxiliares, métodos de clase, decoradores ni funciones anidadas/locales (callbacks/workers) en el código fuente provisto. La cobertura de documentación es del 100% (1/1 funciones).

---

## 3. Ejemplo de Uso

El script está diseñado para ejecución directa. La función `generar_documentacion()` se invoca automáticamente al final del módulo.

**Ejecución como script principal:**

```python
# main.py
from openai import OpenAI

client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="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", 
)

def generar_documentacion():
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    print(f"--- Procesando código de: {ruta_java} ---")
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {
          "role": "system", 
          "content": "Eres un experto en ingeniería de software. Tu tarea es generar un manual técnico detallado "
          "en español para el código Java proporcionado. Explica el propósito de la clase, sus métodos y cómo se "
          "integra en el sistema."
        },
        {"role": "user", "content": codigo}
      ]
    )
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    print("\n¡Documentación generada con éxito!")
    print("Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.")

# Caso de uso real: Ejecución directa
if __name__ == "__main__":
    try:
        generar_documentacion()
        print("Proceso finalizado. Verifique el archivo MANUAL_TECNICO_JUNIT.md")
    except FileNotFoundError:
        print("Error: No se encontró el archivo ResultPrinter.java en la ruta especificada.")
    except Exception as e:
        print(f"Error durante la generación de la documentación: {e}")
```

**Salida esperada en consola:**

```
--- Procesando código de: main/java/junit/textui/ResultPrinter.java ---

¡Documentación generada con éxito!
Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```

