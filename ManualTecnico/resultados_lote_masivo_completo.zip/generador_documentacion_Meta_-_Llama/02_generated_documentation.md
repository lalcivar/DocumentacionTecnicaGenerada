# Documentación Técnica - Generador de Manual Técnico con IA

## 1. Resumen Ejecutivo

Este módulo es un script de automatización que utiliza la API de OpenRouter para generar documentación técnica a partir de código fuente Java. Su propósito es leer el archivo `main/java/junit/textui/ResultPrinter.java`, enviar su contenido al modelo `google/gemini-2.0-flash-001` con un prompt de ingeniería de software y persistir la respuesta generada por la IA en un archivo Markdown denominado `MANUAL_TECNICO_JUNIT.md`.

El script está diseñado para ejecutarse de forma directa y secuencial, sin exponer argumentos vía CLI ni encapsular lógica en clases, actuando como una utilidad de una sola ejecución para la documentación asistida por IA.

---

## 2. Especificación de Funciones y Métodos

Análisis estático del código fuente provisto: se ha detectado **1 única función** a nivel de módulo. No se detectaron métodos de clase, funciones auxiliares, decoradores ni funciones anidadas/locales.

### 2.1. `generar_documentacion()`

Función principal y única del módulo. Orquesta el flujo completo de lectura de código fuente, invocación a la API de LLM y escritura del manual técnico.

#### Docstring (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando IA.

    Lee el contenido del archivo Java ubicado en `main/java/junit/textui/ResultPrinter.java`,
    lo envía como contexto a la API de OpenRouter utilizando el modelo
    `google/gemini-2.0-flash-001` y guarda la documentación generada en el
    archivo `MANUAL_TECNICO_JUNIT.md`.

    La función utiliza el cliente global `client` configurado con `base_url` y
    `api_key` para autenticarse contra OpenRouter. El prompt del sistema instruye
    al modelo para actuar como experto en ingeniería de software.

    Args:
        Ninguno. La función no recibe parámetros. La ruta del archivo de entrada
        y el archivo de salida están hardcodeados dentro de su implementación.

    Returns:
        None: La función no retorna ningún valor. Su efecto es la creación/escritura
        de un archivo en el sistema de ficheros y la impresión de logs en stdout.

    Raises:
        FileNotFoundError: Si el archivo `main/java/junit/textui/ResultPrinter.java`
            no existe en la ruta especificada.
        OSError: Si ocurre un error de E/S al leer el archivo Java o al escribir
            `MANUAL_TECNICO_JUNIT.md` (ej. permisos insuficientes, disco lleno).
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con `utf-8`.
        openai.AuthenticationError: Si la `api_key` provista en el cliente global
            es inválida o ha expirado.
        openai.RateLimitError: Si se excede la cuota de peticiones de la API de OpenRouter.
        openai.APIConnectionError: Si falla la conexión de red hacia `https://openrouter.ai/api/v1`.
        openai.APIStatusError: Para cualquier otro error de estado HTTP retornado por la API.
        IndexError: Si la respuesta de la API no contiene `choices` o su estructura es inesperada
            al acceder a `response.choices[0].message.content`.
    """
```

#### Especificación Detallada

**Tabla de Parámetros**

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :---: | :--- |
| - | - | - | La función no acepta parámetros de entrada. |

**Tabla de Valores de Retorno**

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor. Produce efectos secundarios: escritura de `MANUAL_TECNICO_JUNIT.md` y salida por consola. |

**Tabla de Excepciones (Raises)**

| Excepción | Condición que la provoca |
| :--- | :--- |
| `FileNotFoundError` | Cuando `open(ruta_java, 'r')` no encuentra el archivo `ResultPrinter.java`. |
| `OSError` / `IOError` | Error genérico de sistema de archivos durante la lectura o escritura. |
| `UnicodeDecodeError` | El contenido del archivo Java contiene caracteres no válidos para `utf-8`. |
| `openai.AuthenticationError` | `api_key` inválida, revocada o malformada en la inicialización de `OpenAI()`. |
| `openai.RateLimitError` | Límite de tasa (rate limit) excedido en OpenRouter. |
| `openai.APIConnectionError` | Fallo de red, timeout o DNS al conectar con `base_url`. |
| `openai.APIStatusError` | La API retorna un código de estado HTTP 4xx/5xx no manejado específicamente. |
| `IndexError` / `AttributeError` | La estructura de `response.choices[0].message.content` es nula o inesperada. |

> **Nota sobre el alcance:** No se detectaron funciones anidadas, callbacks, workers de hilos, decoradores ni métodos de clase en el código fuente analizado. La cobertura de documentación es del 100% (1/1 funciones).

#### Dependencia Global Relevante

| Variable | Tipo | Descripción |
| :--- | :--- | :--- |
| `client` | `openai.OpenAI` | Cliente global instanciado a nivel de módulo. Configurado con `base_url="https://openrouter.ai/api/v1"` y `api_key` hardcodeada. Es consumido directamente por `generar_documentacion()`. |

---

## 3. Ejemplo de Uso

El script está diseñado para ejecución directa. No requiere importación como librería ni paso de argumentos.

**Ejecución estándar desde terminal:**

```python
# El script se ejecuta automáticamente al ser invocado,
# ya que contiene una llamada directa a la función en el nivel superior.

# 1. Asegurar que la dependencia esté instalada:
# pip install openai

# 2. Verificar que el archivo objetivo exista en la ruta esperada:
# main/java/junit/textui/ResultPrinter.java

# 3. Ejecutar el script:
# python generador_manual.py

# Salida esperada en consola:
# --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
#
# ¡Documentación generada con éxito!
# Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.

# 4. Uso programático como módulo (si se elimina la llamada final):
from generador_manual import generar_documentacion

try:
    generar_documentacion()
    print("Manual generado correctamente.")
except FileNotFoundError:
    print("Error: No se encontró el archivo Java de origen.")
except Exception as e:
    print(f"Error al generar la documentación: {e}")
```

