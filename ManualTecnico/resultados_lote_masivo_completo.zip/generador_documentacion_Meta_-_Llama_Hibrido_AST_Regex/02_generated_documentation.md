# Documentación Técnica - Generador de Manual Técnico con IA

## 1. Resumen Ejecutivo

Este módulo es un script de automatización que utiliza la API de OpenRouter (compatible con OpenAI) para generar documentación técnica automatizada. Lee el código fuente del archivo Java `main/java/junit/textui/ResultPrinter.java`, lo envía al modelo `google/gemini-2.0-flash-001` con un prompt de sistema especializado en ingeniería de software y persiste la respuesta generada en un archivo Markdown `MANUAL_TECNICO_JUNIT.md`.

El script está diseñado para ejecutarse de forma directa y desatendida, centralizando la configuración del cliente de IA y el flujo de lectura, inferencia y escritura en una única función orquestadora.

---

## 2. Especificación de Funciones y Métodos

Análisis estático del código fuente provisto: se detectó **1 única función** a nivel de módulo. No se detectaron métodos de clase, funciones auxiliares adicionales, decoradores ni funciones anidadas/locales.

### 2.1. `generar_documentacion()`

Función principal y orquestadora del script. Encapsula el flujo completo ETL de documentación: lectura del archivo fuente Java, invocación a la API de chat completions y escritura del manual técnico resultante en disco.

#### Docstring Propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando IA.

    Lee el contenido del archivo `main/java/junit/textui/ResultPrinter.java`,
    envía el código como contexto a la API de OpenRouter utilizando el modelo
    `google/gemini-2.0-flash-001` y guarda la respuesta generada en el archivo
    `MANUAL_TECNICO_JUNIT.md`.

    La función utiliza el cliente global `client` configurado con `base_url` y
    `api_key` para autenticarse contra OpenRouter. Imprime mensajes de estado
    por consola durante el procesamiento.

    Returns:
        None: Esta función no retorna ningún valor. Su efecto es la creación
            /sobrescritura del archivo `MANUAL_TECNICO_JUNIT.md` en el
            directorio de ejecución y la impresión de logs en stdout.

    Raises:
        FileNotFoundError: Si el archivo de origen `main/java/junit/textui/ResultPrinter.java`
            no existe en la ruta especificada.
        OSError: Si ocurre un error de E/S al leer el archivo Java o al escribir
            el archivo de salida `MANUAL_TECNICO_JUNIT.md` (ej. permisos insuficientes, disco lleno).
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con `utf-8`.
        openai.AuthenticationError: Si la `api_key` provista en el cliente global es inválida o expiró.
        openai.RateLimitError: Si se excede la cuota de peticiones de la API de OpenRouter.
        openai.APIConnectionError: Si falla la conexión de red hacia `https://openrouter.ai/api/v1`.
        openai.APIStatusError: Para cualquier otro error HTTP devuelto por la API (ej. 400, 500).
        IndexError: Si la respuesta de la API no contiene `choices` o está vacía.
        AttributeError: Si la estructura de `response.choices[0].message.content` no es la esperada.
    """
```

#### Tabla de Parámetros

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | La función `generar_documentacion()` no acepta parámetros de entrada. Opera sobre la ruta hardcodeada `main/java/junit/textui/ResultPrinter.java` y el cliente global `client`. |

#### Tabla de Valores de Retorno

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor. El resultado se materializa como efecto secundario: creación del archivo `MANUAL_TECNICO_JUNIT.md` con el contenido generado por el LLM. |

#### Tabla de Excepciones (Raises)

| Excepción | Causa | Contexto |
| :--- | :--- | :--- |
| `FileNotFoundError` | El archivo `main/java/junit/textui/ResultPrinter.java` no existe. | `open(ruta_java, 'r')` |
| `OSError` / `IOError` | Fallo de lectura/escritura por permisos, ruta inválida o disco lleno. | `open()` para lectura y escritura |
| `UnicodeDecodeError` | El archivo contiene caracteres no válidos para `utf-8`. | `f.read()` |
| `openai.AuthenticationError` | `api_key` inválida, revocada o malformada. | `client.chat.completions.create()` |
| `openai.RateLimitError` | Límite de tasa o cuota excedida en OpenRouter. | `client.chat.completions.create()` |
| `openai.APIConnectionError` | Error de red, DNS o timeout hacia `base_url`. | `client.chat.completions.create()` |
| `openai.APIStatusError` | Error genérico de la API (4xx/5xx). | `client.chat.completions.create()` |
| `IndexError` | `response.choices` está vacío. | `response.choices[0]` |
| `AttributeError` | La respuesta no contiene el atributo `message.content`. | `response.choices[0].message.content` |

> **Nota sobre alcance:** No se detectaron funciones anidadas/locales, callbacks, workers de hilos, decoradores ni métodos de clase dentro de `generar_documentacion()` o en el módulo. Por lo tanto, la cobertura de documentación es del 100% con esta única función.

#### Dependencia Global Relevante

| Variable | Tipo | Descripción |
| :--- | :--- | :--- |
| `client` | `openai.OpenAI` | Cliente global instanciado a nivel de módulo. Configurado con `base_url="https://openrouter.ai/api/v1"` y `api_key` hardcodeada. Es consumido directamente por `generar_documentacion()`. |

---

## 3. Ejemplo de Uso

El siguiente bloque muestra el uso real del script tal como está diseñado para ejecutarse, incluyendo una variante de importación modular y manejo de excepciones recomendado para producción.

```python
from openai import OpenAI

# 1. Configuración del cliente (recomendado usar variables de entorno)
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="sk-or-v1-..." # Cargar desde os.environ["OPENROUTER_API_KEY"]
)

def generar_documentacion():
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    
    print(f"--- Procesando código de: {ruta_java} ---")
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {
          "role": "system", 
          "content": "Eres un experto en ingeniería de software. Tu tarea es generar un manual técnico detallado "
          "en español para el código Java proporcionado. Explica el propósito de la clase, sus métodos y cómo se "
          "integra en el sistema."
        },
        {"role": "user", "content": codigo}
      ]
    )
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    
    print("\n¡Documentación generada con éxito!")

# 2. Ejecución directa con manejo de errores
if __name__ == "__main__":
    try:
        generar_documentacion()
        print("Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.")
    except FileNotFoundError:
        print("Error: No se encontró el archivo ResultPrinter.java. Verifica la ruta.")
    except Exception as e:
        print(f"Error al generar la documentación: {e}")
```