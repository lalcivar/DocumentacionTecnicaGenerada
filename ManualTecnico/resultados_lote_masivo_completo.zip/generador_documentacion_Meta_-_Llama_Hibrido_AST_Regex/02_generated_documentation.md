# Documentación Técnica - Generador de Manual Técnico con IA

## 1. Resumen Ejecutivo

Este módulo es un script de automatización que utiliza la API de OpenRouter para generar documentación técnica a partir de código fuente Java. Lee el contenido del archivo `main/java/junit/textui/ResultPrinter.java`, lo envía al modelo `google/gemini-2.0-flash-001` con un prompt de sistema especializado en ingeniería de software y persiste la respuesta generada en un archivo Markdown (`MANUAL_TECNICO_JUNIT.md`).

El script está diseñado para ejecutarse de forma directa y secuencial, sin parametrización externa, actuando como una utilidad de una sola ejecución para la documentación asistida por IA.

---

## 2. Especificación de Funciones y Métodos

### 2.1 Análisis de Cobertura

Tras el análisis estático del código fuente provisto, se ha detectado **1 única función** a nivel de módulo.

| Elemento Detectado | Nombre | Tipo |
| :--- | :--- | :--- |
| Función Principal | `generar_documentacion()` | Función a nivel de módulo |
| Clases | *No detectadas* | - |
| Métodos de Clase | *No detectados* | - |
| Funciones Anidadas / Locales | *No detectadas* | - |
| Decoradores | *No detectados* | - |

> **Nota de Cobertura 100%:** La presente documentación cubre la totalidad de las funciones existentes en el código. No se han omitido funciones auxiliares o anidadas por no existir en el fuente analizado.

### 2.2 Módulo Principal

El script opera a nivel de módulo con una variable global de configuración y una llamada de ejecución directa.

**Variable Global: `client`**
Instancia del cliente `OpenAI` configurada para consumir la API de OpenRouter.

*   `base_url (str)`: `https://openrouter.ai/api/v1`
*   `api_key (str)`: Clave de autenticación para OpenRouter.

### 2.3 Función `generar_documentacion()`

Función principal que orquesta el flujo completo de lectura, solicitud a la IA y escritura del manual técnico.

#### Docstring Propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando IA.

    Lee el código fuente del archivo `main/java/junit/textui/ResultPrinter.java`,
    envía su contenido al modelo `google/gemini-2.0-flash-001` a través del
    cliente OpenRouter y guarda la documentación generada en el archivo
    `MANUAL_TECNICO_JUNIT.md`.

    Este proceso incluye la configuración de un prompt de sistema que instruye
    al modelo a actuar como experto en ingeniería de software para explicar
    el propósito de la clase, sus métodos y su integración en el sistema.

    Args:
        Ninguno. La función no recibe parámetros; utiliza rutas de archivo
        hardcodeadas y el cliente global `client`.

    Returns:
        None: La función no retorna ningún valor. Su efecto es la creación/
        sobreescritura de un archivo en el sistema de ficheros y la impresión
        de mensajes de estado en `stdout`.

    Raises:
        FileNotFoundError: Si el archivo de origen `main/java/junit/textui/ResultPrinter.java`
            no existe en la ruta especificada.
        OSError: Si ocurre un error de E/S al leer el archivo Java o al escribir
            el archivo `MANUAL_TECNICO_JUNIT.md` (ej. permisos insuficientes).
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con `utf-8`.
        openai.AuthenticationError: Si la `api_key` proporcionada al cliente es inválida o ha expirado.
        openai.APIConnectionError: Si falla la conexión de red con `https://openrouter.ai/api/v1`.
        openai.RateLimitError: Si se excede la cuota de peticiones de la API.
        openai.APIStatusError: Para cualquier otro error de estado HTTP devuelto por la API.
        IndexError: Si la respuesta de la API no contiene `choices` o su estructura es inesperada.
        AttributeError: Si la estructura de `response.choices[0].message.content` es nula o inválida.
    """
```

#### Especificación Detallada

**Tabla de Parámetros de Entrada**

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| - | - | - | La función no acepta parámetros de entrada. |

**Tabla de Valores de Retorno**

| Tipo | Descripción |
| :--- | :--- |
| `None` | No retorna valor. Produce efectos secundarios: escritura de archivo y salida por consola. |

**Tabla de Manejo de Excepciones (Raises)**

| Excepción | Condición que la Provoca |
| :--- | :--- |
| `FileNotFoundError` | Cuando `open(ruta_java, 'r')` no encuentra el archivo `main/java/junit/textui/ResultPrinter.java`. |
| `OSError` / `IOError` | Error genérico de sistema de archivos al leer o escribir (`MANUAL_TECNICO_JUNIT.md`). |
| `UnicodeDecodeError` | Si el contenido del archivo Java contiene caracteres no válidos para la codificación `utf-8`. |
| `openai.AuthenticationError` | Clave `api_key` inválida, revocada o malformada. |
| `openai.APIConnectionError` | Fallo de conectividad, timeout o DNS al contactar `base_url`. |
| `openai.RateLimitError` | Límite de tasa (429) excedido en OpenRouter. |
| `openai.APIStatusError` | Cualquier otro error HTTP 4xx/5xx devuelto por el servicio. |
| `IndexError` / `AttributeError` | Si `response.choices` está vacío o `response.choices[0].message.content` es `None`. |

---

## 3. Ejemplo de Uso

El siguiente bloque demuestra el uso real del script como utilidad de ejecución directa. No requiere importación como módulo, se ejecuta como script principal.

```python
from openai import OpenAI

# 1. Configuración del cliente (Requerido antes de la llamada)
# Se recomienda externalizar la api_key a variables de entorno por seguridad.
client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="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", 
)

def generar_documentacion():
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    print(f"--- Procesando código de: {ruta_java} ---")
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {
          "role": "system", 
          "content": "Eres un experto en ingeniería de software. Tu tarea es generar un manual técnico detallado "
          "en español para el código Java proporcionado. Explica el propósito de la clase, sus métodos y cómo se "
          "integra en el sistema."
        },
        {"role": "user", "content": codigo}
      ]
    )
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    print("\n¡Documentación generada con éxito!")
    print("Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.")

# 2. Ejecución directa
if __name__ == "__main__":
    try:
        generar_documentacion()
    except FileNotFoundError:
        print("Error: No se encontró el archivo ResultPrinter.java. Verifique la ruta.")
    except Exception as e:
        print(f"Error durante la generación de documentación: {e}")

# Salida esperada en consola:
# --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
# ¡Documentación generada con éxito!
# Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```

**Dependencias:**
*   `openai >= 1.0.0`
*   `Python >= 3.8`