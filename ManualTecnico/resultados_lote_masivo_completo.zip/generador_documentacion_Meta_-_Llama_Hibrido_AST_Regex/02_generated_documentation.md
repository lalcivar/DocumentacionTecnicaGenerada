# Documentación Técnica - Generador de Manual Técnico con IA

## 1. Resumen Ejecutivo

Este módulo es un script de automatización que utiliza la API de OpenRouter (compatible con OpenAI) para generar documentación técnica automatizada. Lee el código fuente del archivo Java `main/java/junit/textui/ResultPrinter.java`, lo envía al modelo `google/gemini-2.0-flash-001` con un prompt de sistema especializado en ingeniería de software y persiste la respuesta generada en un archivo Markdown `MANUAL_TECNICO_JUNIT.md`.

El script está diseñado para ejecutarse de forma directa y secuencial, sin parametrización externa, actuando como una utilidad de una sola ejecución para la documentación del framework JUnit.

---

## 2. Especificación de Funciones y Métodos

Análisis estático del código fuente provisto: se ha detectado **1 única función** a nivel de módulo. No se detectaron clases, métodos de clase, decoradores ni funciones anidadas/locales.

### 2.1. `generar_documentacion()`

Función principal y única del módulo. Orquesta el flujo completo de ETL de documentación: lectura de código fuente, inferencia vía LLM y escritura del manual técnico.

#### Docstring Propuesto (Google Style / PEP 257)

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando un LLM.

    Lee el contenido del archivo `main/java/junit/textui/ResultPrinter.java`,
    lo envía al modelo `google/gemini-2.0-flash-001` a través del cliente
    OpenRouter/OpenAI y guarda la documentación generada en el archivo
    `MANUAL_TECNICO_JUNIT.md` en el directorio de ejecución.

    Esta función no recibe parámetros y no retorna valores. Opera por efectos
    secundarios (I/O de archivos, llamada a API y salida por consola).

    Raises:
        FileNotFoundError: Si el archivo `main/java/junit/textui/ResultPrinter.java`
            no existe en la ruta especificada.
        IOError / OSError: Si ocurre un error durante la lectura del archivo Java
            o la escritura del archivo `MANUAL_TECNICO_JUNIT.md`.
        UnicodeDecodeError: Si el archivo Java no puede ser decodificado con `utf-8`.
        openai.AuthenticationError: Si la `api_key` provista es inválida o ha expirado.
        openai.RateLimitError: Si se excede la cuota de peticiones de la API de OpenRouter.
        openai.APIConnectionError: Si falla la conexión de red hacia `https://openrouter.ai/api/v1`.
        openai.APIStatusError: Para cualquier otro error de estado HTTP retornado por la API.
        IndexError / AttributeError: Si la respuesta de la API no contiene el formato
            esperado en `response.choices[0].message.content`.

    Example:
        >>> generar_documentacion()
        --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
        ¡Documentación generada con éxito!
        Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
    """
```

#### Tabla de Parámetros de Entrada

| Nombre | Tipo | Requerido | Descripción |
| :--- | :--- | :---: | :--- |
| *Ninguno* | - | - | La función no acepta parámetros. Las rutas de entrada/salida y la configuración del modelo están hardcodeadas dentro de su cuerpo. |

#### Tabla de Valores de Retorno

| Tipo | Descripción |
| :--- | :--- |
| `None` | La función no retorna ningún valor. El resultado se materializa como efecto secundario: la creación/sobrescritura del archivo `MANUAL_TECNICO_JUNIT.md` y mensajes en `stdout`. |

#### Tabla de Manejo de Excepciones (Raises)

| Excepción | Condición que la provoca |
| :--- | :--- |
| `FileNotFoundError` | Cuando `open(ruta_java, 'r')` no encuentra el archivo `main/java/junit/textui/ResultPrinter.java`. |
| `OSError` / `IOError` | Fallo de permisos de lectura/escritura o disco lleno al operar con `open()`. |
| `UnicodeDecodeError` | El archivo Java contiene caracteres no válidos para la codificación `utf-8`. |
| `openai.AuthenticationError` | La `api_key` hardcodeada es incorrecta, revocada o malformada. |
| `openai.NotFoundError` | El modelo `google/gemini-2.0-flash-001` no está disponible o la `base_url` es incorrecta. |
| `openai.RateLimitError` | Se ha superado el límite de tasa (rate limit) o cuota de OpenRouter. |
| `openai.APIConnectionError` | Problemas de red, DNS o timeout al conectar con `https://openrouter.ai/api/v1`. |
| `openai.APIStatusError` | Cualquier otro error HTTP 4xx/5xx devuelto por la API. |
| `AttributeError` / `IndexError` | La estructura de `response.choices[0].message.content` es nula o inesperada (respuesta vacía del modelo). |

#### Dependencias y Variables de Módulo Relacionadas

| Elemento | Tipo | Descripción |
| :--- | :--- | :--- |
| `client` | `openai.OpenAI` | Instancia global del cliente OpenAI configurada con `base_url="https://openrouter.ai/api/v1"` y `api_key` hardcodeada. Es una dependencia implícita y obligatoria para `generar_documentacion()`. |

> **Nota de Seguridad:** La `api_key` se encuentra expuesta en texto plano en el código fuente. Se recomienda externalizarla a una variable de entorno (`os.getenv("OPENROUTER_API_KEY")`).

---

## 3. Ejemplo de Uso

El script está diseñado para ejecución directa. No requiere importación de argumentos.

**Opción A: Ejecución directa como script**

```python
# Archivo: generar_manual.py
from openai import OpenAI

client = OpenAI(
  base_url="https://openrouter.ai/api/v1",
  api_key="sk-or-v1-..." # Se recomienda usar os.environ
)

def generar_documentacion():
    ruta_java = "main/java/junit/textui/ResultPrinter.java"
    with open(ruta_java, 'r', encoding='utf-8') as f:
        codigo = f.read()
    print(f"--- Procesando código de: {ruta_java} ---")
    response = client.chat.completions.create(
      model="google/gemini-2.0-flash-001",
      messages=[
        {"role": "system", "content": "Eres un experto en ingeniería de software..."},
        {"role": "user", "content": codigo}
      ]
    )
    manual_contenido = response.choices[0].message.content
    with open("MANUAL_TECNICO_JUNIT.md", "w", encoding="utf-8") as m:
        m.write(manual_contenido)
    print("\n¡Documentación generada con éxito!")

# Punto de entrada
if __name__ == "__main__":
    try:
        generar_documentacion()
        print("Proceso finalizado. Verifique el archivo MANUAL_TECNICO_JUNIT.md")
    except FileNotFoundError as e:
        print(f"Error: No se encontró el archivo Java origen: {e}")
    except Exception as e:
        print(f"Error durante la generación de documentación: {e}")
```

**Opción B: Ejecución desde terminal**

```bash
# 1. Instalar dependencia
pip install openai

# 2. Asegurar que la estructura de archivos exista
# main/java/junit/textui/ResultPrinter.java

# 3. Ejecutar el script
python generar_manual.py

# Salida esperada en consola:
# --- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
# ¡Documentación generada con éxito!
# Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```
