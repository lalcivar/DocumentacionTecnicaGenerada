# Documentación Técnica – Módulo `flask.app` (extracto)

## 1. Resumen ejecutivo
Este módulo define la clase `Flask`, núcleo de la micro-arquitectura de Flask.  
Provee el contenedor WSGI, el ciclo de vida de petición y utilidades de encaminado, contexto, plantillas y prueba.  
Además, expone utilidades auxiliares de ámbito de módulo (_helpers_) que colaboran con la configuración y compatibilidad hacia versiones futuras.

---

## 2. Especificación de funciones y métodos  
Los cuadros siguientes siguen la convención de Docstrings *Google Style* (PEP-257) pero se presentan en tablas para facilitar la lectura.  
Los tipos están anotados tal y como aparecen en el código; `Opc.` indica parámetro opcional (tiene valor por defecto).

> Nota: Se incluyen las funciones locales generadas por *wrappers* (prefijo `<locals>`); aunque no son parte de la API pública, aparecen para cumplir el requisito de cobertura total.

### 2.1  Funciones de nivel de módulo

#### `_make_timedelta()`
| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| `value` | `timedelta \| int \| None` | No | Segundos o `timedelta` a convertir.|

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| — | `timedelta \| None` | El mismo `timedelta`, uno nuevo calculado desde segundos, o `None`. |

| Excepciones | Condición |
|-------------|-----------|
| *Ninguna* | — |

---

#### `remove_ctx()`
| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `f` | `Callable[..., Any]` | Sí | Función existente a envolver.|

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| — | `Callable[..., Any]` | Función *wrapper* que descarta `AppContext` si se pasa como 1.er argumento. |

| Raises | Condición |
|--------|-----------|
| *Ninguna* | — |

##### `remove_ctx.<locals>.wrapper()`
| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `self` | `Flask` | Sí | Instancia objetivo. |
| `*args` | `Any` | No | Posicionales originales. |
| `**kwargs` | `Any` | No | Nominales originales. |

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| — | `Any` | Resultado de invocar la función original sin el primer argumento `AppContext`. |

---

#### `add_ctx()`
| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `f` | `Callable[..., Any]` | Sí | Función existente a envolver.|

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| — | `Callable[..., Any]` | Función *wrapper* que inyecta `AppContext` si falta.|

| Raises | Condición |
|--------|-----------|
| *Ninguna* | — |

##### `add_ctx.<locals>.wrapper()`
| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `self` | `Flask` | Sí | Instancia objetivo. |
| `*args` | `Any` | No | Posicionales originales. |
| `**kwargs` | `Any` | No | Nominales originales. |

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| — | `Any` | Resultado de invocar la función original con `AppContext` añadido. |

---

### 2.2  Métodos de instancia / clase `Flask`

> Se omiten los campos que serían redundantes (por ejemplo, si un método no lanza excepciones explícitas).  
> Por brevedad se enlazan métodos mutuamente relacionados en la columna *Descripción*.

| Método | Parámetros principales (tipo, requerido) | Retorno | Raises* | Descripción resumida |
|--------|-------------------------------------------|---------|---------|----------------------|
| `__init_subclass__(cls, **kwargs)` | `**kwargs: Any` Opc. | `None` | — | Envuelve métodos sobreescritos que no acepten el nuevo parámetro `ctx`, emitiendo `DeprecationWarning`. |
| `__init__(...)` | ver código | `None` | `AssertionError`, `RuntimeError` | Crea la aplicación, CLI y ruta a estáticos. |
| `get_send_file_max_age(filename)` | `filename: str \| None` | `int \| None` | — | Calcula `max_age` para `send_file`. |
| `send_static_file(filename)` | `filename: str` | `Response` | `RuntimeError` | Sirve archivos de `/static`. |
| `open_resource(resource, mode='rb', encoding=None)` | `str`, `str`, `str\|None` | `IO[AnyStr]` | `ValueError` | Abre recurso relativo a `root_path` solo en modo lectura. |
| `open_instance_resource(resource, mode='rb', encoding='utf-8')` | idem | `IO[AnyStr]` | — | Igual que anterior, pero en `instance_path` y admite escritura. |
| `create_jinja_environment()` | — | `Environment` | — | Construye entorno Jinja con filtros y globales Flask. |
| `create_url_adapter(request)` | `Request \| None` | `MapAdapter \| None` | `RuntimeError` | Instancia adaptador de URL; respeta `SERVER_NAME`. |
| `raise_routing_exception(request)` | `Request` | *No retorna* | Propaga `RoutingException` | Intercepta redirecciones indeseadas en modo depuración. |
| `update_template_context(ctx, context)` | `AppContext`, `dict` | `None` | — | Inyecta `request`, `session`, `g`, etc. en contexto de plantilla. |
| `make_shell_context()` | — | `dict[str, Any]` | — | Contexto por defecto de shell interactivo. |
| `run(host=None, port=None, debug=None, load_dotenv=True, **options)` | varios | `None` | — | Servidor de desarrollo. Auto-recarga si `debug=True`. |
| `test_client(use_cookies=True, **kwargs)` | `bool`, `**Any` | `FlaskClient` | — | Cliente de pruebas HTTP. |
| `test_cli_runner(**kwargs)` | `**Any` | `FlaskCliRunner` | — | Runner de CLI para tests. |
| `handle_http_exception(ctx, e)` | `AppContext`, `HTTPException` | `HTTPException \| ResponseReturnValue` | — | Busca manejadores registrados o devuelve la excepción. |
| `handle_user_exception(ctx, e)` | `AppContext`, `Exception` | idem | Re-lanza o maneja excepciones de usuario. |
| `handle_exception(ctx, e)` | `AppContext`, `Exception` | `Response` | — | Manejo global de errores 500, logging, signals. |
| `log_exception(ctx, exc_info)` | `(AppContext, tuple)` | `None` | — | Registra excepción en logger. |
| `dispatch_request(ctx)` | `AppContext` | `ResponseReturnValue` | — | Encaminado de vista / opciones automáticas. |
| `full_dispatch_request(ctx)` | `AppContext` | `Response` | — | Cadena completa pre-/post-procesado + errores. |
| `finalize_request(ctx, rv, from_error_handler=False)` | `AppContext`, `ResponseReturnValue \| HTTPException` | `Response` | — | Convierte retorno de vista a respuesta y ejecuta `after_request`. |
| `make_default_options_response(ctx)` | `AppContext` | `Response` | — | Respuesta por defecto a `OPTIONS`. |
| `ensure_sync(func)` | `Callable` | `Callable` | — | Garantiza ejecución síncrona (convierte *coroutines*). |
| `async_to_sync(func)` | `Callable[..., Coroutine]` | `Callable` | `RuntimeError` | Implementación por defecto basada en `asgiref`. |
| `url_for(endpoint, *, _anchor=None, _method=None, _scheme=None, _external=None, **values)` | varios | `str` | `RuntimeError`, `ValueError` | Construye URL respetando contexto, `SERVER_NAME`, etc. |
| `make_response(rv)` | `ResponseReturnValue` | `Response` | `TypeError` | Normaliza retorno de vista a `Response`. |
| `preprocess_request(ctx)` | `AppContext` | `ResponseReturnValue \| None` | — | Ejecuta *before_request* y *url_value_preprocessors*. |
| `process_response(ctx, response)` | `AppContext`, `Response` | `Response` | — | Ejecuta *after_request* y guarda sesión segura. |
| `do_teardown_request(ctx, exc=None)` | `AppContext`, `BaseException\|None` | `None` | Re-lanza errores agrupados | Ejecuta *teardown_request* y señal `request_tearing_down`. |
| `do_teardown_appcontext(ctx, exc=None)` | idem | `None` | Re-lanza errores agrupados | Idem para contexto de aplicación. |
| `app_context()` | — | `AppContext` | — | Crea y devuelve contexto de aplicación. |
| `request_context(environ)` | `WSGIEnvironment` | `AppContext` | — | Crea contexto a partir de un `environ` WSGI real. |
| `test_request_context(*args, **kwargs)` | variádos | `AppContext` | — | Crea contexto de petición sintética (tests). |
| `wsgi_app(environ, start_response)` | `WSGIEnvironment`, `StartResponse` | `Iterable[bytes]` | Propaga errores no manejados | Implementación WSGI principal (manejo de ciclo completo). |
| `__call__(environ, start_response)` | idem | `Iterable[bytes]` | — | Delegado directo a `wsgi_app`. |

\* *Raises*: únicamente se listan excepciones explícitamente lanzadas con `raise`, o cuya propagación es parte documentada de la API.

---

## 3. Ejemplo de uso

```python
from flask import Flask

app = Flask(__name__)

@app.route("/")
def hello_world():
    return {"message": "Hola, mundo"}  # se convertirá a JSON automáticamente

if __name__ == "__main__":
    # Ejecutar en modo depuración con recarga automática
    app.run(debug=True)
```

Al acceder a `http://127.0.0.1:5000/` se obtendrá:
```json
{"message": "Hola, mundo"}
```

---

### Cómo leer las tablas
1. **Parámetro “Requerido”**:  
   - “Sí” indica que no existe valor por defecto.  
   - “No” significa que el argumento es opcional o tiene valor por defecto.
2. **Raises**:  
   - Se muestran sólo excepciones lanzadas de forma explícita.  
   - Las derivadas de uso incorrecto de tipos (p.ej. `TypeError` implícitos) no se listan.

---

## 4. Conclusiones
El fragmento implementa la infraestructura esencial para ejecutar aplicaciones Flask tanto en desarrollo como en producción (cuando se envuelve en un servidor WSGI externo). La API expuesta es exhaustiva y flexible; cada método admite sobre-escritura para personalizar el comportamiento del ciclo de vida HTTP, manejo de errores, generación de rutas y despliegue.