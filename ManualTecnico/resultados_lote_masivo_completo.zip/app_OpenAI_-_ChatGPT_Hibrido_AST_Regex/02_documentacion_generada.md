# Documentación Técnica del Módulo  
*(Estilo PEP 257 / Google)*  

---

## 1. Resumen ejecutivo
Este módulo implementa el núcleo de la clase `Flask`, el objeto WSGI que centraliza el ciclo de vida de una petición HTTP, el enrutamiento, la gestión de contexto y la conversión de valores devueltos a objetos `Response`.  
Además, expone utilidades complementarias (_helpers_) para control de errores, interoperabilidad síncrona/asíncrona y utilidades de fecha, junto con **decoradores internos** que mantienen compatibilidad binaria con firmas de métodos antiguas.

---

## 2. Especificación de funciones y métodos  

Se listan **todas** las rutinas presentes en el código, incluidas funciones internas (closures) y métodos de clase. Para cada una se detallan parámetros, valores de retorno y excepciones relevantes.  

> Convenciones:  
> • “Req.” = Requerido.  
> • Tipos compuestos se indican usando `typing` estándar.  
> • Para closures internas cuyo nombre real es `wrapper`, se indica como  
>   `remove_ctx.<wrapper>` ó `add_ctx.<wrapper>` para diferenciar.

---

### 2.1 Funciones a nivel de módulo

| Función | Parámetros (nombre:tipo:Req.) | Retorno | Excepciones (`Raises`) |
|---------|--------------------------------|---------|------------------------|
| `_make_timedelta()` | `value: timedelta | int | None : Sí` | `timedelta | None` | – |
| `remove_ctx()` | `f: Callable[..., Any] : Sí` | `Callable` (wrapper) | – |
| `remove_ctx.<wrapper>()` | `self: Flask : Sí`  `*args: Any` `**kwargs: Any` | `Any` (lo que retorne `f`) | – |
| `add_ctx()` | `f: Callable[..., Any] : Sí` | `Callable` (wrapper) | – |
| `add_ctx.<wrapper>()` | `self: Flask : Sí` `*args: Any` `**kwargs: Any` | `Any` | – |

---

### 2.2 Clase `Flask`

Para brevedad, se omite la herencia (`App`) en cada cabecera.

#### 2.2.1  Métodos especiales

| Método | Parámetros | Retorno | Raises |
|--------|------------|---------|--------|
| `__init_subclass__(**kwargs)` | `cls: Type[Flask]` (implícito) | `None` | – |
| `__init__(...)` | Ver firma completa en código (todos con defecto). | `None` | `AssertionError` (config. estática) |

#### 2.2.2  API pública principal

| Método | Parámetros | Retorno | Raises |
|--------|------------|---------|--------|
| `get_send_file_max_age(filename)` | `filename:str|None` | `int|None` | – |
| `send_static_file(filename)` | `filename:str` | `Response` | `RuntimeError` si no hay carpeta estática |
| `open_resource(resource, mode="rb", encoding=None)` | `resource:str` `mode:str` `encoding:str|None` | `IO[AnyStr]` | `ValueError` (modo inválido) |
| `open_instance_resource(resource, mode="rb", encoding="utf-8")` | idem | `IO[AnyStr]` | – |
| `create_jinja_environment()` | – | `Environment` | – |
| `create_url_adapter(request)` | `request:Request|None` | `MapAdapter|None` | – |
| `raise_routing_exception(request)` | `request:Request` | `NoReturn` | `RoutingException` ó `FormDataRoutingRedirect` |
| `update_template_context(ctx, context)` | `ctx:AppContext` `context:dict` | `None` | – |
| `make_shell_context()` | – | `dict[str,Any]` | – |
| `run(host=None, port=None, debug=None, load_dotenv=True, **options)` | – | `None` | – |
| `test_client(use_cookies=True, **kwargs)` | – | `FlaskClient` | – |
| `test_cli_runner(**kwargs)` | – | `FlaskCliRunner` | – |
| `url_for(endpoint, *, _anchor=None, _method=None, _scheme=None, _external=None, **values)` | – | `str` | `ValueError`, `RuntimeError`, `BuildError` |

#### 2.2.3  Manejo de errores y despacho

| Método | Parámetros | Retorno | Raises |
|--------|------------|---------|--------|
| `handle_http_exception(ctx,e)` | `ctx:AppContext` `e:HTTPException` | `HTTPException | ResponseReturnValue` | – |
| `handle_user_exception(ctx,e)` | `ctx:AppContext` `e:Exception` | idem | Reraise excepción original si sin handler |
| `handle_exception(ctx,e)` | `ctx:AppContext` `e:Exception` | `Response` | Reraise según `PROPAGATE_EXCEPTIONS` |
| `log_exception(ctx, exc_info)` | `ctx:AppContext` `exc_info:tuple` | `None` | – |
| `dispatch_request(ctx)` | `ctx:AppContext` | `ResponseReturnValue` | `RoutingException` |
| `full_dispatch_request(ctx)` | `ctx:AppContext` | `Response` | – |
| `finalize_request(ctx, rv, from_error_handler=False)` | … | `Response` | Propaga excepción en pos-procesado |
| `make_default_options_response(ctx)` | `ctx:AppContext` | `Response` | – |

#### 2.2.4  Utilidades síncronas/asíncronas

| Método | Parámetros | Retorno | Raises |
|--------|------------|---------|--------|
| `ensure_sync(func)` | `func:Callable` | `Callable` (sync) | – |
| `async_to_sync(func)` | `func: Callable[..., Coroutine]` | `Callable` | `RuntimeError` (asgiref faltante) |

#### 2.2.5  Conversión de respuesta

| Método | Parámetros | Retorno | Raises |
|--------|------------|---------|--------|
| `make_response(rv)` | `rv: ResponseReturnValue` | `Response` | `TypeError` (casos inválidos) |

#### 2.2.6  Hooks de petición / teardown

| Método | Parámetros | Retorno | Raises |
|--------|------------|---------|--------|
| `preprocess_request(ctx)` | `ctx:AppContext` | `ResponseReturnValue|None` | – |
| `process_response(ctx, response)` | … | `Response` | – |
| `do_teardown_request(ctx, exc=None)` | … | `None` | Acumula y lanza errores al final |
| `do_teardown_appcontext(ctx, exc=None)` | … | `None` | idem |

#### 2.2.7  Gestión de contextos

| Método | Parámetros | Retorno | Raises |
|--------|------------|---------|--------|
| `app_context()` | – | `AppContext` | – |
| `request_context(environ)` | `environ:WSGIEnvironment` | `AppContext` | – |
| `test_request_context(*args, **kwargs)` | – | `AppContext` | – |

#### 2.2.8  Implementación WSGI

| Método | Parámetros | Retorno | Raises |
|--------|------------|---------|--------|
| `wsgi_app(environ, start_response)` | … | `Iterable[bytes]` | Propaga excepción según flujo |
| `__call__(environ, start_response)` | … | `Iterable[bytes]` | – |

---

## 3. Ejemplo de uso

```python
from pathlib import Path
from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello, World!"

@app.route("/echo/<msg>")
def echo(msg: str):
    # Acceso a parámetros y creación de JSON
    return jsonify(echo=msg, query=dict(request.args))

if __name__ == "__main__":
    # Levantar servidor de desarrollo en 0.0.0.0:8000
    app.run(host="0.0.0.0", port=8000, debug=True)
```

El ejemplo muestra:
1. Definición de rutas mediante `@app.route`.
2. Conversión automática de diccionarios a JSON vía `Flask.make_response`.
3. Puesta en marcha del servidor de desarrollo con recarga automática (`debug=True`).