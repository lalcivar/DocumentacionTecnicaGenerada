# Documentación Técnica (Estilo Google / PEP 257)

## 1. Resumen ejecutivo
Este módulo implementa la clase `Flask`, núcleo del framework homónimo, encargada de gestionar el ciclo de vida completo de una aplicación WSGI: enrutamiento, contexto, renderizado de plantillas, sesiones, señales y gestión de errores.  
Además, provee utilidades auxiliares para facilitar la conversión de valores, la manipulación de contextos y la creación de wrappers que garantizan compatibilidad binaria entre distintas versiones del API.

---

## 2. Especificación detallada

Las tablas siguientes describen exhaustivamente **todas** las funciones, métodos y wrappers presentes en el código fuente.  
Las firmas mostradas corresponden al **runtime**, es decir, después de aplicar los decoradores.

> Leyenda columnas (Parámetros)  
> • **Nombre** – Parámetro posicional o keyword.  
> • **Tipo** – Anotación de tipo exacta.  
> • **Req.** – ¿Requerido? (✔︎ = sí, ✖︎ = no).  
> • **Def.** – Valor por defecto cuando *Req.* = ✖︎.

---

### 2.1 Funciones de módulo

#### `_make_timedelta(value)`
| Nombre | Tipo | Req. | Def. | Descripción |
|--------|------|------|------|-------------|
| `value` | `timedelta | int | None` | ✖︎ | `None` | Segundos o `timedelta` a convertir. |
| **Returns** | `timedelta | None` – El mismo objeto si ya es `timedelta`, un nuevo `timedelta(seconds=value)` o `None`. |
| **Raises** | *N/A* |

---

#### `remove_ctx(f)`
Decorador que elimina un argumento `ctx: AppContext` obsoleto desde las llamadas internas a un método sobrecargado.

| Nombre | Tipo | Req. | Def. |
|--------|------|------|------|
| `f` | `Callable[..., Any]` | ✔︎ | — |

| **Returns** | `Callable[..., Any]` – Versión envuelta de `f`. |
| **Raises** | *N/A* |

##### `wrapper(self, *args, **kwargs)`  *(función local)*
| Nombre | Tipo | Req. | Def. |
|--------|------|------|------|
| `self` | `Flask` | ✔︎ | — |
| `*args` | `Any` | ✖︎ | — |
| `**kwargs` | `Any` | ✖︎ | — |
| **Returns** | `Any` – Resultado de `f(...)`. |
| **Raises** | Propaga cualquier excepción de `f`. |

---

#### `add_ctx(f)`
Decorador complementario que **inyecta** el argumento `ctx` cuando falta, manteniendo compatibilidad con implementaciones antiguas que llamen a `super()`.

| Nombre | Tipo | Req. |
|--------|------|------|
| `f` | `Callable[..., Any]` | ✔︎ |

| **Returns** | `Callable[..., Any]` |
| **Raises** | *N/A* |

##### `wrapper(self, *args, **kwargs)`  *(función local)*
Parámetros y comportamiento idénticos al `wrapper` anterior, pero añade `ctx` al `*args` en caso necesario.

---

### 2.2 Clase `Flask`

A continuación se listan **todos** los métodos públicos, especiales y de soporte. Los métodos heredados sin redefinir no se documentan porque no aparecen en el fragmento.

> Para brevedad, las entradas **Returns** y **Raises** indican únicamente diferencias respecto al flujo “feliz”; los errores no listados deben considerarse propagados.

---

#### `Flask.__init_subclass__(cls, **kwargs)`
| Nombre | Tipo | Req. | Def. |
|--------|------|------|------|
| `cls` | `type[Flask]` | ✔︎ | — |
| `**kwargs` | `Any` | ✖︎ | — |
| **Returns** | `None` |
| **Raises** | `DeprecationWarning` (emitido) cuando la subclase sobre-escribe ciertos métodos con la firma antigua. |

---

#### `Flask.__init__(...)`
| Nombre | Tipo | Req. | Def. |
|--------|------|------|------|
| `import_name` | `str` | ✔︎ | — |
| `static_url_path` | `str | None` | ✖︎ | `None` |
| `static_folder` | `str | os.PathLike | None` | ✖︎ | `'static'` |
| `static_host` | `str | None` | ✖︎ | `None` |
| `host_matching` | `bool` | ✖︎ | `False` |
| `subdomain_matching` | `bool` | ✖︎ | `False` |
| `template_folder` | `str | os.PathLike | None` | ✖︎ | `'templates'` |
| `instance_path` | `str | None` | ✖︎ | `None` |
| `instance_relative_config` | `bool` | ✖︎ | `False` |
| `root_path` | `str | None` | ✖︎ | `None` |
| **Returns** | `None` |
| **Raises** | `AssertionError` si `static_host` y `host_matching` son inconsistentes. |

---

#### `get_send_file_max_age(filename)`
| Nombre | Tipo | Req. |
|--------|------|------|
| `filename` | `str | None` | ✔︎ |
| **Returns** | `int | None` – Segundos de caché o `None`. |
| **Raises** | *N/A* |

---

#### `send_static_file(filename)`
| Nombre | Tipo | Req. |
|--------|------|------|
| `filename` | `str` | ✔︎ |
| **Returns** | `flask.wrappers.Response` |
| **Raises** | `RuntimeError` si `static_folder` no está configurada. |

---

#### `open_resource(resource, mode='rb', encoding=None)`
| Nombre | Tipo | Req. | Def. |
|--------|------|------|------|
| `resource` | `str` | ✔︎ | — |
| `mode` | `str` | ✖︎ | `'rb'` |
| `encoding` | `str | None` | ✖︎ | `None` |
| **Returns** | `IO[AnyStr]` – Archivo abierto. |
| **Raises** | `ValueError` si `mode` no es solo-lectura. |

---

#### `open_instance_resource(resource, mode='rb', encoding='utf-8')`
| Igual que el anterior, relativo a `instance_path`. Permite modos de escritura.

| **Raises** | Propaga excepciones estándar de `open`. |

---

#### `create_jinja_environment()`
| **Returns** | `flask.templating.Environment` configurado. |
| **Raises** | *N/A* |

---

#### `create_url_adapter(request)`
| Nombre | Tipo | Req. | Def. |
|--------|------|------|------|
| `request` | `flask.wrappers.Request | None` | ✖︎ | `None` |
| **Returns** | `werkzeug.routing.MapAdapter | None` |
| **Raises** | *N/A* |

---

#### `raise_routing_exception(request)`
| Nombre | Tipo | Req. |
|--------|------|------|
| `request` | `flask.wrappers.Request` | ✔︎ |
| **Raises** | `werkzeug.routing.RoutingException` • `FormDataRoutingRedirect` |

---

#### `update_template_context(ctx, context)`
| Nombre | Tipo | Req. |
|--------|------|------|
| `ctx` | `AppContext` | ✔︎ |
| `context` | `dict[str, Any]` | ✔︎ |
| **Returns** | `None` |

---

#### `make_shell_context()`
| **Returns** | `dict[str, Any]` – Variables iniciales para el REPL. |

---

#### `run(host=None, port=None, debug=None, load_dotenv=True, **options)`
| Parámetros principales detallados en docstring original. |
| **Returns** | `None` |
| **Raises** | `RuntimeError` de Werkzeug; diversas según servidor. |

---

#### `test_client(use_cookies=True, **kwargs)`
| **Returns** | `flask.testing.FlaskClient` |
| **Raises** | *N/A* |

---

#### `test_cli_runner(**kwargs)`
| **Returns** | `flask.testing.FlaskCliRunner` |

---

#### `handle_http_exception(ctx, e)`
| Nombre | Tipo | Req. |
|--------|------|------|
| `ctx` | `AppContext` | ✔︎ |
| `e` | `werkzeug.exceptions.HTTPException` | ✔︎ |
| **Returns** | `HTTPException | ResponseReturnValue` |
| **Raises** | Propaga `RoutingException` sin procesar. |

---

#### `handle_user_exception(ctx, e)`
| Igual que el anterior, pero para excepciones genéricas.  
| **Raises** | Re-lanza `e` cuando no existe manejador. |

---

#### `handle_exception(ctx, e)`
| **Returns** | `flask.wrappers.Response` (código 500) |
| **Raises** | Re-lanza si `PROPAGATE_EXCEPTIONS` = `True`. |

---

#### `log_exception(ctx, exc_info)`
| **Returns** | `None` – Solo registra en el logger de la app. |

---

#### `dispatch_request(ctx)`
| **Returns** | `ResponseReturnValue` |
| **Raises** | Re-lanza errores de enrutado mediante `raise_routing_exception`. |

---

#### `full_dispatch_request(ctx)`
| **Returns** | `flask.wrappers.Response` |

---

#### `finalize_request(ctx, rv, from_error_handler=False)`
| **Returns** | `flask.wrappers.Response` |

---

#### `make_default_options_response(ctx)`
| **Returns** | `flask.wrappers.Response` pre-poblada con cabecera `Allow`. |

---

#### `ensure_sync(func)`
| Nombre | Tipo | Req. |
|--------|------|------|
| `func` | `Callable[..., Any]` | ✔︎ |
| **Returns** | `Callable[..., Any]` – Versión síncrona (envuelta si era async). |

---

#### `async_to_sync(func)`
| Nombre | Tipo | Req. |
|--------|------|------|
| `func` | `Callable[..., Coroutine]` | ✔︎ |
| **Returns** | `Callable[..., Any]` |
| **Raises** | `RuntimeError` si falta `asgiref`. |

---

#### `url_for(endpoint, *, _anchor=None, _method=None, _scheme=None, _external=None, **values)`
| Parámetros idénticos a los documentados en el código. |
| **Returns** | `str` – URL generada. |
| **Raises** | `ValueError`, `RuntimeError`, `BuildError`. |

---

#### `make_response(rv)`
| Nombre | Tipo | Req. |
|--------|------|------|
| `rv` | `ResponseReturnValue` | ✔︎ |
| **Returns** | `flask.wrappers.Response` |
| **Raises** | `TypeError` si `rv` no es convertible a respuesta. |

---

#### `preprocess_request(ctx)`
| **Returns** | `ResponseReturnValue | None` |

---

#### `process_response(ctx, response)`
| **Returns** | `flask.wrappers.Response` |

---

#### `do_teardown_request(ctx, exc=None)`
| **Returns** | `None` |
| **Raises** | Propaga excepción agrupada de `_CollectErrors`. |

---

#### `do_teardown_appcontext(ctx, exc=None)`
| Igual que el anterior, pero para el contexto de aplicación. |

---

#### `app_context()`
| **Returns** | `AppContext` listo para `with ...:` |

---

#### `request_context(environ)`
| **Returns** | `AppContext` |

---

#### `test_request_context(*args, **kwargs)`
| **Returns** | `AppContext` |

---

#### `wsgi_app(environ, start_response)`
| **Returns** | `Iterable[bytes]` |
| **Raises** | Propaga la excepción no gestionada de la vista si corresponde. |

---

#### `__call__(environ, start_response)`
Alias directo a `wsgi_app`.

---

### 3. Ejemplo de uso

```python
from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route("/hello/<name>")
def hello(name: str):
    """Saluda a un usuario por su nombre."""
    return jsonify(message=f"Hola, {name}!"), 200

if __name__ == "__main__":
    # Ejecución sólo en desarrollo
    app.run(debug=True)
```

Uso en pruebas:

```python
def test_hello():
    app.testing = True
    client = app.test_client()

    response = client.get("/hello/Ada")
    assert response.status_code == 200
    assert response.json == {"message": "Hola, Ada!"}
```

---

© Flask core excerpt – documentación generada automáticamente.