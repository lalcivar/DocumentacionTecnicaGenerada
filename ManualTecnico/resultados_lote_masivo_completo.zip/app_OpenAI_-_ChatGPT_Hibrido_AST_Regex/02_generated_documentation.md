# Documentación técnica del módulo (Google Style / PEP 257)

## 1. Resumen ejecutivo
El módulo extiende y adapta la clase `Flask` original para añadir mejoras internas de compatibilidad, control de contexto y utilidades de desarrollo.  
Aporta además funciones auxiliares para el tratamiento de *timedeltas* y dos decoradores (`remove_ctx`, `add_ctx`) que sirven como *shims* de compatibilidad entre firmas antiguas y nuevas de métodos sobre-escritos por el usuario. Todo el código sigue siendo un WSGI-application plenamente compatible, pero añade compatibilidad con *async/await*, CLI y pruebas.

---

## 2. Especificación de funciones y métodos

Las tablas siguientes listan **todas** las funciones, métodos y funciones locales detectadas en el código suministrado.

> Nota:  
> • «Req.» indica si el argumento es obligatorio.  
> • Los tipos siguen las anotaciones presentes en el código.  
> • Cuando una función no documenta excepciones propias, se listan las que *puede* propagar directamente.

### 2.1 Funciones a nivel de módulo

| Función | Descripción breve |
|---------|-------------------|
| `_make_timedelta()` | Convierte enteros (segundos) en `timedelta` homogéneo. |
| `remove_ctx()` | Decorador shim que **elimina** el parámetro `ctx` añadido en versiones nuevas cuando la implementación del usuario aún usa la firma antigua. |
| &nbsp;&nbsp;└── `wrapper()` | Función local que re-inyecta argumentos y llama a la función original. |
| `add_ctx()` | Decorador inverso que **añade** el parámetro `ctx` si la sobre-escritura del usuario no lo incluyó. |
| &nbsp;&nbsp;└── `wrapper()` | Función local que construye el argumento `AppContext` que falta. |

#### `_make_timedelta(value)`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `value` | `timedelta | int | None` | Sí | Valor original que se normaliza. |
| **Return** | `timedelta | None` | — | Misma instancia o un `timedelta` nuevo. |
| **Raises** | — | — | — |

#### `remove_ctx(f) -> F`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `f` | `Callable[..., Any]` | Sí | Función a envolver. |
| **Return** | `Callable[..., Any]` | — | Nueva función sin el primer arg. `ctx` si aparece. |
| **Raises** | — | — | — |

##### `wrapper(self, *args, **kwargs)`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `self` | `Flask` | Sí | Instancia de la clase. |
| `*args` | `Any` | No | Args posicionales. |
| `**kwargs` | `Any` | No | Args nombrados. |
| **Return** | `Any` | — | Resultado de `f`. |
| **Raises** | Las que propague `f`. |

La misma especificación se aplica simétricamente a `add_ctx()` y su `wrapper()`.

---

### 2.2 Métodos de la clase `Flask`

Se documentan en orden alfabético (excepto `__call__`, `__init__`, `__init_subclass__`, colocados al final de la lista).

#### `app_context()`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| (sin) | — | — | — |
| **Return** | `AppContext` | — | Nuevo contexto de aplicación. |
| **Raises** | — | — | — |

---

#### `async_to_sync(func)`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `func` | `Callable[..., Coroutine[Any, Any, Any]]` | Sí | Corrutina a convertir. |
| **Return** | `Callable[..., Any]` | — | Función síncrona equivalente. |
| **Raises** | `RuntimeError` si no está instalado `asgiref`. |

---

#### `create_jinja_environment()`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| (sin) | — | — | — |
| **Return** | `Environment` | — | Entorno Jinja2 configurado. |
| **Raises** | — | — | — |

---

#### `create_url_adapter(request)`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `request` | `Request | None` | Sí | Petición asociada o `None` (modo out-of-request). |
| **Return** | `MapAdapter | None` | — | Adaptador de URL o `None` si no es posible. |
| **Raises** | — | — | Puede propagar `RuntimeError` indirectamente si `SERVER_NAME` falta. |

---

#### `dispatch_request(ctx)`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| **Return** | `ResponseReturnValue` | — | Resultado crudo de la vista. |
| **Raises** | Excepciones del *view function*, `RoutingException`. |

---

#### `do_teardown_appcontext(ctx, exc=None)`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `ctx` | `AppContext` | Sí | Contexto de aplicación. |
| `exc` | `BaseException | None` | No | Excepción no controlada (si la hubo). |
| **Return** | `None` | — | — |
| **Raises** | Propaga errores agrupados mediante `_CollectErrors.raise_any`. |

---

#### `do_teardown_request(ctx, exc=None)`

(Similar a `do_teardown_appcontext`, pero para contexto de **petición**.)

---

#### `ensure_sync(func)`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| `func` | `Callable[..., Any]` | Sí | Función (sync o async) a normalizar. |
| **Return** | `Callable[..., Any]` | — | Siempre función síncrona. |
| **Raises** | — | — | — |

---

#### `finalize_request(ctx, rv, from_error_handler=False)`

| Parámetro | Tipo | Req. |
|-----------|------|------|
| `ctx` | `AppContext` | Sí |
| `rv` | `ResponseReturnValue | HTTPException` | Sí |
| `from_error_handler` | `bool` | No |
| **Return** | `Response` |
| **Raises** | Vuelve a propagar errores salvo que `from_error_handler` sea `True`. |

---

#### `full_dispatch_request(ctx)`

Realiza la cadena completa de *pre-, dispatch y post-process*, manejando excepciones.

| Parámetro | Tipo | Req. |
|-----------|------|------|
| `ctx` | `AppContext` | Sí |
| **Return** | `Response` |
| **Raises** | Excepciones no gestionadas del usuario. |

---

#### `get_send_file_max_age(filename)`

| Parámetro | Tipo | Req. |
|-----------|------|------|
| `filename` | `str | None` | Sí |
| **Return** | `int | None` | Segundos de caché o `None`. |
| **Raises** | — |

---

#### `handle_exception(ctx, e)`

| Parámetro | Tipo | Req. |
|-----------|------|------|
| `ctx` | `AppContext` | Sí |
| `e` | `Exception` | Sí |
| **Return** | `Response` |
| **Raises** | Re-lanza `e` si `PROPAGATE_EXCEPTIONS` = True. |

---

#### `handle_http_exception(ctx, e)`

(Análogo pero para sub-tipo `HTTPException`.)

---

#### `handle_user_exception(ctx, e)`

(Gestiona excepciones no‐HTTP personalizadas.)

---

#### `log_exception(ctx, exc_info)`

Registra en `logger.error`. No retorna valor ni lanza excepción expresa.

---

#### `make_default_options_response(ctx)`

Devuelve respuesta vacía con cabecera `Allow`.

---

#### `make_response(rv)`

Convertidor polimórfico → instancia de `Response`.

| Param. | Tipo | Req. | Descripción breve |
|--------|------|------|-------------------|
| `rv` | `ResponseReturnValue` | Sí | Resultado crudo proveniente de la vista. |
| **Return** | `Response` | — | Objeto normalizado. |
| **Raises** | `TypeError` en variedad de inconsistencias de formato. |

---

#### `make_shell_context()`

Devuelve diccionario de contexto (`{'app': app, 'g': g, …}`).

---

#### `open_instance_resource()` / `open_resource()`

Apertura segura de ficheros relativos a `instance_path` o `root_path`.

| Función | Modo escritura | Extra |
|---------|----------------|-------|
| `open_resource` | Solo lectura (`r/rt/rb`). | Valida modo. |
| `open_instance_resource` | Lectura/Escritura. | — |

Ambas pueden propagar `ValueError` (en modo inválido) o `IOError`.

---

#### `preprocess_request(ctx)`

Ejecuta *url value preprocessors* y *before_request*; puede cortar flujo.

| Return | `ResponseReturnValue | None` |

---

#### `process_response(ctx, response)`

Aplica *after_request*, guarda sesión y devuelve respuesta final.

---

#### `raise_routing_exception(request)`

Convierte algunos `RequestRedirect` a error 400 en modo *debug*.

---

#### `request_context(environ)` / `test_request_context(...)`

Construyen y devuelven `AppContext` para depuración / pruebas.

---

#### `run(**options)`

Arranca servidor de desarrollo (`werkzeug.serving.run_simple`).

| Parámetro destacado | Tipo | Descripción |
|--------------------|------|-------------|
| `host` | `str | None` | Host a enlazar. |
| `port` | `int | None` | Puerto. |
| `debug` | `bool | None` | Fuerza modo debug. |
| `load_dotenv` | `bool` | Lee `.env` / `.flaskenv`. |
| `**options` | `Any` | Passthrough a `run_simple`. |
| **Raises** | — | Propaga de Werkzeug. |

---

#### `send_static_file(filename)`

Sirve un recurso de `static_folder` mediante `send_from_directory`.

| Raises | `RuntimeError` si `static_folder` no está configurado. |

---

#### `test_cli_runner(**kwargs)` / `test_client(...)`

Facilitan entorno de pruebas para CLI y HTTP respectivamente.

---

#### `update_template_context(ctx, context)`

Inyecta variables estándar y *context processors* en un `dict` de contexto.

---

#### `url_for(endpoint, *, _anchor=None, _method=None, _scheme=None, _external=None, **values)`

Generación de URLs interna/externa. Propaga `BuildError` salvo que
`handle_url_build_error` devuelva *fallback*.

---

#### `wsgi_app(environ, start_response)` y `__call__()`

`__call__` es *thin wrapper* que delega en `wsgi_app`.

| Raises | Propaga excepciones de la propia aplicación salvo manejo interno descrito. |

---

#### Constructores y meta-hooks

| Método | Propósito | Raises |
|--------|-----------|--------|
| `__init__(...)` | Configuración de la app, CLI y ruta estática. | `AssertionError` si `static_host` / `host_matching` inconsistentes. |
| `__init_subclass__(cls, **kwargs)` | Envuelve métodos heredados con firmas antiguas y emite `DeprecationWarning`. | — |

---

## 3. Ejemplo de uso

```python
from pathlib import Path
from flask_mod import Flask   # ← módulo documentado

app = Flask(__name__, static_folder=Path(__file__).parent / "public")

@app.route("/")
def index():
    return {"status": "ok"}   # dict ⇒ JSON automatico

@app.cli.command("hello")
def hello_cmd():
    """Comando CLI de ejemplo."""
    click.echo("Hola desde la CLI!")

if __name__ == "__main__":
    # Carga .env, activa recarga automática y sale banner.
    app.run(debug=True)
```

En pruebas:

```python
def test_healthcheck():
    app.testing = True
    with app.test_client() as client:
        res = client.get("/")
        assert res.status_code == 200
        assert res.get_json() == {"status": "ok"}
```

---

## 4. Observaciones finales
1. Los decoradores `remove_ctx` y `add_ctx` son internos; no deben usarse en código de aplicación salvo que se extienda Flask manualmente.  
2. Los métodos que aceptan un parámetro `ctx: AppContext` son la versión **nueva** de la API y deberán mantenerse para compatibilidad futura.  
3. Para permitir vistas `async def`, instale el extra `pip install flask[async]` (dependencia `asgiref`).