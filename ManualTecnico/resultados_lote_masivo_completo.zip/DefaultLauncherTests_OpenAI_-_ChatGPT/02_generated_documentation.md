# DefaultLauncherTests  

## 1. Resumen ejecutivo  
La clase `DefaultLauncherTests` agrupa un conjunto de pruebas de integración que validan el comportamiento interno de la implementación por defecto del `Launcher` de JUnit Platform.  Todas las pruebas verifican cómo el `Launcher` interactúa con motores de prueba (`TestEngine`), filtros, parámetros de configuración y listeners durante las fases de descubrimiento (`discover`) y ejecución (`execute`).  Además, se incluyen utilidades privadas de apoyo y un `record` interno (`ReportedData`) para simplificar la verificación de resultados.

---

## 2. Especificación de constructores y métodos  

La tabla siguiente recoge **todos** los métodos (públicos, protegidos, package-private, privados, estáticos y de clases internas) definidos explícitamente en el código fuente.  Para cada uno se listan parámetros, valor de retorno y excepciones documentadas.

> Nota: Los métodos generados implícitamente por el `record ReportedData` (por ejemplo, `testPlan()`, `startTime()`, etc.) no se detallan porque son sintetizados por el compilador y no forman parte del código fuente declarado.

### Leyenda de columnas
* **Requerido** — Sí: el argumento no puede ser `null`; No: admite `null`.

---

### 2.1 Constructores

| Método (visibilidad) | @param | @return | @throws |
|----------------------|--------|---------|---------|
| `DefaultLauncherTests()` (package) | – | Instancia de la clase | – |
| `ReportedData(TestPlan, TestIdentifier, TestExecutionResult, Instant, Instant)` (private, record) | Véase campos del record | Instancia inmutable | – |

---

### 2.2 Métodos de prueba (@Test, @ParameterizedTest, etc.)

Debido a la extensión de la clase, los métodos se agrupan alfabéticamente.

| Método | Parámetros | @return | @throws |
|--------|------------|---------|---------|
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` | – | void | AssertionError si la aserción falla |
| `assertImposter(String id)` (private) | id :String (Sí) | void | AssertionError si la aserción falla |
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` (private) | testEngine :TestEngine (Sí)<br>inOrder :InOrder (Sí)<br>discoveryListener :LauncherDiscoveryListener (Sí) | void | AssertionError si la aserción falla |
| `constructLauncherWithoutAnyEngines()` | – | void | AssertionError |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | – | void | AssertionError |
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | – | void | AssertionError |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)` | throwableClass :Class&lt;? extends Throwable&gt; (Sí) | void | AssertionError |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | – | void | AssertionError |
| `discoverTestPlanForMultipleEngines()` | – | void | AssertionError |
| `discoverTestPlanForSingleEngine()` | – | void | AssertionError |
| `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | – | void | AssertionError |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | – | void | AssertionError |
| `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()` | – | void | AssertionError |
| `failsIfCriticalSeverityIsConfiguredIncorrectly()` | – | void | AssertionError |
| `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` | – | void | AssertionError |
| `launcherAppliesPostDiscoveryFilters()` | – | void | AssertionError |
| `launcherCanExecuteTestPlanExactlyOnce()` | – | void | AssertionError |
| `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)` | listener :LogRecordListener (Sí) | void | AssertionError |
| `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)` | listener :LogRecordListener (Sí) | void | AssertionError |
| `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)` | listener :LogRecordListener (Sí) | void | AssertionError |
| `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)` | phase :String (Sí)<br>listener :LogRecordListener (Sí) | void | AssertionError |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | – | void | AssertionError |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | – | void | AssertionError |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | – | void | AssertionError |
| `reportsDynamicTestDescriptorsCorrectly()` | – | void | AssertionError |
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)` | listener :LogRecordListener (Sí) | void | AssertionError |
| `reportsEngineExecutionFailureForSelectorResolutionFailure()` | – | void | AssertionError |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | – | void | AssertionError |
| `reportsEngineExecutionFailuresForFailedFinishedEngine()` | – | void | AssertionError |
| `reportsEngineExecutionFailuresForSkippedEngine()` | – | void | AssertionError |
| `reportsEngineExecutionFailuresForStartedEngine()` | – | void | AssertionError |
| `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` | – | void | AssertionError |
| `reportsEngineExecutionFailuresWithoutPriorEvents()` | – | void | AssertionError |
| `reportsFinishedEngines()` | – | void | AssertionError |
| `reportsSkippedEngines()` | – | void | AssertionError |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` | – | void | AssertionError |
| `thirdPartyEngineClaimingToBeVintageResultsInException()` | – | void | AssertionError |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | – | void | AssertionError |
| `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()` | – | void | AssertionError |
| `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | – | void | AssertionError |
| `withAdditionalListener()` | – | void | AssertionError |
| `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()` | – | void | AssertionError |

---

### 2.3 Métodos utilitarios estáticos/privados

| Método | Parámetros | @return | @throws |
|--------|------------|---------|---------|
| `execute(TestEngine engine)` (private static) | engine :TestEngine (Sí) | ReportedData | – |
| `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer)` (private static) | engine :TestEngine (Sí)<br>discoveryConfigurer :UnaryOperator&lt;LauncherDiscoveryRequestBuilder&gt; (Sí) | ReportedData | – |
| `execute(TestEngine engine, UnaryOperator<LauncherDiscoveryRequestBuilder> discoveryConfigurer, UnaryOperator<LauncherExecutionRequestBuilder> executionConfigurer)` (private static) | engine :TestEngine (Sí)<br>discoveryConfigurer :UnaryOperator&lt;LauncherDiscoveryRequestBuilder&gt; (Sí)<br>executionConfigurer :UnaryOperator&lt;LauncherExecutionRequestBuilder&gt; (Sí) | ReportedData | – |
| `findFirstDiscoveryIssueLogRecord(LogRecordListener listener, Level level)` (private static) | listener :LogRecordListener (Sí)<br>level :Level (Sí) | LogRecord | NoSuchElementException si no existe registro |

---

## 3. Ejemplo de uso

Aunque la clase está pensada para ser ejecutada por el runner de JUnit Jupiter, puede instanciarse y usarse manualmente en un entorno de pruebas embebidas.

```java
import org.junit.platform.launcher.core.DefaultLauncherTests;

public class LauncherSmokeTest {

    public static void main(String[] args) {
        DefaultLauncherTests tests = new DefaultLauncherTests();

        // Ejecutamos una de las pruebas de forma imperativa.
        // Cualquier fallo lanzará AssertionError.
        tests.constructLauncherWithoutAnyEngines();

        // También podríamos ejecutar otras pruebas
        tests.discoverEmptyTestPlanWithEngineWithoutAnyTests();

        System.out.println("Smoke-test OK – todas las aserciones superadas.");
    }
}
```

---

@author  
JUnit Platform Contributors (2015–2026)