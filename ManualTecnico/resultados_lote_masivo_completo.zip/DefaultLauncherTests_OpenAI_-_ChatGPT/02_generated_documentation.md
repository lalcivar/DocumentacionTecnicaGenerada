# DefaultLauncherTests

## 1. Resumen ejecutivo
La clase `DefaultLauncherTests` valida de punta a punta la implementación por defecto de `org.junit.platform.launcher.Launcher`.  
Mediante un conjunto exhaustivo de pruebas parametrizadas y utilidades “stub/spy”, comprueba la correcta creación del plan de pruebas, la fase de descubrimiento, la fase de ejecución y la notificación de incidencias y eventos a los distintos “listeners”.  

## 2. Especificación detallada de métodos y constructores

Las tablas siguientes siguen la semántica estándar de Javadoc.

> Nota: todos los métodos son `void`, a menos que se indique lo contrario en la columna **@return**.  
> Para los métodos que propagan aserciones JUnit o Mockito, no se documenta un `@throws` específico; las excepciones son parte del flujo de prueba.

### Métodos públicos (JUnit @ Test / @ ParameterizedTest)

| Método | @param (nombre : tipo) | Requerido | @return | @throws (principales) | Propósito resumido |
|--------|-----------------------|-----------|---------|-----------------------|--------------------|
| `constructLauncherWithoutAnyEngines()` | – | – | `void` | – | Verifica que el `Launcher` falle cuando no se registran motores. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | – | – | `void` | `JUnitException` | Comprueba la detección de ids de motores duplicados. |
| `discoverEmptyTestPlanWithEngineWithoutAnyTests()` | – | – | `void` | – | Garantiza que un motor sin casos produce un plan con un solo “root”. |
| `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()` | – | – | `void` | – | Cubre el caso en el que el motor devuelve `null` como root descriptor. |
| `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)` | `throwableClass : Class<? extends Throwable>` | Sí | `void` | – | Simula errores críticos en la fase de descubrimiento. |
| `reportsEngineExecutionFailuresWithoutPriorEvents()` | – | – | `void` | – | Chequea el reporte de fallos de ejecución sin eventos previos. |
| `reportsEngineExecutionFailuresForSkippedEngine()` | – | – | `void` | – | Verifica el tratamiento de motores que se auto‐omiten (`executionSkipped`). |
| `reportsEngineExecutionFailuresForStartedEngine()` | – | – | `void` | – | Verifica fallos lanzados tras `executionStarted`. |
| `reportsEngineExecutionFailuresForSuccessfullyFinishedEngine()` | – | – | `void` | – | Verifica fallos lanzados tras un resultado “SUCCESSFUL”. |
| `reportsEngineExecutionFailuresForFailedFinishedEngine()` | – | – | `void` | – | Verifica fallos adicionales cuando el motor ya finalizó con “FAILED”. |
| `reportsSkippedEngines()` | – | – | `void` | – | Asegura la correcta notificación de motores totalmente saltados. |
| `reportsFinishedEngines()` | – | – | `void` | – | Comprueba la secuencia de eventos para motores que terminan con éxito. |
| `discoverTestPlanForSingleEngine()` | – | – | `void` | – | Descubrimiento con un solo motor y dos pruebas. |
| `discoverTestPlanForMultipleEngines()` | – | – | `void` | – | Descubrimiento simultáneo con múltiples motores. |
| `launcherAppliesPostDiscoveryFilters()` | – | – | `void` | – | Verifica la aplicación y poda de filtros “post-discovery”. |
| `withoutConfigurationParameters_LauncherPassesEmptyConfigurationParametersIntoTheExecutionRequest()` | – | – | `void` | – | Comprueba que, por defecto, no hay parámetros de configuración. |
| `withConfigurationParameters_LauncherPassesPopulatedConfigurationParametersIntoTheExecutionRequest()` | – | – | `void` | – | Verifica la propagación de parámetros personalizados. |
| `withoutConfigurationParameters_LookupFallsBackToSystemProperty()` | – | – | `void` | – | Evalúa la búsqueda fallback en `System.getProperty`. |
| `withAdditionalListener()` | – | – | `void` | – | Comprueba el registro dinámico de `TestExecutionListener`s. |
| `prunesTestDescriptorsAfterApplyingPostDiscoveryFilters()` | – | – | `void` | – | Evalúa la poda de nodos excluidos tras filtros. |
| `reportsDynamicTestDescriptorsCorrectly()` | – | – | `void` | – | Garantiza la correcta notificación de pruebas dinámicas. |
| `launcherCanExecuteTestPlanExactlyOnce()` | – | – | `void` | `IllegalStateException` | Asegura que un `TestPlan` sólo puede ejecutarse una vez. |
| `thirdPartyEngineUsingReservedEngineIdPrefixEmitsDiscoveryIssue()` | – | – | `void` | `DiscoveryIssueException` | Verifica aviso al usar prefijo `junit-` reservado. |
| `thirdPartyEngineClaimingToBeJupiterResultsInException()` | – | – | `void` | `JUnitException` | Bloquea motores que usurpan ID `junit-jupiter`. |
| `thirdPartyEngineClaimingToBeVintageResultsInException()` | – | – | `void` | `JUnitException` | Bloquea motores que usurpan ID `junit-vintage`. |
| `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()` | – | – | `void` | – | Valida el modo *dry-run* (ejecución simulada). |
| `notifiesDiscoveryListenersOfProcessedSelectors()` | – | – | `void` | – | Comprueba la propagación de eventos `selectorProcessed`. |
| `reportsEngineExecutionFailureForCriticalDiscoveryIssuesAndLogsRemaining(LogRecordListener listener)` | `listener : LogRecordListener` | Inyectado por extensión | `void` | – | Verifica fallos por “critical discovery issues” y logging residual. |
| `logsNonCriticalIssuesForRegularEngineExecution(LogRecordListener listener)` | `listener : LogRecordListener` |  | `void` | – | Comprueba que los *issues* no críticos sólo se registran. |
| `logsAllIssuesForDiscoveryFailure(LogRecordListener listener)` | `listener : LogRecordListener` |  | `void` | – | Verifica el logging de *issues* en un fallo de descubrimiento. |
| `logsNonCriticalIssuesForExecutionFailure(LogRecordListener listener)` | `listener : LogRecordListener` |  | `void` | – | Comprueba el logging de *issues* cuando la ejecución falla. |
| `reportsEngineExecutionFailureOnUnresolvedUniqueIdSelectorWithEnginePrefix()` | – | – | `void` | – | Falla cuando el selector Unresolved pertenece al motor. |
| `ignoresUnresolvedUniqueIdSelectorWithoutEnginePrefix()` | – | – | `void` | – | Ignora selectors Unresolved que pertenecen a otro motor. |
| `reportsEngineExecutionFailureForSelectorResolutionFailure()` | – | – | `void` | – | Asegura fallo cuando `Engine` lanza excepción al resolver selector. |
| `allowsConfiguringCriticalDiscoveryIssueSeverity()` | – | – | `void` | – | Permite parametrizar la severidad “crítica”. |
| `failsIfCriticalSeverityIsConfiguredIncorrectly()` | – | – | `void` | `JUnitException` | Valida error de configuración con severidad inválida. |
| `failsDuringDiscoveryIfConfigurationParameterIsSetAccordingly()` | – | – | `void` | `DiscoveryIssueException` | Permite abortar en fase de descubrimiento vía parámetro. |
| `logsNonCriticalIssuesOnlyOnce(String phase, LogRecordListener listener)` | `phase : String`<br>`listener : LogRecordListener` | Sí | `void` | – | Garantiza que los avisos no críticos se registran una sola vez. |
| `failsDuringDiscoveryIfConfigurationParameterValueIsInvalid()` | – | – | `void` | `JUnitException` | Verifica validación de valores permitidos para el parámetro. |
| `reportsChildrenOfEngineDescriptorAsSkippedAfterCancellationWasRequested()` | – | – | `void` | – | Asegura que tras cancelación se marcan los hijos como *skipped*. |

### Métodos privados de apoyo

| Método | @param | Req. | @return | Descripción corta |
|--------|--------|------|---------|-------------------|
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | ver firma | Sí | `void` | Agrupa las aserciones que validan un descubrimiento fallido. |
| `assertImposter(String id)` | `id : String` | Sí | `void` | Reutilizado por pruebas que validan motores “impostores”. |
| `execute(TestEngine)` | `engine : TestEngine` | Sí | `ReportedData` | Wrapper de conveniencia para descubrimiento+ejecución. |
| `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>)` | idem + `discoveryConfigurer` | Sí | `ReportedData` | Permite inyectar configuración de descubrimiento. |
| `execute(TestEngine, UnaryOperator<LauncherDiscoveryRequestBuilder>, UnaryOperator<LauncherExecutionRequestBuilder>)` | idem + `executionConfigurer` | Sí | `ReportedData` | Configuración completa de fases discovery/execution. |
| `findFirstDiscoveryIssueLogRecord(LogRecordListener, Level)` | `listener : LogRecordListener`<br>`level : Level` | Sí | `LogRecord` | Devuelve el primer registro asociado a `DiscoveryIssueNotifier`. |

#### Tipo interno `ReportedData`
Registro estático que encapsula:
* `TestPlan testPlan`
* `TestIdentifier testIdentifier`
* `TestExecutionResult testExecutionResult`
* `Instant startTime`
* `Instant finishTime`

No tiene lógica adicional: los *accessors* auto-generados (`testPlan()`, `startTime()`, etc.) se omiten por ser triviales.

## 3. Ejemplo de uso

```java
// Ejemplo minimalista: lanzar un engine “stub” y obtener el TestPlan
TestEngine myEngine = new TestEngineStub("my-engine-id");
Launcher launcher = LauncherFactoryForTestingPurposesOnly.createLauncher(myEngine);

// 1. Descubrimiento
LauncherDiscoveryRequest discoveryRequest = LauncherDiscoveryRequestBuilder.request()
        .selectors(DiscoverySelectors.selectPackage("com.acme"))
        .build();
TestPlan testPlan = launcher.discover(discoveryRequest);

// 2. Ejecución
TestExecutionListener listener = new SummaryGeneratingListener();
LauncherExecutionRequest executionRequest = LauncherExecutionRequestBuilder.request(testPlan)
        .listeners(listener)
        .build();
launcher.execute(executionRequest);

// 3. Inspección de resultados
SummaryGeneratingListener summary = (SummaryGeneratingListener) listener;
System.out.printf("Tests ejecutados: %d, fallidos: %d%n",
        summary.getSummary().getTestsSucceededCount(),
        summary.getSummary().getTestsFailedCount());
```

© 2026 – Generated automatically.