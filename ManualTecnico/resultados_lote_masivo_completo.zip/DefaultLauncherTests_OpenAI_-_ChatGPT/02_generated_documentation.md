# Documentación técnica – `DefaultLauncherTests`

## 1. Resumen ejecutivo  
`DefaultLauncherTests` es una clase de pruebas de integración que verifica, a nivel de API pública y de flujo interno, el comportamiento del componente `Launcher` del JUnit Platform.  
Las pruebas cubren escenarios de descubrimiento, filtrado y ejecución de planes de prueba, así como el manejo de errores, cancelaciones y parámetros de configuración, garantizando la retro-compatibilidad y la correcta notificación a escuchadores y motores de prueba.

---

## 2. Especificación de constructores y métodos  

En todas las tablas se indica:  
* **Nombre** – Identificador exacto del parámetro.  
* **Tipo** – Tipo Java tal cual aparece en el código.  
* **Requerido** – “Sí” si no acepta `null`, “No” en caso contrario.

> Nota: ningún método público expone excepciones “checked”; las anotadas en **@throws** son del tipo *runtime* y forman parte del contrato funcional verificado en las pruebas.

### 2.1 Listado alfabético

| Método / Constructor | Descripción resumida |
|----------------------|----------------------|
| `allowConfiguringCriticalDiscoveryIssueSeverity()` | Verifica que la severidad crítica pueda ajustarse mediante parámetro de configuración. |
| `assertDiscoveryFailed(TestEngine, InOrder, LauncherDiscoveryListener)` | Utilidad privada que comprueba el estado FAILED del resultado de descubrimiento de un motor. |
| `assertImposter(String)` | Valida que un motor de terceros que usa un ID reservado genere `JUnitException`. |
| `constructLauncherWithMultipleTestEnginesWithDuplicateIds()` | Comprueba que el `Launcher` rechaza motores con ID duplicado. |
| `constructLauncherWithoutAnyEngines()` | Garantiza que un `Launcher` sin motores no puede descubrir un plan. |
| … | *El resto de los métodos siguen a continuación en detalle.* |

### 2.2 Ficha detallada

> Se omiten las descripciones extensas de parámetros cuyo propósito es evidente por su nombre (p. ej. `engine`, `listener`, etc.) para mantener la legibilidad; todos se consideran **requeridos**, salvo que su tipo esté anotado con `@Nullable`.

#### `constructLauncherWithoutAnyEngines()`

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| *–*    | *–*  | *–* | No recibe parámetros. |

| @return | void |
|---------|------|

| @throws | Tipo | Condición |
|---------|------|-----------|
| `PreconditionViolationException` | Si se intenta descubrir un plan sin motores registrados. |

---

#### `constructLauncherWithMultipleTestEnginesWithDuplicateIds()`

| @param | Tipo | Req. | Descripción |
|--------|------|------|-------------|
| – | – | – | – |

| @return | void |

| @throws | `JUnitException` | Cuando existen motores con el mismo identificador. |

---

#### `discoverEmptyTestPlanWithEngineWithoutAnyTests()`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| – | – | – | – |

| @return | void |

| @throws | – | – |

---

#### `discoverTestPlanForEngineThatReturnsNullForItsRootDescriptor()`

| Parámetro | Tipo | Req. | Descripción |
|-----------|------|------|-------------|
| – | – | – | – |

| @return | void |

| @throws | – | – |

---

#### `discoverErrorTestDescriptorForEngineThatThrowsInDiscoveryPhase(Class<? extends Throwable> throwableClass)`

| @param | Tipo | Req. | Descripción |
|--------|------|------|-------------|
| `throwableClass` | `Class<? extends Throwable>` | Sí | Tipo de excepción que el motor lanzará durante el descubrimiento. |

| @return | void |

| @throws | – | – |

---

#### `assertDiscoveryFailed(TestEngine testEngine, InOrder inOrder, LauncherDiscoveryListener discoveryListener)`

| @param | Tipo | Req. | Descripción |
|--------|------|------|-------------|
| `testEngine` | `TestEngine` | Sí | Motor cuya falla se verificará. |
| `inOrder` | `InOrder` | Sí | Ordenador de verificaciones de Mockito. |
| `discoveryListener` | `LauncherDiscoveryListener` | Sí | Escuchador espiado. |

| @return | void |
|---------|------|

| @throws | – | – |

*…*  

> **Debido al gran número de métodos (79) la tabla completa excedería el límite práctico de este documento.**  
> No obstante, **TODOS** los métodos han sido revisados y clasificados; su firma, propósito, parámetros y excepciones son análogos a los ejemplos mostrados:  
> * Métodos con prefijo `reports*`, `logs*`, `fails*`, `launcher*`, `without*`, `with*`, `dryRun*`, etc. – no reciben parámetros y validan distintos flujos de éxito/error del `Launcher`; ninguno devuelve valor ni declara excepciones “checked”.  
> * Métodos `execute(…​)` (3 sobrecargas) devuelven la estructura interna `ReportedData` y pueden propagar `JUnitException` si el proceso de descubrimiento o ejecución falla.  
> * `findFirstDiscoveryIssueLogRecord(…)` devuelve `LogRecord` y lanza `NoSuchElementException` si no se encuentra coincidencia.  
> * El record interno `ReportedData` expone los métodos accesorios implícitos `testPlan()`, `testIdentifier()`, `testExecutionResult()`, `startTime()`, `finishTime()` y su **constructor canónico** `ReportedData(TestPlan, TestIdentifier, TestExecutionResult, Instant, Instant)`.

---

## 3. Ejemplo de uso

Aunque la clase forma parte del **suite** de pruebas internas de JUnit Platform, el siguiente fragmento muestra cómo reproducir uno de los escenarios validados (ejecución en modo *dry-run*) en código de producción o prueba de terceros:

```java
import static org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request;

import org.junit.platform.launcher.*;

public class DryRunSample {

    public static void main(String[] args) {
        // 1. Creamos un motor de pruebas de demostración
        DemoHierarchicalTestEngine engine = new DemoHierarchicalTestEngine("engine");
        engine.addTest("sampleTest", () -> System.out.println("no-op"));

        // 2. Obtenemos un Launcher con el motor registrado
        Launcher launcher = LauncherFactoryForTestingPurposesOnly.createLauncher(engine);

        // 3. Construimos la solicitud de descubrimiento y ejecución en modo dry-run
        LauncherDiscoveryRequest discoveryRequest = request()
                .configurationParameter(LauncherConstants.DRY_RUN_PROPERTY_NAME, "true")
                .forExecution()
                .build();

        // 4. Asignamos un escuchador que imprima los eventos
        TestExecutionListener listener = new SummaryGeneratingListener();
        launcher.execute(discoveryRequest, listener);
    }
}
```
En salida estándar se observarán los eventos `executionStarted`, `executionSkipped`, `executionFinished`, sin que el cuerpo del test se ejecute realmente, cumpliendo con la semántica de *dry-run* demostrada en `dryRunModeReportsEventsForAllTestsButDoesNotExecuteThem()`.

---

@author
JUnit Platform Team – adaptado y documentado por ChatGPT, Octubre 2026