# Documentación Técnica del Módulo

## 1. Resumen ejecutivo
Este módulo automatiza la generación de manuales técnicos en formato Markdown a partir de archivos fuente Java.  
Para ello, crea un cliente OpenAI apuntando a `openrouter.ai`, lee un archivo Java específico y envía su contenido a un modelo conversacional (`google/gemini-2.0-flash-001`).  
El resultado devuelto por la IA se persiste como `MANUAL_TECNICO_JUNIT.md`.

---

## 2. Especificación de funciones y métodos

### `generar_documentacion()`
Docstring (Google Style):

```python
def generar_documentacion():
    """Genera un manual técnico en Markdown a partir de un archivo Java.

    El flujo consta de cuatro pasos:
      1. Lee el archivo `main/java/junit/textui/ResultPrinter.java`.
      2. Envía su contenido a un modelo LLM alojado en OpenRouter.
      3. Recibe y almacena la respuesta en `MANUAL_TECNICO_JUNIT.md`.
      4. Muestra mensajes de control en consola.

    Raises:
        FileNotFoundError: Si el archivo Java no existe en la ruta indicada.
        PermissionError: Si no se tienen permisos de lectura/escritura de archivos.
        openai.OpenAIError: Si ocurre un error en la llamada a la API de OpenAI.
        OSError: Errores genéricos del sistema de archivos distintos a los anteriores.
    """
```

Tabla de parámetros

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| *─*       | *─*  | *─*       | La función no recibe argumentos. |

Tabla de retorno

| Tipo | Descripción |
|------|-------------|
| `None` | No retorna ningún valor explícito. El efecto principal es la creación del archivo Markdown. |

Tabla de excepciones (`Raises`)

| Excepción | Condición de disparo |
|-----------|---------------------|
| `FileNotFoundError` | El archivo Java indicado no se encuentra. |
| `PermissionError` | Falta de permisos de lectura/escritura. |
| `openai.OpenAIError` | Error genérico devuelto por la librería `openai`. |
| `OSError` | Otros problemas de E/S (ej. espacio insuficiente, fichero bloqueado). |

---

## 3. Ejemplo de uso

```python
"""
Ejemplo mínimo de ejecución del módulo.

Requisitos previos:
1. Instalar dependencias:
   pip install openai
2. Definir la variable de entorno (opcional) o sustituir la clave API por una válida.
"""

from generador_manual import generar_documentacion  # suponiendo que el archivo se llame generador_manual.py

if __name__ == "__main__":
    try:
        generar_documentacion()
    except Exception as exc:  # Captura genérica para logging
        print(f"Ocurrió un error al generar la documentación: {exc}")
```

---

© 2024. Documento generado conforme a los lineamientos de PEP 257 y Google Python Style Guide.