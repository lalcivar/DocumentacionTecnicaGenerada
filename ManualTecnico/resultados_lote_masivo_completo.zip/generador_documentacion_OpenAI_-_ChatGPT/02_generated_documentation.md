# Documentación Técnica del Módulo  
(Estilo Google / PEP 257)

---

## 1. Resumen ejecutivo
Este script automatiza la generación de un manual técnico en formato Markdown para un archivo Java (`ResultPrinter.java`) utilizando la API de OpenAI.  
El flujo consiste en leer el código fuente, enviar una solicitud de chat al modelo `google/gemini-2.0-flash-001` y almacenar la respuesta en `MANUAL_TECNICO_JUNIT.md`.

---

## 2. Especificación de funciones y métodos

### `generar_documentacion()`
```python
def generar_documentacion():
    """Genera un manual técnico en Markdown para un archivo Java.

    El proceso consta de:
      1. Leer el archivo Java indicado.
      2. Enviar el contenido leído a un modelo de chat (Gemini 2.0 Flash) a
         través de la API de OpenAI.
      3. Persistir la respuesta del modelo en un archivo `.md`.
      4. Informar por consola el éxito de la operación.

    Returns
    -------
    None

    Raises
    ------
    FileNotFoundError
        Si la ruta `main/java/junit/textui/ResultPrinter.java`
        no existe o no se puede encontrar.
    PermissionError
        Si no hay permisos para leer el archivo Java o escribir
        el archivo de salida.
    openai.APIStatusError
        Cualquier error HTTP devuelto por la API de OpenAI
        durante la llamada `chat.completions.create`.
    openai.APITimeoutError
        Si la petición a la API excede el tiempo de espera.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| *No recibe parámetros* |

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| `None`  | `NoneType` | La función se ejecuta por sus efectos secundarios. |

| Excepción | Condición de disparo |
|-----------|---------------------|
| `FileNotFoundError` | El archivo Java indicado no se encuentra. |
| `PermissionError` | Falta de permisos de lectura/escritura. |
| `openai.APIStatusError` | Respuesta de error HTTP de la API. |
| `openai.APITimeoutError` | Tiempo de espera excedido. |

---

## 3. Ejemplo de uso

```python
"""
Ejemplo de invocación directa del script.
Se asume que el archivo Java y la clave API son válidos
y que las dependencias (`openai`) están instaladas.
"""
from my_module import generar_documentacion   # Ajustar al nombre real del módulo

if __name__ == "__main__":
    try:
        generar_documentacion()
    except Exception as exc:
        print(f"Error al generar la documentación: {exc}")
```

---

### Notas adicionales
1. El cliente `OpenAI` se instancia a nivel de módulo con la URL de OpenRouter y la clave API correspondiente.  
2. La ejecución de `generar_documentacion()` ocurre en tiempo de importación; si se desea evitarlo, encapsular la llamada en un bloque `if __name__ == "__main__":`.  
3. Se recomienda almacenar la clave API en variables de entorno y recuperarla mediante `os.getenv` para mejorar la seguridad.