# Documentación Técnica (Google Style / PEP-257)

## 1. Resumen ejecutivo
Este módulo automatiza la generación de documentación técnica para un archivo Java (`ResultPrinter.java`) utilizando el modelo de chat de OpenAI hospedado en la plataforma OpenRouter.  
El script lee el código fuente del archivo, envía el contenido al modelo gemini-2.0-flash-001 y persiste la respuesta en un nuevo archivo Markdown (`MANUAL_TECNICO_JUNIT.md`).

---

## 2. Especificación de funciones y métodos

### `generar_documentacion()`
```python
def generar_documentacion() -> None:
    """Genera un manual técnico en formato Markdown para un archivo Java pre-existente."""
```

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| _N/A_     | —    | —         | La función no recibe argumentos de entrada. |

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| `None`  | `NoneType` | La función se ejecuta por sus efectos secundarios (creación de archivo y salida por consola). |

| Excepción | Condición de disparo |
|-----------|----------------------|
| `FileNotFoundError` | El archivo `main/java/junit/textui/ResultPrinter.java` no existe o no es accesible. |
| `UnicodeDecodeError` | El archivo Java contiene caracteres que no pueden decodificarse con UTF-8. |
| `openai.OpenAIError` (o subclases) | Fallos en la llamada `client.chat.completions.create`, por ejemplo problemas de autenticación, cuota o red. |
| `IOError` / `OSError` | Errores genéricos de lectura/escritura en el sistema de archivos. |

Descripción detallada (Docstring completa):

```python
def generar_documentacion() -> None:
    """
    Genera un manual técnico en formato Markdown (`MANUAL_TECNICO_JUNIT.md`) a
    partir del código fuente Java localizado en 
    `main/java/junit/textui/ResultPrinter.java`.

    El flujo de trabajo es el siguiente:
      1. Lee el contenido del archivo Java.
      2. Envía el código al modelo ``google/gemini-2.0-flash-001`` a través de 
         la API de OpenAI/OpenRouter, proporcionando instrucciones en español 
         para elaborar un manual técnico detallado.
      3. Escribe la respuesta del modelo en el archivo 
         ``MANUAL_TECNICO_JUNIT.md`` y notifica el éxito por consola.

    Raises
    ------
    FileNotFoundError
        Si la ruta al archivo Java no existe.
    UnicodeDecodeError
        Si el archivo contiene caracteres no válidos en UTF-8.
    openai.OpenAIError
        Cualquier error devuelto por la API de OpenAI/OpenRouter.
    IOError
        Problemas de lectura o escritura en disco.
    """
```

---

## 3. Ejemplo de uso
A continuación se muestra un ejemplo mínimo de ejecución desde la línea de comandos.  
El script crea el manual técnico siempre que el archivo Java exista y la clave de API sea válida.

```python
"""
Ejemplo de ejecución directa.
$ python generar_manual_junit.py
"""

from generar_manual_junit import generar_documentacion

if __name__ == "__main__":
    try:
        generar_documentacion()
    except FileNotFoundError as err:
        print(f"Archivo inexistente: {err.filename}")
    except Exception as exc:
        print(f"Ocurrió un error inesperado: {exc}")
```

Salidas esperadas:

```
--- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
¡Documentación generada con éxito!
Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```

Esta documentación cubre el 100 % de las funciones presentes en el script y sigue las directrices Google Style / PEP 257.