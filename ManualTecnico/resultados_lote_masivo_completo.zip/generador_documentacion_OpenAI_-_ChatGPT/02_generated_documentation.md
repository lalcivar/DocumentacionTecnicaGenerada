# Documentación técnica del módulo `generar_documentacion.py`

## 1. Resumen ejecutivo  
Este módulo automatiza la generación de un manual técnico para un archivo Java existente (`ResultPrinter.java`).  
Para ello consume la API de OpenRouter (compat-layer OpenAI) y delega la redacción al modelo `google/gemini-2.0-flash-001`, almacenando el resultado en un fichero Markdown (`MANUAL_TECNICO_JUNIT.md`).

---

## 2. Especificación de funciones / métodos

### `generar_documentacion()`
Genera, mediante la llamada a un modelo LLM remoto, la documentación técnica de un archivo Java local y la persiste en disco.

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| _(sin parámetros)_ | — | — | La función opera sobre rutas y claves definidas en el propio módulo. |

| Valor de retorno | Tipo | Descripción |
|------------------|------|-------------|
| `None` | `NoneType` | No devuelve un valor explícito; finaliza tras crear el archivo `MANUAL_TECNICO_JUNIT.md` y mostrar mensajes en consola. |

| Excepciones (`Raises`) | Condición de disparo |
|------------------------|----------------------|
| `FileNotFoundError` | El archivo Java indicado en `ruta_java` no existe o no es accesible. |
| `PermissionError` | El proceso actual no posee permisos suficientes para leer `ruta_java` o escribir `MANUAL_TECNICO_JUNIT.md`. |
| `openai.OpenAIError` (o subclases) | Fallos en la comunicación con la API de OpenRouter/OpenAI. |
| `OSError` | Cualquier error del sistema operativo relacionado con operaciones de E/S (lectura/escritura de archivos). |

Docstring (Google Style / PEP 257):

```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java local.

    Lee el código fuente de ``main/java/junit/textui/ResultPrinter.java``,
    envía el contenido a un modelo LLM (Gemini 2.0 Flash) alojado en
    OpenRouter y persiste la respuesta en ``MANUAL_TECNICO_JUNIT.md``.

    El flujo general es:
        1. Abrir y leer el archivo Java.
        2. Construir el prompt para la IA.
        3. Ejecutar la llamada a ``client.chat.completions.create``.
        4. Guardar la respuesta en disco.
        5. Informar por consola del resultado.

    Raises:
        FileNotFoundError: Si el archivo Java no existe.
        PermissionError: Si no hay permisos de lectura/escritura.
        openai.OpenAIError: Si la API remota devuelve un error.
        OSError: Para otros fallos del sistema de archivos.
    """
```

---

## 3. Ejemplo de uso

```python
"""
Ejemplo de ejecución directa o importación desde otro módulo.
"""

# === Uso como script principal ===
if __name__ == "__main__":
    # Lanza el proceso de documentación sin argumentos.
    generar_documentacion()

# === Uso como función importada ===
# from generar_documentacion import generar_documentacion
# generar_documentacion()
```

La invocación creará (o sobrescribirá) el archivo `MANUAL_TECNICO_JUNIT.md` en el directorio de trabajo y mostrará en consola mensajes similares a:

```
--- Procesando código de: main/java/junit/textui/ResultPrinter.java ---
¡Documentación generada con éxito!
Busca el archivo 'MANUAL_TECNICO_JUNIT.md' en tu carpeta.
```

Fin de la documentación.