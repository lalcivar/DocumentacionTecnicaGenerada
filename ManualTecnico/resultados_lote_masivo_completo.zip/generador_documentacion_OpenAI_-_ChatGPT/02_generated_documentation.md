# Documentación Técnica del Módulo

## 1. Resumen ejecutivo
El módulo automatiza la generación de un manual técnico en español a partir de código fuente Java. Para ello, inicializa un cliente de la API de OpenAI/OpenRouter, lee un archivo Java existente y solicita a un modelo LLM (Gemini 2.0 Flash) la elaboración de la documentación; finalmente persiste el resultado en disco.  
Su objetivo principal es facilitar la creación de documentación técnica sin intervención humana, integrándose fácilmente en un flujo de CI/CD o scripts de build.

---

## 2. Especificación de funciones y métodos

### `generar_documentacion()`
```python
def generar_documentacion():
    ...
```
Docstring (Google Style)
```python
def generar_documentacion():
    """Genera un manual técnico Markdown a partir de un archivo Java.

    El flujo completo es:
        1. Lee el código fuente Java desde `ruta_java`.
        2. Envía el código al modelo `google/gemini-2.0-flash-001`
           mediante la API de OpenAI/OpenRouter.
        3. Escribe la respuesta en un archivo Markdown
           llamado ``MANUAL_TECNICO_JUNIT.md``.

    Raises:
        FileNotFoundError: Si el archivo Java especificado no existe.
        UnicodeDecodeError: Si el archivo no puede decodificarse con UTF-8.
        openai.APIStatusError: Errores HTTP devueltos por la API.
        openai.AuthenticationError: Credenciales inválidas o expiradas.
        openai.APIConnectionError: Problemas de red al contactar la API.
        OSError: Cualquier fallo de E/S al leer o escribir archivos.
    """
```

Tabla de especificación  
| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| *Sin parámetros* | — | — | La función se auto-contiene y opera con variables internas.|

Valores de retorno  
| Tipo | Descripción |
|------|-------------|
| `None` | La función se ejecuta por sus efectos secundarios (I/O). |

Excepciones (`Raises`)  
| Excepción | Condición de disparo |
|-----------|---------------------|
| `FileNotFoundError` | El archivo definido en `ruta_java` no está presente. |
| `UnicodeDecodeError` | El archivo no está codificado en UTF-8. |
| `openai.APIStatusError` | La API responde con un código HTTP diferente de 2xx. |
| `openai.AuthenticationError` | Token o clave API inválida. |
| `openai.APIConnectionError` | Fallas de red o tiempo de espera agotado. |
| `OSError` | Cualquier otro problema de lectura/escritura en disco. |

---

## 3. Ejemplo de uso
```python
"""
Script de ejemplo para generar el manual técnico de ResultPrinter.java.
Se asume que el archivo Java existe en la ruta indicada y que la
variable de entorno OPENAI_API_KEY o la clave hard-coded es válida.
"""
from modulo_documentacion import generar_documentacion  # importar desde su módulo real

if __name__ == "__main__":
    try:
        generar_documentacion()
    except Exception as exc:  # Manejo genérico; afine según sus necesidades
        print(f"Error al generar la documentación: {exc}")
```

> Nota de seguridad: Evite versionar claves API en texto plano. Utilice variables de entorno o gestores de secretos.