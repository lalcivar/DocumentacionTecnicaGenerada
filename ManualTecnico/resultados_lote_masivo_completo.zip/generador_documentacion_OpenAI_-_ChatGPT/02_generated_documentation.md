# Documentación técnica del módulo de generación de manuales con OpenAI
*(Formato de docstring: Google Style / PEP 257)*  

---

## 1. Resumen ejecutivo
Este módulo automatiza la creación de un manual técnico en español para un archivo Java determinado.  
Para ello lee el código fuente localmente, envía dicho código a un modelo de chat alojado en OpenRouter (Gemini 2.0 Flash) mediante la librería `openai` y persiste la respuesta en un archivo Markdown.

---

## 2. Especificación de funciones y métodos

### 2.1 `generar_documentacion()`
```python
def generar_documentacion():
    """Genera un manual técnico en español para un archivo Java usando OpenAI.

    El flujo general es:
    1. Leer el archivo Java `main/java/junit/textui/ResultPrinter.java`.
    2. Invocar el endpoint de chat completions con el modelo
       `google/gemini-2.0-flash-001` a través del cliente `openai.OpenAI`.
    3. Guardar la respuesta en `MANUAL_TECNICO_JUNIT.md`.
    4. Informar por consola el progreso y el resultado.

    Side-effects:
        • Lectura de disco.  
        • Escritura de disco.  
        • Llamadas HTTP externas a la API de OpenRouter.

    Returns
    -------
    None
        Esta función se utiliza únicamente por sus efectos secundarios.

    Raises
    ------
    FileNotFoundError
        Si el archivo Java indicado no existe en la ruta esperada.
    UnicodeDecodeError
        Si el archivo Java no puede decodificarse con UTF-8.
    openai.OpenAIError
        Cualquier error genérico devuelto por la biblioteca `openai`
        (incluye problemas de autenticación, límite de peticiones, etc.).
    IOError
        Fallos genéricos de E/S al leer o escribir archivos.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| *N/A*     | —    | —         | La función no recibe argumentos. |

| Retorno | Tipo | Descripción |
|---------|------|-------------|
| `None`  | `NoneType` | La función actúa por efectos secundarios. |

| Excepción | Condición de disparo |
|-----------|----------------------|
| `FileNotFoundError` | El archivo Java no existe en la ruta indicada. |
| `UnicodeDecodeError` | El archivo no puede decodificarse como UTF-8. |
| `openai.OpenAIError` | Fallo en la llamada a la API de OpenAI/OpenRouter. |
| `IOError` | Problemas de lectura o escritura en disco. |

> Nota de seguridad: el módulo contiene una clave API hard-codeada.  
> Se recomienda moverla a una variable de entorno o gestor de secretos antes de usarlo en producción.

---

## 3. Ejemplo de uso
```python
"""
Ejemplo mínimo para ejecutar la generación de documentación técnica.
Asegúrese de:
1. Tener instalada la librería openai (`pip install openai`).
2. Exportar una variable de entorno con la clave API o
   editar el módulo para no exponer la clave en texto plano.
"""

from modulodocumentador import generar_documentacion  # asumiendo nombre de archivo .py

if __name__ == "__main__":
    generar_documentacion()
```

---

Fin del documento.