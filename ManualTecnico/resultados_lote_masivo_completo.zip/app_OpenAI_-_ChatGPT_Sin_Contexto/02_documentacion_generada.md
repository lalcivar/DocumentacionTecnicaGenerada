========================
Módulo: flask.app (extracto)
========================
Este archivo contiene la implementación **central** de la clase `Flask`, el objeto-aplicación que:

1. Sirve como registro de vistas, blueprints, filtros de plantilla, etc.  
2. Expone una aplicación WSGI (método `__call__`).  
3. Orquesta todo el ciclo de vida de una petición HTTP: creación del contexto, routing, ejecución de vistas, post-procesamiento, gestión de errores y teardown.  

La versión mostrada corresponde a Flask ≥ 3.0, por lo que incluye soporte “async”, tipado estático y varias API recientes.

--------------------------------------------------------------------
1. Importaciones y alias
--------------------------------------------------------------------
• Estándar: `inspect`, `os`, `sys`, `datetime.timedelta`, `weakref`, etc.  
• Tipado: `typing as t`, `collections.abc as cabc`.  
• Externas: `click`, `werkzeug.*` (routing, excepciones, server helpers).  
• Internas de Flask: `ctx`, `globals`, `helpers`, `signals`, `sessions`, `templating`, `testing`, `sansio.app`.  

Esto divide responsabilidades: Werkzeug maneja WSGI-HTTP; Flask agrega comportamiento de framework; el resto son utilidades propias.

--------------------------------------------------------------------
2. Utilidades auxiliares
--------------------------------------------------------------------
1. `_make_timedelta` – Convierte enteros a `datetime.timedelta`.  
2. Decoradores `remove_ctx` / `add_ctx`  
   • Propósito: compatibilidad con firmas antiguas de métodos que ahora reciben `ctx: AppContext`.  
   • Detectan overrides en subclases y envuelven la llamada para añadir o quitar el nuevo parámetro, lanzando avisos de deprecación.

--------------------------------------------------------------------
3. Clase principal: Flask
--------------------------------------------------------------------
Hereda de `sansio.app.App`, una capa sin E/S que contiene partes neutrales respecto a WSGI.

A. Atributos de clase
   • `default_config` – Diccionario inmutable con todas las claves de configuración y sus valores por defecto (debug, cookies, CORS, tamaño de carga, etc.).  
   • `request_class`, `response_class` – Subclases utilizadas para representar petición y respuesta.  
   • `session_interface` – Por omisión `SecureCookieSessionInterface`.

B. Hook de subclase (`__init_subclass__`)
   • Consulta si la subclase sobreescribió métodos importantes sin el nuevo parámetro `ctx` y envuelve con los decoradores mencionados.

C. Constructor (`__init__`)
   1. Llama al constructor del padre (`App`) pasando paths (static, templates, instance, root).  
   2. Crea el grupo CLI (`self.cli`) y fija su nombre.  
   3. Registra la ruta `/static/<path:filename>` (si `static_folder` existe) usando una `weakref` para no crear ciclos de GC.

D. Métodos agrupados por temática
   1. Gestión de archivos
      • `get_send_file_max_age`  
      • `send_static_file`  
      • `open_resource`, `open_instance_resource`
   2. Plantillas (Jinja2)
      • `create_jinja_environment`  
      • `update_template_context`
   3. Routing & URL building  
      • `create_url_adapter` – Crea `MapAdapter` según request o app-context.  
      • `url_for` – Genera URLs; maneja `_external`, `_scheme`, blueprints, etc.  
      • `raise_routing_exception`
   4. Contextos
      • `app_context`, `request_context`, `test_request_context` – Crean y empujan `AppContext`.  
   5. Ciclo de vida de la petición
      a. Pre-procesamiento y dispatch  
         • `preprocess_request` → `dispatch_request` → `full_dispatch_request`  
      b. Post-procesamiento  
         • `process_response`  
      c. Conversión de valores de vista a respuesta  
         • `make_response` (maneja str, bytes, dict, list, tuple, callable, generators, etc.)  
      d. Teardown  
         • `do_teardown_request`, `do_teardown_appcontext`
   6. Gestión de errores y logging  
      • `handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`  
      • Utiliza señales (`got_request_exception`) y decide si propagar en debug/testing.  
   7. Compatibilidad async  
      • `ensure_sync` decide si envolver corutinas mediante `asgiref.sync.async_to_sync`.  
      • `async_to_sync` – punto de extensión por si se quiere otro runtime.
   8. Servidor de desarrollo  
      • `run` – Helper para `werkzeug.serving.run_simple`; respeta env vars, .env y reloader.  
   9. Testing helpers  
      • `test_client`, `test_cli_runner`
  10. Punto de entrada WSGI  
      • `wsgi_app` – Crea `AppContext`, maneja errores, envía respuesta, hace `ctx.pop()`.  
      • `__call__` – Simple proxy a `wsgi_app`.

--------------------------------------------------------------------
4. Señales y extensibilidad
--------------------------------------------------------------------
El módulo emite y consume varias señales de Flask:
• `request_started`, `request_finished`, `request_tearing_down`  
• `appcontext_tearing_down`, `got_request_exception`

Otras extensiones pueden suscribirse para ejecutar lógica adicional sin alterar el núcleo.

--------------------------------------------------------------------
5. Resumen de flujo de petición
--------------------------------------------------------------------
1. Servidor WSGI llama `app(environ, start_response)`.  
2. Se construye un `AppContext` + `Request`, se hace `push()`.  
3. `full_dispatch_request`  
   a. `preprocess_request`: URL preprocessors y before_request.  
   b. `dispatch_request`: routing → vista.  
   c. Excepciones: user / http / internal → manejadores.  
4. `finalize_request`  
   a. `process_response`: after_request, guardar sesión.  
   b. Señal `request_finished`.  
5. Respuesta WSGI se envía; `ctx.pop()` dispara teardown y señales.

--------------------------------------------------------------------
6. Puntos de personalización clave
--------------------------------------------------------------------
• Subclases pueden sobreescribir:
  - Métodos de error (`handle_*`), `make_response`, `create_jinja_environment`.  
• Decoradores del framework (@before_request, @after_request, @teardown_request, etc.) insertan funciones en las colecciones manipuladas por estos métodos.  
• `session_interface` se puede cambiar por uno propio.

--------------------------------------------------------------------
7. Consideraciones de compatibilidad
--------------------------------------------------------------------
• El archivo mantiene compatibilidad con firmas antiguas mediante `remove_ctx` / `add_ctx` y avisos de deprecación.  
• Para usar vistas asíncronas se debe instalar Flask con la extra `[async]` (depende de `asgiref`).

--------------------------------------------------------------------
Conclusión
--------------------------------------------------------------------
Este módulo define el “motor” de Flask: todo lo que ocurre entre que el servidor recibe una conexión y el cliente obtiene una respuesta está coordinado por esta clase. Los métodos expuestos constituyen la API pública para:
• Configurar la aplicación  
• Registrar rutas, plantillas, señales y filtros  
• Ejecutar en modo desarrollo o prueba  
• Integrarse con CLI y extensiones  

Cualquier extensión o aplicación Flask interactúa fundamentalmente con esta clase o sus instancias.