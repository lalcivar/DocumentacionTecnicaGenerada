Documentación técnica  
====================  

Archivo: flask/app.py (fragmento)  
Versión: ≥ 3.2-dev  
Módulo: flask  
Autor original: Pallets / Flask core team  
Licencia: BSD-3-Clause  

Propósito general  
-----------------  
Este archivo implementa la clase Flask, el núcleo de la micro-arquitectura de Flask.  
Un objeto Flask:

1. Cumple el rol de aplicación WSGI.
2. Mantiene el registro global de rutas, blueprints, filtros, señales, etc.  
3. Implementa el ciclo de vida completo de una petición HTTP:
   • creación del contexto,  
   • despacho de la vista,  
   • manejo de excepciones,  
   • post-procesamiento y teardown.  
4. Expone utilidades de servidor (``run``), pruebas (``test_client``), CLI (``cli``) y plantillas (Jinja).  

Estructura principal  
--------------------

1. Importaciones  
   • Librería estándar (inspect, datetime, weakref, urllib, etc.)  
   • Click y Werkzeug (routing, wrappers, serving, exceptions).  
   • Sub-módulos internos de Flask (ctx, sessions, helpers, signals, etc.).  

2. Tipado y ayudas internas  
   • Declaración de ``TypeVar`` y alias para typing.  
   • ``_make_timedelta``: normaliza segundos/``timedelta``.  
   • ``remove_ctx`` / ``add_ctx``: wrappers de compatibilidad para métodos cuyo primer argumento cambió de ``self`` a ``(self, ctx)`` en Flask 3.  

3. Clase Flask(App)  
   """Objeto aplicación y contenedor central."""
   
   3.1 Atributos de clase  
       • ``default_config``: diccionario inmutable con todos los flags y valores por defecto.  
       • ``request_class`` (Request), ``response_class`` (Response).  
       • ``session_interface`` (SecureCookieSessionInterface).  

   3.2 Gancho ``__init_subclass__``  
       Detecta subclasses que no adaptaron la nueva firma de métodos; aplica wrappers y emite DeprecationWarnings.

   3.3 Constructor ``__init__``  
       • Recibe argumentos de rutas estáticas, templates, instancia, etc.  
       • Crea el grupo CLI ``self.cli``.  
       • Registra la ruta ``/static/...`` si procede (con weakref para evitar ciclos).

   3.4 Gestión de archivos  
       • ``get_send_file_max_age``  
       • ``send_static_file``  
       • ``open_resource`` y ``open_instance_resource``

   3.5 Sistema de plantillas  
       • ``create_jinja_environment``: genera Environment y expone helpers globales.

   3.6 Enrutamiento / URL building  
       • ``create_url_adapter``  
       • ``raise_routing_exception``  
       • ``url_for`` (migrado desde ``flask.url_for``).  

   3.7 Contextos  
       • ``update_template_context``  
       • ``make_shell_context``  
       • ``app_context`` / ``request_context`` / ``test_request_context``  

   3.8 Servidor de desarrollo y pruebas  
       • ``run``: wrapper sobre Werkzeug ``run_simple`` con soporte a python-dotenv y protección contra doble ejecución (``FLASK_RUN_FROM_CLI``).  
       • ``test_client`` y ``test_cli_runner``  

   3.9 Manejo de excepciones  
       • ``handle_http_exception``  
       • ``handle_user_exception``  
       • ``handle_exception``  
       • ``log_exception``  

   3.10 Despacho de peticiones  
        • ``dispatch_request`` (matching y llamada a la vista).  
        • ``full_dispatch_request`` (before/after, excepción, finalize).  
        • ``finalize_request``  
        • ``preprocess_request`` / ``process_response`` / ``make_response``  
        • ``make_default_options_response``  

   3.11 Soporte asíncrono  
        • ``ensure_sync``: transforma vistas async → sync usando ``asgiref`` si es necesario.  
        • ``async_to_sync``: implementación concreta.

   3.12 Teardown  
        • ``do_teardown_request``  
        • ``do_teardown_appcontext`` (ejecutan callbacks y emiten señales; uso de helper ``_CollectErrors`` para acumular fallos).  

   3.13 Interfaz WSGI  
        • ``wsgi_app``: crea RequestContext, llama a ``full_dispatch_request`` y hace pop del contexto, garantizando teardown aun con errores.  
        • ``__call__``: simple proxy a ``wsgi_app`` para que el objeto sea invocable por el servidor WSGI.  

4. Funciones auxiliares externas al objeto  
   (``_make_timedelta``, ``remove_ctx``, ``add_ctx``) — ya descritas.  

Flujo de ejecución resumido  
---------------------------  
1. Servidor llama ``app(environ, start_response)`` → ``wsgi_app``  
2. ``request_context`` genera un ``AppContext`` y lo empuja.  
3. ``full_dispatch_request``  
   a. ``preprocess_request`` (url & before_request).  
   b. ``dispatch_request`` (matching + vista).  
   c. Manejo de excepciones si las hay.  
   d. ``finalize_request`` → ``process_response`` (after_request, sesión).  
4. ``Response`` WSGI es devuelto; al finalizar se ejecutan ``do_teardown_request`` y ``do_teardown_appcontext``.  

Señales emitidas  
----------------  
• ``request_started``  
• ``request_finished``  
• ``request_tearing_down``  
• ``appcontext_tearing_down``  
• ``got_request_exception``  

Conclusiones  
------------  
El archivo concentra la lógica central de Flask. Define:

- La configuración por defecto y la personalización vía hooks.  
- El ENLACE entre Werkzeug (servidor, routing, wrappers) y la API pública de Flask.  
- El ciclo de vida de peticiones, excepciones, plantillas, sesiones y CLI.  

Entender esta clase es imprescindible para extender Flask (sub-clases, middlewares, extensiones) o para depurar su comportamiento interno.