# Documentación Técnica - Clase `LocalCacheTest`

### 1. Información General

| Atributo | Detalle |
| :--- | :--- |
| **Nombre Completo** | `com.google.common.cache.LocalCacheTest` |
| **Paquete** | `com.google.common.cache` |
| **Tipo** | Clase de Pruebas Unitarias |
| **Herencia** | `extends junit.framework.TestCase` (JUnit 3) |
| **Autor** | Charles Fry |
| **Licencia** | Apache License 2.0 |
| **Dependencia Principal** | `com.google.common.cache.LocalCache` - Implementación interna de `Cache` de Guava |
| **Anotaciones** | `@GwtIncompatible`, `@J2ktIncompatible`, `@NullUnmarked`, `@SuppressWarnings("GuardedBy")` |

### 2. Descripción General

`LocalCacheTest` **no es una clase de producción**, sino una **suite de pruebas exhaustiva** para validar el comportamiento interno de `LocalCache`, que es el motor concurrente que respalda las implementaciones de `Cache` y `LoadingCache` de Google Guava.

Su objetivo es garantizar la correctitud, concurrencia, y robustez de la caché bajo todas sus configuraciones posibles. Verifica funcionalidades críticas como:

* Concurrencia segmentada y expansión de tablas hash.
* Políticas de desalojo por tamaño `maximumSize` / `maximumWeight`.
* Políticas de expiración por tiempo `expireAfterWrite` y `expireAfterAccess`.
* Referencias débiles `weakKeys` y suaves/débiles `softValues` / `weakValues` para recolección por GC.
* Notificaciones de eliminación vía `RemovalListener` y `RemovalCause`.
* Carga computada `CacheLoader` y manejo de concurrencia durante `refresh`.
* Serialización y manejo de colas de referencia `ReferenceQueue`.

La clase contiene más de 60 métodos de prueba y construye una suite parametrizada que ejecuta los tests de `ConcurrentMap` sobre 11 configuraciones distintas de la caché.

### 3. Estructura y Componentes Principales

#### 3.1 Atributos de Instancia

* `TestLogHandler logHandler`: Captura los logs generados por `LocalCache.logger` para verificar que las excepciones en `RemovalListener` sean logueadas correctamente.
* `static final int SMALL_MAX_SIZE`: Constante definida como `DRAIN_THRESHOLD * 5`, usada para forzar desalojos y expiraciones de forma determinista en los tests.

#### 3.2 Clases Internas Auxiliares

| Clase | Propósito |
| :--- | :--- |
| `TestStringCacheGenerator` | Adaptador que implementa `TestStringMapGenerator` para integrar `LocalCache` con `ConcurrentMapTestSuiteBuilder` de Guava. Permite ejecutar tests genéricos de `Map` sobre la caché. |
| `DummyEntry<K,V>` | Implementación mock de `ReferenceEntry` para simular entradas sin depender de la lógica real de creación. Permite inyectar claves/valores nulos, colisiones de hash y controlar colas de acceso/escritura. |
| `DummyValueReference<K,V>` | Implementación mock de `ValueReference` para simular valores recolectados por GC `clear()`, estados de carga `isLoading()` y pesos. |
| `SerializableCacheLoader`, `SerializableRemovalListener`, `SerializableTicker`, `SerializableWeigher` | Implementaciones serializables mínimas para probar la serialización de `LocalManualCache` y `LocalLoadingCache`. |

### 4. Métodos Principales

Los métodos se agrupan en 7 categorías funcionales. Todos los métodos de prueba siguen la convención JUnit 3 `public void test*()`.

#### A. Configuración y Ciclo de Vida de JUnit

| Método | Descripción |
| :--- | :--- |
| `public static Test suite()` | Construye la suite principal. Registra `LocalCacheTest` y añade 11 suites parametrizadas de `ConcurrentMapTestSuiteBuilder` con distintas configuraciones: `defaults`, `concurrencyLevel[1]`, `maximumSize`, `maximumWeight`, `weakKeys`, `weakValues`, `softValues`, `expireAfterAccess`, `expireAfterWrite`, `removalListener`, `recordStats`. |
| `protected void setUp()` | Inicializa `TestLogHandler` y lo registra en `LocalCache.logger` antes de cada test. |
| `protected void tearDown()` | Elimina el handler del logger después de cada test. |
| `private static <K,V> LocalCache<K,V> makeLocalCache(...)` | Factory helper. Crea instancias directas de `LocalCache` a partir de un `CacheBuilder` con o sin `CacheLoader`. Evita usar `builder.build()`. |
| `private static CacheBuilder<Object,Object> createCacheBuilder()` | Factory helper que retorna `CacheBuilder.newBuilder()`. |

#### B. Tests de Constructor y Configuración - `testSet*`

Validan que `CacheBuilder` configure correctamente los campos internos de `LocalCache`.

* `testDefaults()`: Verifica valores por defecto: `Strength.STRONG`, `expireAfter* = 0`, `concurrencyLevel = 4`, `entryFactory = STRONG`, etc.
* `testSetKeyEquivalence()` / `testSetValueEquivalence()`: Verifica equivalencias personalizadas.
* `testSetConcurrencyLevel()` / `checkConcurrencyLevel()`: Verifica que el número de segmentos se redondee a la potencia de 2 superior.
* `testSetInitialCapacity()` / `checkInitialCapacity()`: Verifica distribución de capacidad inicial por segmento.
* `testSetMaximumSize()` / `checkMaximumSize()`: Verifica distribución de `maxSegmentWeight` y que `segments.length <= max(1, maxSize/10)`.
* `testSetWeigher()`, `testSetWeakKeys()`, `testSetWeakValues()`, `testSetSoftValues()`: Verifican `Strength` y `EntryFactory`.
* `testSetExpireAfterWrite()`, `testSetExpireAfterAccess()`, `testSetRefresh()`, `testSetRemovalListener()`, `testSetTicker()`: Verifican conversión a nanos y asignación de listeners/tickers.
* `testEntryFactory()`: Valida el mapeo de `EntryFactory.getFactory(Strength, usesAccessQueue, usesWriteQueue)`.

#### C. Tests de Cómputo y Carga

* `testCompute()`: Verifica `map.get(key, loader)` y que el loader solo se invoque una vez.
* `testComputeExistingEntry()`: No debe invocar el loader si la clave ya existe.
* `testComputePartiallyCollectedKey/Value()`: Simula clave/valor recolectado por GC y verifica que se recompute.
* `testComputeExpiredEntry()`: Verifica recomputo tras expiración `expireAfterWrite`.
* `testCopyEntry_computing()`: Prueba de concurrencia con `CountDownLatch` y `LoadingValueReference` para verificar copia de entradas en estado `computing`.
* `testSegmentStoreComputedValue()`, `testSegmentRefresh_duplicate()`: Validan transiciones de `LoadingValueReference` a valor cargado.

#### D. Tests de `RemovalListener`

* `testRemovalListener_explicit()`: Causa `EXPLICIT` vía `remove()`, `remove(key,value)`, `iterator.remove()` en `entrySet`, `keySet` y `values`.
* `testRemovalListener_replaced()`: Causa `REPLACED` vía `put()`, `putAll()`, `replace()`.
* `testRemovalListener_collected()`: Causa `COLLECTED` vía `reclaimValue()` con `softValues`.
* `testRemovalListener_expired()`: Causa `EXPIRED` usando `FakeTicker` y `expireAfterWrite`.
* `testRemovalListener_size()`: Causa `SIZE` al exceder `maximumSize`.
* `testRemovalListenerCheckedException()`: Verifica que una excepción en el listener se loguee y no rompa la caché.

#### E. Tests de Núcleo de `Segment`

Operan directamente sobre `LocalCache.Segment` para probar la tabla hash interna.

* `testNewEntry()` / `testCopyEntry()`: Creación y copia de `ReferenceEntry` preservando colas de acceso/escritura.
* `testSegmentGetAndContains()`: Casos de `get()`, `containsKey()`, `containsValue()` con `count=0`, colisión de hash, clave nula y entrada expirada.
* `testSegmentReplace()`, `testSegmentReplaceValue()`, `testSegmentPut()`, `testSegmentPutIfAbsent()`: Semántica de reemplazo e inserción.
* `testSegmentPut_expand()` / `testExpand()` / `testGetCausesExpansion()` / `testPutCausesExpansion()`: Verifican redimensionado de `AtomicReferenceArray` y `threshold`.
* `testReclaimKey()`, `testReclaimValue()`, `testRemoveEntry()`, `testClear()`: Limpieza de entradas y manejo de colas `accessQueue`/`writeQueue`.

#### F. Tests de Desalojo y Expiración

* `testDrainRecencyQueueOnWrite/OnRead()`, `testRecordRead()`, `testRecordReadOnGet()`, `testRecordWrite()`: Verifican el drenado de `recencyQueue` hacia `accessQueue`/`writeQueue` y el umbral `DRAIN_THRESHOLD`.
* `testExpireAfterWrite()` / `testExpireAfterAccess()`: Validan `isLive()` y `expireEntries()` con `FakeTicker`.
* `testEvictEntries()`: Verifica desalojo LRU al exceder `maximumSize`.

#### G. Tests de Infraestructura

* `testDrainKey/ValueReferenceQueueOnWrite/OnRead()`: Simulan `Reference.enqueue()` y verifican limpieza de `keyReferenceQueue` y `valueReferenceQueue`.
* `testSerializationProxyLoading()` / `testSerializationProxyManual()`: Verifican que `LocalLoadingCache` y `LocalManualCache` se serialicen/deserialicen correctamente vía `reserialize()`, preservando `keyStrength`, `weigher`, `ticker`, etc., pero vaciando el contenido.
* `testNullParameters()`: Usa `NullPointerTester` para garantizar `NullPointerException` en parámetros nulos.
* `testRecursiveLoad()`: Verifica que una carga recursiva de la misma clave lance `UncheckedExecutionException` y no cause deadlock.

### 5. Dependencias Clave

* `junit.framework.TestCase`, `TestSuite`
* `com.google.common.truth.Truth.assertThat`
* `com.google.common.testing.FakeTicker`, `TestLogHandler`, `NullPointerTester`
* `com.google.common.collect.testing.ConcurrentMapTestSuiteBuilder`
* `java.util.concurrent` - `CountDownLatch`, `AtomicReferenceArray`, `ReferenceQueue`

> **Nota Técnica:** Esta clase es fundamental para el mantenimiento de Guava. Cualquier cambio en `LocalCache.java` debe pasar esta suite para garantizar que no se introduzcan regresiones en concurrencia, consistencia de memoria o políticas de expiración.
