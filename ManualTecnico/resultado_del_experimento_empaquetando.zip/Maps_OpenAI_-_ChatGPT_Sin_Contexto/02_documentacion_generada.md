Documentación técnica  
Clase: com.google.common.collect.Maps  
Librería: Google Guava  

Descripción general  
------------------  
Maps es una clase utilitaria final (no instanciable) que reúne la mayor parte de la funcionalidad auxiliar que Guava ofrece para trabajar con implementaciones de java.util.Map y sus sub-interfaces (SortedMap, NavigableMap, BiMap, ConcurrentMap, etc.).  

Las rutinas incluidas cubren principalmente cinco áreas:  

1. Fabricación de instancias mutables de Map con parámetros de tipo explícitos (“factory methods”).  
2. Creación de instancias inmutables y coleccionistas para Streams.  
3. Vistas sobre mapas ya existentes (transformaciones perezosas o filtrados) sin copiar datos.  
4. Operaciones algorítmicas (por ejemplo, cálculo de diferencias entre dos mapas).  
5. Envolturas (wrappers) para dotar a un mapa de características de sincronización o de solo-lectura.

Principales grupos de métodos  
-----------------------------  

A. Constructores/fábricas de mapas mutables  
• newHashMap(), newHashMap(Map), newHashMapWithExpectedSize(int)  
• newLinkedHashMap(), newLinkedHashMap(Map), newLinkedHashMapWithExpectedSize(int)  
• newTreeMap(), newTreeMap(Comparator), newTreeMap(SortedMap)  
• newEnumMap(Class), newEnumMap(Map)  
• newIdentityHashMap()  
• newConcurrentMap()  

B. Mapas inmutables y coleccionistas  
• immutableEnumMap(Map) – copia inmutable especializada para claves Enum.  
• toImmutableEnumMap(keyFn, valueFn) y la sobrecarga con mergeFn – collectors para Stream API.  
• immutableEntry(K,V) – entrada inmutable suelta.  

C. Algoritmos sobre Map  
• difference(Map left, Map right) – produce instantánea inmutable con:  
  – entriesOnlyOnLeft(), entriesOnlyOnRight(), entriesInCommon(), entriesDiffering()  
  Versión sobrecargada para SortedMap y para equivalencias de valores personalizadas.  
• indexMap(Collection) – crea un ImmutableMap<elemento,posición>.  
• capacity(int expectedSize) – cálculo interno de capacidad para HashMap.  

D. Generación de vistas (lazy views)  
1. Proyecciones clave-valor  
  • asMap(Set, Function)  
  • asMap(SortedSet, Function)  
  • asMap(NavigableSet, Function)  
2. Transformaciones  
  • transformValues(Map, Function) ← versiones Sorted/Navigable  
  • transformEntries(Map, EntryTransformer) ← versiones Sorted/Navigable  
  Todas devuelven un mapa “live”: los cambios en la vista o en el mapa de respaldo se reflejan mutuamente; la función/transformer se aplica de forma perezosa.  
3. Filtrado  
  • filterKeys(map, Predicate) — versiones Map, SortedMap, NavigableMap, BiMap.  
  • filterValues(map, Predicate) — idem.  
  • filterEntries(map, Predicate) — idem.  

E. Conversión y envolturas  
• asConverter(BiMap) – suministra un Converter bidireccional basado en el BiMap.  
• synchronizedBiMap(BiMap) y synchronizedNavigableMap(NavigableMap) – vistas thread-safe.  
• unmodifiableBiMap(BiMap) y unmodifiableNavigableMap(NavigableMap) – vistas read-only.  

F. Utilidades de apoyo  
• uniqueIndex(Iterable/Iterator, keyFunction) – indexa valores por una clave única.  
• toMap(Iterable/Iterator, valueFunction) – copia inmutable aplicando una función al valor.  
• fromProperties(Properties) – convierte a ImmutableMap<String,String>.  
• Métodos “safe*” (safeGet, safeContainsKey, safeRemove) con manejo de ClassCast/NullPointer.  
• Métodos auxiliares de iteración (keyIterator, valueIterator, entryIterator) y de impresión (toStringImpl).  

Patrones de uso típicos  
-----------------------  
1. Crear un mapa mutable con tipo inferido:  
  Map<Foo,Bar> m = Maps.newHashMap();  
2. Obtener una vista filtrada sin copiar datos:  
  Map<User,Role> admins = Maps.filterValues(allUsers, Role::isAdmin);  
3. Transformar valores manteniendo el orden de claves:  
  Map<String,Integer> sqrt = Maps.transformValues(nums, n -> (int)Math.sqrt(n));  
4. Comparar dos mapas y detectar diferencias:  
  MapDifference<K,V> diff = Maps.difference(mapA, mapB);  
5. Generar un ImmutableMap desde un Stream con claves Enum:  
  ImmutableMap<Day,Task> tasks =  
     stream.collect(Maps.toImmutableEnumMap(Task::day, Function.identity()));  

Notas de diseño  
---------------  
• Todos los métodos son estáticos; la clase posee constructor privado para evitar instanciación.  
• Las vistas devueltas (transform/filtrar/asMap) son perezosas y de “lectura/escritura limitada”; ciertas operaciones (put, iterator.remove) pueden estar deshabilitadas según corresponda.  
• Muchas implementaciones internas delegan en ForwardingMap, AbstractMap o colecciones de Guava para minimizar código repetido.  
• Gran parte de las fábricas mutables están marcadas en comentarios como “innecesarias” desde Java 7 (se pueden sustituir por el constructor estándar y el operador diamante).  

Dependencias relevantes  
-----------------------  
Guava Core (Preconditions, Function, Predicate, Converter, Ordering, Iterables, Iterators, Sets, Lists, ImmutableMap, ImmutableSet, ImmutableCollection…),  
Java Collections Framework,  
Opcionalmente jspecify (anotaciones de null-safety), GWT y J2OBJC para compatibilidad cruzada.