# Documentación Técnica: `CharMatcherBenchmark`

**Paquete:** `com.google.common.base`
**Autores:** David Beaumont, Kevin Bourrillion, David Richter
**Licencia:** Apache License 2.0 (Guava / The Guava Authors)

---

## 1. Descripción general

`CharMatcherBenchmark` es una clase de **benchmarking (medición de rendimiento)** construida sobre el framework **Caliper** de Google. Su propósito es medir el desempeño de las operaciones de la clase `CharMatcher` de Guava —en particular los métodos `matches(char)` y `trimAndCollapseFrom(CharSequence, char)`— bajo distintas configuraciones controladas.

La clase no forma parte de la API pública de Guava: es una herramienta interna de desarrollo utilizada para detectar regresiones de rendimiento y comparar estrategias de implementación de `CharMatcher` (por ejemplo, matchers "precomputados" frente a matchers normales, o la variante optimizada `SmallCharMatcher`).

### Mecánica de funcionamiento

1. Caliper inyecta automáticamente los valores de los parámetros anotados con `@Param`.
2. Caliper invoca `setUp()` (anotado con `@BeforeExperiment`) para construir el `CharMatcher` y la cadena de prueba.
3. Caliper ejecuta repetidamente los métodos anotados con `@Benchmark`, pasándoles un número de repeticiones (`reps`).
4. Cada método de benchmark devuelve un valor acumulado (`dummy`) para evitar que el compilador JIT elimine el código medido como "muerto".

La clase está anotada con `@NullUnmarked` (JSpecify), indicando que su nulabilidad no ha sido especificada.

---

## 2. Parámetros de configuración (`@Param`)

| Campo | Tipo | Valores | Descripción |
|---|---|---|---|
| `config` | `SampleMatcherConfig` | *(enum completo)* | Configuración global: define el `CharMatcher` a evaluar y el conjunto de caracteres coincidentes. |
| `length` | `int` | `64`, `1024` | Longitud de la cadena de prueba generada. |
| `percent` | `int` | `0`, `10`, `50`, `100` | Porcentaje aproximado de caracteres de la cadena que el matcher debe reconocer. |
| `precomputed` | `boolean` | `true` | Si se debe usar la versión `precomputed()` del matcher (tabla de búsqueda optimizada). |
| `size` | `Size` | `DEFAULT`, `SMALL` | Si es `SMALL`, el matcher se reconstruye como un `SmallCharMatcher` a partir de un `BitSet`. |
| `forceSlow` | `boolean` | `false` | Fuerza que el primer carácter de la cadena sea coincidente, para ejercitar el camino lento del recorte (*trimming*). |
| `web` | `boolean` | `false` | Si es `true`, la cadena se genera con una distribución de caracteres derivada de datos reales de la web, ignorando `percent` y `matchingChars`. |

### Estado interno

- `private CharMatcher matcher` — instancia bajo prueba.
- `private String string` — cadena de entrada generada para el experimento.
- `enum Size { DEFAULT, SMALL }` — selector del tipo de implementación de matcher.
- `private static final String NONMATCHING_CHARS` — alfabeto alfanumérico usado para los caracteres que **no** deben coincidir.

---

## 3. Métodos principales

### 3.1 `void setUp()`
**Anotación:** `@BeforeExperiment`

Prepara el estado antes de cada experimento:

1. Obtiene el `CharMatcher` desde `config`, aplicando `precomputed()` si el parámetro correspondiente es `true`.
2. Si `size == Size.SMALL`, vuelca los bits del matcher en un `BitSet` mediante `matcher.setBits(...)` y reconstruye el matcher con `SmallCharMatcher.from(...)`.
3. Genera la cadena de prueba invocando `checkString(...)` con una semilla aleatoria nueva.

---

### 3.2 `int trimAndCollapseFromString(int reps)`
**Anotación:** `@Benchmark`

Mide el rendimiento de `CharMatcher.trimAndCollapseFrom(CharSequence, char)`, que elimina los caracteres coincidentes de los extremos y colapsa las secuencias internas en un único carácter de reemplazo (`'!'`).

- **Parámetro:** `reps` — número de repeticiones indicado por Caliper.
- **Retorno:** suma de las longitudes de los resultados, usada como valor "centinela" anti-optimización.

---

### 3.3 `int matches(int reps)`
**Anotación:** `@Benchmark`

Mide el rendimiento de `CharMatcher.matches(char)` carácter a carácter, recorriendo cíclicamente la cadena de prueba (`i % string.length()`).

- **Parámetro:** `reps` — número de repeticiones.
- **Retorno:** número acumulado de coincidencias.

---

### 3.4 `private static String checkString(int length, int percent, String matchingChars, Random rand, boolean forceSlow, boolean web)`

Genera la cadena de entrada del benchmark. Dos modos de operación:

- **Modo web** (`web == true`): construye la cadena muestreando *code points* mediante `CharSamples`, reproduciendo una distribución realista de caracteres observada en la web. Se ignoran `percent`, `matchingChars` y `forceSlow`.
- **Modo controlado** (por defecto):
  1. Crea una lista de índices `0..length-1` y la mezcla aleatoriamente para garantizar una proporción exacta de coincidencias sin agruparlas.
  2. Si `forceSlow` es `true`, mueve el índice `0` a la primera posición, asegurando un carácter coincidente inicial.
  3. Calcula un umbral `threshold = ((percent * length) + 99) / 100` (redondeo hacia arriba, de modo que cualquier porcentaje > 0 produzca al menos una coincidencia).
  4. Para cada posición, elige un carácter de `matchingChars` o de `NONMATCHING_CHARS` según si el índice mezclado está por debajo del umbral.

---

### 3.5 `private static char randomCharFrom(String s, Random rand)`

Método auxiliar que devuelve un carácter aleatorio uniforme de la cadena `s`.

---

## 4. Clase interna: `CharSamples`

**Visibilidad:** `static class` (ámbito de paquete)
**Autor:** Christopher Swenson
**Origen de los datos:** adaptado de información proporcionada por Mark Davis.

Proporciona un **muestreador de caracteres Unicode** según una distribución de probabilidad empírica derivada de contenido web real. Esto permite medir `CharMatcher` con entradas estadísticamente representativas en lugar de sintéticas.

### Estructura de datos

| Elemento | Descripción |
|---|---|
| `private static int[] prob` | Arreglo de **probabilidades acumuladas** (10 003 entradas), inicializado en dos tramos por razones de límite de tamaño de método del bytecode. |
| `private static int[] chars` | Arreglo paralelo con los **code points** correspondientes (10 002 entradas), también cargado en dos tramos. |
| `private final int sum = 69552218` | Total acumulado de frecuencias; define el rango del sorteo aleatorio. |
| `private final Random random` | Fuente de aleatoriedad. |

Un bloque `static` invoca `populateProb1()`, `populateProb2()`, `populateChars1()` y `populateChars2()` para inicializar las tablas.

### Métodos

#### `public CharSamples(Random random)`
Constructor que recibe el generador de números aleatorios a utilizar.

#### `public int nextCodePoint()`
Devuelve un *code point* Unicode muestreado según la distribución de frecuencias cargada.

**Algoritmo:** genera un valor `needle` uniforme en `[0, sum)` y realiza una **búsqueda binaria** sobre el arreglo de probabilidades acumuladas `prob`, devolviendo el elemento correspondiente de `chars`. El bucle mantiene tres punteros (`l`, `c`, `r`) con sus valores asociados (`lv`, `cv`, `rv`) y estrecha el intervalo hasta localizar el tramo que contiene `needle`.

#### `private static void populateProb1()` / `populateProb2()`
Inicializan, respectivamente, el tramo inicial y el tramo final del arreglo `prob` mediante `System.arraycopy`. La división en dos métodos evita exceder el límite de tamaño de método de la JVM (64 KB de bytecode).

#### `private static void populateChars1()` / `populateChars2()`
Análogos a los anteriores, pero para el arreglo `chars` de code points.

---

## 5. Consideraciones de uso

- **No es una clase de producción.** Está destinada exclusivamente a ejecutarse con el *runner* de Caliper.
- Los valores de retorno de los métodos `@Benchmark` **no son significativos**; existen únicamente para impedir la eliminación de código por parte del JIT.
- La combinación cartesiana de todos los `@Param` determina el número total de escenarios ejecutados; ampliar los valores posibles incrementa el tiempo de ejecución de forma multiplicativa.
- `setUp()` usa una nueva instancia de `Random` sin semilla fija, por lo que las cadenas generadas varían entre ejecuciones (aunque sus propiedades estadísticas —longitud y porcentaje de coincidencia— se mantienen constantes).