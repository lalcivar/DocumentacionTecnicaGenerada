# Documentación Técnica - `CharMatcherBenchmark`

**Paquete:** `com.google.common.base`  
**Licencia:** Apache License 2.0  
**Autores:** David Beaumont, Kevin Bourrillion, David Richter  
**Tipo:** Clase de Benchmark / Rendimiento  
**Anotaciones:** `@NullUnmarked`  
**Dependencias:** Google Guava, Google Caliper, JSpecify

### 1. Descripción General

`CharMatcherBenchmark` es una clase de **benchmarking** diseñada para medir y comparar el rendimiento de la clase `com.google.common.base.CharMatcher` de Guava.

No es una clase de uso en producción, sino una herramienta de micro-benchmarking que utiliza el framework **Caliper** para evaluar el costo computacional de las operaciones de `CharMatcher` bajo diferentes condiciones controladas.

Su objetivo es analizar cómo se comporta `CharMatcher` al variar:
* El tipo de matcher utilizado.
* El tamaño y contenido de la cadena de entrada.
* El porcentaje de caracteres que hacen match.
* Si el matcher está pre-computado u optimizado para conjuntos pequeños.

La clase genera cadenas de prueba sintéticas o basadas en una distribución real de caracteres de la web y ejecuta dos operaciones críticas de forma repetitiva para medir su throughput.

### 2. Configuración del Benchmark - Parámetros Caliper

Caliper inyecta automáticamente los valores de los campos anotados con `@Param`. Cada combinación genera un caso de prueba distinto.

| Parámetro | Tipo | Valores | Descripción |
| :--- | :--- | :--- | :--- |
| `config` | `SampleMatcherConfig` | Inyectado | Define el `CharMatcher` base y el conjunto de `matchingChars` a evaluar. Proviene de `BenchmarkHelpers`. |
| `length` | `int` | `64`, `1024` | Longitud de la cadena `string` sobre la que se ejecuta el benchmark. |
| `percent` | `int` | `0`, `10`, `50`, `100` | Porcentaje de caracteres de la cadena que deben coincidir con el `matcher`. |
| `precomputed` | `boolean` | `true` | Si es `true`, se utiliza `matcher.precomputed()` para optimizar el matcher antes de la prueba. |
| `size` | `Size` | `DEFAULT`, `SMALL` | Determina la implementación del matcher. `SMALL` fuerza el uso de `SmallCharMatcher`. |
| `forceSlow` | `boolean` | `false` | Si es `true`, fuerza que el primer carácter de la cadena haga match para evitar el fast-path de `trim`. |
| `web` | `boolean` | `false` | Si es `true`, ignora `percent` y genera la cadena usando una distribución real de caracteres de la web. |

**Atributos de Estado:**

* `private CharMatcher matcher`: Instancia del matcher a evaluar, ya configurada en `setUp()`.
* `private String string`: Cadena de prueba generada según los parámetros anteriores.

**Enum Interno `Size`:**
Define el tipo de implementación a testear: `DEFAULT` usa el `CharMatcher` estándar y `SMALL` lo convierte a `SmallCharMatcher` vía `BitSet`.

### 3. Métodos Principales

#### 3.1 `void setUp()`
```java
@BeforeExperiment
void setUp()
```
Método de inicialización ejecutado por Caliper **antes de cada experimento** después de inyectar los parámetros.

**Lógica:**
1.  Inicializa `matcher`: Si `precomputed == true`, aplica `config.matcher.precomputed()`.
2.  Si `size == Size.SMALL`, convierte el matcher a `SmallCharMatcher` usando `matcher.setBits(BitSet)` y `SmallCharMatcher.from()`.
3.  Genera la cadena de prueba `string` llamando a `checkString()` con los parámetros actuales.

#### 3.2 Métodos de Benchmark

Son los métodos que Caliper mide. Deben comenzar con `time` o estar anotados con `@Benchmark` y recibir `int reps` como número de repeticiones. Retornan un `int dummy` para evitar que el JIT elimine el código por optimización de código muerto.

**a) `int trimAndCollapseFromString(int reps)`**
```java
@Benchmark
int trimAndCollapseFromString(int reps)
```
Mide el rendimiento de `CharMatcher.trimAndCollapseFrom(String, char)`. En cada iteración ejecuta `matcher.trimAndCollapseFrom(string, '!').length()` y acumula el resultado.

Evalúa el costo de recortar y colapsar secuencias de caracteres coincidentes.

**b) `int matches(int reps)`**
```java
@Benchmark
int matches(int reps)
```
Mide el rendimiento de `CharMatcher.matches(char)`. Itera `reps` veces y verifica si `matcher.matches(string.charAt(i % string.length()))` es verdadero.

Evalúa el costo de la operación más básica y frecuente de `CharMatcher`.

#### 3.3 Métodos de Utilidad

**c) `private static String checkString(...)`**
```java
private static String checkString(int length, int percent, String matchingChars, Random rand, boolean forceSlow, boolean web)
```
Factoría para generar la cadena de prueba.

* **Modo `web == true`:** Genera una cadena de `length` code points usando `CharSamples` que simula la frecuencia real de caracteres en la web.
* **Modo sintético:** Crea una lista de índices `0..length-1`, la mezcla con `Collections.shuffle()` y calcula un `threshold = ((percent * length) + 99) / 100`. Los índices por debajo del threshold se rellenan con un carácter aleatorio de `matchingChars`, el resto con `NONMATCHING_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789"`. Si `forceSlow == true`, fuerza que el índice `0` esté en la primera posición.

**d) `private static char randomCharFrom(String s, Random rand)`**
```java
private static char randomCharFrom(String s, Random rand)
```
Retorna un carácter aleatorio de la cadena `s`. Utilizado por `checkString`.

### 4. Clase Interna Estática `CharSamples`

```java
static class CharSamples
```

Proporciona un generador de code points con una **distribución probabilística derivada de datos reales de la web**, adaptada de datos de Mark Davis.

**Atributos:**
* `private static int[] prob`: Array acumulativo de probabilidades. Tamaño 10003. `sum = 69552218` es el total.
* `private static int[] chars`: Array de 10002 code points correspondientes a cada probabilidad.
* `private final Random random`: Fuente de aleatoriedad.

**Métodos:**

* `static populateProb1(), populateProb2()`: Inicializan el array `prob` en dos partes mediante bloques `static`.
* `static populateChars1(), populateChars2()`: Inicializan el array `chars`.
* `int nextCodePoint()`: Genera un code point aleatorio. Elige un `needle = random.nextInt(sum)` y realiza una **búsqueda binaria** sobre el array `prob` para encontrar el `chars` correspondiente. Simula la frecuencia real de aparición de caracteres.

### 5. Flujo de Ejecución

1.  Caliper inyecta una combinación de `@Param`.
2.  Invoca `setUp()` -> se configura `matcher` y se genera `string`.
3.  Ejecuta repetidamente `trimAndCollapseFromString` y `matches` con diferentes valores de `reps` para medir el tiempo por operación.
4.  Reporta los resultados de throughput/latencia.

> **Nota:** Esta clase no debe ser instanciada manualmente en código de producción. Su único propósito es la evaluación de rendimiento en un entorno controlado de benchmarking.
