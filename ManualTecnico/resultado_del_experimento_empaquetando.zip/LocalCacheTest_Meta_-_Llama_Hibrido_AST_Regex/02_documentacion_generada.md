# Documentación Técnica - `com.google.common.cache.LocalCacheTest`

> **Paquete:** `com.google.common.cache`
> **Clase:** `public class LocalCacheTest extends TestCase`
> **Anotaciones:** `@GwtIncompatible`, `@J2ktIncompatible`, `@NullUnmarked`, `@SuppressWarnings("GuardedBy")`
> **Autor:** `@author Charles Fry`

---

### 1. Resumen Ejecutivo

`LocalCacheTest` es la suite de pruebas unitarias y de integración para `LocalCache`, la implementación concurrente y segmentada que sustenta `CacheBuilder` y `LoadingCache` de Guava. Valida de forma exhaustiva la construcción, configuración, expiración, desalojo por tamaño/peso, referencias débiles/suaves, colas de expiración, drenaje de colas de referencia y notificaciones de `RemovalListener`. Actúa como especificación ejecutable del contrato de concurrencia, consistencia y serialización de la caché.

---

### 2. Especificación de Métodos y Constructores

#### 2.1 Clase Principal `LocalCacheTest`

##### 2.1.1 Ciclo de Vida JUnit

###### `setUp()`
```java
@Override protected void setUp() throws Exception
```
Inicializa el `TestLogHandler` y lo registra en `LocalCache.logger`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| - | - | - | No recibe parámetros |

| @return | Descripción |
|---|---|
| `void` | No retorna valor |

| @throws | Condición |
|---|---|
| `Exception` | Propagada por `super.setUp()` |

###### `tearDown()`
```java
@Override protected void tearDown() throws Exception
```
Remueve el `TestLogHandler` del logger.

| @return | `void` |
| @throws | `Exception` - propagada por `super.tearDown()` |

###### `suite()`
```java
public static Test suite()
```
Construye la `TestSuite` completa incluyendo `ConcurrentMapTestSuiteBuilder` para 11 configuraciones distintas de `LocalCache`.

| @return | `Test` - Suite agregada con todos los casos de prueba |
| @throws | No declara excepciones verificadas |

##### 2.1.2 Helpers de Logging y Factoría

###### `popLoggedThrowable()`
```java
private Throwable popLoggedThrowable()
```
Extrae y limpia el único `LogRecord` almacenado.

| @return | `Throwable` - Excepción logueada en `LogRecord.getThrown()` |
| @throws | `AssertionError` implícito si `logRecords.size() != 1` |

###### `checkNothingLogged()`
```java
private void checkNothingLogged()
```
Verifica que no existan registros en `logHandler`.

| @return | `void` |
| @throws | `AssertionError` si existen logs |

###### `checkLogged(Throwable t)`
```java
private void checkLogged(Throwable t)
```
Valida que la excepción logueada sea igual a `t`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `t` | `Throwable` | Sí | Excepción esperada |

| @return | `void` |

###### `makeLocalCache(CacheBuilder<? super K, ? super V> builder)`
```java
private static <K,V> LocalCache<K,V> makeLocalCache(CacheBuilder<? super K, ? super V> builder)
```
Factoría para caché manual sin `CacheLoader`.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `builder` | `CacheBuilder<? super K, ? super V>` | Sí | Builder configurado |

| @return | `LocalCache<K,V>` - Instancia `new LocalCache<>(builder, null)` |

###### `makeLocalCache(CacheBuilder<? super K, ? super V> builder, CacheLoader<? super K, V> loader)`
```java
private static <K,V> LocalCache<K,V> makeLocalCache(CacheBuilder<? super K, ? super V> builder, CacheLoader<? super K, V> loader)
```
Factoría para caché con carga.

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `builder` | `CacheBuilder<? super K, ? super V>` | Sí | Builder configurado |
| `loader` | `CacheLoader<? super K, V>` | Sí | Loader para cómputo bajo demanda |

| @return | `LocalCache<K,V>` |

###### `createCacheBuilder()`
```java
private static CacheBuilder<Object,Object> createCacheBuilder()
```
| @return | `CacheBuilder<Object,Object>` - `CacheBuilder.newBuilder()` |

##### 2.1.3 Tests de Constructor y Configuración

| Método | @return | @throws | Descripción |
|---|---|---|---|
| `testDefaults()` | `void` | - | Valida valores por defecto: `Strength.STRONG`, `expireAfter* = 0`, `maxWeight = UNSET_INT`, `concurrencyLevel=4`, `entryFactory=STRONG`, `ticker=NULL_TICKER` |
| `testSetKeyEquivalence()` | `void` | - | Verifica `keyEquivalence` personalizada vía `Equivalence` anónima |
| `testSetValueEquivalence()` | `void` | - | Verifica `valueEquivalence` personalizada |
| `testSetConcurrencyLevel()` | `void` | - | Valida redondeo a potencia de 2 (1->1, 3->4, 5->8) |
| `testSetInitialCapacity()` | `void` | - | Valida distribución de capacidad por segmento |
| `testSetMaximumSize()` | `void` | - | Valida partición de `maxSegmentWeight` y `maximumWeight` con `constantWeigher(1)` |
| `testSetWeigher()` | `void` | - | Verifica asignación de `Weigher` personalizado |
| `testSetWeakKeys()` | `void` | - | Verifica `Strength.WEAK` en claves y `EntryFactory.WEAK` |
| `testSetWeakValues()` | `void` | - | Verifica `Strength.WEAK` en valores |
| `testSetSoftValues()` | `void` | - | Verifica `Strength.SOFT` en valores |
| `testSetExpireAfterWrite()` | `void` | - | Verifica `expireAfterWriteNanos = SECONDS.toNanos(42)` |
| `testSetExpireAfterAccess()` | `void` | - | Verifica `expireAfterAccessNanos` |
| `testSetRefresh()` | `void` | - | Verifica `refreshNanos` |
| `testLongAsyncRefresh()` | `void` | `Exception` | Prueba `reload` asíncrono con `ListenableFuture`, `FakeTicker` y `SettableFuture<Thread>`; valida que expiración durante reload retorna valor recargado |
| `testSetRemovalListener()` | `void` | - | Verifica asignación de `RemovalListener` |
| `testSetTicker()` | `void` | - | Verifica asignación de `Ticker` |
| `testEntryFactory()` | `void` | - | Valida `EntryFactory.getFactory(Strength, boolean access, boolean write)` para 8 combinaciones |

**Helpers de configuración:**

###### `checkConcurrencyLevel(int concurrencyLevel, int segmentCount)`
| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `concurrencyLevel` | `int` | Sí | Nivel solicitado |
| `segmentCount` | `int` | Sí | Número esperado de segmentos |

###### `checkInitialCapacity(int concurrencyLevel, int initialCapacity, int segmentSize)`
| @param | Tipo | Requerido |
|---|---|---|
| `concurrencyLevel` | `int` | Sí |
| `initialCapacity` | `int` | Sí |
| `segmentSize` | `int` | Sí |

###### `checkMaximumSize(int concurrencyLevel, int initialCapacity, long maxSize)`
| @param | Tipo | Requerido |
|---|---|---|
| `concurrencyLevel` | `int` | Sí |
| `initialCapacity` | `int` | Sí |
| `maxSize` | `long` | Sí |

###### `checkStrength(LocalCache<Object,Object> map, Strength keyStrength,