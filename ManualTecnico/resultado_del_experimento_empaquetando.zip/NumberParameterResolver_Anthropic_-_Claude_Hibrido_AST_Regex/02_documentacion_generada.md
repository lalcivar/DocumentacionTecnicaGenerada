# Documentación Técnica: `NumberParameterResolver`

**Paquete:** `org.junit.jupiter.engine.execution.injection.sample`
**Versión (`@since`):** 5.0
**Licencia:** Eclipse Public License v2.0
**Tipo:** Clase pública concreta que implementa `org.junit.jupiter.api.extension.ParameterResolver`

---

## 1. Resumen ejecutivo

`NumberParameterResolver` es una implementación deliberadamente **no realista** (*test fixture / sample*) de la interfaz `ParameterResolver` de JUnit Jupiter, diseñada para simular un escenario de incompatibilidad de tipos en la inyección de parámetros. La clase declara soportar cualquier parámetro cuyo tipo sea asignable desde `java.lang.Number`, pero en la fase de resolución siempre devuelve un valor literal `Integer` (`42`), lo que provoca intencionadamente un `IllegalArgumentException` ("argument type mismatch") cuando el parámetro declarado es un subtipo incompatible de `Number` (por ejemplo, `Double`, `Long` o `BigDecimal`).

Su propósito funcional es servir como artefacto de prueba dentro del motor de ejecución de JUnit Jupiter, reproduciendo el patrón real observado en extensiones como el `SpringExtension`, donde un resolutor puede afirmar soporte sobre un supertipo (`ApplicationContext`) y entregar una instancia que no es asignable al subtipo requerido (`WebApplicationContext`).

---

## 2. Especificación de métodos y constructores

### 2.0. Resumen de miembros detectados

| Miembro | Modificadores | Tipo de retorno | Origen |
|---|---|---|---|
| `NumberParameterResolver()` | `public` (implícito) | — | Constructor por defecto sintetizado |
| `supportsParameter(ParameterContext, ExtensionContext)` | `public` | `boolean` | `@Override` de `ParameterResolver` |
| `resolveParameter(ParameterContext, ExtensionContext)` | `public` | `Object` | `@Override` de `ParameterResolver` |

> **Nota de análisis estático:** el código fuente no declara campos, métodos `private`, `protected`, `static`, clases internas, clases anónimas ni bloques de inicialización. Los únicos miembros existentes son los tres listados arriba, incluyendo el constructor por defecto generado por el compilador.

---

### 2.1. Constructor `NumberParameterResolver()`

La clase no declara explícitamente ningún constructor; por tanto el compilador sintetiza el **constructor por defecto sin argumentos** con visibilidad `public` (equivalente a la visibilidad de la clase). Este constructor es el que utiliza JUnit Jupiter al instanciar la extensión de forma declarativa mediante `@ExtendWith(NumberParameterResolver.class)`.

```java
/**
 * Construye una nueva instancia de {@code NumberParameterResolver}.
 *
 * <p>Constructor por defecto sin argumentos, requerido por el mecanismo de
 * registro declarativo de extensiones de JUnit Jupiter
 * ({@code @ExtendWith}), el cual instancia la extensión por reflexión.
 *
 * <p>La instancia resultante no mantiene estado interno, por lo que es
 * inmutable y segura para su reutilización.
 */
public NumberParameterResolver() { }
```

#### Parámetros (`@param`)

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | El constructor no recibe parámetros. |

#### Retorno (`@return`)

| Valor | Descripción |
|---|---|
| `NumberParameterResolver` | Nueva instancia sin estado de la extensión. |

#### Excepciones (`@throws`)

| Excepción | Condición |
|---|---|
| — | El constructor por defecto no declara ni lanza excepciones comprobadas. |

---

### 2.2. Método `supportsParameter(ParameterContext, ExtensionContext)`

```java
/**
 * Determina si este resolutor declara soporte para el parámetro descrito
 * por el {@link ParameterContext} suministrado.
 *
 * <p>La decisión se basa exclusivamente en una comprobación de
 * asignabilidad: se devuelve {@code true} si el tipo declarado del
 * parámetro es {@link Number} o cualquier subtipo de {@link Number}.
 *
 * <p><strong>Advertencia:</strong> el soporte declarado aquí es
 * intencionadamente más amplio que la capacidad real de
 * {@link #resolveParameter(ParameterContext, ExtensionContext)}, que
 * siempre produce un {@link Integer}.
 *
 * @param parameterContext el contexto del parámetro para el que se solicita
 *        la resolución; no debe ser {@code null}, ya que se invoca
 *        {@code getParameter()} sobre él
 * @param extensionContext el contexto de extensión actual; no se utiliza en
 *        esta implementación y se ignora
 * @return {@code true} si el tipo del parámetro es asignable desde
 *         {@link Number}; {@code false} en caso contrario
 * @throws NullPointerException si {@code parameterContext} es {@code null}
 */
@Override
public boolean supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext)
```

#### Parámetros (`@param`)

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `parameterContext` | `org.junit.jupiter.api.extension.ParameterContext` | **Sí** | Contexto del parámetro evaluado. Se invoca `parameterContext.getParameter().getType()` para obtener el tipo declarado. |
| `extensionContext` | `org.junit.jupiter.api.extension.ExtensionContext` | No (no utilizado) | Contexto de extensión del contenedor o test en ejecución. La implementación lo ignora por completo; admite `null` sin afectar al resultado. |

#### Retorno (`@return`)

| Tipo | Valor | Condición |
|---|---|---|
| `boolean` | `true` | `Number.class.isAssignableFrom(tipoDelParámetro)` evalúa a `true`: el parámetro es `Number`, `Integer`, `Long`, `Double`, `Float`, `Short`, `Byte`, `BigDecimal`, `BigInteger`, etc. |
| `boolean` | `false` | El tipo del parámetro no desciende de `Number` (p. ej. `String`, `Object`, `boolean`, `int` primitivo — nótese que los tipos primitivos **no** son asignables desde `Number`). |

#### Excepciones (`@throws`)

| Excepción | Tipo | Condición de lanzamiento |
|---|---|---|
| `NullPointerException` | No comprobada | Si `parameterContext` es `null`, o si `parameterContext.getParameter()` devuelve `null`, al desreferenciar para obtener el tipo. |

#### Notas de implementación

- La comprobación `Number.class.isAssignableFrom(...)` es direccional: el receptor es el supertipo (`Number`) y el argumento el tipo candidato.
- Para parámetros declarados con tipos primitivos (`int`, `double`), `getType()` devuelve `int.class`/`double.class`, que **no** son asignables desde `Number`; el método retornará `false`.

---

### 2.3. Método `resolveParameter(ParameterContext, ExtensionContext)`

```java
/**
 * Resuelve el valor a inyectar para el parámetro previamente aceptado por
 * {@link #supportsParameter(ParameterContext, ExtensionContext)}.
 *
 * <p>Esta implementación ignora ambos contextos y devuelve de forma
 * incondicional el literal entero {@code 42}, autoboxeado a
 * {@link Integer} por tratarse de un valor de retorno {@link Object}.
 *
 * <p>Si el parámetro declarado es un subtipo de {@link Number} distinto de
 * {@link Integer} (o de {@link Number} mismo), el motor de JUnit lanzará un
 * {@link IllegalArgumentException} con el mensaje
 * {@code "argument type mismatch"} al invocar el método por reflexión.
 *
 * @param parameterContext el contexto del parámetro a resolver; no se
 *        utiliza en esta implementación
 * @param extensionContext el contexto de extensión actual; no se utiliza en
 *        esta implementación
 * @return siempre un {@link Integer} con valor {@code 42}, nunca {@code null}
 */
@Override
public Object resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext)
```

#### Parámetros (`@param`)

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `parameterContext` | `org.junit.jupiter.api.extension.ParameterContext` | No (no utilizado) | Contexto del parámetro a resolver. No se desreferencia; tolera `null`. |
| `extensionContext` | `org.junit.jupiter.api.extension.ExtensionContext` | No (no utilizado) | Contexto de extensión. No se desreferencia; tolera `null`. |

#### Retorno (`@return`)

| Tipo declarado | Tipo real | Valor | Garantías |
|---|---|---|---|
| `java.lang.Object` | `java.lang.Integer` (autoboxing de `int`) | `42` | Determinista, no nulo, independiente de los argumentos recibidos. |

#### Excepciones (`@throws`)

| Excepción | Tipo | Condición de lanzamiento |
|---|---|---|
| — | — | El método **no lanza** ninguna excepción por sí mismo. |
| `IllegalArgumentException` | No comprobada (**indirecta**) | Lanzada posteriormente por el mecanismo de invocación reflexiva de JUnit (`java.lang.reflect.Method#invoke`) con el mensaje `"argument type mismatch"`, cuando el valor `Integer` devuelto no es asignable al tipo del parámetro declarado (p. ej. `Double`, `Long`, `BigDecimal`). |
| `ParameterResolutionException` | No comprobada (**indirecta**) | Puede producirse en el motor de Jupiter al envolver fallos de resolución/inyección detectados durante la invocación del método de test. |

> **Importante:** estas excepciones **no** forman parte del contrato de este método; se documentan como efectos observables derivados del diseño intencionadamente defectuoso de la clase.

---

### 2.4. Contrato heredado de `ParameterResolver`

La clase no sobrescribe ningún otro miembro. `ParameterResolver` extiende `Extension` (interfaz marcadora sin métodos), por lo que la implementación de los dos métodos anteriores satisface el contrato completo de la interfaz.

---

## 3. Ejemplo de uso

### 3.1. Escenario de resolución exitosa y de fallo por incompatibilidad

```java
package com.ejemplo.injection;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.engine.execution.injection.sample.NumberParameterResolver;

@