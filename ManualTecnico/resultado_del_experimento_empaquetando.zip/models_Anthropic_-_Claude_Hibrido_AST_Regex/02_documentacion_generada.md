# Documentación Técnica — `requests.models`

---

## 1. Resumen ejecutivo

El módulo `requests.models` define los objetos de dominio que constituyen el núcleo de la librería Requests: `Request` (petición declarativa creada por el usuario), `PreparedRequest` (petición normalizada, con los bytes exactos que viajan por la red) y `Response` (respuesta del servidor, con acceso a contenido, codificación, cookies y utilidades de streaming).

Adicionalmente aporta dos mixins reutilizables —`RequestEncodingMixin` (codificación de parámetros, cuerpos `x-www-form-urlencoded` y `multipart/form-data`) y `RequestHooksMixin` (registro/eliminación de hooks de eventos)— junto con constantes de configuración (`REDIRECT_STATI`, `DEFAULT_REDIRECT_LIMIT`, `CONTENT_CHUNK_SIZE`, `ITER_CHUNK_SIZE`).

El módulo no realiza E/S de red: delega el transporte en los adaptadores (`HTTPAdapter`) y se limita a preparar, validar y decodificar datos.

---

### 1.1 Constantes del módulo

| Constante | Tipo | Valor | Descripción |
|---|---|---|---|
| `REDIRECT_STATI` | `Final[tuple[int, ...]]` | `(301, 302, 303, 307, 308)` | Códigos HTTP considerados redirecciones procesables automáticamente. |
| `DEFAULT_REDIRECT_LIMIT` | `int` | `30` | Límite por defecto de saltos de redirección. |
| `CONTENT_CHUNK_SIZE` | `int` | `10 * 1024` | Tamaño de bloque usado al materializar `Response.content`. |
| `ITER_CHUNK_SIZE` | `int` | `512` | Tamaño de bloque por defecto en `iter_lines()`. |

---

## 2. Especificación de funciones y métodos

---

## 2.1 Clase `RequestEncodingMixin`

Mixin de codificación. Requiere que la clase destino exponga el atributo `url: str | None`.

---

### `path_url()` — *property*

```python
@property
def path_url(self) -> str
```

Construye la porción «path + query» de `self.url`, tal y como debe enviarse en la línea de petición HTTP. Si el path está vacío se normaliza a `"/"`; la query se concatena precedida de `?` solo si existe.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `RequestEncodingMixin` | Sí | Instancia que expone `url`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `str` | Cadena con el path y, opcionalmente, `?<query>`. |

**Raises**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones propias. Propaga errores de `urlsplit` si `self.url` es `None` o no parseable. |

---

### `_encode_params()` — *staticmethod*

```python
@overload
@staticmethod
def _encode_params(data: str) -> str: ...
@overload
@staticmethod
def _encode_params(data: bytes) -> bytes: ...
@overload
@staticmethod
def _encode_params(data: _t.SupportsRead[str | bytes]) -> _t.SupportsRead[str | bytes]: ...
@overload
@staticmethod
def _encode_params(data: _t.KVDataType) -> str: ...

@staticmethod
def _encode_params(
    data: _t.EncodableDataType,
) -> str | bytes | _t.SupportsRead[str | bytes]
```

Codifica parámetros en formato `application/x-www-form-urlencoded`. Comportamiento según el tipo de entrada:

- `str` / `bytes`: se devuelve sin alterar.
- Objeto con `read()` (detectado por `_t.has_read`): se devuelve sin alterar (stream).
- Iterable (dict o lista de 2-tuplas): se normaliza con `to_key_val_list()`, se expanden valores múltiples, se descartan los `None`, se codifican claves/valores a UTF-8 y se serializa con `urlencode(..., doseq=True)`.
- Cualquier otro valor: se devuelve tal cual (rama defensiva, inalcanzable para tipos válidos).

El orden se preserva cuando la entrada es una lista de 2-tuplas; es arbitrario (orden de inserción del dict) en caso contrario.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `data` | `_t.EncodableDataType` | Sí | Datos a codificar: cadena, bytes, objeto legible, dict o lista de 2-tuplas. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `str \| bytes \| _t.SupportsRead[str \| bytes]` | Datos codificados, o el objeto original si es cadena/bytes/stream. |

**Raises**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones propias. Puede propagar `UnicodeEncodeError`/`TypeError` desde `encode()` o `urlencode()`. |

---

### `_encode_files()` — *staticmethod*

```python
@staticmethod
def _encode_files(
    files: _t.FilesType, data: _t.RawDataType | None
) -> tuple[bytes, str]
```

Construye el cuerpo `multipart/form-data` combinando campos de formulario (`data`) y ficheros (`files`). Cada entrada de `files` admite el fichero directo o tuplas de 2, 3 o 4 elementos: `(filename, fileobj)`, `(filename, fileobj, content_type)` o `(filename, fileobj, content_type, custom_headers)`. Cuando no se indica nombre, se infiere con `guess_filename()` o se usa la clave. Los objetos con `read()` se leen íntegramente en memoria. Finalmente delega la serialización en `encode_multipart_formdata()`.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `files` | `_t.FilesType` | Sí |