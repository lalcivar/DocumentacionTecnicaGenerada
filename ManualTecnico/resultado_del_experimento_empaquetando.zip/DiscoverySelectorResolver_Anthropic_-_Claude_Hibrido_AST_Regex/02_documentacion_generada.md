# Documentación Técnica: `DiscoverySelectorResolver`

**Paquete:** `org.junit.platform.suite.engine`
**Modificadores:** `final class` (visibilidad *package-private*)
**Desde:** `1.8`

---

## 1. Resumen ejecutivo

`DiscoverySelectorResolver` es el componente interno del *Suite Engine* de JUnit Platform responsable de traducir una `EngineDiscoveryRequest` en un árbol de `TestDescriptor` colgado de un `SuiteEngineDescriptor`. Para ello delega en un `EngineDiscoveryRequestResolver` configurado estáticamente, que reconoce clases contenedoras de suites (mediante `IsSuiteClass`) y selectores de clase (mediante `ClassSelectorResolver`).

Tras la resolución de selectores, la clase dispara el descubrimiento interno de cada suite detectada y poda (`prune`) las ramas del árbol que no contienen tests, garantizando que el motor exponga únicamente descriptores relevantes. Su visibilidad restringida (`package-private` + `final`) indica que es un detalle de implementación no destinado al consumo público.

---

## 2. Especificación de miembros, constructores y métodos

### 2.1 Tabla resumen de miembros detectados

| # | Miembro | Tipo de elemento | Visibilidad | Estático |
|---|---------|------------------|-------------|----------|
| 1 | `resolver` | Campo (constante de instancia compartida) | `private` | Sí (`static final`) |
| 2 | `DiscoverySelectorResolver()` | Constructor implícito por defecto | *package-private* (derivada de la clase) | No |
| 3 | Lambda `context -> new IsSuiteClass(...)` | Clase anónima / función de fábrica interna | — | Sí (contexto estático) |
| 4 | Lambda `context -> new ClassSelectorResolver(...)` | Clase anónima / función de fábrica interna | — | Sí (contexto estático) |
| 5 | `discoverSuites(SuiteEngineDescriptor)` | Método | `private` | Sí |
| 6 | `SuiteTestDescriptor.class::cast` | Referencia a método (conversión) | — | — |
| 7 | `SuiteTestDescriptor::discover` | Referencia a método (consumidor) | — | — |
| 8 | `resolveSelectors(EngineDiscoveryRequest, SuiteEngineDescriptor)` | Método | *package-private* | No |
| 9 | `TestDescriptor::prune` | Referencia a método (visitante) | — | — |

---

### 2.2 Campo estático `resolver`

```java
private static final EngineDiscoveryRequestResolver<SuiteEngineDescriptor> resolver;
```

**Propósito:** instancia inmutable y compartida del resolutor de peticiones de descubrimiento, construida una única vez durante la inicialización de la clase (`<clinit>`) mediante el patrón *builder* de `EngineDiscoveryRequestResolver`.

| Característica | Detalle |
|----------------|---------|
| Tipo | `EngineDiscoveryRequestResolver<SuiteEngineDescriptor>` |
| Parametrización genérica | `SuiteEngineDescriptor` como descriptor raíz del motor |
| Inicialización | `EngineDiscoveryRequestResolver.<SuiteEngineDescriptor>builder()...build()` |
| Resolutores registrados | 1) `addClassContainerSelectorResolverWithContext(...)` 2) `addSelectorResolver(...)` |
| Mutabilidad | `static final`: la referencia no puede reasignarse |

**Javadoc propuesto:**

```java
/**
 * Resolutor compartido e inmutable que convierte los selectores de una
 * {@link EngineDiscoveryRequest} en descriptores hijos del
 * {@link SuiteEngineDescriptor} suministrado.
 *
 * <p>Se construye una sola vez al inicializar la clase y registra:
 * <ul>
 *   <li>un resolutor de contenedores de clases filtrado por {@code IsSuiteClass};</li>
 *   <li>un {@code ClassSelectorResolver} con el contexto completo de descubrimiento.</li>
 * </ul>
 */
```

---

### 2.3 Constructor `DiscoverySelectorResolver()`

El código fuente **no declara** ningún constructor explícito; el compilador genera el constructor por defecto sin argumentos con la misma visibilidad que la clase (*package-private*).

#### Parámetros (`@param`)

| Nombre | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| — | — | — | El constructor no recibe parámetros. |

#### Retorno (`@return`)

| Valor | Descripción |
|-------|-------------|
| `DiscoverySelectorResolver` | Nueva instancia sin estado propio; todo el estado reside en el campo estático `resolver`. |

#### Excepciones (`@throws`)

| Excepción | Condición |
|-----------|-----------|
| *(ninguna declarada)* | No se declaran ni lanzan excepciones de forma explícita. |

**Javadoc propuesto:**

```java
/**
 * Crea un nuevo resolutor de selectores.
 *
 * <p>La instancia es sin estado ({@code stateless}); puede crearse libremente
 * por cada ejecución del motor sin coste apreciable.
 */
DiscoverySelectorResolver() { }
```

---

### 2.4 Lambda `context -> new IsSuiteClass(context.getIssueReporter())`

Función de fábrica registrada en `addClassContainerSelectorResolverWithContext(...)`. Actúa como predicado de filtrado: solo las clases consideradas *suites* se aceptan como contenedores durante el escaneo de paquetes/*classpath*.

#### Parámetros (`@param`)

| Nombre | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `context` | Contexto de inicialización aportado por el *builder* de `EngineDiscoveryRequestResolver` | Sí | Provee acceso al `DiscoveryIssueReporter` a través de `context.getIssueReporter()`. |

#### Retorno (`@return`)

| Tipo | Descripción |
|------|-------------|
| `IsSuiteClass` | Predicado que determina si una clase candidata es una clase de suite, reportando incidencias de descubrimiento en el *issue reporter* recibido. |

#### Excepciones (`@throws`)

| Excepción | Condición |
|-----------|-----------|
| *(ninguna declarada)* | La propagación de errores depende de la implementación de `IsSuiteClass`. |

---

### 2.5 Lambda `context -> new ClassSelectorResolver(...)`

Función de fábrica registrada en `addSelectorResolver(...)`. Construye el resolutor concreto encargado de procesar selectores de clase, inyectándole todos los elementos del contexto de descubrimiento.

#### Parámetros (`@param`)

| Nombre | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `context` | Contexto de inicialización del *builder* | Sí | Fuente de los seis argumentos que se transfieren a `ClassSelectorResolver`. |

#### Argumentos derivados del `context` y pasados a `ClassSelectorResolver`

| Orden | Expresión | Origen | Finalidad |
|-------|-----------|--------|-----------|
| 1 | `context.getClassNameFilter()` | Contexto | Filtro de nombres de clase aplicable al escaneo. |
| 2 | `context.getEngineDescriptor()` | Contexto | `SuiteEngineDescriptor` raíz sobre el que se añaden los hijos. |
| 3 | `context.getDiscoveryRequest().getConfigurationParameters()` | `EngineDiscoveryRequest` | Parámetros de configuración de la ejecución. |
| 4 | `context.getDiscoveryRequest().getOutputDirectoryCreator()` | `EngineDiscoveryRequest` | Creador de directorios de salida para artefactos. |
| 5 | `context.getDiscoveryRequest().getDiscoveryListener()` | `EngineDiscoveryRequest` | *Listener* de eventos de descubrimiento. |
| 6 | `context.getIssueReporter()` | Contexto | Canal de notificación de incidencias de descubrimiento. |

#### Retorno (`@return`)

| Tipo | Descripción |
|------|-------------|
| `ClassSelectorResolver` | Resolutor de selectores de clase completamente configurado. |

#### Excepciones (`@throws`)

| Excepción | Condición |
|-----------|-----------|
| *(ninguna declarada)* | Las validaciones de argumentos corresponden al constructor de `ClassSelectorResolver`. |

---

### 2.6 Método `discoverSuites(SuiteEngineDescriptor)`

```java
private static void discoverSuites(SuiteEngineDescriptor engineDescriptor)
```

**Propósito:** recorre los hijos directos del descriptor del motor, los convierte a `SuiteTestDescriptor` y activa en cada uno su fase de descubrimiento interno (`discover()`), de modo que cada suite expanda sus propios tests.

**Flujo de implementación:**
1. `engineDescriptor.getChildren().stream()` — obtiene el flujo de hijos resueltos.
2. `.map(SuiteTestDescriptor.class::cast