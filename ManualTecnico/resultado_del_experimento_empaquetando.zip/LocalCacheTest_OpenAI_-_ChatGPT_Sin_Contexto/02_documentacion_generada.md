===================================================================
Documentación técnica
Clase: LocalCacheTest
Paquete: com.google.common.cache
===================================================================

1. Propósito general
--------------------
LocalCacheTest es una clase de pruebas (extiende junit.framework.TestCase) que valida de forma exhaustiva el correcto funcionamiento de la implementación de caché local utilizada internamente por Guava (LocalCache<K,V>).  
El objetivo principal es asegurar que todas las combinaciones de configuración que expone CacheBuilder (concurrencia, tamaño máximo, políticas de expiración, referencias fuertes/débiles/suaves, pesaje, serialización, etc.) se comporten según lo especificado.

La clase se encarga de:
• Crear dinámicamente diferentes variantes de LocalCache a partir de CacheBuilder.  
• Verificar operaciones básicas de mapa concurrente (get/put/remove, iteradores, etc.).  
• Comprobar políticas de expiración, recarga asíncrona y desalojo por tamaño.  
• Inspeccionar la lógica interna de los Segment, ReferenceEntry y colas de acceso/escritura.  
• Validar la interacción con CacheLoader, RemovalListener, Weigher y Ticker.  
• Asegurar la serialización correcta vía los proxies LocalManualCache y LocalLoadingCache.  
• Detectar casos de recarga recursiva y manejo adecuado de excepciones.  

2. Dependencias externas destacadas
-----------------------------------
JUnit 3 (TestCase, TestSuite), Truth, Guava (CacheBuilder, LocalCache y utilitarios), Guava-Testlib (ConcurrentMapTestSuiteBuilder), jspecify, y utilidades de testeo propias de Guava (FakeTicker, TestingCacheLoaders, etc.).

3. Estructura de la clase
-------------------------

A) Constantes
   • SMALL_MAX_SIZE: Tamaño de umbral usado en muchas pruebas de desalojo.  
   • Diversas referencias estáticas importadas de otras clases (DRAIN_THRESHOLD, DISCARDING_QUEUE, etc.).

B) Campos de instancia
   • TestLogHandler logHandler – Captura mensajes de log emitidos por LocalCache para comprobar que se registran (o no) excepciones esperadas.

C) Métodos de factoría/utilidad (principales dentro del contexto de prueba)
   1. suite()                    – Construye un TestSuite que re-utiliza ConcurrentMapTestSuiteBuilder con distintas configuraciones de CacheBuilder.
   2. makeLocalCache(…)          – Envuelve la construcción de LocalCache<K,V> directamente para poder acceder a sus API internas en lugar de usar Cache.build().
   3. createCacheBuilder()       – Devuelve un CacheBuilder nuevo con configuración por defecto; sirve como punto de partida para todas las variaciones.
   4. allEntryTypeMakers()       – Genera iterables de CacheBuilder con todas las combinaciones de políticas de expiración, tamaño, claves/valores débiles, etc.
   5. allEvictingMakers()        – Devuelve sólo combinaciones que provocan desalojo por tamaño o expiración (se usa en pruebas que verifican colas y recencyQueue).
   6. allKeyValueStrengthMakers()– Variantes que cambian únicamente la fortaleza de referencias de clave/valor.
   7. Funciones auxiliares para asserts: assertNotified, assertSameEntries, checkEvictionQueues, checkExpirationTimes, checkAndDrainRecencyQueue, etc.

D) Categorías de métodos de prueba (testXXX)
   Las pruebas siguen el prefijo “test” y pueden agruparse en:

   1. Pruebas de construcción/configuración
      • testDefaults, testSetKeyEquivalence, testSetWeakKeys, testSetMaximumSize, etc.
      Verifican que los campos de LocalCache reflejen la configuración suministrada por CacheBuilder.

   2. Pruebas de operación básica y recarga
      • testCompute, testComputeExistingEntry, testLongAsyncRefresh, testLoadDifferentKeyInLoader, etc.
      Se enfocan en get/put y en la interacción con CacheLoader (síncrono y asíncrono).

   3. Pruebas de listeners y notificaciones
      • testRemovalListener_explicit, testRemovalListener_replaced, testRemovalListener_checkedException, etc.
      Se comprueba la correcta invocación & manejo de RemovalListener bajo diferentes causas (EXPLICIT, REPLACED, COLLECTED, SIZE, EXPIRED).

   4. Pruebas de Segment (nivel interno)
      • testSegmentPut / Get / Replace / Remove / Expand, testRecordRead/Write, testEvictEntries, etc.
      Manipulan directamente los segmentos y sus estructuras internas (tabla, colas de acceso/escritura, recencyQueue).

   5. Pruebas de expiración y desalojo
      • testExpireAfterWrite, testExpireAfterAccess, testEvictEntries, testDrainRecencyQueueOnWrite/Read.

   6. Pruebas de ReferenceQueue
      • testDrainKeyReferenceQueueOnWrite/Read, testDrainValueReferenceQueueOnWrite/Read.

   7. Pruebas de serialización
      • testSerializationProxyLoading, testSerializationProxyManual.
      Aseguran que los proxies serializables de cachés manuales y de carga preserven la configuración y no serialicen entradas no serializables.

   8. Pruebas de error/reentrancia
      • testRecursiveLoad, testRecursiveLoadWithProxy, testRemovalListenerCheckedException.
      Validan que LocalCache detecte correctamente cargas recursivas y propague excepciones apropiadamente.

E) Clases internas “Dummy”
   Utilizadas para simular ReferenceEntry y ValueReference sin las complejidades del GC:
   • DummyEntry<K,V>            – Implementa ReferenceEntry, permite forzar estados específicos.  
   • DummyValueReference<K,V>   – Implementa ValueReference, permite marcar valores como “loading”, limpiarlos, etc.

F) Clases internas serializables de prueba
   • SerializableCacheLoader, SerializableRemovalListener, SerializableTicker, SerializableWeigher.

4. Flujo típico de una prueba
-----------------------------
1. Se crea un CacheBuilder (generalmente vía createCacheBuilder()).  
2. Se personaliza con las características que se desean validar.  
3. Se instancia la caché con makeLocalCache() (o build() para los casos de serialización).  
4. Se ejecutan operaciones sobre la caché o directamente sobre su Segment interno.  
5. Se validan invariantes mediante Truth (assertThat), colas internas, contadores, etc.  
6. Cuando se requieren asserts sobre notificaciones, se utilizan RemovalListeners “Queuing” o “Counting”.  
7. Se limpia el estado (tearDown) retirando el logHandler.

5. Uso de la clase en otros módulos
-----------------------------------
LocalCacheTest no está pensada para ser reutilizada fuera del conjunto de pruebas de Guava; sin embargo, sus utilidades (createDummyEntry, Serializable* helpers, etc.) pueden servir como referencia para implementar nuevos tests que necesiten acceder a la API interna de LocalCache.

6. Consideraciones de diseño
----------------------------
• Las pruebas acceden a campos package-private de LocalCache y Segment, lo que obliga a que LocalCacheTest esté en el mismo paquete.  
• Se evita generalmente llamar a LocalCache.cleanUp(); en su lugar se fuerzan condiciones internas (ReferenceQueue, recencyQueue, etc.).  
• Se utilizan FakeTicker y clocks controlados para pruebas determinísticas de expiración.  
• Se incluyen anotaciones @GwtIncompatible/@AndroidIncompatible para excluir pruebas según plataforma.

7. Métodos más relevantes a recordar
------------------------------------
Aunque la clase es extensa (>3.000 líneas), en la práctica los siguientes métodos son los que suelen necesitarse al extender o entender las pruebas:

• suite()                                 – Punto de entrada de JUnit.  
• makeLocalCache(CacheBuilder, [Loader])  – Crea la instancia bajo prueba.  
• createCacheBuilder()                    – Factoría base de CacheBuilder.  
• allEntryTypeMakers()/allEvictingMakers()– Generadores de combinaciones de configuración.  
• assertNotified(), assertNotificationEnqueued() – Verifican eventos de RemovalListener.  
• checkEvictionQueues(), checkExpirationTimes()  – Validan estructura interna tras operaciones.  

El resto de los métodos testXXX representan casos de prueba individuales que ejercitan funcionalidades específicas de la caché.

===================================================================
Fin de la documentación técnica de LocalCacheTest
===================================================================