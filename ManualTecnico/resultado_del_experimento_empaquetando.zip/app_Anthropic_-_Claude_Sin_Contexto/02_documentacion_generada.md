# Documentación técnica: `flask/app.py`

## 1. Descripción general

Este módulo define la clase **`Flask`**, el objeto central del framework Flask y el punto de entrada de la aplicación **WSGI**. Es la implementación "sansio → síncrona": hereda de `App` (definida en `flask.sansio.app`, que contiene toda la lógica *agnóstica de I/O*: registro de rutas, blueprints, configuración, manejadores de error, etc.) y añade todo lo que depende del protocolo WSGI y del entorno de ejecución real:

- Gestión del ciclo de vida de una petición HTTP (*dispatch*, pre/post-procesado, *teardown*).
- Creación y manejo de contextos de aplicación/petición (`AppContext`).
- Conversión de valores devueltos por las vistas en objetos `Response`.
- Construcción de URLs (`url_for`) mediante adaptadores de Werkzeug.
- Servidor de desarrollo (`run`), clientes de prueba (`test_client`, `test_cli_runner`).
- Integración con Jinja2, sesiones, señales, CLI (Click) y archivos estáticos.
- Soporte para vistas asíncronas (`async def`) mediante `asgiref`.

En resumen: **el archivo es el núcleo de Flask y contiene la implementación del objeto aplicación como callable WSGI**.

---

## 2. Dependencias principales

| Origen | Uso |
|---|---|
| `werkzeug.routing` (`MapAdapter`, `Rule`, `BuildError`, `RequestRedirect`) | Enrutamiento y construcción de URLs |
| `werkzeug.exceptions` (`HTTPException`, `InternalServerError`, `BadRequestKeyError`) | Manejo de errores HTTP |
| `werkzeug.wrappers.Response`, `werkzeug.serving.run_simple` | Respuestas base y servidor de desarrollo |
| `click` / `flask.cli` | Grupo de comandos CLI de la app |
| `flask.ctx.AppContext`, `flask.globals` | Contextos y proxies (`request`, `session`, `g`, `app_ctx`) |
| `flask.sessions` | Interfaz de sesión (cookie firmada por defecto) |
| `flask.signals` | Señales de ciclo de vida |
| `flask.templating.Environment` | Entorno Jinja2 |
| `asgiref.sync` (opcional) | Ejecutar vistas `async` desde WSGI |

---

## 3. Componentes a nivel de módulo

### 3.1 Variables de tipo (`TypeVar`)

```python
T_shell_context_processor, T_teardown, T_template_filter,
T_template_global, T_template_test, F
```
Se usan para preservar la firma de las funciones decoradas (decoradores genéricos y *wrappers*).

### 3.2 `_make_timedelta(value) -> timedelta | None`

Función auxiliar que normaliza un valor de configuración a `timedelta`:
- `None` → `None`
- `timedelta` → se devuelve tal cual
- `int` → `timedelta(seconds=value)`

### 3.3 `remove_ctx(f)` y `add_ctx(f)`

Pareja de decoradores internos que dan **compatibilidad hacia atrás** con la nueva firma de métodos que recibe `ctx: AppContext` como primer parámetro:

- **`remove_ctx(f)`**: envuelve un método *sobrescrito por el usuario con la firma antigua*. Si el primer argumento posicional es un `AppContext`, lo descarta antes de llamar al método.
- **`add_ctx(f)`**: envuelve el método *base* de `Flask`. Si la llamada no incluye un `AppContext`, lo inyecta obteniéndolo de `app_ctx._get_current_object()`.

Ambos usan `functools.update_wrapper` para conservar metadatos.

---

## 4. Clase `Flask(App)`

Objeto central de la aplicación. Se instancia típicamente como `app = Flask(__name__)`; el *import name* sirve para resolver rutas de recursos, plantillas, carpeta estática y mejorar la información de depuración.

### 4.1 Atributos de clase

| Atributo | Descripción |
|---|---|
| `default_config` | `ImmutableDict` con todos los valores de configuración por defecto: `DEBUG`, `SECRET_KEY`, `SECRET_KEY_FALLBACKS`, `PERMANENT_SESSION_LIFETIME`, `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, `MAX_FORM_MEMORY_SIZE`, `MAX_FORM_PARTS`, `TRUSTED_HOSTS`, `SERVER_NAME`, `APPLICATION_ROOT`, `PREFERRED_URL_SCHEME`, `TRAP_HTTP_EXCEPTIONS`, `MAX_COOKIE_SIZE`, `PROVIDE_AUTOMATIC_OPTIONS`, etc. |
| `request_class` | Clase usada para los objetos de petición (`flask.Request`) |
| `response_class` | Clase usada para los objetos de respuesta (`flask.Response`) |
| `session_interface` | Instancia de `SecureCookieSessionInterface` por defecto |

### 4.2 `__init_subclass__(cls, **kwargs)`

Mecanismo de **detección de firmas obsoletas**. Recorre una lista de métodos cuya firma cambió para recibir `ctx: AppContext`:

```
handle_http_exception, handle_user_exception, handle_exception,
log_exception, dispatch_request, full_dispatch_request,
finalize_request, make_default_options_response, preprocess_request,
process_response, do_teardown_request, do_teardown_appcontext
```

Para cada uno, si la subclase lo sobrescribe, inspecciona (vía `inspect.signature`) el segundo parámetro. Si **no** se llama `ctx` ni está anotado como `AppContext`:

1. Emite un `DeprecationWarning` (se eliminará el soporte en Flask 4.0).
2. Envuelve el método de la subclase con `remove_ctx`.
3. Envuelve el método base de `Flask` con `add_ctx`.

### 4.3 `__init__(...)`

Parámetros: `import_name`, `static_url_path`, `static_folder`, `static_host`, `host_matching`, `subdomain_matching`, `template_folder`, `instance_path`, `instance_relative_config`, `root_path`.

Tareas:
1. Delega en `App.__init__` (configuración, rutas base, `url_map`).
2. Crea `self.cli = cli.AppGroup()` y le asigna el nombre de la app.
3. Si hay `static_folder`, valida la coherencia `static_host`/`host_matching` y registra la ruta
   `"{static_url_path}/<path:filename>"` con endpoint `"static"`.
   La vista se registra mediante una **`weakref.ref` a la app** para evitar un ciclo de referencias entre la aplicación y la función de vista.

---

## 5. Métodos agrupados por responsabilidad

### 5.1 Recursos y archivos estáticos

| Método | Descripción |
|---|---|
| `get_send_file_max_age(filename)` | Devuelve el `max_age` de caché a partir de `SEND_FILE_MAX_AGE_DEFAULT` (acepta `int` o `timedelta`). `None` → peticiones condicionales |
| `send_static_file(filename)` | Vista registrada automáticamente para servir ficheros de `static_folder`; usa `send_from_directory` |
| `open_resource(resource, mode="rb", encoding=None)` | Abre un fichero relativo a `root_path`. **Solo lectura** (`"r"`, `"rt"`, `"rb"`) |
| `open_instance_resource(resource, mode="rb", encoding="utf-8")` | Abre un fichero relativo a `instance_path`; admite escritura |

### 5.2 Plantillas (Jinja2)

| Método | Descripción |
|---|---|
| `create_jinja_environment()` | Construye el `Environment` a partir de `jinja_options`; fija `autoescape` y `auto_reload` (según `TEMPLATES_AUTO_RELOAD`/`debug`), e inyecta los globales `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g` y la política `json.dumps_function` |
| `update_template_context(ctx, context)` | Ejecuta los *context processors* de la app y de los blueprints implicados (en orden inverso), preservando los valores originales pasados a `render_template` (tienen prioridad) |

### 5.3 Enrutamiento y URLs

| Método | Descripción |
|---|---|
| `create_url_adapter(request)` | Crea un `MapAdapter`. Con petición: aplica `TRUSTED_HOSTS`, recalcula `request.host`, desactiva `server_name` si `host_matching`, fuerza el subdominio por defecto si `subdomain_matching` está desactivado, y llama a `bind_to_environ`. Sin petición: requiere `SERVER_NAME` y usa `bind(...)` con `APPLICATION_ROOT` y `PREFERRED_URL_SCHEME`; si no, devuelve `None` |
| `raise_routing_exception(request)` | Relanza la excepción de enrutamiento. En modo debug, convierte redirecciones que perderían el cuerpo (distintas de 307/308 y métodos con cuerpo) en `FormDataRoutingRedirect`. Método interno |
| `url_for(endpoint, *, _anchor, _method, _scheme, _external, **values)` | Genera la URL. Resuelve endpoints relativos (`".name"`) con el blueprint actual, decide `_external` según si hay petición activa, aplica `inject_url_defaults`, y en caso de `BuildError` delega en `handle_url_build_error`. Valida que `_scheme` requiera `_external=True` y añade el anclaje codificado |

### 5.4 Ciclo de vida de la petición

Flujo principal:

```
__call__  →  wsgi_app  →  request_context → ctx.push()
                            ↓
                      full_dispatch_request
                            ├─ signal request_started
                            ├─ preprocess_request
                            ├─ dispatch_request
                            ├─ handle_user_exception (si hay error)
                            └─ finalize_request
                                 ├─ make_response
                                 ├─ process_response
                                 └─ signal request_finished
                            ↓
                      ctx.pop(error)  →  do_teardown_request / do_teardown_appcontext
```

| Método | Descripción |
|---|---|
| `wsgi_app(environ, start_response)` | **La aplicación WSGI real**. Crea y empuja el contexto, despacha, captura excepciones (`handle_exception`), devuelve la respuesta y garantiza el *pop* del contexto en `finally`. Soporta `werkzeug.debug.preserve_context` y el filtro `should_ignore_error`. Se mantiene separado de `__call__` para poder envolverlo con middlewares (`app.wsgi_app = Middleware(app.wsgi_app)`) |
| `__call__(environ, start_response)` | Hace la app invocable por el servidor WSGI; delega en `wsgi_app` |
| `full_dispatch_request(ctx)` | Orquesta pre-procesado, despacho, manejo de excepciones de usuario y finalización. Marca `_got_first_request` y avisa si `should_ignore_error` está definido (obsoleto) |
| `dispatch_request(ctx)` | Lanza la excepción de routing si existe; responde automáticamente a `OPTIONS` si la regla lo permite; en otro caso invoca la vista del endpoint con `view_args` a través de `ensure_sync` |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y luego `before_request_funcs` (app + blueprints). Si algún `before_request` devuelve un valor no-`None`, se usa como respuesta y se corta el despacho |
| `process_response(ctx, response)` | Ejecuta las funciones `after_request` (del contexto y registradas, en orden inverso) y guarda la sesión mediante `session_interface.save_session` si no es *null session* |
| `finalize_request(ctx, rv, from_error_handler=False)` | Convierte el valor de retorno en respuesta (`make_response`), aplica `process_response` y emite `request_finished`. Con `from_error_handler=True` registra y silencia fallos del post-procesado |
| `make_default_options_response(ctx)` | Construye la respuesta `OPTIONS` por defecto con los métodos permitidos por el `url_adapter` |
| `make_response(rv)` | Convierte el valor devuelto por una vista en `response_class`. Admite `str`, `bytes`, `dict`/`list` (→ JSON), generadores/iteradores (→ streaming), tuplas `(body, status, headers)` / `(body, status)` / `(body, headers)`, instancias de `Response`, otras respuestas Werkzeug (coerción con `force_type`) y callables WSGI. Lanza `TypeError` con mensajes descriptivos en casos inválidos (incluido retorno `None`) |
| `do_teardown_request(ctx, exc=None)` | Ejecuta todos los `teardown_request` (app + blueprints, orden inverso) y emite `request_tearing_down`. Usa `_CollectErrors` para ejecutar **todos** los callbacks y relanzar los errores agrupados |
| `do_teardown_appcontext(ctx, exc=None)` | Equivalente para `teardown_appcontext` + señal `appcontext_tearing_down`, también con recolección de errores |

### 5.5 Manejo de errores

| Método | Descripción |
|---|---|
| `handle_http_exception(ctx, e)` | Busca un manejador registrado por código y por MRO. Devuelve la excepción sin cambios si no tiene `code` (excepciones proxy) o si es una `RoutingException` |
| `handle_user_exception(ctx, e)` | Punto de entrada general: activa `show_exception` para `BadRequestKeyError` en debug/`TRAP_BAD_REQUEST_ERRORS`, delega en `handle_http_exception` para `HTTPException` no "trapeadas", busca un manejador o relanza |
| `handle_exception(ctx, e)` | Para errores sin manejador. Emite `got_request_exception`; si `PROPAGATE_EXCEPTIONS` (o `testing`/`debug`) relanza; si no, registra el error y produce un `InternalServerError` (con `original_exception`), pasándolo al manejador de 500 si existe, y finaliza la petición |
| `log_exception(ctx, exc_info)` | Registra la excepción como `error` en `self.logger` incluyendo ruta y método |

### 5.6 Contextos

| Método | Descripción |
|---|---|
| `app_context()` | Devuelve un `AppContext` para usar con `with` (habilita `current_app` y `g`) |
| `request_context(environ)` | Crea un `AppContext` con información de petición a partir de un `WSGIEnvironment` (`AppContext.from_environ`). Uso interno |
| `test_request_context(*args, **kwargs)` | Construye un entorno WSGI con `testing.EnvironBuilder` y devuelve el contexto de petición correspondiente; ideal para pruebas |

### 5.7 Soporte asíncrono

| Método | Descripción |
|---|---|
| `ensure_sync(func)` | Devuelve la función tal cual si es síncrona; si es corrutina, la convierte con `async_to_sync`. Se usa en todos los puntos donde se invocan callbacks de usuario |
| `async_to_sync(func)` | Usa `asgiref.sync.async_to_sync`; si `asgiref` no está instalado lanza `RuntimeError` indicando instalar Flask con el extra `async` |

### 5.8 Ejecución, CLI y testing

| Método | Descripción |
|---|---|
| `run(host, port, debug, load_dotenv, **options)` | Arranca el servidor de desarrollo de Werkzeug (`run_simple`). **No apto para producción.** Ignora la llamada si se ejecuta desde `flask run` (`FLASK_RUN_FROM_CLI`), carga `.env`/`.flaskenv`, resuelve host/puerto desde `SERVER_NAME` (por defecto `127.0.0.1:5000`), activa *reloader*/*debugger*/`threaded` según corresponda, muestra el banner y restablece `_got_first_request` al terminar |
| `make_shell_context()` | Devuelve el contexto del shell interactivo (`app`, `g` + todos los `shell_context_processors`) |
| `test_client(use_cookies=True, **kwargs)` | Crea un cliente de pruebas (`test_client_class` o `FlaskClient`), usable como gestor de contexto para inspeccionar los *context locals* |
| `test_cli_runner(**kwargs)` | Crea un runner para probar comandos CLI (`test_cli_runner_class` o `FlaskCliRunner`) |

---

## 6. Señales emitidas

| Señal | Momento |
|---|---|
| `request_started` | Al comenzar `full_dispatch_request` |
| `request_finished` | Tras `process_response` |
| `got_request_exception` | En `handle_exception`, siempre |
| `request_tearing_down` | Al final de `do_teardown_request` |
| `appcontext_tearing_down` | Al final de `do_teardown_appcontext` |

---

## 7. Notas de diseño relevantes

- **Separación `App` / `Flask`**: la lógica independiente del transporte vive en `flask.sansio.app.App`; este módulo añade la capa WSGI, lo que facilita implementaciones alternativas (p. ej. ASGI).
- **Contexto explícito**: los métodos del ciclo de vida reciben `ctx: AppContext` en lugar de depender únicamente de los proxies globales; `__init_subclass__` mantiene compatibilidad con subclases antiguas.
- **`weakref` para la ruta estática**: evita ciclos de referencia que retrasarían la recolección de basura de la aplicación.
- **Recolección de errores en *teardown***: `_CollectErrors` garantiza que todos los callbacks se ejecuten aunque alguno falle.
- **`wsgi_app` separado de `__call__`**: permite aplicar middlewares conservando el objeto aplicación original.
- **Compatibilidad hacia atrás documentada** mediante directivas `.. versionadded::` / `.. versionchanged::` en los docstrings y `DeprecationWarning` para `should_ignore_error` y las firmas sin `ctx`.