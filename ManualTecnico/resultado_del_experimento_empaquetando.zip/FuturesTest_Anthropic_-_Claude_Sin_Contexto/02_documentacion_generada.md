# Documentación técnica — `com.google.common.util.concurrent.FuturesTest`

## 1. Descripción general

`FuturesTest` es la **suite de pruebas unitarias** (JUnit 3, vía `junit.framework.TestCase`) de la clase utilitaria `com.google.common.util.concurrent.Futures` de Guava.

Su objetivo es verificar, de forma exhaustiva, el comportamiento de los *combinadores* y *fábricas* de `ListenableFuture` que expone `Futures`, cubriendo no solo el camino feliz (resultado disponible), sino también:

- propagación de **excepciones**, **errores** (`Error`) y `RejectedExecutionException`;
- semántica de **cancelación** e **interrupción** (hacia atrás, a los futuros de entrada, y hacia adelante, a los futuros derivados);
- **registro (logging)** de excepciones "sobrantes" en futuros agregados (`AggregateFuture`);
- **liberación de referencias** (GC) a futuros de entrada y a los *callables* combinadores;
- robustez frente a implementaciones incorrectas (p. ej. una `AsyncFunction` que devuelve `null`);
- comportamiento de los `toString()` de los futuros derivados (útil para depuración).

### Características estructurales relevantes

| Elemento | Detalle |
|---|---|
| Anotaciones de clase | `@NullMarked` (nulabilidad explícita según JSpecify), `@GwtCompatible` (la clase se compila también para GWT/J2CL) |
| Anotaciones por método | `@GwtIncompatible` y `@J2ktIncompatible` marcan pruebas que no pueden ejecutarse bajo GWT/J2CL o J2KT (uso de hilos, reflexión, `StackOverflowError`, genéricos comodín, etc.); `@AndroidIncompatible` marca pruebas con alto consumo de memoria |
| Estilo | Importaciones estáticas masivas de `Futures.*` y de `Truth.assertThat`, de modo que las pruebas se leen como DSL |

### Estado (campos)

| Campo | Descripción |
|---|---|
| `aggregateFutureLogger` | `Logger` de `AggregateFuture`, al que se engancha un *handler* para capturar lo que Guava registra |
| `aggregateFutureLogHandler` | `TestLogHandler` que almacena los `LogRecord` emitidos durante la prueba |
| `DATA1`, `DATA2`, `DATA3` | Cadenas constantes usadas como valores de los futuros de entrada |
| `REJECTING_EXECUTOR` | `Executor` que siempre lanza `RejectedExecutionException`; permite probar la propagación del rechazo al futuro de salida |

---

## 2. Ciclo de vida de la prueba

| Método | Responsabilidad |
|---|---|
| `setUp()` | Llama a `super.setUp()` y registra `aggregateFutureLogHandler` en el logger de `AggregateFuture`, para poder afirmar sobre lo que se registra. |
| `tearDown()` | Limpia el estado de interrupción del hilo actual (`TestPlatform.clearInterrupt()`) para que una interrupción provocada por una prueba no contamine las siguientes, elimina el *handler* de log y delega en `super.tearDown()`. |

---

## 3. Métodos de prueba principales (agrupados por API probada)

### 3.1 Futuros inmediatos

| Método | Qué verifica |
|---|---|
| `testImmediateFuture()` | `immediateFuture(v)` ya está completo, devuelve `v` con y sin *timeout*, y su `toString()` indica `status=SUCCESS`. |
| `testImmediateVoidFuture()` | `immediateVoidFuture()` completa con `null`. |
| `testImmediateFailedFuture()` | `immediateFailedFuture(e)` lanza `ExecutionException` con causa `e`; `toString()` indica `status=FAILURE`. |
| `testImmediateFailedFuture_cancellationException()` | Un futuro fallido con `CancellationException` **no** se considera cancelado (`isCancelled() == false`). |
| `testImmediateCancelledFutureBasic()` | `immediateCancelledFuture()` está cancelado. |
| `testImmediateCancelledFutureStack()` | La `CancellationException` que se lanza al leer el futuro tiene la pila del *consumidor* (`CallerClass2`) y no la del *productor* (`CallerClass1`), y no tiene causa. |

### 3.2 `transform` y `transformAsync`

Bloque muy amplio que cubre:

- **Genéricos y nulabilidad**: `testTransform_genericsNull`, `testTransform_genericsHierarchy`, `testTransformAsync_genericsWildcard_asyncFunction`, `testTransformAsync_genericsHierarchy_asyncFunction`.
- **Propagación de cancelación/interrupción**: `testTransformAsync_cancelPropagatesToInput`, `..._interruptPropagatesToInput`, `..._cancelPropagatesToAsyncOutput`, `..._interruptPropagatesToAsyncOutput`, `..._inputCancelButNotInterruptPropagatesToOutput`, `..._interruptPropagatesToTransformingThread`.
- **Fallos del transformador**: `testTransform_errorAfterCancellation`, `..._exceptionAfterCancellation`, `..._getThrowsRuntimeException`, `..._getThrowsError`, `..._listenerThrowsError`, `testTransformAsync_asyncFunction_error`, `..._nullInsteadOfFuture` (comprueba el mensaje de NPE que sugiere `immediateFuture(null)`).
- **Desbordamiento de pila**: `testTransform_stackOverflow`, `testTransformAsync_stackOverflow`.
- **Executor**: `testTransform_executor` (usa `ExecutorSpy`), `testTransform_rejectionPropagatesToOutput`, `testTransformAsync_rejectionPropagatesToOutput`.
- **Memoización del resultado**: `testTransformValueRemainsMemoized` y `testTransformExceptionRemainsMemoized` comprueban que la función se aplica **una sola vez** y que su resultado (valor, excepción o `Error`) queda fijado.
- **Cancelación y ejecución diferida**: `testTransformAsync_asyncFunction_cancelledWhileApplyingFunction`, `..._cancelledBeforeApplyingFunction`, `..._timeout`.
- **Depuración**: `testTransformAsync_functionToString` (el `toString()` del futuro incluye el de la función en ejecución).

### 3.3 `lazyTransform`

| Método | Qué verifica |
|---|---|
| `testLazyTransform()` | La función se aplica **en cada** llamada a `get()` (no se memoiza), usando `FunctionSpy` para contar invocaciones. |
| `testLazyTransform_exception()` | Las excepciones de la función se envuelven en `ExecutionException`, tanto en el `get()` sin *timeout* como con él. |

### 3.4 `catching` y `catchingAsync`

Pruebas clonadas del antiguo `withFallback`:

- **Camino feliz / fallback**: `testCatching[Async]_inputDoesNotRaiseException`, `..._inputRaisesException`, `..._fallbackNotReady`.
- **Filtrado por tipo de excepción**: `testCatching[Async]_throwable`, `..._customTypeMatch`, `..._customTypeNoMatch`, `..._inputCancelledWithoutFallback`.
- **Fallos del fallback**: `..._fallbackGeneratesRuntimeException`, `..._fallbackGeneratesCheckedException`, `..._fallbackGeneratesError`, `..._fallbackReturnsRuntimeException`, `..._fallbackReturnsCheckedException`, `..._nullInsteadOfFuture`.
- **Cancelación**: `..._resultInterruptedBeforeFallback`, `..._resultCancelledBeforeFallback`, `..._resultCancelledAfterFallback`, `..._errorAfterCancellation`, `..._exceptionAfterCancellation`, `..._interruptPropagatesToTransformingThread`.
- **Otros**: `..._stackOverflow`, `..._getThrowsRuntimeException`, `..._getThrowsError`, `..._listenerThrowsError`, `..._rejectionPropagatesToOutput`, `..._functionToString`, `testCatchingAsync_futureToString`.

Los métodos privados `runExpectedExceptionCatchingAsyncTest(...)` y `runExpectedExceptionCatchingTest(...)` parametrizan estos escenarios (lanzar la excepción vs. devolverla envuelta en un futuro).

### 3.5 `submit`, `submitAsync` y `scheduleAsync`

| Método | Qué verifica |
|---|---|
| `testSubmit_callable_returnsValue` / `_throwsException` | `submit(Callable, Executor)` completa con el valor o envuelve la excepción. |
| `testSubmit_runnable_completesAfterRun` / `_throwsException` | `submit(Runnable, Executor)` solo completa cuando el *executor* ejecuta la tarea; las excepciones se propagan. |
| `testSubmitAsync_asyncCallable_error`, `..._nullInsteadOfFuture`, `..._cancelledWhileApplyingFunction`, `..._cancelledBeforeApplyingFunction`, `