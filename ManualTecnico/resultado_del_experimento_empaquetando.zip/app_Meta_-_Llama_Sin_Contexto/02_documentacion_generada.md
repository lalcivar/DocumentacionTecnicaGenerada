# Documentación Técnica - `flask/app.py` - Clase `Flask`

## 1. Descripción General

**Archivo:** `flask/app.py`  
**Clase Principal:** `Flask`  
**Herencia:** `Flask(App)` -> hereda de `sansio.app.App`  
**Tipo:** Núcleo del Framework Flask  
**Protocolo:** WSGI - Web Server Gateway Interface

Este archivo implementa el objeto central de cualquier aplicación Flask. La clase `Flask` es la aplicación WSGI propiamente dicha. Actúa como registro central para:

* Definición de rutas y vistas `view_functions`
* Gestión de configuración `config`
* Motor de plantillas Jinja2
* Gestión de contextos de aplicación y de petición `AppContext`
* Ciclo de vida completo de la petición HTTP
* Manejo de sesiones, errores y señales

Instanciar `Flask(__name__)` crea el contenedor que orquesta toda la interacción entre el servidor web, Werkzeug y el código del usuario.

> **Uso típico:**
> ```python
> from flask import Flask
> app = Flask(__name__)
> ```

---

### 2. Dependencias Principales

| Librería | Uso en el archivo |
| :--- | :--- |
| `werkzeug` | Routing `MapAdapter, Rule`, Wrappers `Request, Response`, Servidor `run_simple`, Excepciones `HTTPException` |
| `jinja2` | Creación del entorno de plantillas `Environment` |
| `click` | Grupo de comandos CLI `AppGroup` |
| `itsdangerous` | Vía `SecureCookieSessionInterface` para sesiones firmadas |
| `.sansio.app.App` | Clase base que contiene la lógica independiente de I/O |
| `.ctx.AppContext` | Gestión de contextos con `ContextVar` |
| `.signals` | Señales `request_started`, `request_finished`, `got_request_exception` |

---

### 3. Componentes Principales

#### 3.1 Funciones Auxiliares de Módulo

| Función | Descripción |
| :--- | :--- |
| `_make_timedelta(value)` | Normaliza un valor de configuración a `timedelta`. Si recibe un `int`, lo convierte a segundos. Si es `None` o `timedelta`, lo retorna sin cambios. Usado para `PERMANENT_SESSION_LIFETIME`. |
| `remove_ctx(f)` | Decorador para compatibilidad hacia atrás. Elimina el nuevo argumento `ctx: AppContext` si una subclase aún usa la firma antigua sin `ctx`. Envuelve el método para mantener compatibilidad hasta Flask 4.0. |
| `add_ctx(f)` | Decorador inverso. Inyecta automáticamente el `AppContext` actual `app_ctx._get_current_object()` cuando se llama a un método base desde una subclase con firma antigua. |

#### 3.2 Método de Metaprogramación

**`__init_subclass__(cls)`**
Intercepta la creación de subclases de `Flask`. Inspecciona mediante `inspect.signature` si los métodos críticos `handle_exception`, `dispatch_request`, `finalize_request`, etc., fueron sobreescritos sin el nuevo parámetro `ctx`. Si detecta la firma antigua, emite un `DeprecationWarning` y aplica `remove_ctx` / `add_ctx` para adaptar la llamada. Garantiza la transición no disruptiva a la nueva API.

#### 3.3 Clase `Flask`

##### A. Atributos de Clase y Configuración

*   `default_config: ImmutableDict`: Diccionario inmutable con la configuración por defecto de toda aplicación Flask. Incluye:
    `DEBUG`, `TESTING`, `SECRET_KEY`, `SERVER_NAME`, `APPLICATION_ROOT`, `SESSION_COOKIE_*`, `MAX_CONTENT_LENGTH`, `PREFERRED_URL_SCHEME`, `TEMPLATES_AUTO_RELOAD`, entre otros.
*   `request_class: type[Request] = Request`: Clase a instanciar por cada petición entrante.
*   `response_class: type[Response] = Response`: Clase a instanciar para construir respuestas.
*   `session_interface: SessionInterface = SecureCookieSessionInterface()`: Estrategia para guardar/cargar sesiones en cookies firmadas.

##### B. Constructor `__init__()`

Inicializa la aplicación. Delega la mayor parte de la lógica a `super().__init__()` de `sansio.app.App`.

**Parámetros clave:**
`import_name`, `static_url_path`, `static_folder`, `static_host`, `host_matching`, `subdomain_matching`, `template_folder`, `instance_path`, `root_path`.

**Lógica relevante:**
1.  Crea el grupo CLI `self.cli = cli.AppGroup()` y le asigna `self.name`.
2.  Si `has_static_folder` es verdadero, registra automáticamente la ruta `"{static_url_path}/<path:filename>"` con endpoint `static` y `view_func = send_static_file`.

##### C. Gestión de Recursos y Plantillas

| Método | Descripción |
| :--- | :--- |
| `get_send_file_max_age(filename)` | Determina el `max_age` para caché de `send_file`. Lee `SEND_FILE_MAX_AGE_DEFAULT` del config. |
| `send_static_file(filename)` | View function para servir archivos estáticos. Usa `send_from_directory()`. |
| `open_resource(resource, mode, encoding)` | Abre un archivo relativo a `root_path` solo en modo lectura. |
| `open_instance_resource(resource, mode, encoding)` | Abre un archivo relativo a `instance_path`. Permite escritura. |
| `create_jinja_environment()` | Crea y configura el `Environment` de Jinja2. Inyecta globales `url_for`, `get_flashed_messages`, `config`, `request`, `session`, `g` y la política `json.dumps_function`. |

##### D. Enrutamiento y URLs

| Método | Descripción |
| :--- | :--- |
| `create_url_adapter(request)` | Crea un `MapAdapter` de Werkzeug para hacer `match` y `build` de URLs. Gestiona `TRUSTED_HOSTS`, `SERVER_NAME`, `host_matching` y `subdomain_matching`. Si no hay request, intenta crear el adapter con `SERVER_NAME`. |
| `raise_routing_exception(request)` | En modo `debug`, intercepta `RequestRedirect` para peticiones no GET/HEAD/OPTIONS y lo convierte en `FormDataRoutingRedirect` para evitar pérdida de datos de formulario. |
| `url_for(endpoint, ...)` | Implementación central de `flask.url_for`. Resuelve endpoints relativos `.nombre`, inyecta `url_defaults`, construye la URL con `url_adapter.build()` y maneja `_anchor`, `_scheme`, `_external`. Delegado por el helper global `flask.url_for`. |
| `make_default_options_response(ctx)` | Genera la respuesta automática para peticiones `OPTIONS` con la cabecera `Allow`. |

##### E. Ciclo de Vida de la Petición - Núcleo WSGI

Este es el flujo más importante del archivo:

```
wsgi_app(environ) -> request_context(environ) -> ctx.push()
  -> full_dispatch_request(ctx)
    -> request_started signal
    -> preprocess_request(ctx) [before_request + url_value_preprocessors]
    -> dispatch_request(ctx) [match URL + ejecuta view_function]
    -> handle_user_exception() si hay error
  -> finalize_request(ctx, rv) [make_response + process_response + request_finished]
  -> ctx.pop() -> do_teardown_request() + do_teardown_appcontext()
```

| Método | Responsabilidad |
| :--- | :--- |
| `wsgi_app(environ, start_response)` | **Entry point WSGI.** Crea el `AppContext`, hace `push()`, llama a `full_dispatch_request`, gestiona excepciones con `handle_exception` y garantiza el `pop()` del contexto incluso con errores. Respeta `werkzeug.debug.preserve_context`. |
| `__call__(environ, start_response)` | Hace que la instancia `app` sea callable como aplicación WSGI. Simplemente delega a `wsgi_app`. Permite aplicar middlewares sobre `wsgi_app`. |
| `full_dispatch_request(ctx)` | Orquesta el dispatch completo. Marca `_got_first_request`, envía señal `request_started`, ejecuta `preprocess_request` y `dispatch_request`. Captura cualquier `Exception` y la delega a `handle_user_exception`. |
| `preprocess_request(ctx)` | Ejecuta `url_value_preprocessors` y `before_request_funcs` de la app y del blueprint. Si alguna función retorna un valor no nulo, corta el flujo y lo usa como respuesta. |
| `dispatch_request(ctx)` | Hace el matching real. Si hay `routing_exception` la eleva. Si la regla tiene `provide_automatic_options` y el método es `OPTIONS`, retorna `make_default_options_response`. Si no, ejecuta `view_functions[endpoint](**view_args)`. |
| `finalize_request(ctx, rv, from_error_handler)` | Convierte `rv` a `Response` con `make_response`, luego aplica `process_response` y envía `request_finished`. |
| `process_response(ctx, response)` | Ejecuta `after_request` del contexto y de la app/blueprint en orden inverso, y guarda la sesión con `session_interface.save_session()`. |
| `do_teardown_request(ctx, exc)` | Ejecuta `teardown_request_funcs` y envía `request_tearing_down`. Usa `_CollectErrors` para ejecutar todos los callbacks aunque uno falle. |
| `do_teardown_appcontext(ctx, exc)` | Ejecuta `teardown_appcontext_funcs` y envía `appcontext_tearing_down`. |

##### F. Manejo de Respuestas y Conversión

**`make_response(rv)`**
Normaliza cualquier valor retornado por una vista a una instancia de `response_class`. Soporta:
*   `str`, `bytes`, `bytearray`, `Iterator` -> Crea Response directamente
*   `dict`, `list` -> Convierte a JSON vía `self.json.response()`
*   `tuple` -> Desempaqueta `(body, status, headers)`, `(body, status)` o `(body, headers)`
*   `Response` u otro `BaseResponse` / `callable` WSGI -> Coerción con `force_type`
*   Lanza `TypeError` si `rv is None` o el tipo no es válido.

**`ensure_sync(func)` y `async_to_sync(func)`**
Soporte para vistas asíncronas en un servidor WSGI síncrono. Si `func` es `iscoroutinefunction`, la envuelve con `asgiref.sync.async_to_sync` para ejecutarla de forma bloqueante.

##### G. Manejo de Errores

| Método | Descripción |
| :--- | :--- |
| `handle_http_exception(ctx, e)` | Busca un handler registrado para el código de `HTTPException` o su MRO. Si no existe, retorna la excepción misma. Ignora `RoutingException`. |
| `handle_user_exception(ctx, e)` | Punto de entrada para cualquier excepción en la vista. Si es `BadRequestKeyError` y `DEBUG`/`TRAP_BAD_REQUEST_ERRORS`, muestra la clave. Si es `HTTPException`, delega a `handle_http_exception`. Si no, busca handler; si no hay, hace `raise`. |
| `handle_exception(ctx, e)` | Último recurso para excepciones no manejadas. Envía `got_request_exception`, respeta `PROPAGATE_EXCEPTIONS` re-elevando el error en debug/testing, loguea con `log_exception`, crea un `InternalServerError(original_exception=e)` y busca handler para 500. |
| `log_exception(ctx, exc_info)` | Loguea `Exception on {path} [{method}]` con `self.logger.error`. |

##### H. Contextos, Testing y Utilidades

| Método | Descripción |
| :--- | :--- |
| `app_context()` | Crea un `AppContext` manual para usar con `with app.app_context():`. Expone `current_app` y `g`. |
| `request_context(environ)` | Crea un `AppContext` desde un `environ` WSGI. Expone `request` y `session`. No debe usarse directamente. |
| `test_request_context(*args, **kwargs)` | Helper para tests. Usa `EnvironBuilder` para crear un `environ` falso y retorna un `request_context`. |
| `test_client(use_cookies, **kwargs)` | Crea un `FlaskClient` para tests de integración HTTP. |
| `test_cli_runner(**kwargs)` | Crea un `FlaskCliRunner` para testear comandos `click`. |
| `make_shell_context()` | Ejecuta todos los `shell_context_processors` y retorna `{"app": self, "g": g}` para `flask shell`. |
| `update_template_context(ctx, context)` | Inyecta variables al contexto de Jinja. Ejecuta `template_context_processors` de la app y blueprints. |
| `run(host, port, debug, load_dotenv, **options)` | Servidor de desarrollo. Carga `.env`, resuelve `host/port` desde `SERVER_NAME`, configura `use_reloader`/`use_debugger` y llama a `werkzeug.serving.run_simple`. Ignora la llamada si `FLASK_RUN_FROM_CLI=true`. |

---

### 4. Flujo de Ejecución Resumido

1.  El servidor WSGI invoca `app(environ, start_response)` -> `wsgi_app`.
2.  Se crea y se hace `push` del `AppContext`.
3.  `full_dispatch_request` dispara `preprocess_request` y `dispatch_request`.
4.  El valor de la vista se normaliza con `make_response` y se post-procesa con `process_response`.
5.  Se ejecutan los teardowns y se hace `pop` del contexto, retornando el iterable de bytes al servidor.

Este archivo es, por tanto, el **orquestador del framework**: conecta el routing de Werkzeug, el renderizado de Jinja2, el sistema de señales y el ciclo de vida WSGI en una sola clase cohesiva y extensible.