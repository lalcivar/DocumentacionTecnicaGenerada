# Documentación Técnica: `requests/models.py`

## 1. Descripción general

El módulo `requests.models` contiene los objetos primarios que dan soporte al funcionamiento de la librería **Requests**. Define el modelo de datos completo del ciclo de vida de una petición HTTP:

1. **Construcción declarativa** de una petición por parte del usuario (`Request`).
2. **Preparación / normalización** de esa petición hasta obtener los bytes exactos que se enviarán al servidor (`PreparedRequest`).
3. **Representación y consumo** de la respuesta devuelta por el servidor (`Response`).

Adicionalmente, el módulo aporta dos *mixins* reutilizables que encapsulan la lógica de codificación de cuerpos/parámetros (`RequestEncodingMixin`) y la gestión de *hooks* de eventos (`RequestHooksMixin`).

El módulo está escrito con anotaciones de tipos modernas (`from __future__ import annotations`, `typing.overload`, `Final`, `Literal`, `cast`) y utiliza `urllib3` para el parseo de URLs y la codificación *multipart*.

### Nota de implementación relevante

```python
import encodings.idna  # noqa: F401
```

La importación explícita de `encodings.idna` se realiza al inicio para evitar una importación implícita posterior dentro de hilos, lo que podría provocar un `LookupError` cuando la librería estándar se encuentra empaquetada en un ZIP (p. ej. *Embedded Python*).

---

## 2. Dependencias principales

| Origen | Elementos utilizados | Propósito |
|---|---|---|
| `urllib3.exceptions` | `DecodeError`, `LocationParseError`, `ProtocolError`, `ReadTimeoutError`, `SSLError` | Captura de errores de bajo nivel para traducirlos a excepciones propias de Requests |
| `urllib3.fields` / `urllib3.filepost` | `RequestField`, `encode_multipart_formdata` | Construcción de cuerpos `multipart/form-data` |
| `urllib3.util` | `parse_url` | Parseo de URLs conforme a RFC 3986 |
| `.compat` | `JSONDecodeError`, `basestring`, `builtin_str`, `chardet`, `cookielib`, `urlencode`, `urlsplit`, `urlunparse`, `json as complexjson` | Capa de compatibilidad |
| `.cookies` | `_copy_cookie_jar`, `cookiejar_from_dict`, `get_cookie_header` | Gestión de cookies |
| `.exceptions` | `InvalidURL`, `MissingSchema`, `HTTPError`, `InvalidJSONError`, `StreamConsumedError`, etc. | Errores públicos de la librería |
| `.utils` / `._internal_utils` | `super_len`, `requote_uri`, `check_header_validity`, `guess_json_utf`, `to_native_string`, `unicode_is_ascii`, … | Utilidades de normalización y detección |
| `.hooks`, `.status_codes`, `.structures` | `default_hooks`, `codes`, `CaseInsensitiveDict` | Infraestructura auxiliar |

---

## 3. Constantes del módulo

| Constante | Tipo | Valor | Descripción |
|---|---|---|---|
| `REDIRECT_STATI` | `Final[tuple[int, ...]]` | `(301, 302, 303, 307, 308)` | Conjunto de códigos HTTP que indican una redirección procesable automáticamente |
| `DEFAULT_REDIRECT_LIMIT` | `int` | `30` | Número máximo de redirecciones permitidas por defecto |
| `CONTENT_CHUNK_SIZE` | `int` | `10 * 1024` | Tamaño de bloque usado al leer `Response.content` |
| `ITER_CHUNK_SIZE` | `int` | `512` | Tamaño de bloque por defecto en `Response.iter_lines()` |

---

## 4. Componentes principales

### 4.1 `RequestEncodingMixin`

Mixin sin estado propio (salvo el atributo esperado `url`) que aporta la lógica de **codificación de URL, parámetros y cuerpos**.

#### Propiedades

| Miembro | Firma | Descripción |
|---|---|---|
| `path_url` | `-> str` | Construye la parte *path + query* de la URL (`/ruta?query`). Si no hay path, devuelve `/`. |

#### Métodos estáticos

**`_encode_params(data) -> str | bytes | SupportsRead`**

Codifica parámetros. Está declarado con múltiples `@overload` para precisar el tipo de retorno según la entrada:

| Entrada | Retorno | Comportamiento |
|---|---|---|
| `str` | `str` | Se devuelve tal cual |
| `bytes` | `bytes` | Se devuelve tal cual |
| objeto con `.read()` | el mismo objeto | Se delega al stream |
| `dict` / lista de 2-tuplas | `str` | Se aplica `urlencode(..., doseq=True)` |

Soporta valores múltiples por clave (listas/iterables), omite valores `None` y codifica claves y valores a UTF-8. El orden se conserva cuando la entrada es una lista de 2-tuplas.

**`_encode_files(files, data) -> tuple[bytes, str]`**

Construye el cuerpo de una petición `multipart/form-data` y devuelve `(body, content_type)`.

- Lanza `ValueError` si no se proporcionan `files` o si `data` es una cadena.
- Acepta `files` como `dict` o lista de tuplas; cada valor puede ser:
  - un objeto fichero / cadena / bytes,
  - una 2-tupla `(filename, fileobj)`,
  - una 3-tupla `(filename, fileobj, content_type)`,
  - una 4-tupla `(filename, fileobj, content_type, custom_headers)`.
- Si no se indica nombre de fichero, se infiere con `guess_filename()` o se usa la clave.
- Delegación final a `encode_multipart_formdata()` de `urllib3`.

---

### 4.2 `RequestHooksMixin`

Mixin que gestiona el registro de *callbacks* asociados a eventos.

| Método | Firma | Descripción |
|---|---|---|
| `register_hook` | `(event: str, hook: Iterable[HookType] \| HookType) -> None` | Registra uno o varios hooks en un evento. Lanza `ValueError` si el evento no está soportado. Acepta un callable único o un iterable de callables (filtrando defensivamente los no invocables). |
| `deregister_hook` | `(event: str, hook: HookType) -> bool` | Elimina un hook previamente registrado. Devuelve `True` si existía, `False` en caso contrario. |

---

### 4.3 `Request(RequestHooksMixin)`

Objeto **creado por el usuario** que describe de forma declarativa una petición. No se envía directamente: se transforma en un `PreparedRequest`.

#### Constructor

```python
Request(method=None, url=None, headers=None, files=None, data=None,
        params=None, auth=None, cookies=None, hooks=None, json=None)
```

| Parámetro | Descripción |
|---|---|
| `method` | Método HTTP a utilizar |
| `url` | URL de destino |
| `headers` | Diccionario de cabeceras |
| `files` | Diccionario `{nombre: fileobj}` para subida *multipart* |
| `data` | Cuerpo de la petición; si es `dict` o lista de 2-tuplas se aplica *form-encoding* |
| `json` | Cuerpo JSON (se usa si no hay `files` ni `data`) |
| `params` | Parámetros de query string |
| `auth` | Handler de autenticación o tupla `(usuario, contraseña)` |
| `cookies` | `dict` o `CookieJar` |
| `hooks` | Diccionario de hooks (uso interno) |

Los parámetros nulos se inicializan a colecciones vacías; los hooks se inicializan con `default_hooks()` y luego se registran los proporcionados.

#### Métodos

| Método | Descripción |
|---|---|
| `prepare() -> PreparedRequest` | Construye y devuelve el `PreparedRequest` listo para transmisión |
| `__repr__()` | `<Request [MÉTODO]>` |

#### Ejemplo

```python
>>> import requests
>>> req = requests.Request('GET', 'https://httpbin.org/get')
>>> req.prepare()
<PreparedRequest [GET]>
```

---

### 4.4 `PreparedRequest(RequestEncodingMixin, RequestHooksMixin)`

Objeto **totalmente mutable** que contiene los bytes exactos que se enviarán al servidor. Se genera a partir de un `Request`; **no debe instanciarse manualmente**.

#### Atributos

| Atributo | Tipo | Descripción |
|---|---|---|
| `method` | `str \| None` | Verbo HTTP normalizado a mayúsculas |
| `url` | `str \| None` | URL final ya normalizada/recodificada |
| `headers` | `CaseInsensitiveDict[str \| bytes]` | Cabeceras HTTP |
| `body` | `BodyType` | Cuerpo a enviar (bytes, str o stream) |
| `hooks` | `dict[str, list[HookType]]` | Hooks registrados |
| `_cookies` | `CookieJar \| None` | `CookieJar` usado para generar la cabecera `Cookie` |
| `_body_position` | `int \| object \| None` | Posición inicial de un cuerpo *file-like*, para poder rebobinar en redirecciones |

#### Método orquestador

**`prepare(method, url, headers, files, data, params, auth, cookies, hooks, json)`**

Ejecuta la cadena de preparación en un orden estricto:

1. `prepare_method()`
2. `prepare_url()`
3. `prepare_headers()`
4. `prepare_cookies()`
5. `prepare_body()`
6. `prepare_auth()` — **debe ser el último paso funcional**, para que esquemas como OAuth operen sobre una petición completamente preparada.
7. `prepare_hooks()` — posterior a `prepare_auth` porque los autenticadores pueden añadir hooks.

#### Métodos de preparación

| Método | Descripción |
|---|---|
| `prepare_method(method)` | Normaliza el verbo HTTP a mayúsculas y a cadena nativa |
| `_get_idna_encoded_host(host)` *(estático)* | Codifica el host con IDNA (`uts46=True`); lanza `UnicodeError` ante `idna.IDNAError` |
| `prepare_url(url, params)` | Normalización completa de la URL (ver detalle abajo) |
| `prepare_headers(headers)` | Crea un `CaseInsensitiveDict`, valida cada cabecera con `check_header_validity()` y normaliza los nombres |
| `prepare_body(data, files, json)` | Determina y construye el cuerpo (ver detalle abajo) |
| `prepare_content_length(body)` | Fija `Content-Length` según `super_len(body)`; si no hay cuerpo y el método no es `GET`/`HEAD`, establece `Content-Length: 0` |
| `prepare_auth(auth, url)` | Si no se pasa auth, la extrae de la URL con `get_auth_from_url()`. Una tupla de 2 elementos se trata como *Basic Auth