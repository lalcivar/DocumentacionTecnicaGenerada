# Documentación técnica: `com.google.common.collect.Maps`

## 1. Descripción general

`Maps` es una **clase de utilidades estáticas** (`final`, con constructor privado, no instanciable) perteneciente a la librería **Guava** de Google. Su propósito es agrupar métodos auxiliares relacionados con el manejo de instancias de `Map` y sus variantes (`SortedMap`, `NavigableMap`, `BiMap`, `ConcurrentMap`, `EnumMap`, etc.).

Es la contraparte, para mapas, de otras clases de utilidad de Guava como `Lists`, `Sets` y `Queues`.

**Características principales:**

| Aspecto | Detalle |
|---|---|
| Tipo | Clase utilitaria final, no instanciable (`private Maps() {}`) |
| Paquete | `com.google.common.collect` |
| Anotaciones | `@GwtCompatible` (compatible con GWT; ciertos métodos marcados `@GwtIncompatible` / `@J2ktIncompatible`) |
| Desde | Guava 2.0 |
| Soporte de nulabilidad | Uso extensivo de genéricos con `@Nullable Object` y `@ParametricNullness` (JSpecify) |

**Dos grandes familias de operaciones:**

1. **Fábricas (copias)** — crean mapas nuevos e independientes (`newHashMap`, `toMap`, `uniqueIndex`, `immutableEnumMap`…).
2. **Vistas (views)** — devuelven mapas *en vivo* respaldados por otra colección: los cambios se propagan en ambos sentidos (`asMap`, `transformValues`, `transformEntries`, `filterKeys`, `filterValues`, `filterEntries`, `subMap`, wrappers inmutables/sincronizados).

---

## 2. Métodos principales por categoría

### 2.1 Métodos de fábrica (creación de mapas mutables)

Facilitan la creación de mapas con inferencia de tipos. Hoy se consideran *de facto* obsoletos, pues el operador diamante (`<>`) cubre su función.

| Método | Descripción |
|---|---|
| `newHashMap()` / `newHashMap(Map)` | Crea un `HashMap` vacío o copiado de otro mapa. |
| `newHashMapWithExpectedSize(int)` | Crea un `HashMap` con capacidad inicial suficiente para `expectedSize` entradas sin redimensionar. Lanza `IllegalArgumentException` si es negativo. |
| `newLinkedHashMap()` / `newLinkedHashMap(Map)` / `newLinkedHashMapWithExpectedSize(int)` | Equivalentes para `LinkedHashMap` (orden de inserción). |
| `newTreeMap()` / `newTreeMap(SortedMap)` / `newTreeMap(Comparator)` | Crea `TreeMap` con orden natural, copiando el orden de otro `SortedMap`, o con un `Comparator` dado. |
| `newEnumMap(Class)` / `newEnumMap(Map)` | Crea un `EnumMap` a partir del tipo de clave o de un mapa existente. |
| `newIdentityHashMap()` | Crea un `IdentityHashMap`. |
| `newConcurrentMap()` | Crea un `ConcurrentHashMap` vacío (devuelto como `ConcurrentMap`). |
| `capacity(int)` *(paquete-privado)* | Calcula la capacidad interna necesaria para evitar el *rehashing* dado un tamaño esperado y factor de carga 0.75. |

### 2.2 Mapas inmutables y *collectors*

| Método | Descripción |
|---|---|
| `immutableEnumMap(Map<K,V>)` | Devuelve un `ImmutableMap` respaldado internamente por un `EnumMap`; el orden de iteración es el de declaración del `enum`. Valida que no existan claves/valores nulos. |
| `toImmutableEnumMap(keyFunction, valueFunction)` | `Collector` para streams que produce un `ImmutableMap` especializado en claves `enum`. Lanza `IllegalArgumentException` ante claves duplicadas. |
| `toImmutableEnumMap(keyFunction, valueFunction, mergeFunction)` | Igual que el anterior, pero resuelve claves duplicadas con un `BinaryOperator`. |
| `fromProperties(Properties)` | Convierte un objeto `Properties` en un `ImmutableMap<String, String>`. Lanza `ClassCastException` si alguna clave no es `String`. |
| `indexMap(Collection<E>)` *(interno)* | Devuelve un mapa del i-ésimo elemento de una colección a su índice `i`. |

### 2.3 Comparación de mapas

| Método | Descripción |
|---|---|
| `difference(Map left, Map right)` | Calcula la diferencia entre dos mapas y devuelve un `MapDifference` **inmutable** (instantánea). Expone entradas solo a la izquierda, solo a la derecha, comunes y con valores distintos. |
| `difference(Map, Map, Equivalence)` | Variante que permite definir la relación de equivalencia para comparar valores. |
| `difference(SortedMap left, Map right)` | Variante que devuelve un `SortedMapDifference`, usando el comparador del mapa izquierdo (o `Ordering.natural()`). |

> Si solo se necesita saber si dos mapas son iguales, se recomienda `left.equals(right)`.

Clases internas de soporte: `MapDifferenceImpl`, `SortedMapDifferenceImpl`, `ValueDifferenceImpl`.

### 2.4 Conversión de colecciones a mapas

| Método | Descripción |
|---|---|
| `toMap(Iterable<K>, Function<K,V>)` | `ImmutableMap` cuyas claves son los elementos distintos del iterable y los valores se calculan con la función. Orden: primera aparición de cada clave. |
| `toMap(Iterator<K>, Function<K,V>)` | Igual, partiendo de un iterador. |
| `uniqueIndex(Iterable<V>, Function<V,K>)` | Indexa valores por una clave derivada de cada valor. Lanza `IllegalArgumentException` si la función genera claves duplicadas (sugiere usar `Multimaps.index`). |
| `uniqueIndex(Iterator<V>, Function<V,K>)` | Versión para iteradores. |

### 2.5 Vistas de conjuntos como mapas (`asMap`)

Devuelven un `Map` **en vivo** cuyas claves son los elementos del `Set` y cuyos valores se calculan *perezosamente* con una `Function`. Soportan eliminación (se propaga al set), pero **no** operaciones `put`.

- `asMap(Set<K>, Function)` → `Map<K,V>`
- `asMap(SortedSet<K>, Function)` → `SortedMap<K,V>`
- `asMap(NavigableSet<K>, Function)` → `NavigableMap<K,V>` *(`@GwtIncompatible`)*

Implementaciones internas: `AsMapView`, `SortedAsMapView`, `NavigableAsMapView`, además de los envoltorios `removeOnlySet`, `removeOnlySortedSet`, `removeOnlyNavigableSet`.

### 2.6 Transformación de valores y entradas

| Método | Descripción |
|---|---|
| `transformValues(Map/SortedMap/NavigableMap, Function<V1,V2>)` | Vista del mapa donde cada valor se transforma con la función. Conserva el orden de iteración; la función se aplica de forma **perezosa**. |
| `transformEntries(Map/SortedMap/NavigableMap, EntryTransformer<K,V1,V2>)` | Igual, pero la lógica de transformación puede depender **de la clave y del valor**. |
| `transformEntry(EntryTransformer, Entry)` *(interno)* | Vista transformada de una única entrada. |
| `asEntryToEntryFunction(EntryTransformer)` *(interno)* | Adapta un `EntryTransformer` a una `Function<Entry,Entry>`. |

**Interfaz pública anidada:**

```java
public interface EntryTransformer<K, V1, V2> {
    V2 transformEntry(K key, V1 value);
}
```
Define la transformación del valor a partir del par clave-valor. Se espera que no tenga efectos secundarios y que sea consistente con `equals`.

> Las vistas transformadas **no** son *thread-safe* ni serializables, incluso si el mapa subyacente lo es. Dado que la función se evalúa en cada acceso, debe ser rápida; si no se necesita una vista, conviene copiar el resultado.

### 2.7 Filtrado

Todos devuelven vistas en vivo. El predicado debe ser *consistente con equals*. `put`/`putAll` lanzan `IllegalArgumentException` si la entrada no satisface el predicado.

| Método | Sobrecargas |
|---|---|
| `filterKeys(..., Predicate<K>)` | `Map`, `SortedMap`, `NavigableMap`, `BiMap` |
| `filterValues(..., Predicate<V>)` | `Map`, `SortedMap`, `NavigableMap`, `BiMap` |
| `filterEntries(..., Predicate<Entry<K,V>>)` | `Map`, `SortedMap`, `NavigableMap`, `BiMap` |

Métodos privados `filterFiltered(...)` combinan predicados cuando se filtra un mapa ya filtrado (para que `clear()`, `removeAll()` y `retainAll()` funcionen correctamente). Implementaciones internas: `AbstractFilteredMap`, `FilteredKeyMap`, `FilteredEntryMap`, `FilteredEntrySortedMap`, `FilteredEntryNavigableMap`, `FilteredEntryBiMap`, `FilteredMapValues`.

> Advertencia de rendimiento: operaciones como `size()` deben recorrer todo el mapa subyacente.

### 2.8 Envoltorios (inmutables y sincronizados)

| Método | Descripción |
|---|---|
| `unmodifiableBiMap(BiMap)` | Vista de solo lectura de un `BiMap`; las modificaciones lanzan `UnsupportedOperationException`. Serializable si el original lo es. |
| `unmodifiableNavigableMap(NavigableMap)` | Vista de solo lectura de un `NavigableMap`. |
| `synchronizedBiMap(BiMap)` | Vista sincronizada (thread-safe) de un `BiMap`. Requiere sincronización manual al iterar sus vistas. |
| `synchronizedNavigableMap(NavigableMap)` | Vista sincronizada de un `NavigableMap`, incluyendo sus submapas y vistas de claves. |
| `unmodifiableEntrySet(