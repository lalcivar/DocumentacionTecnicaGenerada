==============================
Documentación técnica  
Módulo: requests.models
==============================

Introducción
------------
El archivo `requests/models.py` define los objetos de más bajo nivel que utiliza la biblioteca **Requests** para construir, serializar y des-serializar peticiones HTTP.  
En términos prácticos, contiene:

1. Constantes de ayuda y valores por defecto.  
2. Dos mixins reutilizables (para codificación y para hooks).  
3. Tres clases **públicas y nucleares**:  
   • `Request` – representación de la petición creada por el usuario.  
   • `PreparedRequest` – versión inmutable/lista-para-enviar de `Request`.  
   • `Response` – representación de la respuesta devuelta por el servidor.  

Su misión global es transformar la intención del usuario (“haz un GET a … con estos encabezados”) en una secuencia de bytes válida para la red y, más tarde, exponer la contestación del servidor de forma cómoda.

Dependencias externas relevantes
--------------------------------
• `urllib3` – I/O y decodificación de la capa de transporte.  
• Librerías de detección de charset (`chardet` o `charset_normalizer`).  
• `idna` – soporte de dominios internacionales.  
• Propios sub-módulos de Requests: `_internal_utils`, `auth`, `cookies`, `exceptions`, `hooks`, `structures`, `utils`, etc.  

Constantes principales
----------------------
• `REDIRECT_STATI`      – Códigos HTTP que indican un redireccionamiento procesable.  
• `DEFAULT_REDIRECT_LIMIT` – Límite de saltos de redirección.  
• `CONTENT_CHUNK_SIZE`  – Tamaño estándar (10 KB) para leer contenido en streaming.  
• `ITER_CHUNK_SIZE`     – Tamaño de corte usado por `iter_lines` (512 B).

Mixins
------

1. RequestEncodingMixin  
   - Proporciona utilidades de serialización:  
     • `path_url` – parte de ruta + query del URL.  
     • `_encode_params` – normaliza parámetros (dict/list/str/bytes/file-like).  
     • `_encode_files` – construye cuerpos `multipart/form-data`.

2. RequestHooksMixin  
   - Gestiona los *hooks* (“callbacks” que se ejecutan en distintos eventos).  
   - Métodos: `register_hook`, `deregister_hook`.

Clase Request
-------------
Objeto mutable que el usuario crea manualmente.  
Atributos clave: `method`, `url`, `headers`, `params`, `data`, `json`, `files`, `auth`, `cookies`, `hooks`.  
Método esencial:  

• `prepare()` – devuelve un `PreparedRequest` realizando:  
  - Normalización de método y URL.  
  - Serialización de cuerpo, archivos, cookies.  
  - Inyección de cabeceras y autenticación.  
  - Copia de hooks.

Clase PreparedRequest
---------------------
Versión “congelada” que contiene exactamente lo que se enviará por el *adapter* (`Session.send`).  
Responsabilidades:

• Serialización completa mediante `prepare(...)` que delega en:  
  - `prepare_method` – mayúsculas, ASCII-safe.  
  - `prepare_url`    – validación, IDNA, quoting, merge de parámetros.  
  - `prepare_headers` – `CaseInsensitiveDict`.  
  - `prepare_body`   – lógica JSON, form-urlencoded, multipart, streaming, cálculo de `Content-Length` o `Transfer-Encoding`.  
  - `prepare_auth`   – soporta tuplas (Basic) o *callables* personalizados.  
  - `prepare_cookies` – genera cabecera `Cookie` usando `CookieJar`.  
  - `prepare_hooks`.  

Otros puntos relevantes:
• Maneja re-envío de peticiones con *body* basado en archivos (guarda `_body_position`).  
• `copy()` – útil para redirecciones.  
• En caso de error lanza excepciones tipificadas de `requests.exceptions`.

Clase Response
--------------
Representa la respuesta HTTP procesada.  
Atributos internos: `_content`, `_content_consumed`, `_next` (para redirecciones), `raw` (objeto file-like de urllib3) y los clásicos `status_code`, `headers`, `url`, etc.  

Métodos/properties destacadas:

• `ok`                         – booleano (códigos < 400).  
• `is_redirect`, `is_permanent_redirect` – inspección de cabeceras.  
• `iter_content`, `iter_lines` – lectura perezosa, con soporte de `decode_unicode`.  
• `content`, `text`, `json()`  – acceso a cuerpo como bytes, str y objeto Python.  
• `links`                      – parseo de cabecera `Link`.  
• `raise_for_status()`         – lanza `HTTPError` si status ≥ 400.  
• Context manager (`__enter__/__exit__`) – cierre automático de conexión.  
• `close()`                    – libera recursos a la *connection pool*.

Flujo típico
------------
1. El usuario crea `Request`.  
2. Llama a `prepare()` → obtiene `PreparedRequest`.  
3. `Session.send(prep_request)` (definido en otro módulo) transmite los bytes.  
4. El *adapter* de `urllib3` devuelve un *response* bruto.  
5. Se construye un objeto `Response`, que expone API de alto nivel al usuario.  

Relaciones e hilos de ejecución
-------------------------------
• `PreparedRequest` y `Response` no dependen mutuamente en tiempo de compilación, pero `Response.request` guarda la referencia para trazabilidad.  
• Hooks y autenticadores pueden mutar un `PreparedRequest` antes de enviarse.  
• Cookies viajan del `CookieJar` al encabezado y viceversa; métodos auxiliares viven en `requests.cookies`.  

Notas de diseño / decisiones clave
----------------------------------
• Se realiza import explícito de `encodings.idna` para evitar *implicit imports* problemáticos en entornos embebidos.  
• El hostname se IDNA-codifica sólo cuando se detectan caracteres no ASCII.  
• Para *streams* sin longitud conocida se usa `Transfer-Encoding: chunked`.  
• Existe tratamiento diferenciado para errores de capa de transporte (`SSLError`, `ReadTimeoutError`, etc.) convirtiéndolos a excepciones propias de Requests.  
• La serialización JSON aplica `allow_nan=False` y encapsula los fallos en `InvalidJSONError`.

Puntos de extensión
-------------------
• Hooks (`response`, `request`, etc.) permiten ejecutar lógica arbitraria.  
• Autenticación: cualquier callable que acepte un `PreparedRequest` y devuelva el mismo u otro.  
• Subclasificación de `Response` para añadir comportamiento personalizado.  

Resumen
-------
`requests.models` forma el **núcleo de modelo de datos** de la librería Requests. Define cómo se representan las peticiones antes y después de ser enviadas y provee herramientas para convertir parámetros de alto nivel en bytes aptos para HTTP, así como para exponer la respuesta de manera amigable, segura y extensible.