# Documentación Técnica: `requests/sessions.py`

## 1. Descripción general

Este módulo implementa el objeto **`Session`** de la librería `requests`, cuya responsabilidad es **gestionar y persistir configuración y estado entre múltiples peticiones HTTP**.

Mientras que las funciones de nivel superior (`requests.get()`, `requests.post()`, etc.) crean y descartan una sesión por llamada, `Session` permite reutilizar:

- **Cookies** (a través de un `RequestsCookieJar` compartido).
- **Cabeceras por defecto** (`headers`).
- **Credenciales de autenticación** (`auth`).
- **Proxies**, verificación TLS (`verify`), certificados de cliente (`cert`).
- **Hooks** de eventos.
- **Pool de conexiones**, mediante *adapters* montados por prefijo de URL (lo que habilita *keep-alive* y mejora notablemente el rendimiento).

Adicionalmente, el módulo contiene toda la **lógica de resolución de redirecciones** (seguimiento de `3xx`, reconstrucción de método, auth y proxies, manejo de cookies entre saltos) encapsulada en el mixin `SessionRedirectMixin`.

El fichero está completamente anotado con *type hints* (`from __future__ import annotations`) y utiliza `TYPE_CHECKING` para importaciones usadas solo por el verificador de tipos.

---

## 2. Dependencias y re-exportaciones

| Origen | Uso principal |
|---|---|
| `._internal_utils.to_native_string` | Normalización de cadenas/bytes (cabeceras `Location`). |
| `._types.is_prepared` | *Type guard* para asegurar que un `PreparedRequest` está completamente inicializado. |
| `.adapters.HTTPAdapter` / `BaseAdapter` | Transporte real de la petición. |
| `.auth._basic_auth_str` | Construcción de la cabecera `Proxy-Authorization`. |
| `.cookies.*` | Creación, extracción y fusión de *cookie jars*. |
| `.exceptions.*` | `TooManyRedirects`, `InvalidSchema`, errores de codificación. |
| `.hooks.*` | `default_hooks`, `dispatch_hook`. |
| `.models.*` | `Request`, `PreparedRequest`, `Response`, `REDIRECT_STATI`, `DEFAULT_REDIRECT_LIMIT`. |
| `.utils.*` | Resolución de proxies, netrc, re-codificación de URIs, rebobinado de cuerpos. |

> **Nota de compatibilidad:** varios símbolos (`PreparedRequest`, `Request`, `Response`, `REDIRECT_STATI`, `DEFAULT_REDIRECT_LIMIT`, `should_bypass_proxies`, `default_headers`, etc.) se importan y **re-exponen** aquí (marcados con `# noqa: F401`) porque históricamente vivían en este módulo. Se mantienen para no romper código externo.

### `preferred_clock`

Selección del reloj más preciso según la plataforma, usado para medir `Response.elapsed`:

```python
preferred_clock = time.perf_counter  # en Windows ("win32")
preferred_clock = time.time          # en el resto de plataformas
```

---

## 3. Funciones a nivel de módulo

### `merge_setting(request_setting, session_setting, dict_class=OrderedDict) -> Any`

Resuelve el valor efectivo de una opción combinando el valor de la petición con el de la sesión.

Reglas:
1. Si alguno de los dos es `None`, devuelve el otro.
2. Si **ambos** son `Mapping`, los fusiona: primero la sesión, luego la petición (la petición **gana**). El tipo del resultado lo determina `dict_class` (p. ej. `CaseInsensitiveDict` para cabeceras).
3. Si no son mapeos (p. ej. `verify`, `stream`), devuelve directamente el valor de la petición.
4. Las claves cuyo valor final sea `None` se **eliminan** del resultado. Esto es lo que permite "desactivar" una cabecera de sesión pasando `{'Header': None}` en la petición.

### `merge_hooks(request_hooks, session_hooks, dict_class=OrderedDict) -> HooksType`

Fusión especializada de hooks. Existe porque el valor por defecto de los hooks de una petición es `{'response': []}`, y una fusión ingenua destruiría los hooks de la sesión. Si uno de los dos está vacío o es `None`, devuelve el otro; en caso contrario delega en `merge_setting`.

### `session() -> Session`

Fábrica legada que devuelve una `Session`.

> **Deprecada desde 1.0.0.** Se conserva solo por retrocompatibilidad; el código nuevo debe instanciar `Session()` directamente.

---

## 4. Clase `SessionRedirectMixin`

Mixin que concentra la lógica de redirecciones. Declara los atributos que espera de la clase anfitriona (`max_redirects`, `trust_env`, `cookies`) y el método abstracto `send()`.

### `get_redirect_target(resp) -> str | None`

Devuelve la URL de destino si la respuesta es una redirección (`resp.is_redirect`), o `None`.

Detalle relevante: el módulo HTTP estándar decodifica cabeceras en `latin1`, pero en la práctica los `Location` no-ASCII suelen venir en UTF-8. Por ello la cabecera se **re-codifica a `latin1` y se decodifica como `utf8`**.

### `should_strip_auth(old_url, new_url) -> bool`

Decide si debe eliminarse la cabecera `Authorization` al redirigir. Devuelve `True` (eliminar) cuando:

- Cambia el *hostname*, **o**
- Cambia el puerto o el esquema.

Excepciones (devuelve `False`, se conserva la auth):

- Redirección `http` → `https` usando puertos estándar (80/`None` → 443/`None`), mantenida por retrocompatibilidad aunque no la exija el RFC 7235.
- Mismo esquema y ambos puertos coinciden con el puerto por defecto de ese esquema (`DEFAULT_PORTS`).

### `resolve_redirects(resp, req, stream, timeout, verify, cert, proxies, yield_requests, **adapter_kwargs) -> Generator[Response]`

**Generador** que es el núcleo del seguimiento de redirecciones. Por cada salto:

1. Copia la petición original (`req.copy()`) y actualiza el historial (`resp.history`).
2. Consume `resp.content` para **liberar el socket** (con *fallback* a `resp.raw.read()` ante `ChunkedEncodingError`, `ContentDecodingError` o `RuntimeError`) y cierra la respuesta.
3. Lanza `TooManyRedirects` si se supera `self.max_redirects`.
4. Normaliza la URL destino:
   - URLs sin esquema (`//host/path`) → se les añade el esquema previo (RFC 1808 §4).
   - Reutiliza el *fragment* anterior si el nuevo no lo tiene (RFC 7231 §7.1.2).
   - URLs relativas → `urljoin` contra `resp.url`; en todos los casos se aplica `requote_uri` (RFC 3986).
5. Reconstruye el método con `rebuild_method`.
6. Si el código **no** es `307`/`308`, purga `Content-Length`, `Content-Type` y `Transfer-Encoding` y **descarta el cuerpo** (`body = None`).
7. Gestiona cookies: elimina `Cookie`, extrae las cookies de la respuesta al *jar* de la nueva petición, fusiona con las de la sesión y las vuelve a preparar.
8. Reconstruye proxies (`rebuild_proxies`) y autenticación (`rebuild_auth`).
9. Si el cuerpo es rebobinable (`_body_position is not None` y hay cabecera de longitud/encoding), llama a `rewind_body`.
10. Finalmente:
    - Si `yield_requests=True`: emite el `PreparedRequest` **sin enviarlo** (uso interno, para `Response.next`).
    - Si no: envía la petición con `allow_redirects=False`, persiste cookies en la sesión, calcula el siguiente destino y emite la `Response`.

### `rebuild_auth(prepared_request, response) -> None`

Elimina la cabecera `Authorization` si `should_strip_auth()` lo indica, y si `trust_env` está activo intenta obtener nuevas credenciales desde `.netrc` para el nuevo host (`get_netrc_auth`), aplicándolas con `prepare_auth`.

### `rebuild_proxies(prepared_request, proxies) -> dict[str, str]`

Reevalúa la configuración de proxy para la nueva URL:

- Recalcula los proxies con `resolve_proxies` (teniendo en cuenta variables de entorno y `NO_PROXY`).
- Elimina siempre la cabecera `Proxy-Authorization` heredada.
- La vuelve a añadir (vía `_basic_auth_str`) **solo si el esquema no es HTTPS** y hay credenciales en la URL del proxy, para evitar filtrarla en túneles TLS (urllib3 la gestiona internamente en el adapter estándar).

### `rebuild_method(prepared_request, response) -> None`

Ajusta el método HTTP tras la redirección, combinando estándar y comportamiento de navegadores:

| Código | Condición | Método resultante |
|---|---|---|
| `303 See Other` | método ≠ `HEAD` | `GET` |
| `302 Found` | método ≠ `HEAD` | `GET` |
| `301 Moved Permanently` | método == `POST` | `GET` |

---

## 5. Clase `Session(SessionRedirectMixin)`

Objeto principal del módulo. Soporta uso como **gestor de contexto**:

```python
with requests.Session() as s:
    s.get("https://httpbin.org/get")
```

### 5.1 Atributos de instancia

| Atributo | Tipo | Valor por defecto | Descripción |
|---|---|---|---|
| `headers` | `CaseInsensitiveDict[str]` | `default_headers()` | Cabeceras enviadas en cada petición. |
| `auth` | `AuthType` | `None` | Autenticación por defecto (tupla o callable). |
| `proxies` | `dict[str, str]` | `{}` | Mapeo esquema(+host) → URL de proxy. |
| `hooks` | `dict[str, list[HookType]]` | `default_hooks()` | Hooks de eventos. |
| `params` | `MutableMapping` | `{}` | Parámetros de *query string* por defecto. |
| `stream` | `bool` | `False` | Si no se descarga el cuerpo inmediatamente. |
| `verify` | `VerifyType` | `True` | Verificación TLS o ruta a un *CA bundle*. |
| `cert` | `CertType` | `None` | Certificado de cliente (`'cert.pem'` o `('cert','key')`). |
| `max_redirects` | `int` | `DEFAULT_REDIRECT_LIMIT` (30) | Límite de redirecciones. |