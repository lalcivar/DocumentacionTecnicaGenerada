# Documentación Técnica del Módulo  
*(siguiendo PEP-257 y Google Style Docstrings)*  

## 1. Resumen ejecutivo
El módulo amplía las capacidades del núcleo de Flask mediante la definición de utilidades auxiliares y la implementación de una sub-clase `Flask` con lógica propia para despacho de peticiones, gestión de contexto, CLI, manejo de errores, conversión síncrona/asincrónica y otras tareas de infraestructura.  
En conjunto, el archivo constituye una aplicación WSGI lista para producción, ofreciendo además herramientas para pruebas, shell interactivo, servidor de desarrollo y utilidades para plantillas Jinja, todo ello manteniendo compatibilidad con el estándar de documentación y tipado moderno de Python.

---

## 2. Especificación detallada de funciones y métodos

> Convención de tablas  
> • **Oblig** = ¿El argumento es obligatorio?  
> • **Tipo** = Tipo anotado o inferido  
> • **Devuelve** = Tipo de retorno  
> • **Excepciones** = Excepciones que la función puede lanzar directamente  

### 2.1  Funciones de módulo

#### `_make_timedelta()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `value` | `timedelta | int | None` | No | Segundos o instancia `timedelta`; `None` para invariante |

| Devuelve | Descripción |
|----------|-------------|
| `timedelta | None` | Si `value` es `int`, se convierte a `timedelta`; si es `None` o ya es `timedelta`, se retorna tal cual. |

| Excepciones | Motivo |
|-------------|--------|
| — | — |

---

#### `remove_ctx()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `f` | `Callable[..., Any]` | Sí | Función a envolver. |

| Devuelve | Descripción |
|----------|-------------|
| `Callable[..., Any]` | Función *wrapper* que elimina un posible `AppContext` del primer argumento antes de delegar en `f`. |

| Excepciones | Motivo |
|-------------|--------|
| — | — |

##### `remove_ctx.<locals>.wrapper()`
Función interna generada dinámicamente.  

| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `self` | `Flask` | Sí | Instancia del `Flask` actual. |
| `*args` | `Any` | No | Argumentos posicionales restantes. |
| `**kwargs` | `Any` | No | Argumentos nombrados restantes. |

| Devuelve | Descripción |
|----------|-------------|
| `Any` | Resultado de la llamada original a `f`. |

---

#### `add_ctx()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `f` | `Callable[..., Any]` | Sí | Función a envolver. |

| Devuelve | Descripción |
|----------|-------------|
| `Callable[..., Any]` | Función *wrapper* que inyecta un `AppContext` en la posición 0 si no existe. |

| Excepciones | Motivo |
|-------------|--------|
| — | — |

##### `add_ctx.<locals>.wrapper()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `self` | `Flask` | Sí | Instancia del `Flask` actual. |
| `*args` | `Any` | No | Argumentos posicionales restantes. |
| `**kwargs` | `Any` | No | Argumentos nombrados restantes. |

| Devuelve | Descripción |
|----------|-------------|
| `Any` | Resultado de la llamada original a `f`. |

---

### 2.2  Clase `Flask`  
*(se listan únicamente los métodos definidos en este archivo; los heredados no aparecen)*  

> Para claridad, los modificadores `@classmethod` y `@staticmethod` se indican cuando aplican.

#### `Flask.__init_subclass__(cls, **kwargs)`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `cls` | `type[Flask]` | Sí | Sub-clase que se está inicializando. |
| `**kwargs` | `Any` | No | Argumentos adicionales ignorados. |

| Devuelve | Descripción |
|----------|-------------|
| `None` | — |

| Excepciones | Motivo |
|-------------|--------|
| `DeprecationWarning` *(emite)* | Si métodos sobre-escritos no aceptan `ctx: AppContext`. |

---

#### `Flask.__init__(...)`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `import_name` | `str` | Sí | Punto de importación de la app. |
| `static_url_path` | `str | None` | No | URL base para ficheros estáticos. |
| `static_folder` | `str | os.PathLike | None` | No | Carpeta que contiene los estáticos. |
| `static_host` | `str | None` | No | Host para la ruta estática si `host_matching=True`. |
| `host_matching` | `bool` | No | Habilita reglas específicas de host. |
| `subdomain_matching` | `bool` | No | Habilita emparejamiento de subdominios. |
| `template_folder` | `str | os.PathLike | None` | No | Carpeta de plantillas Jinja. |
| `instance_path` | `str | None` | No | Ruta alternativa de instancia. |
| `instance_relative_config` | `bool` | No | Config. relativa a `instance_path`. |
| `root_path` | `str | None` | No | Raíz de la aplicación. |

| Devuelve | Descripción |
|----------|-------------|
| `None` | — |

| Excepciones | Motivo |
|-------------|--------|
| `AssertionError` | Combinación inválida `static_host` ↔︎ `host_matching`. |

---

#### `get_send_file_max_age()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `filename` | `str | None` | Sí | Nombre del fichero solicitado. |

| Devuelve | Descripción |
|----------|-------------|
| `int | None` | Segundos de cacheo o `None`. |

| Excepciones | Motivo |
|-------------|--------|
| — | — |

---

#### `send_static_file()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `filename` | `str` | Sí | Fichero a servir desde `static_folder`. |

| Devuelve | Descripción |
|----------|-------------|
| `Response` | Respuesta WSGI preparada. |

| Excepciones | Motivo |
|-------------|--------|
| `RuntimeError` | Si `static_folder` no está configurado. |

---

#### `open_resource()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `resource` | `str` | Sí | Ruta relativa a `root_path`. |
| `mode` | `str` | No | Modo de apertura (`'r'`, `'rt'`, `'rb'`). |
| `encoding` | `str | None` | No | Codificación para modo texto. |

| Devuelve | Descripción |
|----------|-------------|
| `IO[AnyStr]` | Objeto archivo listo para lectura. |

| Excepciones | Motivo |
|-------------|--------|
| `ValueError` | Modo no permitido (solo lectura). |
| `FileNotFoundError` | El recurso no existe. |

---

#### `open_instance_resource()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `resource` | `str` | Sí | Ruta relativa a `instance_path`. |
| `mode` | `str` | No | Modo de apertura. |
| `encoding` | `str | None` | No | Codificación si aplica. |

| Devuelve | Descripción |
|----------|-------------|
| `IO[AnyStr]` | Archivo listo para E/S. |

| Excepciones | Motivo |
|-------------|--------|
| `FileNotFoundError` | Recurso inexistente. |

---

#### `create_jinja_environment()`
| Devuelve | Descripción |
|----------|-------------|
| `Environment` | Entorno Jinja2 configurado con filtros y globales específicos de Flask. |

| Excepciones | Motivo |
|-------------|--------|
| — | — |

---

#### `create_url_adapter()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `request` | `Request | None` | No | Petición o `None` para uso fuera de request. |

| Devuelve | Descripción |
|----------|-------------|
| `MapAdapter | None` | Adaptador de URL o `None` si no se puede crear. |

---

#### `raise_routing_exception()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `request` | `Request` | Sí | Petición asociada al error de ruteo. |

| Devuelve | Descripción |
|----------|-------------|
| — | Nunca retorna (`NoReturn`). |

| Excepciones | Motivo |
|-------------|--------|
| `RoutingException` sub-clases | Re-lanzadas o convertidas a `FormDataRoutingRedirect`. |

---

#### `update_template_context()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto de aplicación. |
| `context` | `dict[str, Any]` | Sí | Diccionario que será actualizado in-place. |

| Devuelve | Descripción |
|----------|-------------|
| `None` | — |

---

#### `make_shell_context()`
| Devuelve | Descripción |
|----------|-------------|
| `dict[str, Any]` | Variables inyectadas al intérprete interactivo. |

---

#### `run()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `host` | `str | None` | No | Host de escucha. |
| `port` | `int | None` | No | Puerto. |
| `debug` | `bool | None` | No | Habilita/inhabilita modo debug. |
| `load_dotenv` | `bool` | No | Carga archivos `.env`. |
| `**options` | `Any` | No | Parámetros extra para `werkzeug.serving.run_simple`. |

| Devuelve | Descripción |
|----------|-------------|
| `None` | — |

| Excepciones | Motivo |
|-------------|--------|
| `RuntimeError` | Si se invoca con `FLASK_RUN_FROM_CLI` pero en reloader. |

---

#### `test_client()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `use_cookies` | `bool` | No | Activa almacenamiento de cookies en pruebas. |
| `**kwargs` | `Any` | No | Pasa argumentos al constructor personalizado de cliente. |

| Devuelve | Descripción |
|----------|-------------|
| `FlaskClient` | Cliente de pruebas ready-to-use. |

---

#### `test_cli_runner()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `**kwargs` | `Any` | No | Args adicionales para el runner. |

| Devuelve | Descripción |
|----------|-------------|
| `FlaskCliRunner` | Runner de comandos para pruebas. |

---

#### `handle_http_exception()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `e` | `HTTPException` | Sí | Excepción HTTP capturada. |

| Devuelve | Descripción |
|----------|-------------|
| `HTTPException | ResponseReturnValue` | Respuesta final o excepción sin manejar. |

---

#### `handle_user_exception()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `e` | `Exception` | Sí | Excepción de usuario. |

| Devuelve | Descripción |
|----------|-------------|
| `HTTPException | ResponseReturnValue` | Respuesta o re-lanza la excepción. |

| Excepciones | Motivo |
|-------------|--------|
| `Exception` | Re-lanzada si no existe manejador registrado. |

---

#### `handle_exception()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto actual. |
| `e` | `Exception` | Sí | Excepción sin manejar. |

| Devuelve | Descripción |
|----------|-------------|
| `Response` | Respuesta 500 o la retornada por un handler de error. |

---

#### `log_exception()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc_info` | `tuple[type, BaseException, TracebackType] | tuple[None,…]` | Sí | Tupla de información de excepción. |

| Devuelve | Descripción |
|----------|-------------|
| `None` | — |

---

#### `dispatch_request()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |

| Devuelve | Descripción |
|----------|-------------|
| `ResponseReturnValue` | Valor crudo devuelto por la vista. |

---

#### `full_dispatch_request()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |

| Devuelve | Descripción |
|----------|-------------|
| `Response` | Respuesta final tras pre/post-procesado. |

---

#### `finalize_request()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |
| `rv` | `ResponseReturnValue | HTTPException` | Sí | Valor de vista o error. |
| `from_error_handler` | `bool` | No | Modo seguro frente a errores. |

| Devuelve | Descripción |
|----------|-------------|
| `Response` | Respuesta lista para WSGI. |

---

#### `make_default_options_response()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |

| Devuelve | Descripción |
|----------|-------------|
| `Response` | Respuesta OPTIONS automática. |

---

#### `ensure_sync()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `func` | `Callable[..., Any]` | Sí | Función (sync o async). |

| Devuelve | Descripción |
|----------|-------------|
| `Callable[..., Any]` | Función envuelta para ejecución síncrona. |

---

#### `async_to_sync()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `func` | `Callable[..., Coroutine]` | Sí | Corrutina a convertir. |

| Devuelve | Descripción |
|----------|-------------|
| `Callable[..., Any]` | Envoltorio síncrono. |

| Excepciones | Motivo |
|-------------|--------|
| `RuntimeError` | Si no se instala `asgiref` (`pip install flask[async]`). |

---

#### `url_for()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `endpoint` | `str` | Sí | Nombre del endpoint. |
| `_anchor` | `str | None` | No | Fragmento URL. |
| `_method` | `str | None` | No | Método HTTP a resolver. |
| `_scheme` | `str | None` | No | Esquema (http/https). |
| `_external` | `bool | None` | No | Fuerza URL absoluta. |
| `**values` | `Any` | No | Parámetros variables de la regla. |

| Devuelve | Descripción |
|----------|-------------|
| `str` | URL construida. |

| Excepciones | Motivo |
|-------------|--------|
| `RuntimeError` | Sin `SERVER_NAME` fuera de request. |
| `ValueError` | `_scheme` seteado con `_external=False`. |
| `BuildError` | Fallo en construcción y sin handler alternativo. |

---

#### `make_response()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `rv` | `ResponseReturnValue` | Sí | Cualquier tipo permitido por Flask. |

| Devuelve | Descripción |
|----------|-------------|
| `Response` | Instancia concreta de `response_class`. |

| Excepciones | Motivo |
|-------------|--------|
| `TypeError` | Tupla mal formada, tipo no soportado o `None`. |

---

#### `preprocess_request()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |

| Devuelve | Descripción |
|----------|-------------|
| `ResponseReturnValue | None` | Si algún `before_request` corta el flujo. |

---

#### `process_response()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |
| `response` | `Response` | Sí | Respuesta a procesar. |

| Devuelve | Descripción |
|----------|-------------|
| `Response` | Respuesta final tras filtros y session-save. |

---

#### `do_teardown_request()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc` | `BaseException | None` | No | Excepción sin manejar. |

| Devuelve | Descripción |
|----------|-------------|
| `None` | — |

| Excepciones | Motivo |
|-------------|--------|
| `Exception` | Re-lanza agrupadas desde `_CollectErrors`. |

---

#### `do_teardown_appcontext()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc` | `BaseException | None` | No | Excepción sin manejar. |

| Devuelve | Descripción |
|----------|-------------|
| `None` | — |

---

#### `app_context()`
| Devuelve | Descripción |
|----------|-------------|
| `AppContext` | Contexto de aplicación listo para usar con `with`. |

---

#### `request_context()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI bruto. |

| Devuelve | Descripción |
|----------|-------------|
| `AppContext` | Contexto que incluye petición. |

---

#### `test_request_context()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `*args` | `Any` | No | Ver docstring original. |
| `**kwargs` | `Any` | No | Ídem. |

| Devuelve | Descripción |
|----------|-------------|
| `AppContext` | Contexto de pruebas. |

---

#### `wsgi_app()`
| Parámetro | Tipo | Oblig | Descripción |
|-----------|------|-------|-------------|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callback para iniciar respuesta. |

| Devuelve | Descripción |
|----------|-------------|
| `Iterable[bytes]` | Respuesta iterable conforme a WSGI. |

---

#### `__call__()`
Alias a `wsgi_app`; mismos parámetros y retorno.

---

## 3. Ejemplo de uso

```python
from myflaskapp import Flask

# 1. Crear instancia
app = Flask(__name__, template_folder="templates")

# 2. Definir una vista
@app.route("/")
def hello_world():
    return {"message": "Hola Mundo"}, 200

# 3. Trabajar con contextos manualmente
with app.app_context():
    # Acceso a `current_app` y `g`
    ctx_data = app.make_shell_context()
    print(ctx_data["app"].name)   # -> myflaskapp

# 4. Ejecutar servidor de desarrollo
if __name__ == "__main__":
    app.run(debug=True, port=5001)
```

El ejemplo ilustra la creación de una aplicación, declaración de rutas, uso explícito del contexto de aplicación y arranque del servidor en modo desarrollo.