--------------------------------------------------------------------
Documentación técnica – com.google.common.cache.LocalCache<K,V>
--------------------------------------------------------------------

1. Propósito general  
LocalCache es la implementación base sobre la que Guava construye las
instancias de Cache devueltas por CacheBuilder (LocalManualCache y
LocalLoadingCache).  Combina:

• Un mapa hash concurrente segmentado (similar a ConcurrentHashMap).  
• Políticas de expiración por tiempo (expireAfterWrite / expireAfterAccess).  
• Política de recarga automática (refreshAfterWrite).  
• Evicción por tamaño/peso (maximumSize / maximumWeight + Weigher).  
• Selección de referencias STRONG, SOFT o WEAK para claves y valores.  
• Recolección asistida por GC (ReferenceQueue) y notificación de
  eliminaciones (RemovalListener).  
• Estadísticas de uso (hits, misses, evictions, loadSuccess, etc.).  

Todo ello se ofrece con alto grado de concurrencia gracias a “lock
striping”: la tabla se divide en segmentos independientes que heredan
de ReentrantLock y sólo se bloquean cuando es estrictamente necesario
(escrituras o limpieza).

--------------------------------------------------------------------
2. Estructura interna (resumen)
--------------------------------------------------------------------
          CacheBuilder
             │
             ▼
   ┌──────────────────────┐
   │   LocalCache<K,V>    │   ← implementación principal
   └──────────────────────┘
             │delegates a
             ▼
   ┌──────────────────────┐
   │ Segment<K,V> (N)     │   hash-table + lock + colas LRU
   └──────────────────────┘
             │ contiene
             ▼
   ReferenceEntry<K,V> ──► ValueReference<K,V>
           (Strong/Weak)      (Strong/Soft/Weak/Loading…)

Colas internas  
• writeQueue  – orden por momento de escritura.  
• accessQueue – orden LRU (lecturas/escrituras).  
• recencyQueue – buffer sin bloqueo que se drena bajo lock.  

--------------------------------------------------------------------
3. Tipos y enumeraciones destacadas
--------------------------------------------------------------------
Strength                 – STRONG | SOFT | WEAK (para claves/valores).  
EntryFactory             – fábrica de ReferenceEntry según política.  
ValueReference           – wrapper de valor; puede ser fuerte, débil,
                            soft o “LoadingValueReference” mientras se
                            está cargando.  
LoadingValueReference    – puente con CacheLoader y Future.  

--------------------------------------------------------------------
4. API pública (vía interfaces Map / Cache) – métodos principales
--------------------------------------------------------------------
• V get(Object key)  
  – Lectura estándar; no cambia orden LRU si no se halló valor.

• V get(K key, CacheLoader<? super K,V> loader) / getOrLoad(key)  
  – Versión “loading”; coordina cargas concurrentes mediante
    LoadingValueReference y, opcionalmente, refresco asíncrono.

• ImmutableMap<K,V> getAll / getAllPresent  
  – Obtención masiva con soporte opcional a loadAll del CacheLoader.

• V put(K key, V value) / putIfAbsent / putAll  
  – Inserción con actualización de colas y eventual evicción.

• V remove(Object key) / boolean remove(key,value)  
  – Eliminación explícita con notificación a RemovalListener.

• boolean containsKey / containsValue  
  – Implementaciones lock-free para lectura; la versión value hace N
    pasadas para minimizar falsos negativos.

• void clear()  
  – Vacía la caché, limpia colas y notifica.

• long size() / longSize()  
  – Suma perezosa de los contadores de los segmentos.

• void cleanUp()  
  – Fuerza drenado de ReferenceQueue y colas internas.

• void refresh(K key)        (sólo LocalLoadingCache)  
  – Programa una recarga si el valor es elegible.

--------------------------------------------------------------------
5. Operaciones internas clave (selección)
--------------------------------------------------------------------
Segment  
• V get(K,int,CacheLoader)             – ruta crítica de lectura/carga.  
• V put(K,int,V,boolean)               – inserción con evicción.  
• void evictEntries(ReferenceEntry)    – mantiene peso <= máximo.  
• void expireEntries(long now)         – retira elementos caducados.  
• void drainReferenceQueues()          – procesa GC (Weak/Soft refs).  
• ReferenceEntry<K,V> copyEntry(…)     – rehash sin parar el mundo.  

LocalCache  
• int hash(Object) / Segment<K,V> segmentFor(int) – dispersión y
  selección de segmento.  
• boolean isExpired(entry,now)         – regla única de expiración.  
• void processPendingNotifications()   – entrega eventos al listener.  

--------------------------------------------------------------------
6. Consideraciones de concurrencia
--------------------------------------------------------------------
• Lecturas: mayormente sin bloqueo; sólo se verifica un volatile
  (count) y se recorre la lista inmutable de la cubeta.  
• Escrituras: bloquean el Segment correspondiente.  
• Limpieza: se intenta primero sin bloqueo (tryLock), cayendo a una
  pasada bloqueante ocasional.  
• Los contadores de hits/misses se mantienen por Segment y se agregan
  bajo demanda para evitar contención.

--------------------------------------------------------------------
7. Serialización
--------------------------------------------------------------------
La propia LocalCache no se serializa; en su lugar expone proxies:

• ManualSerializationProxy – reconstituye un Cache manual.  
• LoadingSerializationProxy – reconstituye un LoadingCache.  

Ambos guardan únicamente la configuración (strengths, políticas,
listener, etc.) y, tras deserializar, reconstruyen la estructura
completa mediante CacheBuilder.

--------------------------------------------------------------------
8. Clases adaptadoras de alto nivel
--------------------------------------------------------------------
• LocalManualCache<K,V>   – implementa Cache delegando en LocalCache.  
• LocalLoadingCache<K,V>  – extiende la anterior y añade LoadingCache.
  Estas son las instancias reales que recibe el usuario.

--------------------------------------------------------------------
9. Resumen
--------------------------------------------------------------------
LocalCache es el núcleo de la infraestructura de caché de Guava: un
hash map concurrente extensible con políticas de expiración, peso,
L-R-U, recarga automática y soporte de referencias blandas/débiles.
Su diseño basado en segmentos reduce la contención, mientras que sus
colas internas hacen posible aplicar de forma eficiente las distintas
políticas sin sacrificar el rendimiento de las operaciones de mapa
convencionales.