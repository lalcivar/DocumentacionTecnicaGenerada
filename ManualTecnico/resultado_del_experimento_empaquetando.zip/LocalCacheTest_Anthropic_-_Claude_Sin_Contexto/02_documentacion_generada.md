# Documentación técnica: `LocalCacheTest`

**Paquete:** `com.google.common.cache`
**Autor:** Charles Fry
**Jerarquía:** `junit.framework.TestCase` → `LocalCacheTest`
**Anotaciones:** `@GwtIncompatible`, `@J2ktIncompatible`, `@SuppressWarnings("GuardedBy")`, `@NullUnmarked`

---

## 1. Descripción general

`LocalCacheTest` es la clase de pruebas unitarias (basada en JUnit 3 / `TestCase`) que valida el comportamiento interno de `LocalCache`, la implementación concurrente y segmentada que sustenta a `CacheBuilder`, `Cache` y `LoadingCache` en Guava.

A diferencia de las pruebas de API pública (`CacheBuilderTest`, `LoadingCacheTest`, etc.), esta clase es una prueba de **caja blanca**: accede directamente a campos y métodos de visibilidad de paquete de `LocalCache` (`segments`, `keyStrength`, `entryFactory`, `Segment.table`, `recencyQueue`, `accessQueue`, `writeQueue`, etc.) para verificar invariantes que no son observables desde fuera.

Las áreas funcionales cubiertas son:

| Área | Qué se verifica |
|---|---|
| Construcción/configuración | Traducción correcta de las opciones de `CacheBuilder` a los campos de `LocalCache` (fuerzas de referencia, equivalencias, concurrencia, capacidad, pesos, expiración, refresco, ticker, listener). |
| Carga (`CacheLoader`) | Cálculo bajo demanda, reutilización de valores ya presentes, recarga asíncrona, entradas expiradas o parcialmente recolectadas, cargas recursivas. |
| `RemovalListener` | Notificaciones con la causa correcta (`EXPLICIT`, `REPLACED`, `COLLECTED`, `EXPIRED`, `SIZE`) y manejo de excepciones lanzadas por el listener. |
| Núcleo de `Segment` | `get`, `put`, `putIfAbsent`, `replace`, `remove`, `storeLoadedValue`, `removeLoadingValue`, `reclaimKey`, `reclaimValue`, `removeEntry`, `removeEntryFromChain`, `expand`, `clear`. |
| Desalojo y recencia | Orden de las colas de acceso/escritura, drenaje de `recencyQueue`, expiración por escritura/acceso, desalojo por tamaño. |
| Colas de referencias | Drenaje de `keyReferenceQueue` / `valueReferenceQueue` en lecturas y escrituras (claves débiles, valores débiles/blandos). |
| Serialización | Que los *proxies* de serialización (`LocalManualCache`, `LocalLoadingCache`) preserven la configuración y descarten el contenido. |
| Contratos generales | Nulabilidad (`NullPointerTester`) y conformidad con `ConcurrentMap` mediante los *test suite builders* de `guava-testlib`. |

---

## 2. Infraestructura de la prueba

### `public static Test suite()`
Construye la suite completa de pruebas. Además de añadir los métodos `testXxx()` de la propia clase, genera **once** suites derivadas de `ConcurrentMapTestSuiteBuilder` (usando `TestStringCacheGenerator`), una por cada configuración relevante del `CacheBuilder`: valores por defecto, `concurrencyLevel(1)`, `maximumSize`, `maximumWeight` + `weigher`, `weakKeys`, `weakValues`, `softValues`, `expireAfterAccess`, `expireAfterWrite`, `removalListener` y `recordStats`. Cada suite verifica que `LocalCache` cumple el contrato de `ConcurrentMap` con las características `CollectionSize.ANY`, `MapFeature.GENERAL_PURPOSE` y `CollectionFeature.SUPPORTS_ITERATOR_REMOVE`.
Marcada `@AndroidIncompatible` porque depende de los *test-suite builders*.

### `setUp()` / `tearDown()`
Registran y des-registran un `TestLogHandler` en `LocalCache.logger`, de modo que las pruebas puedan comprobar qué excepciones se registran (en lugar de propagarse).

### Utilidades de *logging*
- `popLoggedThrowable()` — extrae (y limpia) el único `Throwable` registrado.
- `checkNothingLogged()` — asegura que no se registró nada.
- `checkLogged(Throwable)` — asegura que se registró exactamente la excepción indicada.

### Fábricas de instancias
- `makeLocalCache(CacheBuilder)` y `makeLocalCache(CacheBuilder, CacheLoader)` — instancian `LocalCache` directamente (en vez de `builder.build()`) para tener acceso a su API interna.
- `createCacheBuilder()` — atajo para `CacheBuilder.newBuilder()`.

### Constante
- `SMALL_MAX_SIZE = DRAIN_THRESHOLD * 5` — tamaño máximo "pequeño" usado de forma recurrente para forzar desalojos y drenajes de colas.

---

## 3. Métodos de prueba principales

### 3.1 Configuración y construcción

- **`testDefaults()`** — verifica todos los valores por defecto: fuerzas `STRONG`, equivalencias por defecto, tiempos de expiración/refresco en 0, `maxWeight == UNSET_INT`, `EntryFactory.STRONG`, `NullListener`, `DISCARDING_QUEUE`, `NULL_TICKER`, `concurrencyLevel == 4`, 4 segmentos de 4 entradas, y que ningún mecanismo de desalojo/expiración esté activo.
- **`testSetKeyEquivalence()` / `testSetValueEquivalence()`** — la equivalencia personalizada se aplica solo al lado correspondiente.
- **`testSetConcurrencyLevel()`** (+ `checkConcurrencyLevel`) — el número de segmentos se redondea a la potencia de dos superior.
- **`testSetInitialCapacity()`** (+ `checkInitialCapacity`) — la capacidad inicial se reparte entre segmentos y se redondea a potencia de dos.
- **`testSetMaximumSize()`** (+ `checkMaximumSize`) — la suma de `maxSegmentWeight` iguala el máximo solicitado y el número de segmentos se limita respecto al tamaño máximo; se prueba tanto con `maximumSize` como con `maximumWeight` + `weigher`.
- **`testSetWeigher()`**, **`testSetWeakKeys()`**, **`testSetWeakValues()`**, **`testSetSoftValues()`** (+ `checkStrength`) — asignación de `weigher`, fuerzas de referencia y `EntryFactory` resultante.
- **`testSetExpireAfterWrite()` / `testSetExpireAfterAccess()` / `testSetRefresh()`** — conversión de duraciones a nanosegundos.
- **`testSetRemovalListener()` / `testSetTicker()`** — asignación de colaboradores.
- **`testEntryFactory()`** — tabla de decisión de `EntryFactory.getFactory(strength, usesAccess, usesWrite)` para las 8 combinaciones.

### 3.2 Carga y cómputo

- **`testCompute()`** — el `CacheLoader` se invoca una sola vez por clave (memoización).
- **`testComputeExistingEntry()`** — no se invoca el loader si la entrada ya existe.
- **`testComputePartiallyCollectedKey()` / `testComputePartiallyCollectedValue()`** — una clave o un valor recolectado fuerza una recarga; se comprueba el efecto sobre `segment.count`.
- **`testComputeExpiredEntry()`** — una entrada expirada se vuelve a cargar (`@AndroidIncompatible`).
- **`testRecordReadOnCompute()`** — las lecturas provocadas por `get(key, loader)` actualizan el orden de recencia y respetan `DRAIN_THRESHOLD`.
- **`testLongAsyncRefresh()`** — escenario de concurrencia con `FakeTicker`, `CountDownLatch` y `SettableFuture`: una recarga asíncrona lenta durante la cual la entrada expira; se verifica que el hilo que bloquea finalmente obtiene el valor recargado.
- **`testLoadDifferentKeyInLoader()`** — cargar *otra* clave desde dentro de un loader es legal.
- **`testRecursiveLoad()` / `testRecursiveLoadWithProxy()`** — la carga recursiva de la *misma* clave falla con excepción en lugar de bloquearse indefinidamente (apoyadas en `testLoadThrows`).
- **`testCopyEntry_computing()`** — copiar una entrada en estado de carga (`LoadingValueReference`) desde otro hilo no pierde el valor calculado ni genera notificaciones espurias.
- **`testSegmentRefresh_duplicate()`** — `Segment.refresh` devuelve `null` si ya hay una carga en curso.

### 3.3 `RemovalListener`

- **`testRemovalListener_explicit()`** — notificación `EXPLICIT` para `remove`, `remove(k,v)` y `remove()` sobre los iteradores de `entrySet`, `keySet` y `values`.
- **`testRemovalListener_replaced()` / `testRemovalListener_replaced_computing()`** — notificación `REPLACED` para `put`, `putAll`, `replace(k,v)` y `replace(k,v1,v2)`, incluso cuando se sobrescribe una entrada en cómputo.
- **`testRemovalListener_collected()`** — notificación `COLLECTED` al reclamar un valor blando.
- **`testRemovalListener_expired()`** — notificación `EXPIRED` dirigida por `FakeTicker`.
- **`testRemovalListener_size()`** — notificación `SIZE` al superar `maximumSize`.
- **`testRemovalListenerCheckedException()`** — una excepción lanzada por el listener se registra en el log y no se propaga.
- **`assertNotified(listener, key, value, cause)`** — helper estático que extrae la siguiente notificación de la cola y valida clave, valor y causa.

### 3.4 Núcleo de `Segment`

- **`testNewEntry()` / `testCopyEntry()`** (+ `assertConnected`) — creación y copia de entradas para todas las combinaciones de tipo de entrada, incluida la preservación de los enlaces en las colas de acceso/escritura.
- **`testSegmentGetAndContains()`** — `get`, `containsKey`, `containsValue` ante: tabla con `count == 0`, claves nulas (recolectadas), colisiones de hash, colisiones de clave y entradas expiradas.
- **`testSegmentReplaceValue()` / `testSegmentReplace()` / `testSegmentPut()` / `testSegmentPutIfAbsent()` / `testSegmentRemove()