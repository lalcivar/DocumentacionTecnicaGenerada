Documentación técnica  
Clase: org.junit.jupiter.engine.execution.injection.sample.NumberParameterResolver  
Autoría: JUnit Jupiter – proyecto de ejemplo  
Desde: JUnit 5.0  

1. Propósito general  
NumberParameterResolver es una implementación de la interfaz org.junit.jupiter.api.extension.ParameterResolver incluida como ejemplo en el motor de JUnit Jupiter. Su función consiste en “resolver” (inyectar) argumentos para parámetros de métodos de prueba que sean subtipos de java.lang.Number.  

Aunque el método supportsParameter() afirma dar soporte a cualquier subtipo de Number, el método resolveParameter() siempre devuelve la misma instancia de java.lang.Integer con el valor 42. En consecuencia:

• Puede inyectar correctamente un Integer o un tipo padre (Number, Object).  
• Puede provocar en tiempo de ejecución una excepción IllegalArgumentException ("argument type mismatch") cuando el parámetro solicitado es otro subtipo de Number (Long, Double, BigDecimal, etc.).  

El objetivo de la clase es ilustrar que un ParameterResolver podría declarar soporte genérico para un tipo, pero terminar suministrando un valor no compatible según el contexto de la prueba (similar al caso descrito con Spring y ApplicationContext).  

2. Principales métodos públicos  

2.1 boolean supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext)  
Descripción:  
– Indica a JUnit Jupiter si este resolver es capaz de suministrar un valor para el parámetro actualmente procesado.  

Parámetros:  
• parameterContext – Información de reflexión sobre el parámetro (tipo, índice, anotaciones, etc.).  
• extensionContext – Información contextual sobre la ejecución actual (clase de prueba, método, extensiones registradas...).  

Lógica interna:  
return Number.class.isAssignableFrom(parameterContext.getParameter().getType());  
Es decir, devuelve true si el tipo declarado del parámetro es Number o cualquiera de sus subclases.  

Efectos:  
Cuando devuelve true, el motor de pruebas delegará la resolución del argumento al método resolveParameter() de la misma instancia.  

2.2 Object resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext)  
Descripción:  
– Devuelve el objeto concreto que se inyectará en el parámetro para la invocación del método de prueba.  

Parámetros:  
• parameterContext – Igual que en supportsParameter(), permite leer metadatos del parámetro (no utilizado en esta implementación).  
• extensionContext – Igual que en supportsParameter() (no utilizado aquí).  

Valor devuelto:  
Siempre retorna la constante Integer 42.  

Consecuencias:  
• Correcto si el tipo del parámetro es Integer, Number o Object.  
• Provoca IllegalArgumentException (“argument type mismatch”) dentro de JUnit si el parámetro requiere, por ejemplo, Long o Double, porque el valor 42 (Integer) no es asignable a esos tipos.  

3. Uso típico  
No se recomienda utilizar esta implementación en producción. Sirve exclusivamente como demostración en material formativo o pruebas de concepto:

```java
@ExtendWith(NumberParameterResolver.class)
void testSuma(Integer numero) {
    assertEquals(42, numero);
}
```

4. Resumen  
NumberParameterResolver exhibe deliberadamente un desacople entre la detección de soporte (basada en la jerarquía de tipos) y la provisión real del valor (un único Integer). Esto lo convierte en un recurso didáctico para mostrar:  

• Cómo implementar un ParameterResolver en JUnit 5.  
• Qué ocurre cuando el valor resuelto no es compatible con el tipo del parámetro.  

No contiene lógica adicional, dependencias externas ni manejo de excepciones propio.