--------------------------------------------------------------------------
Documentación Técnica  
Clase: org.junit.platform.suite.engine.DiscoverySelectorResolver  
Desde: JUnit Platform 1.8  
--------------------------------------------------------------------------

1. Descripción general
----------------------
DiscoverySelectorResolver es una clase `final` con acceso por paquete (no pública) que forma parte del “Suite Engine” de JUnit Platform.  
Su única responsabilidad es transformar un `EngineDiscoveryRequest` —que contiene los *discovery selectors* producidos por el usuario (por ejemplo, anotaciones `@SelectClasses`, `@SelectPackages`, etc.)— en un árbol de `TestDescriptor`s adecuado para el motor de suites (`SuiteEngineDescriptor`).

En esencia, funciona como un *pipeline* que:

1. Enlaza distintos *selector resolvers* (adaptadores que saben interpretar cada tipo de selector).
2. Ejecuta la resolución sobre el request recibido.
3. Descubre recursivamente las clases marcadas como `@Suite`.
4. Elimina nodos vacíos o redundantes del árbol resultante (poda).

2. Colaboraciones externas
--------------------------
• EngineDiscoveryRequest  
• SuiteEngineDescriptor (propio del Suite Engine)  
• EngineDiscoveryRequestResolver (utilidad de apoyo genérico incluida en JUnit Platform)  
• DiscoveryIssueReporter (reporte de problemas durante el descubrimiento)  
• ClassSelectorResolver e IsSuiteClass (resolvers concretos añadidos al pipeline)

3. Atributos
------------
• resolver (estático, inmutable)  
  Instancia pre-construida de `EngineDiscoveryRequestResolver<SuiteEngineDescriptor>` configurada con:

  - addClassContainerSelectorResolverWithContext → IsSuiteClass  
  - addSelectorResolver → ClassSelectorResolver  

  De este modo se soportan, dentro del contexto de las suites, los selectores de contenedor de clases y los selectores de clase individuales.

4. Principales métodos
----------------------

4.1 resolveSelectors(EngineDiscoveryRequest request,  
                     SuiteEngineDescriptor engineDescriptor)
• Visibilidad: *package-private*  
• Flujo completo que ejecuta el descubrimiento.

  a) Crea un `DiscoveryIssueReporter` deduplicante que, a su vez, re-expide los eventos al `DiscoveryListener` original del request.  
  b) Invoca `resolver.resolve(request, engineDescriptor, issueReporter)`:  
     – Cada selector del request es evaluado por la cadena de resolvers configurados en el atributo `resolver`.  
     – Por cada selector válido se generan y añaden hijos al `SuiteEngineDescriptor`.  
  c) Llama a `discoverSuites(engineDescriptor)` para procesar recursivamente los nodos que representan clases anotadas como `@Suite`.  
  d) Finalmente, ejecuta `engineDescriptor.accept(TestDescriptor::prune)` para limpiar nodos vacíos o dupllicados del árbol.

4.2 discoverSuites(SuiteEngineDescriptor engineDescriptor)  (privado, estático)
• Recorre los hijos directos del `engineDescriptor`, castea cada uno a `SuiteTestDescriptor` y ejecuta su método `discover()`.  
• Se encarga de que las suites anidadas se procesen en cascada.

5. Flujo de trabajo resumido
----------------------------
1. Un motor de pruebas de tipo *Suite* llama a `resolveSelectors()` durante la fase de descubrimiento.  
2. Se construye el árbol inicial de descriptores.  
3. Se identifican y expanden las clases anotadas con `@Suite`.  
4. Se aplica poda para optimizar el árbol final que será usado en la ejecución.

6. Consideraciones de diseño
----------------------------
• Inmutabilidad: solo contiene un atributo estático final.  
• Thread-safe: no mantiene estado mutable alguno.  
• Extensión: al ser `final` y *package-private* no puede sub-clasificarse; cualquier cambio en la cadena de resolvers se debe realizar modificando la creación del atributo `resolver`.

7. Dependencias de versión
--------------------------
Disponible desde JUnit Platform 1.8; cambios internos podrían ocurrir sin previo aviso porque no es parte de la API pública.

--------------------------------------------------------------------------