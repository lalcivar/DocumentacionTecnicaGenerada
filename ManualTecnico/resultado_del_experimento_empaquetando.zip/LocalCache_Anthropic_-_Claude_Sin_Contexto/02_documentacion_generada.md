# Documentación técnica — `com.google.common.cache.LocalCache<K, V>`

## 1. Visión general

`LocalCache<K, V>` es la **implementación interna** (package-private, `final`) del mapa hash concurrente que respalda a todas las cachés construidas mediante `CacheBuilder`. Extiende `AbstractMap<K, V>` e implementa `ConcurrentMap<K, V>`, por lo que se comporta como un mapa concurrente convencional, pero añade todas las capacidades propias de una caché:

| Capacidad | Mecanismo |
|---|---|
| Carga automática de valores | `CacheLoader` + `LoadingValueReference` |
| Expiración por escritura / acceso | `expireAfterWriteNanos`, `expireAfterAccessNanos`, colas `WriteQueue`/`AccessQueue` |
| Refresco asíncrono | `refreshNanos`, `refresh(...)`, `loadAsync(...)` |
| Desalojo por tamaño o peso | `maxWeight`, `Weigher`, algoritmo LRU por segmento |
| Claves/valores débiles o suaves | `Strength` (`STRONG`, `SOFT`, `WEAK`) + `ReferenceQueue` |
| Notificación de eliminaciones | `RemovalListener` + `removalNotificationQueue` |
| Estadísticas | `StatsCounter` global y por segmento |

La implementación deriva directamente de la revisión 1.96 de `ConcurrentHashMap` de Doug Lea: la tabla se **subdivide en *segmentos*** (`Segment<K, V>`, que heredan de `ReentrantLock`), cada uno con su propia tabla hash, sus colas de orden y su contador de estadísticas. Las lecturas son no bloqueantes (basadas en campos `volatile`, principalmente `count`); las escrituras bloquean únicamente el segmento afectado, lo que permite escrituras concurrentes en segmentos distintos.

Las estructuras del algoritmo de reemplazo de páginas (LRU) se mantienen **consistentes de forma "casual"**: los accesos se registran en una `recencyQueue` por segmento y se vuelcan en lote cuando se cruza `DRAIN_THRESHOLD` o cuando ocurre una escritura, amortizando así el costo de mantener el orden de recencia y evitando contención de bloqueos.

> **Nota:** esta clase no es parte de la API pública de Guava. Los usuarios interactúan con ella a través de `Cache`, `LoadingCache` o `asMap()`.

---

## 2. Constantes relevantes

| Constante | Descripción |
|---|---|
| `MAXIMUM_CAPACITY = 1 << 30` | Capacidad máxima de la tabla (potencia de dos). |
| `MAX_SEGMENTS = 1 << 16` | Límite superior del número de segmentos. |
| `CONTAINS_VALUE_RETRIES = 3` | Reintentos no sincronizados en `containsValue`. |
| `DRAIN_THRESHOLD = 0x3F` | Número de lecturas bufferizadas por segmento antes de actualizar el orden de recencia (debe ser `2^n - 1`, se usa como máscara). |
| `DRAIN_MAX = 16` | Máximo de entradas drenadas por pasada de limpieza. |

---

## 3. Constructor

```java
LocalCache(CacheBuilder<? super K, ? super V> builder,
           @Nullable CacheLoader<? super K, V> loader)
```

Construye la caché a partir de la configuración del `CacheBuilder`:

1. Copia estrategias (`keyStrength`, `valueStrength`, equivalencias, `weigher`, `ticker`, `removalListener`).
2. Calcula el número de segmentos como la menor potencia de dos que supere `concurrencyLevel`, garantizando —cuando hay desalojo por tamaño— al menos ~10 entradas por segmento (evita desalojos "aleatorios").
3. Elige la `EntryFactory` adecuada según la fuerza de la clave y si se requieren colas de acceso/escritura.
4. Distribuye `maxWeight` entre los segmentos de modo que la suma de los pesos máximos por segmento sea exactamente el peso máximo global.

---

## 4. Métodos principales

### 4.1 Predicados de configuración

Métodos booleanos de bajo costo que determinan qué funcionalidades están activas y, por tanto, qué estructuras y tipos de entrada deben usarse:

- `evictsBySize()` — hay un peso/tamaño máximo definido.
- `customWeigher()` — se configuró un `Weigher` distinto del trivial.
- `expires()`, `expiresAfterWrite()`, `expiresAfterAccess()` — políticas de expiración activas.
- `refreshes()` — refresco automático activo.
- `usesAccessQueue()`, `usesWriteQueue()` — qué colas de orden deben instanciarse.
- `recordsAccess()`, `recordsWrite()`, `recordsTime()` — si deben registrarse marcas temporales.
- `usesAccessEntries()`, `usesWriteEntries()` — qué tipo de `ReferenceEntry` crear.
- `usesKeyReferences()`, `usesValueReferences()` — si se necesitan `ReferenceQueue` para GC.

### 4.2 Hashing y direccionamiento de segmentos

- `static int rehash(int h)` — aplica una función hash suplementaria (variante Wang/Jenkins) para dispersar bits y evitar colisiones en tablas de longitud potencia de dos.
- `int hash(Object key)` — combina `keyEquivalence.hash(key)` con `rehash`.
- `Segment<K, V> segmentFor(int hash)` — devuelve el segmento responsable de un hash dado, usando `segmentShift` y `segmentMask`.
- `Segment<K,V> createSegment(...)`, `Segment<K,V>[] newSegmentArray(int)` — creación de segmentos.

### 4.3 Operaciones `Map` / `ConcurrentMap`

Todas delegan en el segmento correspondiente:

| Método | Comportamiento |
|---|---|
| `get(Object key)` | Lectura sin bloqueo; devuelve `null` si no existe, expiró o fue recolectado. Puede disparar un refresco. |
| `getOrDefault(key, default)` | Variante con valor por defecto. |
| `put(K, V)` / `putIfAbsent(K, V)` | Delegan en `Segment.put(key, hash, value, onlyIfAbsent)`. No admiten `null`. |
| `putAll(Map)` | Iteración de `put`. |
| `remove(Object)` / `remove(Object, Object)` | Eliminación explícita (causa `RemovalCause.EXPLICIT`). |
| `replace(K, V)` / `replace(K, V, V)` | Reemplazo condicional e incondicional (causa `REPLACED`). |
| `containsKey(Object)` | Consulta sin alterar el orden de recencia. |
| `containsValue(Object)` | Barrido de todos los segmentos con hasta `CONTAINS_VALUE_RETRIES` reintentos y comprobación de estabilidad vía `modCount`. |
| `clear()` | Limpia todos los segmentos, encolando notificaciones de eliminación. |
| `isEmpty()` | Suma `count` y `modCount` por segmento para evitar falsos positivos en concurrencia. |
| `size()` / `longSize()` | Tamaño aproximado (saturado a `int` en `size()`). |
| `keySet()`, `values()`, `entrySet()` | Vistas perezosas (`KeySet`, `Values`, `EntrySet`) con iteradores débilmente consistentes. |

### 4.4 Operaciones específicas de caché

- `V get(K key, CacheLoader<? super K, V> loader)` — obtiene el valor y, si falta, lo **carga** usando el loader indicado; lanza `ExecutionException`, `UncheckedExecutionException` o `ExecutionError` según el tipo de fallo.
- `V getOrLoad(K key)` — equivalente usando `defaultLoader`.
- `V getIfPresent(Object key)` — lectura que registra *hit* o *miss* en el contador global, sin cargar.
- `ImmutableMap<K, V> getAllPresent(Iterable<?> keys)` — múltiples lecturas sin carga, con registro de estadísticas agregadas.
- `ImmutableMap<K, V> getAll(Iterable<? extends K> keys)` — lectura masiva con carga en bloque; intenta `loadAll` y, si el loader no lo implementa (`UnsupportedLoadingOperationException`), hace *fallback* a cargas individuales.
- `Map<K, V> loadAll(Set<? extends K> keys, CacheLoader loader)` — invoca `CacheLoader.loadAll`, valida que no devuelva `null` ni claves/valores nulos, almacena los resultados y registra el tiempo de carga.
- `void refresh(K key)` — fuerza un refresco asíncrono de la entrada.
- `void invalidateAll(Iterable<?> keys)` — invalidación masiva.
- `void cleanUp()` — ejecuta el mantenimiento pendiente (drenaje de colas de referencias, expiración, notificaciones) en todos los segmentos.

### 4.5 Expiración, recolección y notificaciones

- `boolean isExpired(ReferenceEntry, long now)` — true si la entrada superó `expireAfterAccessNanos` o `expireAfterWriteNanos`.
- `V getLiveValue(ReferenceEntry, long now)` — valor "vivo" (no nulo, no expirado, no en carga) **sin** intentar limpiar entradas obsoletas; apto para uso fuera del contexto de un segmento (p. ej., durante iteración).
- `void reclaimKey(ReferenceEntry)` / `void reclaimValue(ValueReference)` — eliminan entradas cuya clave o valor fue recolectado por el GC.
- `void processPendingNotifications()` — vacía `removalNotificationQueue` invocando `RemovalListener.onRemoval`, capturando y registrando cualquier excepción del listener.
- Utilidades estáticas de enlazado de colas: `connectAccessOrder`, `nullifyAccessOrder`, `connectWriteOrder`, `nullifyWriteOrder`.

### 4.6 Métodos de conveniencia para pruebas (`@VisibleForTesting`)

`newEntry(...)`, `copyEntry(...)`, `newValueReference(...)`, `isLive(...)` — delegan en el segmento correspondiente; el código productivo debe llamar directamente a los métodos de `Segment`.

---

## 5. Tipos anidados principales

| Tipo | Rol |
|---|---|
| `Segment<K, V>` | Tabla hash especializada que extiende `ReentrantLock`. Contiene la lógica real de `get`, `put`, `remove`, `replace`, `expand` (rehash), carga (`lockedGetOrLoad`, `loadSync`, `loadAsync`, `getAndRecordStats`), refresco (`scheduleRefresh`, `refresh`, `insertLoadingValueReference`), desalojo (`evictEntries`, `getNextEvictable`), expiración (`expireEntries`, `tryExpireEntries`), drenaje de colas (`drainReferenceQueues`, `drainRecencyQueue`) y limpieza (`preWri