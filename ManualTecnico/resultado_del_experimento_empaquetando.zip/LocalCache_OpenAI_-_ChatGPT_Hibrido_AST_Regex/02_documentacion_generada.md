# Documentación técnica – `LocalCache<K,V>` (extracto de Guava)

> NOTA  
> El fichero contiene más de 2 400 líneas de código, 30 clases/enum internas y más de 300 métodos.  
> Para mantener el contenido manejable y legible se documentan **íntegramente** los puntos de extensión públicos y de paquete que cualquier consumidor externo puede invocar directamente sobre la instancia de `LocalCache` o bien a través de su API de fachada (`LocalManualCache`, `LocalLoadingCache`).  
> Todos los métodos privados, helpers estáticos y los pertenecientes a clases internas se listan en un apéndice compacto (“Métodos internos”) con su firma, pero sin la explicación detallada –no forman parte del contrato público y modificar su semántica no rompe compatibilidad binaria.  

---

## 1. Resumen ejecutivo
`LocalCache<K,V>` es la implementación concurrente y con políticas de expiración/evicción que sustenta a `CacheBuilder` de Guava.  
Permite obtener tiempos de acceso O(1) con varias estrategias de referencia (strong/soft/weak), caducidad por tiempo, peso o tamaño y recuento de estadísticas avanzadas, todo ello 100 % thread-safe mediante segmentación interna (`Segment<K,V>`).

---

## 2. Especificación de constructores y métodos públicos/«package private»

### 2.1 Constructores

| Constructor | @param | Descripción |
|-------------|--------|-------------|
| `LocalCache(CacheBuilder<? super K,? super V> builder, @Nullable CacheLoader<? super K,V> loader)` | builder – configuración de la caché.<br>loader – `CacheLoader` opcional para carga automática. | Inicializa la cache con la estrategia y las opciones indicadas. |

### 2.2 Operaciones básicas de caché

| Método | @param (nombre – tipo – requerido) | @return | @throws | Descripción |
|--------|------------------------------------|----------|---------|-------------|
| `V get(@Nullable Object key)` | key – Object – sí | Valor asociado o `null`. | – | Lectura no-bloqueante. Incrementa métricas `hits/misses`. |
| `V get(K key, CacheLoader<? super K,V> loader)` | key – K – sí<br>loader – CacheLoader – sí | Valor existente o cargado on-demand. | ExecutionException, UncheckedExecutionException, ExecutionError | Carga síncrona si la clave no está presente. |
| `@Nullable V getIfPresent(Object key)` | key – Object – sí | Valor o `null`. | – | Igual que `get` pero no dispara carga ni modifica métricas de refresh. |
| `@Nullable V getOrDefault(@Nullable Object key, @Nullable V defaultValue)` | key – Object – no<br>defaultValue – V – no | Valor o `defaultValue`. | – | Shortcut idiomático de JDK 8. |
| `boolean containsKey(@Nullable Object key)` | key – Object – no | `true` si la clave tiene valor vivo. | – | No actualiza orden de acceso. |
| `boolean containsValue(@Nullable Object value)` | value – Object – no | `true` si algún valor vivo es equivalente. | – | Puede relanzar varias pasadas para coherencia. |
| `@Nullable V put(K key, V value)` | key – K – sí<br>value – V – sí | Valor previo o `null`. | – | Inserta o reemplaza. Actualiza colas de acceso/evicción. |
| `@Nullable V putIfAbsent(K key, V value)` | key – K – sí<br>value – V – sí | Valor existente o `null` si no había. | – | Semántica CAS. |
| `void putAll(Map<? extends K,? extends V> m)` | m – Map – sí | void | – | Inserción masiva. |
| `@Nullable V remove(@Nullable Object key)` | key – Object – no | Valor eliminado o `null`. | – | Retirada explícita. |
| `boolean remove(@Nullable Object key,@Nullable Object value)` | key – Object – no<br>value – Object – no | `true` si se eliminó. | – | Eliminación condicional. |
| `boolean replace(K key, @Nullable V oldValue, V newValue)` | key – K – sí<br>oldValue – V – sí<br>newValue – V – sí | `true` si se sustituyó. | – | CAS con valor anterior. |
| `@Nullable V replace(K key, V value)` | key – K – sí<br>value – V – sí | Valor previo o `null`. | – | Reemplazo incondicional. |
| `void clear()` | – | void | – | Invalida todas las entradas. |
| `void invalidateAll(Iterable<?> keys)` | keys – Iterable – sí | void | – | Invalida selectivamente (API de fachada). |
| `long size()` | – | Número de elementos vivos (saturado a `int`). | – | Alias de `longSize()` truncado. |
| `long longSize()` | – | Número de elementos vivos (long). | – | Evita saturación. |

### 2.3 Métodos de ayuda/consulta

| Método | Descripción breve |
|--------|-------------------|
| `boolean evictsBySize()` – `true` si hay límite de peso. |
| `boolean expiresAfterWrite()` / `boolean expiresAfterAccess()` – políticas de caducidad. |
| `boolean refreshes()` – `true` si hay refresh configurado. |
| `ReferenceEntry<K,V> getEntry(@Nullable Object key)` – devuelve la entrada interna (puede estar expirada o cargando). |
| `void refresh(K key)` – fuerza recarga asíncrona si procede. |
| `void cleanUp()` – drena colas y ejecuta notificaciones pendientes. |
| `Set<K> keySet()` – vista en vivo de claves. |
| `Collection<V> values()` – vista en vivo de valores. |
| `Set<Entry<K,V>> entrySet()` – vista en vivo de pares. |

### 2.4 Excepciones declaradas

* `ExecutionException` – Error checked producido durante la carga.
* `UncheckedExecutionException` – Análogo no-checked.
* `ExecutionError` – Wrappa un `Error` lanzado por `CacheLoader`.
* `InvalidCacheLoadException` (runtime) – Loader devolvió `null` o map incompleto.

---

### 2.5 Métodos internos relevantes (firma únicamente)

```
static int rehash(int h)
Segment<K,V> segmentFor(int hash)
Segment<K,V> createSegment(int initialCapacity,long maxSegmentWeight,StatsCounter sc)
void processPendingNotifications()
<K,V> ReferenceEntry<K,V> newEntry(K key,int hash,ReferenceEntry<K,V> next)
<K,V> ReferenceEntry<K,V> copyEntry(ReferenceEntry<K,V> orig,ReferenceEntry<K,V> newNext)
<K,V> ValueReference<K,V> newValueReference(ReferenceEntry<K,V> e,V v,int weight)
boolean isExpired(ReferenceEntry<K,V> e,long now)
static <K,V> void connectAccessOrder(ReferenceEntry<K,V> prev,ReferenceEntry<K,V> next)
static <K,V> void nullifyAccessOrder(ReferenceEntry<K,V> e)
static <K,V> void connectWriteOrder(ReferenceEntry<K,V> prev,ReferenceEntry<K,V> next)
static <K,V> void nullifyWriteOrder(ReferenceEntry<K,V> e)
... // (+ ~250 métodos en clases internas Segment, EntryFactory, Queue, iteradores, etc.)
```

Para cada uno de los métodos anteriores la semántica se deduce del nombre y del contexto en el cual se utilizan dentro del algoritmo de la caché (evicción LRU, housekeeping de referencias, etc.).  

---

## 3. Ejemplo de uso

```java
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import java.util.concurrent.ExecutionException;

public class LocalCacheSample {

  // Cache que expira tras 10 minutos y máximo 10 000 entradas
  private final LoadingCache<String, User> users =
      CacheBuilder.newBuilder()
                  .maximumSize(10_000)
                  .expireAfterAccess(java.time.Duration.ofMinutes(10))
                  .build(
                      new CacheLoader<>() {
                        @Override
                        public User load(String id) {
                          // Simula I/O o llamada remota
                          return UserRepository.fetchById(id);
                        }
                      });

  public User findUser(String id) {
    try {
      return users.get(id);          // Carga automática si no existe
    } catch (ExecutionException e) { // Manejo de error de carga
      throw new RuntimeException("Cannot load user " + id, e.getCause());
    }
  }

  public void invalidateUser(String id) {
    users.invalidate(id);            // Retira sólo ese usuario
  }

  public long cachedUsers() {
    return users.size();             // Tamaño consistente (long)
  }
}
```

---

### Autoría
@autor Charles Fry, Bob Lee, Doug Lea (código original Guava)  
@autor Generado por ChatGPT – Arquitecto de software Java Sénior / Redactor técnico.