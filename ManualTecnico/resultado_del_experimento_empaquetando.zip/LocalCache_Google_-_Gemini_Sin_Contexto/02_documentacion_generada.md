Claro, aquí tienes la documentación técnica para la clase `LocalCache` de Guava.

---

### Documentación Técnica: Clase `LocalCache<K, V>`

### Descripción General

La clase `LocalCache<K, V>` es la implementación central y concreta del sistema de caché en memoria de la biblioteca Guava de Google. Aunque es una clase pública, no está diseñada para ser instanciada o utilizada directamente por los desarrolladores. En su lugar, se configura y se crea a través de la clase `CacheBuilder`, que devuelve una instancia de `Cache` o `LoadingCache` (implementadas internamente por `LocalManualCache` y `LocalLoadingCache`, que a su vez envuelven a `LocalCache`).

`LocalCache` es, en esencia, un `ConcurrentMap` altamente optimizado con funcionalidades avanzadas de caché, como políticas de expulsión (eviction), expiración de entradas, recarga automática de valores y manejo de estadísticas. Su diseño está fuertemente inspirado en `ConcurrentHashMap` para lograr un alto rendimiento en entornos concurrentes.

### Arquitectura y Características Principales

La arquitectura de `LocalCache` se basa en la segmentación para lograr una alta concurrencia.

1.  **Concurrencia por Segmentación**: La caché se divide en un número de `Segmentos`. Cada segmento es una tabla de hash independiente con su propio bloqueo (`ReentrantLock`). Las operaciones de escritura (como `put` o `remove`) solo bloquean el segmento específico al que pertenece la clave, permitiendo que otros hilos operen en diferentes segmentos simultáneamente. Las operaciones de lectura son en su mayoría no bloqueantes.

2.  **Políticas de Expulsión (Eviction)**: `LocalCache` soporta varias estrategias para decidir cuándo eliminar una entrada:
    *   **Basada en Tamaño/Peso**: Se puede configurar un tamaño máximo (`maximumSize`) o un peso máximo (`maximumWeight` con un `Weigher`). Cuando se excede el límite, la caché expulsa las entradas menos recientemente usadas (algoritmo LRU - Least Recently Used).
    *   **Basada en Tiempo**: Las entradas pueden expirar y ser eliminadas después de un cierto tiempo:
        *   `expireAfterAccess`: La entrada expira si no ha sido leída o actualizada en un período de tiempo determinado.
        *   `expireAfterWrite`: La entrada expira si no ha sido actualizada en un período de tiempo determinado.

3.  **Recarga Automática y Refresco**:
    *   Si la caché se construye como un `LoadingCache` (con un `CacheLoader`), intentará cargar automáticamente un valor para una clave si esta no se encuentra en la caché.
    *   También soporta el refresco asíncrono de entradas (`refreshAfterWrite`), donde un valor antiguo puede seguir siendo servido mientras se carga uno nuevo en segundo plano.

4.  **Tipos de Referencia**: Para un mejor control sobre la memoria, `LocalCache` permite configurar las claves y valores para que sean almacenados como referencias débiles (`WeakReference`) o suaves (`SoftReference`). Esto permite que el recolector de basura de Java elimine entradas de la caché si la memoria es escasa.
    *   `weakKeys`: Las entradas se eliminan si su clave ya no tiene referencias fuertes en otra parte.
    *   `weakValues` / `softValues`: Las entradas se eliminan si su valor es recolectado por el GC.

5.  **Notificaciones y Estadísticas**:
    *   Se puede registrar un `RemovalListener` para ser notificado cuando una entrada es eliminada de la caché, junto con la causa (`RemovalCause`).
    *   Si se habilita, la caché puede registrar estadísticas de rendimiento (`CacheStats`), como el número de aciertos (hits), fallos (misses), expulsiones y tiempo de carga.

### Métodos Principales

Aunque `LocalCache` implementa la interfaz `ConcurrentMap<K, V>`, sus métodos más relevantes son los que se exponen a través de las interfaces `Cache` y `LoadingCache`. A continuación se describen las operaciones fundamentales que `LocalCache` realiza.

---

#### `V get(Object key)`
Recupera el valor asociado a la `key` especificada. Si la entrada ha expirado o ha sido recolectada por el GC, se considera ausente y el método devuelve `null`. Esta operación actualiza el tiempo de acceso de la entrada si la caché está configurada con `expireAfterAccess`.

*   **Parámetros**:
    *   `key`: La clave cuyo valor se va a recuperar.
*   **Retorno**:
    *   El valor asociado a la `key`, o `null` si no existe una entrada válida.

---

#### `V get(K key, CacheLoader<? super K, V> loader)`
Este es el método central para las cachés con carga (`LoadingCache`). Intenta obtener el valor para la `key`. Si no se encuentra, utiliza el `CacheLoader` proporcionado para calcular o cargar el valor. El nuevo valor se inserta en la caché y se devuelve.

*   **Parámetros**:
    *   `key`: La clave cuyo valor se va a recuperar o cargar.
    *   `loader`: El cargador que computará el valor si no está presente.
*   **Retorno**:
    *   El valor (existente o recién cargado) asociado a la `key`. Nunca devuelve `null` a menos que el `loader` lo haga (lo cual es considerado un error).
*   **Lanza**:
    *   `ExecutionException`: Si el `loader` lanza una excepción durante la carga.
    *   `UncheckedExecutionException`: Si el `loader` lanza una excepción no chequeada.

---

#### `V getIfPresent(Object key)`
Este método es específico de la interfaz `Cache`. Devuelve el valor asociado a la `key` solo si está presente en la caché y es válido (no ha expirado). A diferencia de `get()` en un `LoadingCache`, **nunca** intentará cargar un valor.

*   **Parámetros**:
    *   `key`: La clave a buscar.
*   **Retorno**:
    *   El valor si está presente y es válido; de lo contrario, `null`.

---

#### `V put(K key, V value)`
Asocia el `value` especificado con la `key` en la caché. Si ya existía una entrada para esa clave, el valor anterior es reemplazado. Esta operación también actualiza el tiempo de escritura y acceso de la entrada.

*   **Parámetros**:
    *   `key`: La clave con la que se asociará el valor.
    *   `value`: El valor a ser asociado con la clave.
*   **Retorno**:
    *   El valor anterior asociado con la `key`, o `null` si no había ninguno.

---

#### `void invalidate(Object key)` (implementado a través de `remove`)
Elimina la entrada asociada a la `key` de la caché. Si se ha configurado un `RemovalListener`, será notificado con la causa `EXPLICIT`.

*   **Parámetros**:
    *   `key`: La clave de la entrada a eliminar.

---

#### `void cleanUp()`
Realiza tareas de mantenimiento en la caché. Esto incluye la eliminación de entradas que han expirado o cuyas claves/valores han sido recolectados por el recolector de basura. Normalmente, estas tareas se realizan de forma oportunista durante las operaciones de escritura, pero este método permite forzar la limpieza manualmente.

---

#### `long size()`
Devuelve el número aproximado de entradas en la caché. El valor puede ser ligeramente impreciso debido a la naturaleza concurrente de la caché.

*   **Retorno**:
    *   El número de entradas en la caché.

---

#### `ConcurrentMap<K, V> asMap()`
Devuelve una vista de la caché como un `ConcurrentMap`. Las modificaciones realizadas en este mapa se reflejan en la caché y viceversa. Esta vista proporciona acceso a toda la funcionalidad de `ConcurrentMap` que no está directamente en la interfaz `Cache`.

*   **Retorno**:
    *   Una vista de la caché como un mapa concurrente.