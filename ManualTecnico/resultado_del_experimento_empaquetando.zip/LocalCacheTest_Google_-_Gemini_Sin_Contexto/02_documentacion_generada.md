Claro, aquí tienes la documentación técnica para la clase `LocalCacheTest` en formato Markdown.

---

### Documentación Técnica: Clase `LocalCacheTest`

### Descripción General

La clase `LocalCacheTest` es una suite de pruebas exhaustiva diseñada para verificar el comportamiento y la correctitud de la clase `com.google.common.cache.LocalCache`, que es la implementación subyacente de los cachés creados con `CacheBuilder` en la biblioteca Guava de Google.

Esta clase no forma parte de la API pública de Guava para el consumidor final, sino que es una herramienta interna de desarrollo y aseguramiento de la calidad. Su propósito es probar de manera rigurosa todas las características de `LocalCache`, incluyendo:

*   **Operaciones básicas de un mapa concurrente**: `put`, `get`, `remove`, `replace`, etc.
*   **Políticas de desalojo (eviction)**: por tamaño máximo, por peso y LRU (Least Recently Used).
*   **Políticas de expiración**: por tiempo transcurrido desde el último acceso (`expireAfterAccess`) y desde la última escritura (`expireAfterWrite`).
*   **Manejo de referencias**: uso de referencias débiles (`weakKeys`, `weakValues`) y suaves (`softValues`) para permitir que el recolector de basura limpie entradas del caché.
*   **Carga de valores**: pruebas sobre `CacheLoader`, incluyendo cargas concurrentes, recursivas y refresco de valores.
*   **Notificaciones de eliminación**: verificación de que los `RemovalListener` son invocados correctamente con la causa adecuada (`EXPLICIT`, `REPLACED`, `COLLECTED`, `EXPIRED`, `SIZE`).
*   **Serialización**: asegura que la configuración del caché se puede serializar y deserializar correctamente.
*   **Estadísticas**: pruebas sobre la correcta recolección de métricas como `hitCount`, `missCount`, etc. (aunque las pruebas específicas de `CacheStats` están en otra clase, aquí se prueba la configuración `recordStats`).

La clase utiliza el framework de pruebas JUnit 3 (`TestCase`), junto con librerías de aserción como `Truth` y utilidades de testing de Guava como `FakeTicker` para simular el paso del tiempo de forma controlada.

### Métodos Principales y Funcionalidad Probada

Más que tener "métodos principales" para ser usados por un programador, la clase se compone de una gran cantidad de métodos de prueba (`test...`), cada uno enfocado en un aspecto específico de `LocalCache`. A continuación, se agrupan los métodos de prueba más representativos según la funcionalidad que verifican.

#### 1. Configuración e Inicialización
Estos métodos verifican que el caché se construye correctamente según las especificaciones del `CacheBuilder`.
*   `testDefaults()`: Comprueba que un caché creado sin configuración específica tiene los valores por defecto esperados (fortaleza de claves/valores, niveles de concurrencia, etc.).
*   `testSetConcurrencyLevel()`, `testSetInitialCapacity()`, `testSetMaximumSize()`: Validan que los parámetros de tamaño y concurrencia se aplican correctamente, distribuyendo la capacidad entre los segmentos internos del caché.
*   `testSetWeakKeys()`, `testSetWeakValues()`, `testSetSoftValues()`: Aseguran que el tipo de referencia para claves y valores se establece correctamente.
*   `testSetExpireAfterWrite()`, `testSetExpireAfterAccess()`: Confirman que los tiempos de expiración se configuran en nanosegundos internamente.

#### 2. Políticas de Expiración y Desalojo (Eviction)
Estos métodos utilizan un `FakeTicker` para controlar el tiempo y probar las políticas de limpieza del caché.
*   `testExpireAfterWrite()`: Simula el paso del tiempo para verificar que una entrada es eliminada después de que ha transcurrido el tiempo configurado desde su creación o última modificación.
*   `testExpireAfterAccess()`: Similar al anterior, pero verifica que la expiración se basa en el tiempo desde el último acceso (lectura o escritura).
*   `testEvictEntries()`: Prueba la política de desalojo por tamaño. Añade más elementos que el tamaño máximo permitido y verifica que las entradas más antiguas (según la política LRU) son eliminadas.
*   `testRecordRead()` y `testRecordWrite()`: Prueban a bajo nivel que las operaciones de lectura y escritura actualizan correctamente las colas internas (`accessQueue`, `writeQueue`) que gestionan el orden para la expiración y el desalojo.

#### 3. Notificaciones de Eliminación (`RemovalListener`)
Estos métodos aseguran que el `RemovalListener` configurado es invocado con la causa correcta cuando una entrada es eliminada.
*   `testRemovalListener_explicit()`: Verifica que la causa es `EXPLICIT` cuando se usa `remove()` o se elimina a través de un iterador.
*   `testRemovalListener_replaced()`: Verifica que la causa es `REPLACED` cuando se usa `put()` o `replace()` sobre una clave ya existente.
*   `testRemovalListener_collected()`: Prueba que la causa es `COLLECTED` cuando una entrada es eliminada por el recolector de basura (en cachés con referencias débiles/suaves).
*   `testRemovalListener_expired()`: Confirma que la causa es `EXPIRED` cuando una entrada es eliminada por haber superado su tiempo de vida.
*   `testRemovalListener_size()`: Asegura que la causa es `SIZE` cuando una entrada es desalojada porque el caché alcanzó su tamaño o peso máximo.

#### 4. Carga de Valores y Concurrencia
Estos métodos se centran en la funcionalidad de `CacheLoader` y el comportamiento del caché bajo condiciones de concurrencia.
*   `testCompute()`: Prueba la funcionalidad básica de `get(key, loader)`, asegurando que el `CacheLoader` solo se invoca una vez para una misma clave si el valor ya está en el caché.
*   `testLongAsyncRefresh()`: Un test complejo que prueba el refresco asíncrono de un valor, asegurando que el valor antiguo se sigue sirviendo mientras el nuevo se carga en segundo plano, incluso si el antiguo expira durante la carga.
*   `testCopyEntry_computing()`: Simula un escenario de alta concurrencia donde una entrada está siendo calculada por un hilo mientras otro hilo intenta interactuar con ella, probando la consistencia interna.
*   `testRecursiveLoad()`: Verifica que el caché detecta y lanza una excepción cuando un `CacheLoader` intenta cargar de forma recursiva la misma clave que ya está en proceso de carga, evitando bucles infinitos.

#### 5. Manejo de Referencias y Recolección de Basura
Estos métodos prueban la interacción del caché con el recolector de basura de Java.
*   `testDrainKeyReferenceQueueOnWrite()` y `testDrainValueReferenceQueueOnWrite()`: Verifican que cuando una clave o valor con referencia débil/suave es recolectado por el GC, la entrada correspondiente es eliminada del caché durante una operación de escritura posterior.
*   `testReclaimKey()` y `testReclaimValue()`: Prueban los métodos internos que se encargan de procesar las colas de referencias y eliminar las entradas "muertas" del caché.

#### 6. Suite de Pruebas de `ConcurrentMap`
*   `suite()`: Este método estático es fundamental, ya que utiliza `ConcurrentMapTestSuiteBuilder` para generar dinámicamente un conjunto masivo de pruebas que verifican que `LocalCache` cumple con todo el contrato de la interfaz `java.util.concurrent.ConcurrentMap`. Esto asegura que el caché se puede usar de forma segura como un mapa concurrente.