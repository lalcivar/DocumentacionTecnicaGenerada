/**
 * FuturesTest
 *
 * Propósito general
 * -----------------
 * Esta clase contiene el *suite* de pruebas unitarias para la utilidad
 * `com.google.common.util.concurrent.Futures` de la biblioteca Google Guava.
 * Valida la correcta operación –tanto en escenarios exitosos como de error,
 * cancelación e interrupción– de todas las primitivas de composición y manejo
 * de *ListenableFuture* que ofrece la clase Futures.
 *
 * El objetivo principal es garantizar que las implementaciones:
 *
 *  • Cumplan los contratos de la interfaz `Future` y de `ListenableFuture`.  
 *  • Propaguen o no propaguen cancelaciones cuando corresponde.  
 *  • Entreguen resultados memoizados y excepciones idempotentes.  
 *  • Conserven la semántica de los *executors* y conserven el *stack trace*.  
 *  • No introduzcan fugas de memoria ni *dead-locks* bajo alta concurrencia.  
 *
 * Organización de las pruebas
 * ---------------------------
 * Por legibilidad las pruebas se agrupan (implícitamente) en bloques temáticos:
 *
 * 1.  **Futuros inmediatos**  
 *     - `testImmediateFuture`, `testImmediateVoidFuture`,
 *       `testImmediateFailedFuture`, `testImmediateCancelledFuture*`
 *
 * 2.  **Transformaciones síncronas y asíncronas**  
 *     - `testTransform*`, `testTransformAsync*`, `testLazyTransform*`
 *
 * 3.  **Manejo de excepciones (catching / catchingAsync)**  
 *     - `testCatching*`, `testCatchingAsync*`
 *
 * 4.  **Envío y agendado de tareas (submit / submitAsync / scheduleAsync)**  
 *     - `testSubmit*`, `testScheduleAsync*`
 *
 * 5.  **Combinadores de colecciones de futuros**  
 *     - `testAllAsList*`, `testSuccessfulAsList*`,
 *       `testWhenAllComplete*`, `testWhenAllSucceed*`,
 *       `testInCompletionOrder*`
 *
 * 6.  **Decoradores y utilidades**  
 *     - `testNonCancellationPropagating*`
 *
 * 7.  **Pruebas extensivas de matrices de casos**  
 *     - `testAllAsList_extensive`, `testSuccessfulAsList_extensive`
 *
 * 8.  **Pruebas de integridad/GC y validación de *null-checks***  
 *     - `testInputGCedIfUnreferenced`, `testFutures_nullChecks`
 *
 * Métodos de prueba principales
 * -----------------------------
 * A continuación se listan los métodos más representativos, indicando la
 * funcionalidad de Futures que ejercitan:
 *
 *  • `testImmediateFuture` / `testImmediateVoidFuture`  
 *    Verifican que un futuro inmediato retorne el valor o `null`
 *    instantáneamente y su representación textual contenga el estado correcto.
 *
 *  • `testImmediateFailedFuture`  
 *    Asegura que las excepciones se encapsulen en `ExecutionException` y que
 *    `toString()` muestre *FAILURE*.
 *
 *  • `testTransform_genericsNull` / `testTransform_genericsHierarchy`  
 *    Comprueban la corrección del *bridge* de tipos genéricos y la invocación
 *    única de la función de transformación.
 *
 *  • `testTransformAsync_cancelPropagatesToInput` y relacionados  
 *    Evalúan la propagación (o no) de cancelación e interrupción en
 *    transformaciones asíncronas.
 *
 *  • `testCatching_inputRaisesException`  
 *    Garantiza que la función de *fallback* se invoque exactamente una vez y
 *    que el valor devuelto se propague.
 *
 *  • `testAllAsList_failure` / `testAllAsList_cancelled`  
 *    Comprueban que la colección compuesta falle o se cancele al ocurrir el
 *    primer error/cancelación en sus componentes.
 *
 *  • `testSuccessfulAsList_partialFailure`  
 *    Demuestra que los futuros fallidos se reemplazan por `null` y no afectan
 *    al resto del resultado.
 *
 *  • `testWhenAllComplete_asyncResult`  
 *    Valida que `whenAllComplete` invoque el *combiner* sólo después de que
 *    todos los futuros terminen –con éxito, error o cancelación– y que
 *    soporte funciones asíncronas.
 *
 *  • `testInCompletionOrder*`  
 *    Verifican que la utilidad devuelva la misma cantidad de futuros y que
 *    estos se completen estrictamente en el orden de finalización de los
 *    insumos, propagando correctamente valores, excepciones y cancelaciones.
 *
 *  • `testNonCancellationPropagating_*`  
 *    Aseguran que el futuro decorador refleje el resultado final sin reenviar
 *    la cancelación hacia la fuente.
 *
 * Clases de soporte internas
 * --------------------------
 *  • `SingleCallListener`: Runnable auxiliar que detecta invocaciones dobles.  
 *  • `FunctionSpy`, `AsyncFunctionSpy`: decoradores que contabilizan llamadas.  
 *  • `TestFutureBatch`: genera combinaciones exhaustivas de futuros para
 *    pruebas matriciales.  
 *  • Diversas clases *dummy* (`Foo`, `Bar`, etc.) y excepciones de prueba
 *    (`SomeError`, `SomeUncheckedException`, `MyException`) empleadas para
 *    verificar tipado y propagación de fallos.
 *
 * Cómo leer las pruebas
 * ---------------------
 * Cada método usa utilidades estáticas de Guava como `Futures.getDone`,
 * `MoreExecutors.directExecutor()`, verificaciones de Truth (`assertThat`) y
 * helpers de JUnit/Truth para lanzar y capturar excepciones.
 *
 * Al ejecutar el *suite* (por ejemplo con Maven, Gradle o Ant), cualquier
 * regresión en las primitivas de Futures será detectada a través de fallos en
 * estas pruebas.
 */

