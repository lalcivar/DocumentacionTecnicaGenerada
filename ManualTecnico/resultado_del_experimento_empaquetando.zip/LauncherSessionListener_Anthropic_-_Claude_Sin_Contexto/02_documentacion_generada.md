# Documentación técnica: `LauncherSessionListener`

## Información general

| Atributo | Valor |
|---|---|
| **Paquete** | `org.junit.platform.launcher` |
| **Tipo** | Interfaz pública (`public interface`) |
| **Disponible desde** | Versión 1.8 |
| **Estado de la API** | `@API(status = STABLE, since = "1.10")` |
| **Licencia** | Eclipse Public License v2.0 |

---

## Descripción general

`LauncherSessionListener` es una interfaz de *callback* (patrón Observador) que forma parte de la API del *Launcher* de la Plataforma JUnit. Su propósito es permitir que el código cliente sea **notificado del ciclo de vida de una `LauncherSession`**, es decir, cuando dicha sesión se abre y cuando se cierra.

Una `LauncherSession` representa el contexto global en el que se ejecutan uno o varios descubrimientos y ejecuciones de pruebas. Al poder interceptar su apertura y cierre, esta interfaz resulta especialmente útil para:

- Inicializar y liberar recursos costosos y compartidos por todas las pruebas de la sesión (contenedores, bases de datos embebidas, servidores HTTP, conexiones, etc.).
- Configurar infraestructura transversal: logging, métricas, trazas, variables de entorno o propiedades del sistema.
- Registrar tiempos globales de ejecución o generar informes agregados de la sesión completa.
- Realizar tareas de limpieza garantizadas al finalizar toda la ejecución.

### Mecanismos de registro

Una implementación de esta interfaz puede registrarse de dos formas:

1. **Programáticamente**, mediante `LauncherConfig.Builder#addLauncherSessionListeners`, pasando la configuración resultante a `LauncherFactory.openSession(LauncherConfig)`.
2. **Automáticamente**, a través del mecanismo `java.util.ServiceLoader` de Java, declarando la implementación en el archivo de servicio correspondiente (`META-INF/services/org.junit.platform.launcher.LauncherSessionListener`).

### Características de diseño

- **Métodos `default` vacíos**: todos los métodos declarados poseen una implementación por defecto sin comportamiento (*no-op*). Esto permite que las clases implementadoras sobrescriban únicamente los eventos que les interesan, sin necesidad de implementar la interfaz completa.
- **Invocación**: los métodos son llamados por el `Launcher` o por la `LauncherSession` creada a través de `LauncherFactory`. No deben invocarse manualmente desde el código de usuario.

---

## Constantes

### `NOOP`

```java
LauncherSessionListener NOOP = new LauncherSessionListener() {};
```

Instancia constante que proporciona una implementación **sin operación** (*no-op*) de la interfaz. Se trata de una clase anónima que hereda todas las implementaciones por defecto, por lo que no realiza ninguna acción ante los eventos de la sesión.

**Uso típico:** aplicar el patrón *Null Object* para evitar comprobaciones de nulidad cuando no se requiere ningún listener, o como valor por defecto en configuraciones y pruebas.

---

## Métodos principales

### `launcherSessionOpened(LauncherSession session)`

```java
default void launcherSessionOpened(LauncherSession session)
```

Se invoca inmediatamente **después de que una sesión del launcher ha sido abierta**, antes de que comience el descubrimiento o la ejecución de pruebas.

| Parámetro | Tipo | Descripción |
|---|---|---|
| `session` | `LauncherSession` | La sesión que ha sido abierta. Permite acceder al `Launcher` asociado a la sesión. |

**Implementación por defecto:** vacía (no realiza ninguna acción).

**Casos de uso habituales:** arranque de recursos compartidos, registro de la hora de inicio, configuración de propiedades globales.

---

### `launcherSessionClosed(LauncherSession session)`

```java
default void launcherSessionClosed(LauncherSession session)
```

Se invoca **después de que la sesión del launcher ha sido cerrada**, una vez finalizadas todas las ejecuciones de pruebas asociadas a ella.

| Parámetro | Tipo | Descripción |
|---|---|---|
| `session` | `LauncherSession` | La sesión que ha sido cerrada. |

**Implementación por defecto:** vacía (no realiza ninguna acción).

**Casos de uso habituales:** liberación de recursos, cierre de conexiones, volcado de informes o métricas agregadas.

---

## Ejemplo de uso

### Implementación de un listener

```java
package com.ejemplo.test;

import org.junit.platform.launcher.LauncherSession;
import org.junit.platform.launcher.LauncherSessionListener;

public class RecursosCompartidosListener implements LauncherSessionListener {

    private ServidorEmbebido servidor;

    @Override
    public void launcherSessionOpened(LauncherSession session) {
        servidor = new ServidorEmbebido();
        servidor.iniciar();
        System.setProperty("servidor.url", servidor.getUrl());
    }

    @Override
    public void launcherSessionClosed(LauncherSession session) {
        if (servidor != null) {
            servidor.detener();
        }
    }
}
```

### Registro mediante `ServiceLoader`

Archivo: `src/test/resources/META-INF/services/org.junit.platform.launcher.LauncherSessionListener`

```
com.ejemplo.test.RecursosCompartidosListener
```

### Registro programático

```java
LauncherConfig config = LauncherConfig.builder()
        .addLauncherSessionListeners(new RecursosCompartidosListener())
        .build();

try (LauncherSession session = LauncherFactory.openSession(config)) {
    Launcher launcher = session.getLauncher();
    // Descubrimiento y ejecución de pruebas...
}
```

---

## Consideraciones de implementación

- **Idempotencia y robustez**: una excepción lanzada desde un listener puede afectar a la ejecución global de la sesión; se recomienda capturar y gestionar los errores internamente.
- **Concurrencia**: la sesión puede ejecutar pruebas en paralelo, por lo que los recursos creados en `launcherSessionOpened` deben ser *thread-safe* si se comparten entre pruebas.
- **Orden de invocación**: cuando hay varios listeners registrados, el orden de notificación no está garantizado de forma estricta, por lo que no deben establecerse dependencias entre ellos.
- **Compatibilidad binaria**: al ser una interfaz con métodos `default`, JUnit puede añadir nuevos eventos en versiones futuras sin romper las implementaciones existentes.

---

## Clases y elementos relacionados

- `LauncherSession` — Representa la sesión cuyo ciclo de vida se notifica.
- `LauncherConfig.Builder#addLauncherSessionListeners` — Registro programático de listeners.
- `LauncherFactory` — Fábrica que crea el `Launcher` y abre las sesiones.
- `Launcher` — Componente que realiza el descubrimiento y la ejecución de pruebas.
- `TestExecutionListener` — Alternativa para escuchar eventos de ejecución individuales (no de sesión).