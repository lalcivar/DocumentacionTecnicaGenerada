# LocalCacheTest – Documentación Técnica

## 1. Resumen ejecutivo  
`LocalCacheTest` es la batería de pruebas de regresión y de caja‐blanca que valida el comportamiento interno de `com.google.common.cache.LocalCache` y sus clases auxiliares.  
La clase cubre exhaustivamente — mediante pruebas unitarias, de concurrencia y de serialización — toda la superficie pública y privada del motor de caché local de Guava, incluyendo políticas de expiración, recarga, referencia débil/suave, pesos y notificaciones de eliminación.

---

## 2. Especificación de constructores y métodos  

En la tabla siguiente se listan **todos** los miembros detectados en el archivo fuente.  
El nombre se muestra tal cual aparece en código; los parámetros están en el mismo orden que la declaración original.

| # | Miembro | @param (nombre:tipo)(¿req?) | @return | @throws | Visibilidad / static |
|---|---------|-----------------------------|---------|---------|----------------------|
| 1 | `LocalCacheTest()` | — | — | — | public constructor |
| 2 | `suite()` | — | `Test` – Suite JUnit auto-generada | — | public static |
| 3 | `setUp()` | — | void | Exception | protected |
| 4 | `tearDown()` | — | void | Exception | protected |
| 5 | `testDefaults()` | — | void | — | public |
| 6 | `testSetKeyEquivalence()` | — | void | — | public |
| 7 | `testSetValueEquivalence()` | — | void | — | public |
| 8 | `testSetConcurrencyLevel()` | — | void | — | public |
| 9 | `testSetInitialCapacity()` | — | void | — | public |
|10 | `testSetMaximumSize()` | — | void | — | public |
|11 | `testSetWeigher()` | — | void | — | public |
|12 | `testSetWeakKeys()` | — | void | — | public |
|13 | `testSetWeakValues()` | — | void | — | public |
|14 | `testSetSoftValues()` | — | void | — | public |
|15 | `testSetExpireAfterWrite()` | — | void | — | public |
|16 | `testSetExpireAfterAccess()` | — | void | — | public |
|17 | `testSetRefresh()` | — | void | — | public |
|18 | `testLongAsyncRefresh()` | — | void | Exception | public |
|19 | `testSetRemovalListener()` | — | void | — | public |
|20 | `testSetTicker()` | — | void | — | public |
|21 | `testEntryFactory()` | — | void | — | public |
|22 | `testCompute()` | — | void | ExecutionException | public |
|23 | `testRecordReadOnCompute()` | — | void | ExecutionException | public |
|24 | `testComputeExistingEntry()` | — | void | ExecutionException | public |
|25 | `testComputePartiallyCollectedKey()` | — | void | ExecutionException | public |
|26 | `testComputePartiallyCollectedValue()` | — | void | ExecutionException | public |
|27 | `testComputeExpiredEntry()` | — | void | ExecutionException | public |
|28 | `testValues()` | — | void | — | public |
|29 | `testCopyEntry_computing()` | — | void | — | public |
|30 | `testRemovalListenerCheckedException()` | — | void | — | public |
|31 | `testRemovalListener_replaced_computing()` | — | void | — | public |
|32 | `testSegmentRefresh_duplicate()` | — | void | — | public |
|33 | `testRemovalListener_explicit()` | — | void | — | public |
|34 | `testRemovalListener_replaced()` | — | void | — | public |
|35 | `testRemovalListener_collected()` | — | void | — | public |
|36 | `testRemovalListener_expired()` | — | void | — | public |
|37 | `testRemovalListener_size()` | — | void | — | public |
|38 | `testNewEntry()` | — | void | — | public |
|39 | `testCopyEntry()` | — | void | — | public |
|40 | `testSegmentGetAndContains()` | — | void | — | public |
|41 | `testSegmentReplaceValue()` | — | void | — | public |
|42 | `testSegmentReplace()` | — | void | — | public |
|43 | `testSegmentPut()` | — | void | — | public |
|44 | `testSegmentPutIfAbsent()` | — | void | — | public |
|45 | `testSegmentPut_expand()` | — | void | — | public |
|46 | `testSegmentPut_evict()` | — | void | — | public |
|47 | `testSegmentStoreComputedValue()` | — | void | — | public |
|48 | `testSegmentRemove()` | — | void | — | public |
|49 | `testSegmentRemoveValue()` | — | void | — | public |
|50 | `testExpand()` | — | void | — | public |
|51 | `testGetCausesExpansion()` | — | void | ExecutionException | public |
|52 | `testGetOrDefault()` | — | void | — | public |
|53 | `testPutCausesExpansion()` | — | void | — | public |
|54 | `testReclaimKey()` | — | void | — | public |
|55 | `testRemoveEntryFromChain()` | — | void | — | public |
|56 | `testExpand_cleanup()` | — | void | — | public |
|57 | `testClear()` | — | void | — | public |
|58 | `testClear_notification()` | — | void | — | public |
|59 | `testRemoveEntry()` | — | void | — | public |
|60 | `testReclaimValue()` | — | void | — | public |
|61 | `testRemoveComputingValue()` | — | void | — | public |
|62 | `testDrainRecencyQueueOnWrite()` | — | void | — | public |
|63 | `testDrainRecencyQueueOnRead()` | — | void | — | public |
|64 | `testRecordRead()` | — | void | — | public |
|65 | `testRecordReadOnGet()` | — | void | — | public |
|66 | `testRecordWrite()` | — | void | — | public |
|67 | `testExpireAfterWrite()` | — | void | — | public |
|68 | `testExpireAfterAccess()` | — | void | — | public |
|69 | `testEvictEntries()` | — | void | — | public |
|70 | `testDrainKeyReferenceQueueOnWrite()` | — | void | — | public |
|71 | `testDrainValueReferenceQueueOnWrite()` | — | void | — | public |
|72 | `testDrainKeyReferenceQueueOnRead()` | — | void | — | public |
|73 | `testDrainValueReferenceQueueOnRead()` | — | void | — | public |
|74 | `testNullParameters()` | — | void | — | public |
|75 | `testSerializationProxyLoading()` | — | void | — | public |
|76 | `testSerializationProxyManual()` | — | void | — | public |
|77 | `testLoadDifferentKeyInLoader()` | — | void | ExecutionException | public |
|78 | `testRecursiveLoad()` | — | void | InterruptedException | public |
|79 | `testRecursiveLoadWithProxy()` | — | void | InterruptedException | public |
|80 | `allEntryTypeMakers()` | — | `Iterable<CacheBuilder<Object,Object>>` | — | private static |
|81 | `allEvictingMakers()` | — | `Iterable<CacheBuilder<Object,Object>>` | — | static |
|82 | `allKeyValueStrengthMakers()` | — | `Iterable<CacheBuilder<Object,Object>>` | — | private static |
|83 | `makeLocalCache(CacheBuilder)` | builder:CacheBuilder – req | `LocalCache<K,V>` | — | private static |
|84 | `makeLocalCache(CacheBuilder,CacheLoader)` | builder:CacheBuilder – req<br>loader:CacheLoader – req | `LocalCache<K,V>` | — | private static |
|85 | `createCacheBuilder()` | — | `CacheBuilder<Object,Object>` | — | private static |
|86 | `popLoggedThrowable()` | — | `Throwable` | — | private |
|87 | `checkNothingLogged()` | — | void | — | private |
|88 | `checkLogged(Throwable)` | t:Throwable – req | void | — | private |
|89 | `checkConcurrencyLevel(int,int)` | concurrencyLevel:int – req<br>segmentCount:int – req | void | — | private static |
|90 | `checkInitialCapacity(int,int,int)` | concurrencyLevel:int – req<br>initialCapacity:int – req<br>segmentSize:int – req | void | — | private static |
|91 | `checkMaximumSize(int,int,long)` | concurrencyLevel:int – req<br>initialCapacity:int – req<br>maxSize:long – req | void | — | private static |
|92 | `checkStrength(LocalCache,Strength,Strength)` | map:LocalCache – req<br>keyStrength:Strength – req<br>valueStrength:Strength – req | void | — | private static |
|93 | `incrementCount(Segment)` | segment:Segment – req | void | — | private static |
|94 | `assertNotified(QueuingRemovalListener,K,V,RemovalCause)` | listener:QueuingRemovalListener – req<br>key:K – req<br>value:V – req<br>cause:RemovalCause – req | void | — | static |
|95 | `assertConnected(LocalCache,ReferenceEntry,ReferenceEntry)` | map:LocalCache – req<br>one:ReferenceEntry – req<br>two:ReferenceEntry – req | void | — | private static |
|96 | `checkAndDrainRecencyQueue(LocalCache,Segment,List)` | map:LocalCache – req<br>segment:Segment – req<br>reads:List – req | void | — | static |
|97 | `checkEvictionQueues(LocalCache,Segment,List,List)` | map:LocalCache – req<br>segment:Segment – req<br>readOrder:List – req<br>writeOrder:List – req | void | — | static |
|98 | `assertSameEntries(List,List)` | expectedEntries:List – req<br>actualEntries:List – req | void | — | private static |
|99 | `checkExpirationTimes(LocalCache)` | map:LocalCache – req | void | — | static |
|100| `countLiveEntries(LocalCache,long)` | map:LocalCache – req<br>now:long – req | int – entradas vivas | — | private static |
|101| `assertNotificationEnqueued(LocalCache,K,V)` | map:LocalCache – req<br>key:K – req<br>value:V – req | void | — | private static |
|102| `createDummyEntry(K,int,V,ReferenceEntry)` | key:K – opt<br>hash:int – req<br>value:V – opt<br>next:ReferenceEntry – opt | `DummyEntry<K,V>` | — | private static |
|103| *… métodos internos/clases anidadas (`DummyEntry`, `DummyValueReference`, `Serializable…`)* | — | — | — | — |

> Nota:  
> • Todos los “test*” siguen la convención JUnit 3 y no reciben parámetros.  
> • Los métodos privados auxiliares y los inner-classes se listan con fines de exhaustividad; sus detalles de implementación (colas, referencias, etc.) se mantienen inalterados respecto al código fuente.  
> • Ninguno de los métodos declara genéricamente `NullPointerException`; cualquier NPE se produce por contrato cuando se viola la precondición de no-nulos de Guava.

---

## 3. Ejemplo de uso

```java
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LocalCache;
import com.google.common.cache.CacheLoader;
import java.util.concurrent.ExecutionException;

public class LocalCacheExample {

  public static void main(String[] args) throws ExecutionException {
    // 1. Crear el builder con política de expiración y peso
    CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder()
        .expireAfterWrite(10, java.util.concurrent.TimeUnit.MINUTES)
        .maximumWeight(1000)
        .weigher((key, val) -> 1);   // peso constante

    // 2. Instanciar LocalCache mediante el helper del test
    LocalCache<String, String> cache =
        LocalCacheTest.makeLocalCache(builder, new CacheLoader<>() {
          @Override
          public String load(String key) {
            return "valor-para-" + key;
          }
        });

    // 3. Operar con la caché
    String v1 = cache.getOrLoad("foo");          // carga “foo”
    String v2 = cache.get("foo");                // hit
    System.out.println(v1.equals(v2));           // true
  }
}
```

Este fragmento demuestra cómo el propio `LocalCacheTest` reutiliza sus factories (`makeLocalCache`) para construir una instancia de `LocalCache` totalmente configurable, idéntica a la que la biblioteca Guava produciría a través de `CacheBuilder.build()`.

---

© 2023 – Adaptado y documentado por IA.