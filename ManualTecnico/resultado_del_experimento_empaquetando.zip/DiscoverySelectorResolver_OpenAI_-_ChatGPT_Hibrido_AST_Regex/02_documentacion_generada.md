# DiscoverySelectorResolver - Documentación Técnica

## 1. Resumen ejecutivo
`DiscoverySelectorResolver` es una clase utilitaria interna del motor de suites de JUnit Platform. Su responsabilidad principal es transformar los selectores (e.g. `@Suite`, `@SelectClasses`) incluidos en un `EngineDiscoveryRequest` en un conjunto jerárquico de descriptores de prueba (`SuiteEngineDescriptor`) y ejecutar el ciclo de descubrimiento correspondiente.  
Tras la resolución, la clase también depura los descriptores y notifica cualquier incidencia encontrada durante el proceso de descubrimiento.

## 2. Especificación de métodos y constructores

### Métodos

#### discoverSuites(SuiteEngineDescriptor engineDescriptor)
| Visibilidad | `static` | Descripción breve |
|-------------|----------|-------------------|
| `private`   | ✅       | Ejecuta el proceso de descubrimiento específico de cada `SuiteTestDescriptor` hijo del `engineDescriptor` recibido. |

@param / @return / @throws  
| @param | Tipo | Obligatorio | Descripción |
|--------|------|------------|-------------|
| engineDescriptor | `SuiteEngineDescriptor` | Sí | Descriptor raíz que contendrá uno o varios `SuiteTestDescriptor` a descubrir. |

| @return | Tipo | Descripción |
|---------|------|-------------|
| —       | `void` | El método no devuelve valor. |

| @throws | Condición | Descripción |
|---------|-----------|-------------|
| — | — | Este método no propaga excepciones comprobadas. Errores en fase de descubrimiento se registran mediante `DiscoveryIssueReporter`. |

---

#### resolveSelectors(EngineDiscoveryRequest request, SuiteEngineDescriptor engineDescriptor)
| Visibilidad | `static` | Descripción breve |
|-------------|----------|-------------------|
| `package-private` | ❌ | Punto de entrada principal: resuelve los selectores del `request`, delega en el `resolver` interno, ejecuta descubrimiento de suites y realiza la poda de descriptores vacíos. |

@param / @return / @throws  
| @param | Tipo | Obligatorio | Descripción |
|--------|------|------------|-------------|
| request | `EngineDiscoveryRequest` | Sí | Solicitud de descubrimiento que contiene selectores, filtros y parámetros de configuración. |
| engineDescriptor | `SuiteEngineDescriptor` | Sí | Descriptor raíz donde se añadirán los nodos resultantes. |

| @return | Tipo | Descripción |
|---------|------|-------------|
| —       | `void` | El método no devuelve valor. |

| @throws | Condición | Descripción |
|---------|-----------|-------------|
| — | — | El método no declara excepciones. Cualquier problema se canaliza a través de `DiscoveryIssueReporter`. |

---

### Campos relevantes

| Campo | Tipo | Visibilidad | Descripción |
|-------|------|-------------|-------------|
| `resolver` | `EngineDiscoveryRequestResolver<SuiteEngineDescriptor>` | `private static final` | Estrategia compuesta encargada de procesar las diferentes clases de selectores (`ClassContainerSelector`, `ClassSelector`, etc.). |

## 3. Ejemplo de uso

```java
package org.junit.platform.suite.engine;

import org.junit.platform.engine.EngineDiscoveryRequest;
import org.junit.platform.engine.support.descriptor.EngineDescriptor;

class SuiteEngineInitializer {

    void bootstrap(EngineDiscoveryRequest request) {
        // Se crea el descriptor raíz que contendrá la jerarquía de la suite.
        SuiteEngineDescriptor rootDescriptor = new SuiteEngineDescriptor(
                EngineDescriptor.ROOT.getUniqueId(), "JUnit-Suite");

        // Se instancia el resolver (constructor implícito por defecto).
        DiscoverySelectorResolver selectorResolver = new DiscoverySelectorResolver();

        // Se resuelven y descubren los selectores presentes en el request.
        selectorResolver.resolveSelectors(request, rootDescriptor);

        // En este punto, rootDescriptor contiene la estructura final de pruebas
        // lista para su ejecución por el engine correspondiente.
    }
}
```

Autor: Equipo de desarrollo de JUnit Platform (2015-2026) – Documentación generada por IA.