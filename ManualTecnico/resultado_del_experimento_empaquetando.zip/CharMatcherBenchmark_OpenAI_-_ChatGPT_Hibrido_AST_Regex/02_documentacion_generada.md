# Documentación técnica – `CharMatcherBenchmark`

## 1. Resumen ejecutivo  
`CharMatcherBenchmark` es un micro-benchmark (Caliper) concebido para medir el rendimiento de diferentes variantes de `CharMatcher` de Guava al procesar cadenas con distribuciones de caracteres configurables.  
La clase permite comparar operaciones de recorte y colapso (`trimAndCollapseFrom`) y comprobación de coincidencia de caracteres individuales (`matches`) en múltiples tamaños y densidades de datos, pudiendo además forzar casos límite (matcher pequeño, pre-cómputo, primer carácter coincidente, etc.).

---

## 2. Especificación de constructores y métodos  

### 2.1 Clase `CharMatcherBenchmark`

| Constructores / Métodos | Visibilidad | Descripción breve |
|-------------------------|-------------|-------------------|
| `CharMatcherBenchmark()` | `public` | Crea una instancia para su uso por Caliper. |
| `setUp()` | *package-private* | Inicializa el `CharMatcher` y la cadena de prueba con los parámetros inyectados por Caliper. |
| `trimAndCollapseFromString(int reps)` | `public` | Ejecuta la operación `trimAndCollapseFrom` en bucle para medir su rendimiento. |
| `matches(int reps)` | `public` | Mide el rendimiento de la comprobación `matches` sobre caracteres individuales. |
| `checkString(int length, int percent, String matchingChars, Random rand, boolean forceSlow, boolean web)` | `private static` | Construye la cadena de prueba asegurando un porcentaje de coincidencias determinado. |
| `randomCharFrom(String s, Random rand)` | `private static` | Devuelve un carácter aleatorio de una cadena. |

#### Detalle de parámetros, retornos y excepciones

##### `CharMatcherBenchmark()`

No recibe parámetros explícitos; Caliper inyecta los campos `@Param` tras la construcción.  

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| – | – | – | – |

| @return | `CharMatcherBenchmark` |
|---------|------------------------|
| Instancia inicializada sin estado significativo. |

| @throws |
|---------|
| No lanza excepciones declaradas. |

---

##### `setUp()`

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| – | – | – | No recibe parámetros; usa campos `@Param`. |

| @return | `void` |
|---------|--------|
| – |

| @throws |
|---------|
| No lanza excepciones declaradas. |

---

##### `trimAndCollapseFromString(int reps)`

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `reps` | `int` | Sí | Número de repeticiones de la prueba. |

| @return | `int` |
|---------|-------|
| Acumulado de las longitudes resultantes de la operación, utilizado para evitar la eliminación por el compilador JIT. |

| @throws |
|---------|
| No lanza excepciones declaradas. |

---

##### `matches(int reps)`

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `reps` | `int` | Sí | Número de repeticiones de la prueba. |

| @return | `int` |
|---------|-------|
| Conteo de coincidencias encontrado durante la prueba. |

| @throws |
|---------|
| No lanza excepciones declaradas. |

---

##### `checkString(int length, int percent, String matchingChars, Random rand, boolean forceSlow, boolean web)`

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `length` | `int` | Sí | Longitud de la cadena a generar. |
| `percent` | `int` | Sí | Porcentaje de caracteres que deben coincidir con el `CharMatcher`. |
| `matchingChars` | `String` | Sí | Conjunto de caracteres considerados coincidentes. |
| `rand` | `Random` | Sí | Fuente de aleatoriedad. |
| `forceSlow` | `boolean` | Sí | Si es `true`, se asegura que el primer carácter coincida. |
| `web` | `boolean` | Sí | Si es `true`, genera la cadena usando la distribución web de `CharSamples`. |

| @return | `String` |
|---------|----------|
| Cadena construida según los criterios indicados. |

| @throws |
|---------|
| No lanza excepciones declaradas. |

---

##### `randomCharFrom(String s, Random rand)`

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `s` | `String` | Sí | Cadena base de la cual elegir. |
| `rand` | `Random` | Sí | Fuente de aleatoriedad. |

| @return | `char` |
|---------|--------|
| Carácter seleccionado aleatoriamente de `s`. |

| @throws |
|---------|
| No lanza excepciones declaradas. |

---

### 2.2 Clase interna `CharSamples`

| Constructores / Métodos | Visibilidad | Descripción breve |
|-------------------------|-------------|-------------------|
| `CharSamples(Random random)` | `public` | Instancia un generador de puntos de código según una distribución web. |
| `nextCodePoint()` | `public` | Devuelve el siguiente punto de código conforme a la distribución. |
| `populateProb1()` | `private static` | Carga la primera mitad del array de probabilidades. |
| `populateProb2()` | `private static` | Completa la carga del array de probabilidades. |
| `populateChars1()` | `private static` | Carga la primera mitad del array de puntos de código. |
| `populateChars2()` | `private static` | Completa la carga del array de puntos de código. |

#### Detalle de métodos principales

##### `CharSamples(Random random)`

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `random` | `Random` | Sí | Fuente de aleatoriedad usada por la instancia. |

| @return | `CharSamples` |
|---------|---------------|
| Instancia preparada para generar puntos de código. |

| @throws |
|---------|
| No lanza excepciones declaradas. |

---

##### `nextCodePoint()`

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| – | – | – | No recibe parámetros. |

| @return | `int` |
|---------|-------|
| Punto de código Unicode seleccionado según la distribución cargada. |

| @throws |
|---------|
| No lanza excepciones declaradas, pero puede lanzar `ArrayIndexOutOfBoundsException` si los arrays se corrompen (no ocurre en uso normal). |

---

##### Métodos `populateProb1()`, `populateProb2()`, `populateChars1()`, `populateChars2()`

Todos son `private static void`, sin parámetros ni valores de retorno y sin excepciones declaradas.  
Se ejecutan una sola vez dentro del *static initializer* para poblar las tablas de probabilidades y caracteres.

---

## 3. Ejemplo de uso

```java
import com.google.common.base.CharMatcher;
import com.google.common.base.CharMatcherBenchmark;

public class BenchmarkRunner {

  public static void main(String[] args) {
    // Ejecución manual (fuera de Caliper) – solo a modo demostrativo.
    CharMatcherBenchmark bench = new CharMatcherBenchmark();

    // Normalmente Caliper llamaría a setUp() tras inyectar @Param;
    // para la demo se invoca directamente.
    bench.setUp();

    int reps = 1_000;          // Número de repeticiones
    int len1 = bench.trimAndCollapseFromString(reps);
    int hits = bench.matches(reps);

    System.out.println("Total trim length: " + len1);
    System.out.println("Total matches: " + hits);
  }
}
```

> Nota: en un escenario real se compilaría y ejecutaría el benchmark mediante Caliper (`caliper runner ...`) para obtener métricas comparables; el fragmento anterior solo ilustra la interacción básica con los métodos públicos.