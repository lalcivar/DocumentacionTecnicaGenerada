# NúmeroParameterResolver – Documentación Técnica

## 1. Resumen ejecutivo  
`NumberParameterResolver` es una implementación de `org.junit.jupiter.api.extension.ParameterResolver` que declara soporte para cualquier parámetro cuyo tipo sea `java.lang.Number` (o subclases) y siempre inyecta el valor constante `Integer` `42`. Su finalidad principal es ejemplificar escenarios en los que el *resolver* anuncia compatibilidad con un tipo amplio, aunque entregue un objeto de tipo más concreto.

---

## 2. Especificación de constructores y métodos  

### 2.1 NumberParameterResolver()  
Constructor por defecto. No realiza inicialización adicional.

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| — | — | — | — |

| @return | Tipo | Descripción |
|---------|------|-------------|
| — | — | — |

| @throws | Condición | Descripción |
|---------|-----------|-------------|
| — | — | — |

@author JUnit Jupiter Team


### 2.2 supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext)

Determina si este *resolver* puede manejar el parámetro solicitado. Devuelve `true` cuando el tipo del parámetro es asignable desde `Number`.

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| parameterContext | ParameterContext | Sí | Metadatos del parámetro a resolver. |
| extensionContext | ExtensionContext | Sí | Contexto actual de la extensión. |

| @return | Tipo | Descripción |
|---------|------|-------------|
| boolean | `boolean` | `true` si el tipo del parámetro extiende `Number`; en otro caso, `false`. |

| @throws | Condición | Descripción |
|---------|-----------|-------------|
| — | — | Este método no lanza excepciones declaradas. |

@author JUnit Jupiter Team


### 2.3 resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext)

Resuelve e inyecta el valor del parámetro. Siempre retorna el `Integer` `42`, independientemente del tipo concreto solicitado.

| @param | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| parameterContext | ParameterContext | Sí | Metadatos del parámetro a resolver. |
| extensionContext | ExtensionContext | Sí | Contexto actual de la extensión. |

| @return | Tipo | Descripción |
|---------|------|-------------|
| Object | `Integer` | Valor constante `42` que se inyectará en el parámetro. |

| @throws | Condición | Descripción |
|---------|-----------|-------------|
| — | — | Este método no lanza excepciones declaradas. |

@author JUnit Jupiter Team

---

## 3. Ejemplo de uso

```java
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.engine.execution.injection.sample.NumberParameterResolver;

@ExtendWith(NumberParameterResolver.class)
class CalculadoraTest {

    @Test
    @DisplayName("La constante 42 se inyecta correctamente")
    void pruebaInyeccion(Number numero) {
        // número será un Integer con valor 42
        assert numero.intValue() == 42;
    }
}
```

En el ejemplo, el método de prueba `pruebaInyeccion` declara un parámetro de tipo `Number`. Gracias a `@ExtendWith(NumberParameterResolver.class)`, JUnit invoca internamente:

1. `supportsParameter(...)`, que devuelve `true`.
2. `resolveParameter(...)`, que retorna el valor `42`.

El parámetro `numero` recibe dicho valor sin necesidad de inicialización manual.