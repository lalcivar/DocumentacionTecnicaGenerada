───────────────────────────────────────────────────────────────  
CharMatcherBenchmark – Documentación Técnica  
───────────────────────────────────────────────────────────────  

1. Propósito general  
   CharMatcherBenchmark es un micro-benchmark basado en Google Caliper cuyo objetivo es medir el rendimiento de diferentes implementaciones de com.google.common.base.CharMatcher (Guava) para dos patrones de uso típicos:  
   • trimAndCollapseFrom(…) sobre cadenas.  
   • matches(…) sobre caracteres individuales.  

   El benchmark reproduce múltiples escenarios variando, entre otros, el tamaño de la cadena de entrada, el porcentaje de caracteres que coinciden con el matcher y la técnica interna que emplea CharMatcher (versión normal, pre-computada o SmallCharMatcher).

2. Integración con Caliper  
   • La clase está anotada con @NullUnmarked y no necesita un constructor explícito.  
   • Caliper detecta automáticamente los métodos anotados con @Benchmark y los que comienzan por “time…”.  
   • Los campos anotados con @Param se inicializan por reflexión antes de cada experimento; luego se invoca @BeforeExperiment → setUp().  

3. Parámetros de ejecución (@Param)  
   • SampleMatcherConfig config – Matriz de configuraciones pre-definidas (matcher, caracteres que deben hacer match, etc.)  
   • int length – Longitud de la cadena a generar (64 o 1024).  
   • int percent – Porcentaje de la cadena que debe coincidir con el matcher (0, 10, 50, 100).  
   • boolean precomputed – Si es true se usa matcher.precomputed().  
   • Size size – Enum (DEFAULT | SMALL). SMALL fuerza el uso de SmallCharMatcher.  
   • boolean forceSlow – Si es true garantiza que el primer carácter coincida para forzar la ruta lenta de trimAndCollapseFrom().  
   • boolean web – Si es true genera la cadena de prueba a partir de distribución de texto web real usando CharSamples (verte apartado 6).  

4. Flujo de trabajo por experimento  
   1. Caliper inyecta los parámetros.  
   2. setUp()  
      2.1 Se selecciona el CharMatcher adecuado (pre-computado, SmallCharMatcher, etc.).  
      2.2 Se genera la cadena de prueba mediante checkString(…).  
   3. Ejecución de los métodos @Benchmark:  
      • trimAndCollapseFromString(int reps)  
      • matches(int reps)  
   4. Caliper recoge el valor devuelto (dummy) para impedir optimizaciones JIT y calcula las métricas de tiempo.  

5. Métodos principales  

   5.1 setUp()  
       Configura el estado del experimento:  
       – Decide si usar matcher.precomputed() o la instancia original.  
       – Crea SmallCharMatcher si size == SMALL.  
       – Construye la cadena de prueba invocando checkString(…).  

   5.2 @Benchmark int trimAndCollapseFromString(int reps)  
       • Bucle de reps iteraciones.  
       • En cada vuelta llama a matcher.trimAndCollapseFrom(string,'!') y acumula la longitud del resultado en el entero dummy.  
       • Mide el coste total de la operación sobre Strings.  

   5.3 @Benchmark int matches(int reps)  
       • Bucle de reps iteraciones.  
       • Para cada iteración verifica matcher.matches(char) sobre posiciones rotatorias de la cadena.  
       • Evalúa el coste mínimo de comprobación de un solo carácter.  

   5.4 checkString(int length, int percent, String matchingChars, Random r, boolean forceSlow, boolean web)  
       Genera la cadena de prueba respetando los parámetros solicitados:  
       – Modo ‘web’: usa CharSamples (ver 6) para repartir código Unicode según frecuencias reales.  
       – Modo ‘sintético’: baraja posiciones para asegurarse de que justo ‘percent’ % sean caracteres de matchingChars.  
       – forceSlow permite colocar un carácter coincidente al principio.  

   5.5 randomCharFrom(String s, Random r)  
       Devuelve un carácter aleatorio de la cadena s.  

6. Clase anidada estática CharSamples  
   Objetivo: suministrar caracteres con una distribución estadística obtenida de contenido web (lista cortesía de Mark Davis).  
   • Se compone de cuatro grandes arreglos estáticos:  
     – prob[]  (mapa acumulativo de probabilidades)  
     – chars[] (lista de code-points Unicode ordenados por frecuencia)  
   • nextCodePoint() implementa una búsqueda binaria sobre prob[] para transformar un valor aleatorio (needle) en un code-point según la distribución.  
   • populateProb1/2, populateChars1/2 inicializan las tablas en un bloque static.  

7. Estructuras auxiliares  
   – NONMATCHING_CHARS – Conjunto de caracteres seguros que no deben coincidir.  
   – enum Size – Conmutador para activar SmallCharMatcher.  

8. Extensibilidad / puntos de modificación  
   • Añadir más tamaños de cadenas o porcentajes basta con incluir nuevos valores en @Param.  
   • Para comparar nuevos tipos de CharMatcher se amplía SampleMatcherConfig.  
   • Para patrones de texto diferentes se puede sustituir CharSamples o proveer un nuevo generador dentro de checkString().  

9. Dependencias  
   – Google Caliper (org.openjdk.caliper.*).  
   – Guava (com.google.common.base.*).  
   – jspecify annotations (org.jspecify.*).  

10. Consideraciones de rendimiento  
   – El entero dummy evita que el compilador elimine el trabajo útil.  
   – Todos los arreglos gigantes (prob, chars) se inicializan una sola vez en bloques static; no impactan en las medidas de tiempo de los benchmarks.  
   – La generación de Strings ocurre solo en setUp(), fuera del perímetro cronometrado.  

Con esta documentación el desarrollador puede entender la finalidad del benchmark, saber qué dimensiones de prueba existen, cómo se generan los datos y qué método mide cada métrica.