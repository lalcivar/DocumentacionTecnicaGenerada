# Documentación Técnica - `com.google.common.cache.LocalCache`

> **Paquete:** `com.google.common.cache`
> **Clase:** `final class LocalCache<K, V> extends AbstractMap<K, V> implements ConcurrentMap<K, V>`
> **Autores:** `@author Charles Fry`, `@author Bob Lee`, `@author Doug Lea`
> **Anotaciones:** `@GwtCompatible`, `@NullUnmarked`, `@SuppressWarnings({"GoodTime", "nullness"})`

---

### 1. Resumen Ejecutivo

`LocalCache` es la implementación concurrente de tabla hash segmentada construida por `CacheBuilder`, derivada de `ConcurrentHashMap` (rev. 1.96). Gestiona el almacenamiento, expiración, evicción por peso/tamaño, referencias débiles/suaves y carga asíncrona mediante una arquitectura de `Segment` bloqueados con `ReentrantLock`, colas de acceso/escritura para políticas LRU y contadores de estadísticas.

Proporciona operaciones no bloqueantes para lectura y escrituras concurrentes por segmento, con soporte para `Ticker`, `Weigher`, `RemovalListener`, `CacheLoader` y recolección de referencias vía `ReferenceQueue`. Es una clase de uso interno (`package-private`) instanciada exclusivamente a través de `CacheBuilder` y expuesta vía `LocalManualCache` y `LocalLoadingCache`.

---

### 2. Especificación de Métodos y Constructores

#### 2.1 Clase Principal `LocalCache<K,V>`

##### 2.1.1 Constructor

###### `LocalCache()`
```java
LocalCache(CacheBuilder<? super K, ? super V> builder, @Nullable CacheLoader<? super K, V> loader)
```

| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `builder` | `CacheBuilder<? super K, ? super V>` | Sí | Configuración de concurrencia, expiración, peso, fuerza de referencia y listeners. |
| `loader` | `CacheLoader<? super K, V>` | No | Loader por defecto para operaciones de carga. `null` para caché manual. |

| @return | Descripción |
| :--- | :--- |
| `LocalCache` | Nueva instancia inicializada con segmentos, colas y contadores. |

| @throws | Condición |
| :--- | :--- |
| `NullPointerException` | Si `builder` es nulo. |

---

##### 2.1.2 Métodos de Configuración y Estado

| Método | Descripción | @return |
| :--- | :--- | :--- |
| `evictsBySize()` | Verifica si `maxWeight >= 0`. | `boolean` - `true` si hay límite de peso/tamaño. |
| `customWeigher()` | Verifica si `weigher != OneWeigher.INSTANCE`. | `boolean` |
| `expires()` | `expiresAfterWrite() \|\| expiresAfterAccess()`. | `boolean` |
| `expiresAfterWrite()` | `expireAfterWriteNanos > 0`. | `boolean` |
| `expiresAfterAccess()` | `expireAfterAccessNanos > 0`. | `boolean` |
| `refreshes()` | `refreshNanos > 0`. | `boolean` |
| `usesAccessQueue()` | `expiresAfterAccess() \|\| evictsBySize()`. | `boolean` |
| `usesWriteQueue()` | `expiresAfterWrite()`. | `boolean` |
| `recordsWrite()` | `expiresAfterWrite() \|\| refreshes()`. | `boolean` |
| `recordsAccess()` | `expiresAfterAccess()`. | `boolean` |
| `recordsTime()` | `recordsWrite() \|\| recordsAccess()`. | `boolean` |
| `usesWriteEntries()` | `usesWriteQueue() \|\| recordsWrite()`. | `boolean` |
| `usesAccessEntries()` | `usesAccessQueue() \|\| recordsAccess()`. | `boolean` |
| `usesKeyReferences()` | `keyStrength != STRONG`. | `boolean` |
| `usesValueReferences()` | `valueStrength != STRONG`. | `boolean` |

Todos sin `@param` ni `@throws`.

##### 2.1.3 Métodos Utilitarios Estáticos y de Hash

###### `rehash()`
| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `h` | `int` | Sí | Hash code original. |
| @return | `int` - Hash suplementario dispersado (variante Wang/Jenkins). |

###### `hash()`
| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `key` | `@Nullable Object` | No | Clave a hashear vía `keyEquivalence`. |
| @return | `int` - `rehash(keyEquivalence.hash(key))` |

###### `segmentFor()`
| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `hash` | `int` | Sí | Hash de la clave. |
| @return | `Segment<K,V>` - Segmento correspondiente `(hash >>> segmentShift) & segmentMask`. |

###### `createSegment()`
| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `initialCapacity` | `int` | Sí | Capacidad inicial del segmento. |
| `maxSegmentWeight` | `long` | Sí | Peso máximo por segmento (`UNSET_INT` si no hay límite). |
| `statsCounter` | `StatsCounter` | Sí | Contador de estadísticas. |
| @return | `Segment<K,V>` | | |

###### `newSegmentArray()`
| @param | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ssize` | `int` | Sí | Número de segmentos. |
| @return | `Segment<K,V>[]` | | |

##### 2.1.4 Métodos de Ciclo de Vida de Entradas

| Método | @param | @return | @throws |
| :--- | :--- | :--- | :--- |
| `newEntry(K key, int hash, ReferenceEntry<K,V> next)` | `key`, `hash`, `next` | `ReferenceEntry<K,V>` creada vía `segment.newEntry` bajo lock | - |
| `copyEntry(ReferenceEntry<K,V> original, ReferenceEntry<K,V> newNext)` | `original`, `newNext` | Copia de entrada o `null` si GC | - |
| `newValueReference(ReferenceEntry<K,V> entry, V value, int weight)` | `entry`, `value` (NotNull), `weight` | `Value