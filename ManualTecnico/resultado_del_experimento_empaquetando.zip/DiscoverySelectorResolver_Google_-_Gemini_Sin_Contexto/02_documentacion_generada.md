Claro, aquí tienes la documentación técnica para la clase `DiscoverySelectorResolver` en Java.

---

### **Documentación Técnica: Clase `DiscoverySelectorResolver`**

#### **Descripción General**

La clase `DiscoverySelectorResolver` es un componente interno y final del motor de suites de JUnit Platform (`junit-platform-suite-engine`). Su propósito principal es orquestar el proceso de descubrimiento de tests (test discovery) para las suites de JUnit.

Esta clase no es parte de la API pública y su visibilidad de paquete (`package-private`) refuerza su rol como una clase de ayuda interna.

Su función es procesar un `EngineDiscoveryRequest` (una solicitud para descubrir tests) y resolver los `DiscoverySelectors` (criterios de búsqueda, como nombres de clase o paquetes) para identificar qué clases son suites de tests. Una vez identificadas, inicia un segundo proceso de descubrimiento para encontrar los tests contenidos *dentro* de cada suite.

En resumen, `DiscoverySelectorResolver` actúa como el cerebro que traduce una solicitud de "encuentra tests" en un árbol de descriptores de tests (`TestDescriptor`) poblado, comenzando por las clases de suite.

#### **Análisis de Componentes Clave**

La lógica principal de la clase se concentra en un campo estático `resolver` y su método principal `resolveSelectors`.

*   **Campo `resolver`**:
    *   Es una instancia estática y pre-configurada de `EngineDiscoveryRequestResolver`. Este objeto está especializado para trabajar con el `SuiteEngineDescriptor` (el nodo raíz del árbol de tests para el motor de suites).
    *   Está configurado para manejar dos tipos de selectores:
        1.  **Selectores de Contenedor de Clases**: Utiliza `IsSuiteClass` para determinar si una clase es una suite de tests (por ejemplo, si está anotada con `@Suite`). Esto permite descubrir suites cuando se escanea un paquete o un classpath.
        2.  **Selectores de Clase**: Utiliza `ClassSelectorResolver` para manejar la selección directa de una clase. Esto permite que un usuario ejecute una suite especificando su nombre de clase directamente.

#### **Métodos Principales**

La clase tiene un método público (a nivel de paquete) principal y un método de ayuda privado.

##### **`void resolveSelectors(EngineDiscoveryRequest request, SuiteEngineDescriptor engineDescriptor)`**

Este es el método de entrada y el orquestador principal de la clase. Ejecuta el proceso de descubrimiento en tres pasos:

1.  **Resolución de Selectores**:
    *   Invoca al `resolver` estático para procesar los selectores definidos en el `EngineDiscoveryRequest`.
    *   El `resolver` identifica las clases que son suites de tests y las añade como nodos hijos (`SuiteTestDescriptor`) al `engineDescriptor` (el descriptor raíz del motor).
    *   Durante este paso, se utiliza un `DiscoveryIssueReporter` para notificar cualquier problema encontrado, como clases que no se pueden cargar o que no son suites válidas.

2.  **Descubrimiento Recursivo de Suites**:
    *   Llama al método privado `discoverSuites(engineDescriptor)`. Este método itera sobre los descriptores de suite recién creados y delega a cada uno la responsabilidad de descubrir sus propios tests internos. Esto permite que las suites anidadas funcionen correctamente.

3.  **Poda del Árbol de Tests (Pruning)**:
    *   Finalmente, invoca `engineDescriptor.accept(TestDescriptor::prune)`. Este paso recorre el árbol de tests completo y elimina cualquier rama que no contenga tests ejecutables. Por ejemplo, si se descubre una suite que resulta estar vacía, se elimina del plan de ejecución para evitar nodos innecesarios.

##### **`private static void discoverSuites(SuiteEngineDescriptor engineDescriptor)`**

Este es un método de ayuda estático y privado que se encarga de la segunda fase del descubrimiento.

*   **Propósito**: Recorrer los hijos directos del `engineDescriptor`, que en este punto son `SuiteTestDescriptor`.
*   **Acción**: Para cada `SuiteTestDescriptor`, invoca su método `discover()`. Esto desencadena el proceso de descubrimiento de los tests que están definidos *dentro* de esa suite en particular, poblando así el siguiente nivel del árbol de tests.