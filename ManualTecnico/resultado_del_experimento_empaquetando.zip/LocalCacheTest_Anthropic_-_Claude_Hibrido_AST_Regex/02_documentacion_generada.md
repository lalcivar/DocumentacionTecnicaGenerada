# Documentación Técnica: `com.google.common.cache.LocalCacheTest`

---

## 1. Resumen ejecutivo

`LocalCacheTest` es la suite de pruebas unitarias de caja blanca (*white-box*) de la implementación interna `LocalCache` de Guava Cache. Verifica directamente el estado interno del mapa concurrente segmentado (segmentos, tablas `AtomicReferenceArray`, colas de acceso/escritura/recencia, fuerzas de referencia, factorías de entradas, notificaciones de remoción, expiración, refresco y serialización), por lo que accede a campos y métodos de visibilidad de paquete que no forman parte de la API pública.

Además de los casos de prueba JUnit 3 (`junit.framework.TestCase`), la clase expone una `suite()` que compone múltiples configuraciones de `CacheBuilder` contra los *test suite builders* de `ConcurrentMapTestSuiteBuilder`, y define un conjunto de dobles de prueba internos (`DummyEntry`, `DummyValueReference`, `Serializable*`) usados para simular entradas parcialmente recolect