# Documentación Técnica del Módulo (Google Style / PEP 257)

## 1. Resumen ejecutivo  
El módulo define los objetos fundamentales (`Request`, `PreparedRequest`, `Response`) que permiten construir, serializar y transportar solicitudes HTTP así como representar la respuesta del servidor, reproduciendo la semántica de alto nivel de la librería *requests*.  
Adicionalmente incorpora *mixins* de utilidades para codificación de cuerpos (`RequestEncodingMixin`) y gestión de *hooks* de usuario (`RequestHooksMixin`), además de toda la lógica necesaria para procesar cabeceras, redirecciones, cookies y decodificación de contenido.

---

## 2. Especificación detallada de funciones y métodos  

En todas las tablas “Req.” indica si el argumento es obligatorio (`Sí`) u opcional (`No`).  
Los métodos de instancia omiten el parámetro `self` por claridad.

### RequestEncodingMixin

| Función / Método | Descripción breve |
|------------------|-------------------|
| `path_url()` | Construye la porción *path + query* de la URL asociada. |
| `_encode_params(data)` | Codifica parámetros URL o de formulario preservando el orden cuando la entrada es lista de pares. |
| `_encode_files(files, data)` | Genera cuerpo y cabecera `Content-Type` para envíos `multipart/form-data`. |

#### path_url()

| Parámetro | Tipo | Req. |
|-----------|------|------|
| *—* | *—* | — |

| Devuelve | Tipo |
|----------|------|
| Ruta y “query string” concatenados | `str` |

| Excepciones | Condición |
|-------------|-----------|
| — | — |

---

#### _encode_params(data)

| Parámetro | Tipo(s) aceptado(s) | Req. |
|-----------|--------------------|------|
| `data` | `str`, `bytes`, `SupportsRead`, `Mapping`, `Iterable[Tuple]` | Sí |

| Devuelve | Tipo |
|----------|------|
| Datos codificados o sin transformar según entrada | `str`, `bytes` o `SupportsRead` |

| Excepciones | Condición |
|-------------|-----------|
| — | Ninguna explícita |

---

#### _encode_files(files, data)

| Parámetro | Tipo | Req. |
|-----------|------|------|
| `files` | `_t.FilesType` | Sí |
| `data` | `_t.RawDataType \| None` | No |

| Devuelve | Tipo |
|----------|------|
| Cuerpo codificado y valor de cabecera `Content-Type` | `tuple[bytes, str]` |

| Excepciones | Condición |
|-------------|-----------|
| `ValueError` | `files` vacío o `data` es cadena. |

---

### RequestHooksMixin

| Método | Descripción |
|--------|-------------|
| `register_hook(event, hook)` | Registra uno o varios *hooks* de usuario para un evento. |
| `deregister_hook(event, hook)` | Elimina un *hook* previamente registrado. |

#### register_hook(event, hook)

| Parámetro | Tipo | Req. |
|-----------|------|------|
| `event` | `str` | Sí |
| `hook` | `Callable \| Iterable[Callable]` | Sí |

| Devuelve | Tipo |
|----------|------|
| `None` | `None` |

| Excepciones | Condición |
|-------------|-----------|
| `ValueError` | Evento no soportado. |

---

#### deregister_hook(event, hook)

| Parámetro | Tipo | Req. |
|-----------|------|------|
| `event` | `str` | Sí |
| `hook` | `Callable` | Sí |

| Devuelve | Tipo |
|----------|------|
| Indica si el *hook* existía | `bool` |

| Excepciones | Condición |
|-------------|-----------|
| — | — |

---

### Request

| Método | Descripción |
|--------|-------------|
| `__init__(...)` | Crea un objeto de solicitud de alto nivel configurable. |
| `__repr__()` | Representación legible (`<Request [METHOD]>`). |
| `prepare()` | Convierte la instancia en un `PreparedRequest` inmutable listo para enviar. |

#### Request.__init__

(Se listan sólo argumentos explícitos de API pública)

| Parámetro | Tipo | Valor por defecto |
|-----------|------|-------------------|
| `method` | `str \| None` | `None` |
| `url` | `_t.UriType \| None` | `None` |
| `headers` | `Mapping[str, str | bytes] \| None` | `None` |
| `files` | `_t.FilesType \| None` | `None` |
| `data` | `_t.DataType \| None` | `None` |
| `params` | `_t.ParamsType \| None` | `None` |
| `auth` | `_t.AuthType \| None` | `None` |
| `cookies` | `CookieJar | dict | None` | `None` |
| `hooks` | `_t.HooksInputType \| None` | `None` |
| `json` | `_t.JsonType \| None` | `None` |

| Devuelve | Tipo |
|----------|------|
| Instancia inicializada | `None` |

| Excepciones | Condición |
|-------------|-----------|
| — | — |

---

#### Request.prepare()

| Parámetro | Tipo | Req. |
|-----------|------|------|
| *—* | *—* | — |

| Devuelve | Tipo |
|----------|------|
| Solicitud preparada | `PreparedRequest` |

| Excepciones | Condición |
|-------------|-----------|
| — | — |

---

### PreparedRequest

| Método / Propiedad | Descripción |
|--------------------|-------------|
| `__init__()` | Inicializa miembros plenamente mutables. |
| `prepare(...)` | Realiza la preparación integral (método, URL, cabeceras, cuerpo, auth, cookies, hooks). |
| `copy()` | Devuelve una copia superficial segura. |
| `prepare_method(method)` | Normaliza el verbo HTTP. |
| `_get_idna_encoded_host(host)` | Convierte dominios Unicode a IDNA. |
| `prepare_url(url, params)` | Valida y normaliza la URL final. |
| `prepare_headers(headers)` | Genera cabeceras internas. |
| `prepare_body(data, files, json)` | Determina cuerpo, longitud y cabeceras asociadas. |
| `prepare_content_length(body)` | Ajusta `Content-Length` según método/cuerpo. |
| `prepare_auth(auth, url)` | Aplica autenticación. |
| `prepare_cookies(cookies)` | Genera cabecera `Cookie`. |
| `prepare_hooks(hooks)` | Registra hooks adicionales. |
| `path_url`, `_encode_params`, `_encode_files` | Herdados de `RequestEncodingMixin`. |
| `register_hook`, `deregister_hook` | Herdados de `RequestHooksMixin`. |

(Para brevedad se detalla sólo la firma de los miembros con lógica destacada. Todos los métodos siguen la misma convención de tablas mostrada arriba.)

Ejemplo específico:

#### prepare_url(url, params)

| Parámetro | Tipo | Req. |
|-----------|------|------|
| `url` | `_t.UriType` | Sí |
| `params` | `_t.ParamsType` | Sí |

| Devuelve | Tipo |
|----------|------|
| `None` (estado interno actualizado) | `None` |

| Excepciones | Condición |
|-------------|-----------|
| `InvalidURL` | URL malformada o sin host. |
| `MissingSchema` | Falta esquema (`http/https`). |

*(Los demás métodos mantienen tablas de parámetros, retornos y excepciones análogas a las ya ilustradas.)*

---

### Response

| Método / Propiedad | Descripción |
|--------------------|-------------|
| `__init__()` | Construye estructura vacía de respuesta. |
| Context managers `__enter__`, `__exit__` | Soporte *with*. |
| Serialización `__getstate__`, `__setstate__` | Define “pickling”. |
| Conformidad bool `__bool__`, `__nonzero__` | Alias de `ok`. |
| Iteración `__iter__` | Itera en chunks binarios. |
| Propiedades `ok`, `is_redirect`, `is_permanent_redirect`, `next`, `apparent_encoding`, `content`, `text`, `links`. |
| `iter_content(...)` | Generador seguro de chunks (incluye la función local `generate()`). |
| `iter_lines(...)` | Generador línea-a-línea. |
| `json(**kwargs)` | Decodifica cuerpo JSON. |
| `raise_for_status()` | Lanza `HTTPError` según código. |
| `close()` | Libera la conexión subyacente. |

#### iter_content(chunk_size=1, decode_unicode=False)

| Parámetro | Tipo | Default |
|-----------|------|---------|
| `chunk_size` | `int | None` | `1` |
| `decode_unicode` | `bool` | `False` |

| Devuelve | Tipo |
|----------|------|
| Iterador de bytes o str | `Iterator[bytes | str]` |

| Excepciones | Condición |
|-------------|-----------|
| `StreamConsumedError` | Contenido ya consumido. |
| `TypeError` | `chunk_size` no entero. |
| `ChunkedEncodingError` | Error de protocolo/decodificación. |
| `ContentDecodingError` | Error al descomprimir. |
| `ConnectionError` | Timeout de lectura. |
| `RequestsSSLError` | Falla SSL. |

##### Función interna `generate()`

Generador que encapsula la lógica de lectura desde `self.raw` y mapea las excepciones de `urllib3` a excepciones de más alto nivel.

| Devuelve | Tipo |
|----------|------|
| Fragmentos de respuesta | `Generator[bytes, None, None]` |

| Excepciones | Igual que tabla anterior (se relanza desde *wrapper*). |

*(De manera análoga se documentan `iter_lines`, `json`, `raise_for_status`, etc.)*

---

## 3. Ejemplo de uso práctico

```python
from requests.models import Request, Response

# 1. Crear objeto Request de alto nivel
req = Request(
    method='POST',
    url='https://httpbin.org/post',
    json={'foo': 'bar'},
    headers={'User-Agent': 'DocSample/1.0'}
)

# 2. Convertir a PreparedRequest
preq = req.prepare()
print(preq.method, preq.url)               # -> 'POST' 'https://httpbin.org/post'
print(preq.headers['Content-Type'])        # -> 'application/json'
print(preq.body)                           # -> b'{"foo": "bar"}'

# 3. Simular envío con un Session real
import requests
with requests.Session() as s:
    resp: Response = s.send(preq)
    resp.raise_for_status()                # lanza HTTPError sólo si status >= 400
    data = resp.json()
    print(data['json'])                    # -> {'foo': 'bar'}

# 4. Consumir contenido en streaming
for line in resp.iter_lines(decode_unicode=True):
    print(line)
```

Este ejemplo cubre:  
• creación de la solicitud,  
• preparación exhaustiva (URL, cabeceras, cuerpo),  
• envío real mediante `Session.send`,  
• validación de estado y decodificación JSON,  
• consumo paulatino del cuerpo con `iter_lines`.
