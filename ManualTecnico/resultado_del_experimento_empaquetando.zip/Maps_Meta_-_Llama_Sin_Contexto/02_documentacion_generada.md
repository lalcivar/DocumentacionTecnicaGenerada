# Documentación Técnica - Clase `Maps`

**Paquete:** `com.google.common.collect`  
**Librería:** Google Guava  
**Versión:** Desde 2.0  
**Autores:** Kevin Bourrillion, Mike Bostock, Isaac Shum, Louis Wasserman  
**Licencia:** Apache License 2.0  
**Anotación:** `@GwtCompatible`  
**Tipo:** Clase final de utilidad - No instanciable

### 1. Descripción General

`Maps` es una clase de utilidad estática que proporciona métodos helper para trabajar con instancias de `Map`, incluyendo `SortedMap`, `NavigableMap`, `BiMap`, `EnumMap` y `ConcurrentMap`. Es el equivalente para mapas de las clases `Lists`, `Sets` y `Queues` de Guava.

La clase no puede ser instanciada, su constructor es privado `private Maps() {}` y expone únicamente métodos estáticos. Su objetivo es simplificar la creación, transformación, filtrado y comparación de mapas, ofreciendo vistas en vivo, copias inmutables y operaciones funcionales.

> **Nota:** Muchos métodos de creación como `newHashMap()`, `newTreeMap()` se consideran obsoletos desde Java 7 por la introducción del operador diamante `<>`. Se recomienda usar directamente los constructores `new HashMap<>()`.

### 2. Características Principales

*   **Factoría de Mapas:** Creación optimizada de `HashMap`, `LinkedHashMap`, `TreeMap`, `EnumMap`, `IdentityHashMap` y `ConcurrentHashMap` con capacidad inicial calculada para evitar redimensionamientos.
*   **Vistas en Vivo (Live Views):** La mayoría de métodos como `transformValues`, `filterKeys` y `asMap` no copian el mapa, sino que retornan una vista que refleja los cambios del mapa subyacente.
*   **Inmutabilidad:** Soporte para creación de `ImmutableMap` e `ImmutableEnumMap` y collectors para Streams.
*   **Programación Funcional:** Integración con `Function`, `Predicate` y `EntryTransformer` de Guava para transformar y filtrar entradas.
*   **Seguridad y Wrappers:** Métodos para obtener vistas sincronizadas y no modificables de `BiMap` y `NavigableMap`.

### 3. Métodos Principales

#### 3.1 Creación de Mapas Mutables

| Método | Descripción |
| :--- | :--- |
| `newHashMap()` / `newHashMap(Map)` / `newHashMapWithExpectedSize(int)` | Crea un `HashMap` vacío, con copia o con capacidad inicial optimizada. `capacity(int)` calcula `ceil(expectedSize / 0.75)` para evitar rehash. |
| `newLinkedHashMap()` / `newLinkedHashMapWithExpectedSize(int)` | Crea un `LinkedHashMap` que mantiene el orden de inserción. |
| `newTreeMap()` / `newTreeMap(Comparator)` / `newTreeMap(SortedMap)` | Crea un `TreeMap` ordenado por orden natural o por un `Comparator` específico. |
| `newEnumMap(Class)` / `newEnumMap(Map)` | Crea un `EnumMap` optimizado para claves de tipo `Enum`. |
| `newConcurrentMap()` | Crea un `ConcurrentHashMap` vacío y thread-safe. |
| `newIdentityHashMap()` | Crea un `IdentityHashMap` que compara claves por referencia `==` en lugar de `equals()`. |

#### 3.2 Mapas Inmutables y Collectors

| Método | Descripción |
| :--- | :--- |
| `immutableEnumMap(Map<K extends Enum, V>)` | Retorna una copia inmutable de un mapa respaldada por `EnumMap`. Itera en el orden de definición del `Enum`, no en el de inserción. |
| `toImmutableEnumMap(Function, Function)` | Retorna un `Collector` para Streams que acumula elementos en un `ImmutableMap` con claves `Enum`. Lanza `IllegalArgumentException` si hay claves duplicadas. |
| `toImmutableEnumMap(Function, Function, BinaryOperator)` | Sobrecarga que permite definir una función de merge para resolver claves duplicadas. |

#### 3.3 Transformación y Vistas

| Método | Descripción |
| :--- | :--- |
| `asMap(Set<K>, Function<K,V>)` | Retorna una vista `Map` en vivo donde cada clave del `Set` se mapea a `function.apply(key)`. Soporta `SortedSet` y `NavigableSet` retornando `SortedMap` y `NavigableMap` respectivamente. No soporta `put`, sí `remove`. |
| `toMap(Iterable/Iterator, Function)` | Crea un `ImmutableMap` donde las claves son los elementos del iterable y los valores son el resultado de aplicar la función. Si hay duplicados, conserva el último. |
| `uniqueIndex(Iterable/Iterator, Function)` | Indexa valores por una clave derivada. Lanza `IllegalArgumentException` si la función genera claves duplicadas. Sugiere usar `Multimaps.index` en ese caso. |
| `transformValues(Map, Function)` | Vista donde cada valor es transformado por la función. La transformación es lazy. Sobrecargas para `SortedMap` y `NavigableMap`. |
| `transformEntries(Map, EntryTransformer)` | Vista más potente que `transformValues`, permite transformar el valor usando tanto la clave como el valor original. Define la interfaz interna `EntryTransformer<K,V1,V2>`. |
| `fromProperties(Properties)` | Convierte un objeto `Properties` en un `ImmutableMap<String, String>`. |
| `immutableEntry(K, V)` | Crea una entrada `Map.Entry` inmutable y serializable. Alternativa a `Map.entry()` de Java 9. |

#### 3.4 Comparación y Diferencias

| Método | Descripción |
| :--- | :--- |
| `difference(Map, Map)` | Calcula la diferencia inmutable entre dos mapas. Retorna un objeto `MapDifference<K,V>` que expone: `entriesOnlyOnLeft()`, `entriesOnlyOnRight()`, `entriesInCommon()` y `entriesDiffering()`. |
| `difference(Map, Map, Equivalence)` | Sobrecarga que permite definir una equivalencia personalizada para comparar valores. |
| `difference(SortedMap, Map)` | Versión para mapas ordenados que retorna `SortedMapDifference` y respeta el `Comparator` del mapa izquierdo. |

#### 3.5 Filtrado

Todos retornan una **vista en vivo** que filtra bajo demanda. Las operaciones `put` que no cumplan el predicado lanzan `IllegalArgumentException`.

| Método | Descripción |
| :--- | :--- |
| `filterKeys(Map, Predicate<K>)` | Filtra por clave. Sobrecargas para `SortedMap`, `NavigableMap` y `BiMap`. |
| `filterValues(Map, Predicate<V>)` | Filtra por valor. Sobrecargas para `SortedMap`, `NavigableMap` y `BiMap`. |
| `filterEntries(Map, Predicate<Entry<K,V>>)` | Filtra por par clave-valor. Es el método más general. |

#### 3.6 Wrappers de Sincronización y No Modificables

| Método | Descripción |
| :--- | :--- |
| `synchronizedBiMap(BiMap)` | Retorna una vista sincronizada thread-safe de un `BiMap`. Requiere sincronización manual al iterar. |
| `unmodifiableBiMap(BiMap)` | Retorna una vista de solo lectura de un `BiMap`. |
| `unmodifiableNavigableMap(NavigableMap)` | Retorna una vista no modificable de un `NavigableMap`. |
| `synchronizedNavigableMap(NavigableMap)` | Retorna una vista sincronizada de un `NavigableMap`. |
| `asConverter(BiMap)` | Convierte un `BiMap` en un `Converter<A,B>` bidireccional. |

#### 3.7 Utilidades Adicionales

| Método | Descripción |
| :--- | :--- |
| `subMap(NavigableMap, Range)` | Retorna la vista de la porción del mapa cuyas claves están contenidas en un `Range` de Guava. Valida compatibilidad con comparadores personalizados. |

### 4. Clases e Interfaces Internas

*   `MapDifference<K,V>` y `SortedMapDifference<K,V>`: Interfaces que representan el resultado de `difference()`.
*   `EntryTransformer<K,V1,V2>`: Interfaz funcional para `transformEntries()`.
*   `UnmodifiableBiMap`, `FilteredEntryMap`, `TransformedEntriesMap`, `AsMapView`: Implementaciones privadas de vistas.

### 5. Consideraciones Técnicas

*   **Rendimiento:** Las vistas son lazy. Operaciones como `containsValue()` o `toString()` aplican la función de transformación múltiples veces. Para uso intensivo, copiar la vista a un nuevo `HashMap` es más eficiente.
*   **Nulabilidad:** La clase está anotada con `@Nullable` y `@ParametricNullness` (JSpecify). La mayoría de métodos aceptan claves/valores nulos si el mapa subyacente los acepta.
*   **Thread-Safety:** Las vistas retornadas no son thread-safe a menos que se use el wrapper `synchronized*`.
*   **Dependencias:** Utiliza `Preconditions`, `Predicates`, `Iterators` y `Collections2` de Guava.

