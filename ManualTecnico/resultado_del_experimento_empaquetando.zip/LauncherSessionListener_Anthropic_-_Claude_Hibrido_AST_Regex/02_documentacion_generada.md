# Documentación Técnica: `LauncherSessionListener`

**Paquete:** `org.junit.platform.launcher`
**Tipo:** `public interface`
**Anotación de API:** `@API(status = STABLE, since = "1.10")`
**Disponible desde (`@since`):** `1.8`

---

## 1. Resumen ejecutivo

`LauncherSessionListener` es una interfaz de *callback* (patrón Observer) del JUnit Platform Launcher API que permite a los clientes recibir notificaciones sobre el ciclo de vida de una `LauncherSession`, concretamente cuando ésta se abre y cuando se cierra. Está diseñada como *interfaz con métodos `default` vacíos*, de modo que las implementaciones solo necesitan sobrescribir los eventos que realmente les interesan, evitando la necesidad de clases adaptadoras.

El registro de implementaciones puede realizarse de forma **programática**, mediante `LauncherConfig.Builder#addLauncherSessionListeners` sobre la configuración entregada a `LauncherFactory#openSession(LauncherConfig)`, o de forma **declarativa/automática** a través del mecanismo `java.util.ServiceLoader` de Java. La invocación de sus métodos es responsabilidad exclusiva del `Launcher` / `LauncherSession` construidos por `LauncherFactory`; el consumidor nunca debería llamarlos manualmente.

---

## 2. Especificación de miembros, constructores y métodos

### 2.1 Resumen de elementos detectados

| Elemento | Tipo de elemento | Modificadores efectivos | Descripción breve |
|---|---|---|---|
| `LauncherSessionListener` | Interfaz | `public` | Contrato de escucha del ciclo de vida de sesión. |
| `NOOP` | Campo constante | `public static final` (implícito en interfaz) | Instancia *no-op* (clase anónima) del listener. |
| *Constructor implícito de la clase anónima de `NOOP`* | Constructor sintético | `package-private` (implícito) | Constructor por defecto generado por el compilador para la clase anónima. |
| `launcherSessionOpened(LauncherSession)` | Método | `public default` | Notificación de apertura de sesión. |
| `launcherSessionClosed(LauncherSession)` | Método | `public default` | Notificación de cierre de sesión. |

> **Nota sobre constructores:** al tratarse de una interfaz, `LauncherSessionListener` **no declara ni puede declarar constructores**. El único constructor presente en el código fuente es el constructor por defecto *implícito* de la clase anónima utilizada para inicializar la constante `NOOP` (`new LauncherSessionListener() {}`), generado automáticamente por el compilador. No recibe parámetros, no retorna valor y no declara excepciones.

---

### 2.2 Campo constante `NOOP`

```java
/**
 * Implementación «no-op» (sin operación) de {@code LauncherSessionListener}.
 *
 * <p>Se materializa como una clase anónima que implementa la interfaz sin
 * sobrescribir ningún método, heredando por tanto las implementaciones
 * {@code default} vacías de {@link #launcherSessionOpened(LauncherSession)} y
 * {@link #launcherSessionClosed(LauncherSession)}.
 *
 * <p>Resulta idónea como valor por defecto (en lugar de {@code null}) o como
 * objeto nulo en escenarios de composición y pruebas.
 */
LauncherSessionListener NOOP = new LauncherSessionListener() {
};
```

| Característica | Valor |
|---|---|
| Nombre | `NOOP` |
| Tipo declarado | `LauncherSessionListener` |
| Modificadores | `public static final` (implícitos por ser campo de interfaz) |
| Inicialización | Clase anónima vacía: `new LauncherSessionListener() {}` |
| Métodos sobrescritos por la clase anónima | Ninguno (hereda ambos `default`) |
| Seguridad frente a hilos | Inmutable y sin estado → *thread-safe* |
| Excepciones (`@throws`) | Ninguna; su inicialización estática no puede fallar |

**Métodos efectivos de la clase anónima de `NOOP`:**

| Método heredado | Comportamiento efectivo |
|---|---|
| `launcherSessionOpened(LauncherSession session)` | Cuerpo vacío. No realiza ninguna acción ni valida el argumento. |
| `launcherSessionClosed(LauncherSession session)` | Cuerpo vacío. No realiza ninguna acción ni valida el argumento. |

---

### 2.3 Método `launcherSessionOpened(LauncherSession)`

```java
/**
 * Llamado cuando una sesión del launcher ha sido abierta.
 *
 * <p>La implementación {@code default} está vacía; las implementaciones
 * concretas pueden sobrescribirla para ejecutar lógica de preparación global
 * (p. ej., arranque de contenedores, servidores embebidos, conexiones
 * compartidas o inicialización de recursos de infraestructura) antes de que
 * comience el descubrimiento y la ejecución de pruebas.
 *
 * <p>Invocado por el {@link LauncherSession} creado vía
 * {@link LauncherFactory}. No debe invocarse manualmente por el cliente.
 *
 * @param session la sesión que acaba de abrirse; proporciona acceso al
 *                {@link Launcher} asociado a la sesión
 */
default void launcherSessionOpened(LauncherSession session) {
}
```

**Parámetros de entrada (`@param`)**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `session` | `org.junit.platform.launcher.LauncherSession` | Sí (posicional obligatorio) | La sesión recién abierta. Es suministrada por la infraestructura del Launcher; la implementación `default` la ignora por completo. |

**Valor de retorno (`@return`)**

| Tipo | Descripción |
|---|---|
| `void` | No retorna valor. La notificación es puramente un efecto lateral. |

**Excepciones (`@throws`)**

| Excepción | Condición |
|---|---|
| *Ninguna declarada* | La firma no declara excepciones comprobadas (*checked*). La implementación `default` (cuerpo vacío) no puede lanzar excepción alguna. Las implementaciones que sobrescriban este método solo podrán propagar `RuntimeException` o `Error` (excepciones no comprobadas). |

**Contrato y notas de implementación**

- Debe invocarse **exactamente una vez por sesión**, en el momento de la apertura, antes de cualquier invocación al `Launcher` de la sesión.
- Las implementaciones deben ser tolerantes a fallos y breves: una excepción no comprobada propagada desde este punto puede abortar la apertura de la sesión.
- No se garantiza orden entre múltiples listeners registrados; no deben existir dependencias implícitas de orden entre ellos.

---

### 2.4 Método `launcherSessionClosed(LauncherSession)`

```java
/**
 * Llamado cuando una sesión del launcher ha sido cerrada.
 *
 * <p>La implementación {@code default} está vacía; las implementaciones
 * concretas pueden sobrescribirla para liberar recursos globales adquiridos
 * durante {@link #launcherSessionOpened(LauncherSession)} (cierre de
 * conexiones, parada de servicios, volcado de informes agregados, etc.).
 *
 * <p>Invocado por el {@link LauncherSession} creado vía
 * {@link LauncherFactory}. No debe invocarse manualmente por el cliente.
 *
 * @param session la sesión que acaba de cerrarse
 */
default void launcherSessionClosed(LauncherSession session) {
}
```

**Parámetros de entrada (`@param`)**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `session` | `org.junit.platform.launcher.LauncherSession` | Sí (posicional obligatorio) | La sesión que ha sido cerrada. Tras esta notificación la sesión ya no debe utilizarse para ejecutar pruebas. La implementación `default` la ignora. |

**Valor de retorno (`@return`)**

| Tipo | Descripción |
|---|---|
| `void` | No retorna valor. |

**Excepciones (`@throws`)**

| Excepción | Condición |
|---|---|
| *Ninguna declarada* | No se declaran excepciones comprobadas. La implementación `default` no lanza nada. Las sobrescrituras deben evitar propagar excepciones, ya que se producirían durante la fase de limpieza y podrían enmascarar errores previos. |

**Contrato y notas de implementación**

- Se invoca una única vez por sesión, al final de su ciclo de vida (típicamente desde `LauncherSession#close()`, compatible con *try-with-resources*).
- Es el punto simétrico de `launcherSessionOpened(LauncherSession)`: todo recurso creado allí debería liberarse aquí.
- La liberación debe ser idempotente y defensiva, dado que el listener podría no haber completado correctamente su apertura.

---

### 2.5 Matriz de trazabilidad completa de métodos

| Método / Constructor | Firma exacta | Visibilidad | Estático | Cuerpo en el código fuente |
|---|---|---|---|---|
| `launcherSessionOpened()` | `default void launcherSessionOpened(LauncherSession session)` | `public` (implícito) | No | Vacío |
| `launcherSessionClosed()` | `default void launcherSessionClosed(LauncherSession session)` | `public` (implícito) | No | Vacío |
| Constructor implícito de la clase anónima de `NOOP` | `<init>()` | `package-private` (sintético) | No | Generado por el compilador |
| Métodos de la clase anónima de `NOOP` | — | — | — | Ninguno declarado; hereda los dos `default` |

> No existen en el código fuente métodos `private`, `protected`, `static` ni `abstract` adicionales. La interfaz no declara métodos abstractos, por lo que **no es una interfaz funcional válida para expresiones lambda** (no posee un único método abstracto); la implementación debe realizarse mediante clase nombrada o clase anónima.

---

## 3. Ejemplo de uso

### 3.1 Implementación de un listener de sesión con recursos globales

```java
package com.example.testinfra;

import org.junit.platform.launcher.LauncherSession;
import org.junit.platform.launcher.LauncherSessionListener;

/**
 * Listener que arranca y detiene una infraestructura compartida una única vez
 * por sesión del Launcher, sin importar cuántos planes de prueba se ejecuten.
 *
 * @author Equipo de Plataforma de Pruebas
 */
public class SharedInfrastructureSessionListener implements LauncherSessionListener {

    private Emb