# Documentación Técnica - Clase `LocalCache<K, V>`

**Paquete:** `com.google.common.cache`  
**Librería:** Google Guava  
**Tipo:** `final class LocalCache<K,V> extends AbstractMap<K,V> implements ConcurrentMap<K,V>`  
**Anotaciones:** `@GwtCompatible`, `@NullUnmarked`  
**Autores:** Charles Fry, Bob Lee, Doug Lea  
**Licencia:** Apache License 2.0  
**Basada en:** `ConcurrentHashMap` rev. 1.96

---

### 1. Descripción General

`LocalCache` es la implementación central y concurrente del caché construido por `CacheBuilder`. Es una clase de uso interno `package-private` y **no debe ser instanciada directamente** por el usuario final. Toda su configuración se realiza a través de `CacheBuilder`.

Implementa un mapa hash concurrente segmentado, thread-safe para lecturas no bloqueantes y escrituras concurrentes. Combina las características de un `ConcurrentHashMap` con políticas avanzadas de caché:

* Evicción por tamaño/peso con algoritmo **LRU** por segmento.
* Expiración por tiempo `expireAfterWrite` y `expireAfterAccess`.
* Refresco automático `refreshAfterWrite`.
* Referencias débiles `WeakReference` y suaves `SoftReference` para claves y valores.
* Estadísticas `StatsCounter`, notificaciones `RemovalListener` y carga asíncrona vía `CacheLoader`.

> Es la clase que respalda a `LocalManualCache` y `LocalLoadingCache`, que son las implementaciones expuestas como `Cache` y `LoadingCache`.

### 2. Arquitectura y Principios de Diseño

La estrategia principal es la **segmentación**:

1.  La tabla se subdivide en un arreglo de `Segment[]`. Cada `Segment` es una tabla hash especializada que hereda de `ReentrantLock`.
2.  El `hash` de la clave determina el segmento mediante `segmentShift` y `segmentMask`. Esto permite escrituras concurrentes en diferentes segmentos sin contención.
3.  Las lecturas son **no bloqueantes** y se apoyan en campos `volatile` como `count` y `table` para garantizar visibilidad.
4.  Para evitar contención por la política LRU, los accesos se registran en una `recencyQueue` y se drenan en lotes cuando se supera `DRAIN_THRESHOLD = 0x3F` o al realizar una escritura.
5.  Dos colas de ordenamiento mantienen el orden de evicción: `writeQueue` y `accessQueue`.

### 3. Constantes y Configuración Principal

| Constante | Valor | Descripción |
| :--- | :--- | :--- |
| `MAXIMUM_CAPACITY` | `1 << 30` | Capacidad máxima de la tabla. |
| `MAX_SEGMENTS` | `1 << 16` | Número máximo de segmentos. |
| `DRAIN_THRESHOLD` | `0x3F` | Nº de lecturas bufferizadas antes de drenar la cola de recencia. |
| `DRAIN_MAX` | `16` | Nº máximo de entradas a drenar en una sola limpieza. |
| `CONTAINS_VALUE_RETRIES` | `3` | Reintentos sin bloqueo para `containsValue()`. |

### 4. Atributos Clave

| Atributo | Tipo | Descripción |
| :--- | :--- | :--- |
| `segments` | `Segment<K,V>[]` | Arreglo de segmentos. Núcleo de la concurrencia. |
| `concurrencyLevel` | `int` | Nivel de concurrencia configurado. |
| `keyStrength / valueStrength` | `Strength` | Estrategia de referencia: `STRONG`, `WEAK`, `SOFT`. |
| `maxWeight` | `long` | Peso máximo del caché. `UNSET_INT` si no hay límite. |
| `weigher` | `Weigher<K,V>` | Función para calcular el peso de cada entrada. |
| `expireAfterAccessNanos` | `long` | Tiempo de expiración tras el último acceso. |
| `expireAfterWriteNanos` | `long` | Tiempo de expiración tras la última escritura. |
| `refreshNanos` | `long` | Tiempo tras el cual una entrada es candidata a refresco. |
| `removalListener` | `RemovalListener` | Listener invocado al expirar/evictar una entrada. |
| `ticker` | `Ticker` | Fuente de tiempo testeable. |
| `entryFactory` | `EntryFactory` | Factoría para crear `ReferenceEntry` según la configuración. |
| `globalStatsCounter` | `StatsCounter` | Acumulador de estadísticas globales. |

Métodos de configuración: `evictsBySize()`, `expiresAfterWrite()`, `expiresAfterAccess()`, `refreshes()`, `usesKeyReferences()`, `recordsTime()`.

### 5. Métodos Principales

#### 5.1 Ciclo de Vida y Construcción
| Método | Descripción |
| :--- | :--- |
| `LocalCache(CacheBuilder, CacheLoader)` | Constructor principal. Calcula el número de segmentos, capacidad inicial y peso máximo por segmento. Inicializa colas y factorías. |
| `createSegment(int, long, StatsCounter)` | Crea un nuevo `Segment`. |
| `newEntry(K, int, ReferenceEntry)` | Método de conveniencia para testing. Delega en `Segment.newEntry()`. |
| `newValueReference(ReferenceEntry, V, int)` | Crea una `ValueReference` según el `valueStrength`. |

#### 5.2 Operaciones de Mapa - `ConcurrentMap`
| Método | Descripción |
| :--- | :--- |
| `get(Object key)` | Obtiene el valor si está presente y no expirado. Registra hit/miss y programa un refresco si corresponde. |
| `get(K key, CacheLoader)` | Obtiene o carga el valor de forma síncrona. Si está cargando, espera con `waitForLoadingValue()`. |
| `getIfPresent(Object key)` | Versión que no carga, solo consulta. Actualiza estadísticas globales. |
| `getOrDefault(Object, V)` | Retorna el valor o el valor por defecto. |
| `containsKey(Object)` / `containsValue(Object)` | Verificación de existencia. `containsValue` realiza hasta 3 reintentos sin bloqueo para consistencia. |
| `put(K, V)` / `putIfAbsent(K, V)` | Inserta o actualiza. Expande la tabla si supera `threshold` y ejecuta `evictEntries()`. |
| `replace(K, V)` / `replace(K, V, V)` | Reemplazo atómico condicional. |
| `remove(Object)` / `remove(Object, Object)` | Eliminación explícita. Genera notificación `RemovalCause.EXPLICIT`. |
| `putAll(Map)` | Inserción en lote. |
| `clear()` | Limpia todos los segmentos, colas de referencia y notifica eliminaciones. |
| `size()` / `longSize()` / `isEmpty()` | Cálculo agregado del `count` de todos los segmentos con control de `modCount` para consistencia. |
| `keySet()` / `values()` / `entrySet()` | Vistas del mapa respaldadas por iteradores `HashIterator` que filtran entradas expiradas/colectadas. |

#### 5.3 Operaciones de Caché Avanzadas
| Método | Descripción |
| :--- | :--- |
| `getAllPresent(Iterable)` | Retorna un `ImmutableMap` solo con las claves presentes. |
| `getAll(Iterable)` | Obtiene todas las claves. Para las ausentes invoca `loadAll()` o fallback a `load()` individual. |
| `loadAll(Set, CacheLoader)` | Invoca `CacheLoader.loadAll()`. Valida nulos y registra estadísticas de carga. |
| `refresh(K key)` | Refresca de forma asíncrona el valor de una clave. |
| `invalidateAll(Iterable)` | Invalida un conjunto de claves. |
| `cleanUp()` | Ejecuta limpieza en todos los segmentos: drena colas de referencia y expira entradas. |
| `getLiveValue(ReferenceEntry, long)` | Retorna el valor solo si la entrada es válida, no colectada y no expirada. |
| `isExpired(ReferenceEntry, long)` | Determina si una entrada expiró por `expireAfterAccess` o `expireAfterWrite`. |
| `isLive(ReferenceEntry, long)` | Verifica si una entrada está viva. Usado para testing. |

#### 5.4 Utilidades Internas
| Método | Descripción |
| :--- | :--- |
| `hash(Object)` / `rehash(int)` | Calcula el hash usando `keyEquivalence` y aplica función suplementaria de Wang/Jenkins para dispersar bits. |
| `segmentFor(int hash)` | Retorna el `Segment` correspondiente a un hash. |
| `reclaimKey(ReferenceEntry)` / `reclaimValue(ValueReference)` | Limpieza de entradas cuyas claves/valores fueron recolectados por el GC. |
| `processPendingNotifications()` | Drena `removalNotificationQueue` e invoca a `removalListener`. |

### 6. Clases Internas Relevantes

*   **`Segment<K,V> extends ReentrantLock`**: Núcleo de la concurrencia. Contiene la tabla `AtomicReferenceArray<ReferenceEntry>`, las colas `writeQueue`, `accessQueue`, `recencyQueue` y las `ReferenceQueue` para GC. Implementa toda la lógica de `get`, `put`, `expand()`, `evictEntries()`, `expireEntries()` y `drainReferenceQueues()`.
*   **`Strength (Enum)`**: `STRONG`, `SOFT`, `WEAK`. Define cómo se referencia el valor y la `Equivalence` por defecto.
*   **`EntryFactory (Enum)`**: 8 variantes `STRONG`, `STRONG_ACCESS`, `WEAK_WRITE`, etc. Crea el tipo de `ReferenceEntry` adecuado según si se usa cola de acceso/escritura y referencias débiles.
*   **`ValueReference<K,V> (Interface)`**: Abstrae el valor. Implementaciones: `StrongValueReference`, `WeakValueReference`, `SoftValueReference` y sus variantes `Weighted*`. `LoadingValueReference` representa un valor en carga con un `SettableFuture`.
*   **`ReferenceEntry<K,V> (Interface)`**: Nodo de la tabla hash. Extensiones como `StrongEntry`, `WeakEntry`, `StrongAccessWriteEntry` almacenan `hash`, `next`, `accessTime` y `writeTime`.
*   **`WriteQueue` / `AccessQueue`**: Colas doblemente enlazadas personalizadas que gestionan el orden LRU. Están integradas directamente en `ReferenceEntry`.
*   **`LocalManualCache` / `LocalLoadingCache`**: Wrappers serializables que exponen la API `Cache` y `LoadingCache` y delegan en `LocalCache`.
*   **`ManualSerializationProxy` / `LoadingSerializationProxy`**: Proxies para serialización que reconstruyen el caché vía `CacheBuilder` al deserializar.

### 7. Consideraciones

*   **Thread-Safety:** Totalmente thread-safe. Lecturas sin bloqueo, escrituras con bloqueo a nivel de segmento.
*   **No usar directamente:** Al ser `final` y package-private, su uso externo debe ser siempre a través de `CacheBuilder.newBuilder().build()`.
*   **Consistencia:** No garantiza consistencia global inmediata para `size()` y `containsValue()` bajo alta contención, pero ofrece garantías de eventual consistencia mediante `modCount`.

