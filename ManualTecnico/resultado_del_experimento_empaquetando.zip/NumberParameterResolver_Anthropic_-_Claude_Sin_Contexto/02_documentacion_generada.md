# Documentación Técnica

## Clase `NumberParameterResolver`

**Paquete:** `org.junit.jupiter.engine.execution.injection.sample`

**Implementa:** `org.junit.jupiter.api.extension.ParameterResolver`

**Desde:** JUnit Jupiter 5.0

**Licencia:** Eclipse Public License v2.0

---

## Descripción general

`NumberParameterResolver` es una implementación **de ejemplo (no realista)** de la interfaz `ParameterResolver` de la API de extensiones de JUnit Jupiter. Su propósito es servir como artefacto de prueba interno del motor de ejecución de JUnit (`junit-jupiter-engine`) para verificar el comportamiento del framework cuando un resolutor de parámetros **declara soportar un tipo más amplio del que realmente es capaz de proporcionar**.

Concretamente, la clase:

- **Declara** que puede resolver cualquier parámetro cuyo tipo sea `java.lang.Number` o alguna de sus subclases (`Integer`, `Long`, `Double`, `BigDecimal`, etc.).
- **Resuelve** siempre, de forma incondicional, el valor literal `42`, que por autoboxing se convierte en un `java.lang.Integer`.

Esta discrepancia intencional provoca que, cuando un método de prueba declara un parámetro de tipo `Number` compatible pero distinto de `Integer` (por ejemplo `Double` o `Long`), la invocación reflexiva del método falle con una `IllegalArgumentException` con el mensaje *"argument type mismatch"*. Dicho escenario permite a JUnit validar y documentar el mensaje de error que se reporta al usuario en estos casos.

### Justificación del diseño (caso de uso real)

Aunque a primera vista el comportamiento parezca ilógico, el Javadoc original describe un escenario legítimo: existen resolutores que **no pueden determinar de antemano** el tipo concreto del objeto que acabarán inyectando.

El ejemplo citado es la `SpringExtension` de Spring Framework:

| Situación | Resultado |
|---|---|
| El resolutor afirma soportar cualquier subtipo de `ApplicationContext`. | `supportsParameter` devuelve `true`. |
| El parámetro requerido es `WebApplicationContext`, pero la clase de prueba no está anotada con `@WebAppConfiguration`. | Spring carga un `ApplicationContext` genérico, no un `WebApplicationContext`. |
| JUnit intenta invocar el método de prueba con el valor resuelto. | Se lanza `IllegalArgumentException: argument type mismatch`. |

De este modo, la clase modela un patrón de fallo real que puede presentarse con extensiones de terceros.

---

## Métodos principales

### `supportsParameter(ParameterContext, ExtensionContext)`

```java
@Override
public boolean supportsParameter(ParameterContext parameterContext,
                                 ExtensionContext extensionContext)
```

Determina si este resolutor es capaz de proporcionar un valor para el parámetro indicado.

**Parámetros**

| Nombre | Tipo | Descripción |
|---|---|---|
| `parameterContext` | `ParameterContext` | Contexto del parámetro que se pretende resolver; da acceso al objeto `Parameter`, su índice y la instancia de prueba asociada. |
| `extensionContext` | `ExtensionContext` | Contexto de ejecución actual (clase o método de prueba, almacén de estado, etc.). |

**Retorno**

`boolean` — `true` si el tipo declarado del parámetro es asignable a `java.lang.Number` (es decir, si `Number.class.isAssignableFrom(tipo)`); `false` en caso contrario.

**Comportamiento**

Realiza la comprobación mediante reflexión sobre el tipo declarado del parámetro:

```java
Number.class.isAssignableFrom(parameterContext.getParameter().getType())
```

> **Nota:** la comprobación opera sobre tipos de referencia. Los tipos primitivos (`int`, `double`, …) **no** son asignables a `Number`, por lo que no serán soportados.

---

### `resolveParameter(ParameterContext, ExtensionContext)`

```java
@Override
public Object resolveParameter(ParameterContext parameterContext,
                               ExtensionContext extensionContext)
```

Proporciona el valor que se inyectará en el parámetro previamente aceptado por `supportsParameter`.

**Parámetros**

| Nombre | Tipo | Descripción |
|---|---|---|
| `parameterContext` | `ParameterContext` | Contexto del parámetro a resolver (no se utiliza en esta implementación). |
| `extensionContext` | `ExtensionContext` | Contexto de ejecución actual (no se utiliza en esta implementación). |

**Retorno**

`Object` — siempre el valor constante `42`, autoboxeado a `java.lang.Integer`.

**Comportamiento**

Implementación constante e independiente del contexto. No valida que el tipo esperado del parámetro sea compatible con `Integer`, lo que constituye precisamente la condición de fallo que esta clase pretende reproducir.

---

## Ejemplo de uso

```java
@ExtendWith(NumberParameterResolver.class)
class EjemploTest {

    @Test
    void casoExitoso(Number numero) {
        // Se inyecta correctamente: Integer es un Number
        assertEquals(42, numero.intValue());
    }

    @Test
    void casoExitosoConInteger(Integer numero) {
        // Se inyecta correctamente
        assertEquals(42, numero);
    }

    @Test
    void casoFallido(Double numero) {
        // supportsParameter devuelve true (Double es Number),
        // pero resolveParameter devuelve un Integer
        // → IllegalArgumentException: argument type mismatch
    }
}
```

---

## Consideraciones y advertencias

- **Ámbito de uso:** clase de soporte para la suite de pruebas interna de JUnit Jupiter. **No está destinada a uso en producción** ni forma parte de la API pública del framework; su paquete (`...engine.execution.injection.sample`) y su naturaleza de *sample* lo indican explícitamente.
- **Sin estado:** la clase no mantiene estado mutable, por lo que es intrínsecamente *thread-safe* y puede reutilizarse entre invocaciones.
- **Contrato de `ParameterResolver`:** ilustra que JUnit confía en el resultado de `supportsParameter` y **no verifica** la compatibilidad de tipos del valor devuelto por `resolveParameter` antes de invocar el método de prueba; la verificación la realiza implícitamente la invocación reflexiva de Java.
- **Buena práctica derivada:** las implementaciones reales de `ParameterResolver` deberían ser lo más precisas posible en `supportsParameter` y, cuando no sea factible, lanzar una `ParameterResolutionException` con un mensaje descriptivo en `resolveParameter` en lugar de permitir un `argument type mismatch` poco informativo.