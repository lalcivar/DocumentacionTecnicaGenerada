# Documentación Técnica - Módulo `flask.app.Flask`

## 1. Resumen Ejecutivo

Este módulo implementa la clase central `Flask` que extiende `sansio.app.App` para proveer una aplicación WSGI completa. Actúa como registro central para vistas, reglas de URL, configuración, manejo de sesiones, contextos de aplicación/request, sistema de plantillas Jinja2 y CLI con Click. El archivo también define utilidades de compatibilidad para la migración de firmas con `AppContext` (`remove_ctx`, `add_ctx`) y la gestión del ciclo de vida de la petición WSGI (`wsgi_app`, `full_dispatch_request`).

---

## 2. Especificación de Funciones y Métodos

### 2.1 Funciones a Nivel de Módulo

#### ` _make_timedelta()`

Convierte un valor entero (segundos) o `timedelta` en un objeto `timedelta` normalizado.

**Docstring (Google Style):**
```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    """Normaliza un valor a timedelta.

    Args:
        value: Valor a convertir. Puede ser timedelta, entero en segundos o None.

    Returns:
        Objeto timedelta si se proporciona int o timedelta, None si la entrada es None.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `value` | `timedelta \| int \| None` | Sí | Valor en segundos o timedelta a normalizar. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `timedelta \| None` | `timedelta` | Timedelta normalizado o None. |

| Excepciones | Condición |
| :--- | :--- |
| `N/A` | No lanza excepciones directamente. |

---

#### `remove_ctx()`

Decorador de compatibilidad para subclases que aún usan la firma antigua sin `ctx: AppContext`. Elimina el primer argumento `AppContext` si está presente antes de delegar al método original.

**Docstring (Google Style):**
```python
def remove_ctx(f: F) -> F:
    """Envuelve un método para eliminar el argumento AppContext inyectado.

    Args:
        f: Función/método a envolver.

    Returns:
        Función envuelta con update_wrapper que descarta AppContext si es el primer arg.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `f` | `F (Callable[..., Any])` | Sí | Método objetivo a envolver. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `F` | `Callable` | Wrapper con firma compatible hacia atrás. |

#### `remove_ctx.wrapper()`

Función anidada/local dentro de `remove_ctx`.

```python
def wrapper(self: Flask, *args: Any, **kwargs: Any) -> Any:
    """Wrapper interno que filtra AppContext.

    Args:
        self: Instancia de Flask.
        *args: Argumentos posicionales, puede incluir AppContext como args[0].
        **kwargs: Argumentos nominales.

    Returns:
        Resultado de f(self, *args_filtrados, **kwargs).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `Any` | No | Argumentos posicionales. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

---

#### `add_ctx()`

Decorador inverso a `remove_ctx`. Inyecta el `AppContext` actual (`app_ctx._get_current_object()`) como primer argumento si el método base es invocado sin él vía `super()`.

**Docstring (Google Style):**
```python
def add_ctx(f: F) -> F:
    """Envuelve un método base para inyectar AppContext automáticamente.

    Args:
        f: Método base de Flask a envolver.

    Returns:
        Función envuelta que asegura AppContext como primer argumento.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `f` | `F (Callable[..., Any])` | Sí | Método base a envolver. |

#### `add_ctx.wrapper()`

Función anidada/local dentro de `add_ctx`.

```python
def wrapper(self: Flask, *args: Any, **kwargs: Any) -> Any:
    """Wrapper interno que inyecta AppContext.

    Args:
        self: Instancia de Flask.
        *args: Argumentos posicionales.
        **kwargs: Argumentos nominales.

    Returns:
        Resultado de f(self, ctx, *args, **kwargs).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `Any` | No | Argumentos posicionales. |
| `**kwargs` | `Any` | No | Argumentos nominales. |

---

### 2.2 Clase `Flask`

Hereda de `sansio.app.App`. Implementa la aplicación WSGI, gestión de contextos, routing, manejo de errores y ciclo de vida de la petición.

#### `Flask.__init_subclass__()`

Hook de creación de subclases que detecta métodos sobreescritos con firma antigua (sin `ctx`) y aplica `remove_ctx`/`add_ctx` con advertencia de deprecación.

```python
def __init_subclass__(cls, **kwargs: Any) -> None:
    """Intercepta la definición de subclases para compatibilidad de firmas.

    Args:
        cls: Subclase de Flask siendo creada.
        **kwargs: Argumentos adicionales de clase.

    Raises:
        DeprecationWarning: Si un método sobreescrito no incluye 'ctx: AppContext'.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `cls` | `type` | Sí | Subclase en creación. |
| `**kwargs` | `Any` | No | Argumentos de metaclase. |

| Retorno | Tipo |
| :--- | :--- |
| `None` | `None` |

#### `Flask.__init__()`

Constructor principal de la aplicación.

```python
def __init__(self, import_name: str, static_url_path: str | None = None, static_folder: str | os.PathLike[str] | None = "static", static_host: str | None = None, host_matching: bool = False, subdomain_matching: bool = False, template_folder: str | os.PathLike[str] | None = "templates", instance_path: str | None = None, instance_relative_config: bool = False, root_path: str | None = None) -> None:
    """Inicializa la aplicación Flask.

    Args:
        import_name: Nombre del paquete/módulo de la aplicación.
        static_url_path: Ruta URL para archivos estáticos.
        static_folder: Carpeta de archivos estáticos.
        static_host: Host para la ruta estática (requerido si host_matching=True).
        host_matching: Habilita matching por host en url_map.
        subdomain_matching: Habilita matching por subdominio.
        template_folder: Carpeta de plantillas.
        instance_path: Ruta alternativa de instancia.
        instance_relative_config: Si True, config relativa a instance_path.
        root_path: Ruta raíz de archivos de la app.

    Raises:
        AssertionError: Si la combinación static_host/host_matching es inválida.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `import_name` | `str` | Sí | Nombre de importación para resolución de recursos. |
| `static_url_path` | `str \| None` | No | Path URL estático. Default `None` (deriva de `static_folder`). |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | Carpeta estática. Default `"static"`. |
| `static_host` | `str \| None` | No | Host estático. Default `None`. |
| `host_matching` | `bool` | No | Default `False`. |
| `subdomain_matching` | `bool` | No | Default `False`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | Default `"templates"`. |
| `instance_path` | `str \| None` | No | Default `None`. |
| `instance_relative_config` | `bool` | No | Default `False`. |
| `root_path` | `str \| None` | No | Default `None` (autodetectado). |

#### `Flask.__init__.<lambda>()`

Función anidada/local (callback) registrada como `view_func` para la ruta estática.

```python
lambda **kw: self_ref().send_static_file(**kw)
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `**kw` | `Any` | Sí | Debe contener `filename: str`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `Response` | `Response` | Respuesta con archivo estático. |

| Excepciones | Condición |
| :--- | :--- |
| `RuntimeError` | Si `static_folder` no está configurado al invocar `send_static_file`. |

---

#### `Flask.get_send_file_max_age()`

```python
def get_send_file_max_age(self, filename: str | None) -> int | None:
    """Determina el max_age de caché para send_file.

    Args:
        filename: Nombre del archivo solicitado.

    Returns:
        Segundos de max_age o None para usar peticiones condicionales.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| None` | Sí | Nombre del archivo. |

| Retorno | Tipo |
| :--- | :--- |
| `int \| None` | `int \| None` |

#### `Flask.send_static_file()`

```python
def send_static_file(self, filename: str) -> Response:
    """Sirve un archivo desde static_folder.

    Args:
        filename: Ruta relativa dentro de static_folder.

    Returns:
        Objeto Response con el archivo.

    Raises:
        RuntimeError: Si has_static_folder es False.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str` | Sí | Nombre del archivo. |

#### `Flask.open_resource()`

```python
def open_resource(self, resource: str, mode: str = "rb", encoding: str | None = None) -> IO[AnyStr]:
    """Abre un recurso relativo a root_path solo en lectura.

    Args:
        resource: Ruta relativa a root_path.
        mode: Modo de apertura. Solo "r", "rt", "rb".
        encoding: Codificación si mode es texto.

    Returns:
        Handle de archivo abierto.

    Raises:
        ValueError: Si mode no es de lectura.
        FileNotFoundError: Si el recurso no existe.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `resource` | `str` | Sí | Ruta del recurso. |
| `mode` | `str` | No | Default `"rb"`. |
| `encoding` | `str \| None` | No | Default `None`. |

#### `Flask.open_instance_resource()`

```python
def open_instance_resource(self, resource: str, mode: str = "rb", encoding: str | None = "utf-8") -> IO[AnyStr]:
    """Abre un recurso relativo a instance_path (lectura/escritura).

    Args:
        resource: Ruta relativa a instance_path.
        mode: Modo de apertura.
        encoding: Codificación para modo texto.

    Returns:
        Handle de archivo abierto.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `resource` | `str` | Sí | Ruta del recurso. |
| `mode` | `str` | No | Default `"rb"`. |
| `encoding` | `str \| None` | No | Default `"utf-8"`. |

#### `Flask.create_jinja_environment()`

```python
def create_jinja_environment(self) -> Environment:
    """Crea el entorno Jinja2 configurado para la app.

    Returns:
        Entorno Jinja2 con globals (url_for, config, request, session, g) y políticas JSON.
    """
```

#### `Flask.create_url_adapter()`

```python
def create_url_adapter(self, request: Request | None) -> MapAdapter | None:
    """Crea un adaptador de URLs para construir/matchear rutas.

    Args:
        request: Objeto Request actual o None si fuera de contexto de request.

    Returns:
        MapAdapter vinculado al environ o a SERVER_NAME, o None si no hay SERVER_NAME fuera de request.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request` | `Request \| None` | Sí | Request actual. |

#### `Flask.raise_routing_exception()`

```python
def raise_routing_exception(self, request: Request) -> NoReturn:
    """Intercepta excepciones de routing en modo debug.

    Args:
        request: Request que contiene routing_exception.

    Raises:
        RequestRedirect | FormDataRoutingRedirect | RoutingException: Siempre relanza la excepción.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request` | `Request` | Sí | Request con `routing_exception`. |

#### `Flask.update_template_context()`

```python
def update_template_context(self, ctx: AppContext, context: dict[str, Any]) -> None:
    """Inyecta variables de contexto y procesadores en el contexto de plantilla.

    Args:
        ctx: Contexto de aplicación activo.
        context: Diccionario de contexto a actualizar in-place.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto de app. |
| `context` | `dict[str, Any]` | Sí | Contexto de plantilla. |

#### `Flask.make_shell_context()`

```python
def make_shell_context(self) -> dict[str, Any]:
    """Ejecuta shell_context_processors y retorna el contexto para flask shell.

    Returns:
        Diccionario con 'app', 'g' y valores de procesadores.
    """
```

#### `Flask.run()`

```python
def run(self, host: str | None = None, port: int | None = None, debug: bool | None = None, load_dotenv: bool = True, **options: Any) -> None:
    """Ejecuta el servidor de desarrollo Werkzeug.

    Args:
        host: Hostname. Default "127.0.0.1" o SERVER_NAME.
        port: Puerto. Default 5000 o SERVER_NAME.
        debug: Habilita/deshabilita modo debug.
        load_dotenv: Carga .env/.flaskenv.
        **options: Opciones para werkzeug.serving.run_simple (use_reloader, use_debugger, threaded, etc.).

    Returns:
        None. Bloquea hasta que el servidor termina.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `host` | `str \| None` | No | Default `None`. |
| `port` | `int \| None` | No | Default `None`. |
| `debug` | `bool \| None` | No | Default `None`. |
| `load_dotenv` | `bool` | No | Default `True`. |
| `**options` | `Any` | No | Opciones Werkzeug. |

#### `Flask.test_client()`

```python
def test_client(self, use_cookies: bool = True, **kwargs: Any) -> FlaskClient:
    """Crea un cliente de pruebas WSGI.

    Args:
        use_cookies: Si True, preserva cookies entre peticiones.
        **kwargs: Argumentos para test_client_class.

    Returns:
        Instancia de FlaskClient.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `use_cookies` | `bool` | No | Default `True`. |
| `**kwargs` | `Any` | No | Args para constructor del cliente. |

#### `Flask.test_cli_runner()`

```python
def test_cli_runner(self, **kwargs: Any) -> FlaskCliRunner:
    """Crea un runner para probar comandos CLI.

    Args:
        **kwargs: Argumentos para test_cli_runner_class.

    Returns:
        Instancia de FlaskCliRunner.
    """
```

#### `Flask.handle_http_exception()`

```python
def handle_http_exception(self, ctx: AppContext, e: HTTPException) -> HTTPException | ResponseReturnValue:
    """Maneja HTTPException invocando handlers registrados.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción HTTP.

    Returns:
        Respuesta del handler o la excepción original si no hay handler.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `HTTPException` | Sí | Excepción HTTP. |

#### `Flask.handle_user_exception()`

```python
def handle_user_exception(self, ctx: AppContext, e: Exception) -> HTTPException | ResponseReturnValue:
    """Maneja excepciones de usuario, delegando a handle_http_exception si aplica.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción capturada.

    Returns:
        Valor de respuesta del handler.

    Raises:
        Exception: Si no hay handler registrado, relanza e.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `Exception` | Sí | Excepción. |

#### `Flask.handle_exception()`

```python
def handle_exception(self, ctx: AppContext, e: Exception) -> Response:
    """Maneja excepciones no controladas generando 500 InternalServerError.

    Args:
        ctx: Contexto de aplicación.
        e: Excepción no manejada.

    Returns:
        Response finalizada (500 o del handler de 500).

    Raises:
        Exception: Si PROPAGATE_EXCEPTIONS es True, relanza e.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `e` | `Exception` | Sí | Excepción. |

#### `Flask.log_exception()`

```python
def log_exception(self, ctx: AppContext, exc_info: tuple[type, BaseException, TracebackType] | tuple[None, None, None]) -> None:
    """Registra una excepción en el logger de la app.

    Args:
        ctx: Contexto de aplicación.
        exc_info: Tupla exc_info de sys.exc_info().
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc_info` | `tuple` | Sí | Info de excepción. |

#### `Flask.dispatch_request()`

```python
def dispatch_request(self, ctx: AppContext) -> ResponseReturnValue:
    """Despacha la petición a la view function matcheada.

    Args:
        ctx: Contexto de aplicación con request.

    Returns:
        Valor de retorno de la vista.

    Raises:
        RequestRedirect | BuildError | KeyError: Errores de routing o vista no encontrada.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |

#### `Flask.full_dispatch_request()`

```python
def full_dispatch_request(self, ctx: AppContext) -> Response:
    """Ciclo completo: preprocess -> dispatch -> finalize con manejo de errores.

    Args:
        ctx: Contexto de aplicación.

    Returns:
        Response finalizada.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |

#### `Flask.finalize_request()`

```python
def finalize_request(self, ctx: AppContext, rv: ResponseReturnValue | HTTPException, from_error_handler: bool = False) -> Response:
    """Convierte rv en Response y ejecuta post-procesamiento.

    Args:
        ctx: Contexto de aplicación.
        rv: Valor de retorno de vista o excepción HTTP.
        from_error_handler: Si True, suprime errores en post-procesamiento y solo loguea.

    Returns:
        Response procesada.

    Raises:
        Exception: Si from_error_handler es False y process_response falla.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `rv` | `ResponseReturnValue \| HTTPException` | Sí | Valor a convertir. |
| `from_error_handler` | `bool` | No | Default `False`. |

#### `Flask.make_default_options_response()`

```python
def make_default_options_response(self, ctx: AppContext) -> Response:
    """Genera respuesta automática para método OPTIONS.

    Args:
        ctx: Contexto de aplicación.

    Returns:
        Response con header Allow poblado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |

#### `Flask.ensure_sync()`

```python
def ensure_sync(self, func: Callable[..., Any]) -> Callable[..., Any]:
    """Asegura que una función sea síncrona para workers WSGI.

    Args:
        func: Función sync o async.

    Returns:
        Función síncrona (original o envuelta vía async_to_sync).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `func` | `Callable[..., Any]` | Sí | Función a normalizar. |

#### `Flask.async_to_sync()`

```python
def async_to_sync(self, func: Callable[..., Coroutine[Any, Any, Any]]) -> Callable[..., Any]:
    """Convierte una corrutina en función síncrona bloqueante.

    Args:
        func: Función async def.

    Returns:
        Función síncrona que ejecuta la corrutina.

    Raises:
        RuntimeError: Si asgiref no está instalado y se requiere soporte async.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `func` | `Callable[..., Coroutine]` | Sí | Corrutina. |

#### `Flask.url_for()`

```python
def url_for(self, /, endpoint: str, *, _anchor: str | None = None, _method: str | None = None, _scheme: str | None = None, _external: bool | None = None, **values: Any) -> str:
    """Genera URL para un endpoint.

    Args:
        endpoint: Nombre del endpoint (puede ser relativo con ".").
        _anchor: Ancla a añadir como #anchor.
        _method: Método HTTP para discriminar regla.
        _scheme: Esquema (http/https) si _external=True.
        _external: Si True fuerza URL externa con dominio.
        **values: Valores para variables de URL y query string.

    Returns:
        URL generada como string.

    Raises:
        RuntimeError: Si se llama fuera de request y sin SERVER_NAME.
        ValueError: Si _scheme se especifica con _external=False.
        BuildError: Si handle_url_build_error no retorna string.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `endpoint` | `str` | Sí | Endpoint. |
| `_anchor` | `str \| None` | No | Default `None`. |
| `_method` | `str \| None` | No | Default `None`. |
| `_scheme` | `str \| None` | No | Default `None`. |
| `_external` | `bool \| None` | No | Default `None`. |
| `**values` | `Any` | No | Variables de URL. |

#### `Flask.make_response()`

```python
def make_response(self, rv: ResponseReturnValue) -> Response:
    """Convierte el valor de retorno de una vista en Response.

    Args:
        rv: Valor de retorno (str, bytes, dict, list, tuple, Response, WSGI callable, iterator).

    Returns:
        Instancia de response_class.

    Raises:
        TypeError: Si rv es None, tupla inválida o tipo no soportado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `rv` | `ResponseReturnValue` | Sí | Valor de vista. |

#### `Flask.preprocess_request()`

```python
def preprocess_request(self, ctx: AppContext) -> ResponseReturnValue | None:
    """Ejecuta url_value_preprocessors y before_request_funcs.

    Args:
        ctx: Contexto de aplicación.

    Returns:
        Valor de respuesta si un before_request lo retorna, None para continuar.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |

#### `Flask.process_response()`

```python
def process_response(self, ctx: AppContext, response: Response) -> Response:
    """Ejecuta after_request_funcs y guarda la sesión.

    Args:
        ctx: Contexto de aplicación.
        response: Response a procesar.

    Returns:
        Response modificada.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `response` | `Response` | Sí | Respuesta. |

#### `Flask.do_teardown_request()`

```python
def do_teardown_request(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta teardown_request_funcs y señal request_tearing_down.

    Args:
        ctx: Contexto de aplicación.
        exc: Excepción no manejada durante el dispatch o None.

    Raises:
        ExceptionGroup | Exception: Si algún teardown falla (colectadas vía _CollectErrors).
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc` | `BaseException \| None` | No | Default `None`. |

#### `Flask.do_teardown_appcontext()`

```python
def do_teardown_appcontext(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta teardown_appcontext_funcs y señal appcontext_tearing_down.

    Args:
        ctx: Contexto de aplicación.
        exc: Excepción durante el contexto o None.

    Raises:
        ExceptionGroup | Exception: Si algún teardown falla.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `ctx` | `AppContext` | Sí | Contexto. |
| `exc` | `BaseException \| None` | No | Default `None`. |

#### `Flask.app_context()`

```python
def app_context(self) -> AppContext:
    """Crea un AppContext sin request.

    Returns:
        Nuevo AppContext asociado a esta app.
    """
```

#### `Flask.request_context()`

```python
def request_context(self, environ: WSGIEnvironment) -> AppContext:
    """Crea un AppContext con información de request desde environ WSGI.

    Args:
        environ: Diccionario WSGI environ.

    Returns:
        AppContext con request, session y g disponibles al hacer push().
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |

#### `Flask.test_request_context()`

```python
def test_request_context(self, *args: Any, **kwargs: Any) -> AppContext:
    """Crea un AppContext de prueba usando EnvironBuilder.

    Args:
        *args: Argumentos posicionales para EnvironBuilder.
        **kwargs: Argumentos nominales para EnvironBuilder (path, base_url, subdomain, url_scheme, data, json, etc.).

    Returns:
        AppContext de prueba listo para usar en bloque with.
    """
```

#### `Flask.wsgi_app()`

```python
def wsgi_app(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
    """Aplicación WSGI real. Gestiona push/pop de contexto y manejo de errores.

    Args:
        environ: Entorno WSGI.
        start_response: Callable WSGI start_response(status, headers, exc_info).

    Returns:
        Iterable de bytes de la respuesta.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callback de inicio de respuesta. |

#### `Flask.__call__()`

```python
def __call__(self, environ: WSGIEnvironment, start_response: StartResponse) -> Iterable[bytes]:
    """Entry-point WSGI. Delega a wsgi_app para permitir middleware.

    Args:
        environ: Entorno WSGI.
        start_response: Callable WSGI.

    Returns:
        Iterable de bytes.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callback. |

---

## 3. Ejemplo de Uso

```python
from flask import Flask, request, jsonify, url_for

# 1. Creación de la aplicación
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SERVER_NAME"] = "example.com"
app.config["SECRET_KEY"] = "dev-secret-key"

# 2. Registro de vistas y manejo de contexto
@app.route("/hello/<name>", methods=["GET"])
def hello(name: str):
    # url_for usa Flask.url_for internamente
    profile_url = url_for("hello", name=name, _external=False)
    return jsonify(message=f"Hola {name}", url=profile_url)

@app.before_request
def log_request():
    print(f"Request: {request.method} {request.path}")

@app.teardown_request
def teardown_req(exc):
    if exc:
        print(f"Error en request: {exc}")

# 3. Uso de contextos fuera de request (scripts, tests)
with app.app_context():
    # Acceso a current_app, g y apertura de recursos
    with app.open_resource("schema.sql", mode="r", encoding="utf-8") as f:
        schema = f.read()

# 4. Cliente de pruebas y contexto de request de prueba
with app.test_client() as client:
    rv = client.get("/hello/Mundo")
    assert rv.status_code == 200
    assert rv.json["message"] == "Hola Mundo"

with app.test_request_context("/hello/Test?x=1"):
    assert request.args["x"] == "1"
    assert url_for("hello", name="Test") == "/hello/Test"

# 5. Ejecución como aplicación WSGI (desarrollo)
if __name__ == "__main__":
    # wsgi_app es invocado por el servidor; __call__ delega a wsgi_app
    app.run(host="127.0.0.1", port=5000, debug=True)

# 6. Uso como WSGI callable con middleware
# from werkzeug.middleware.proxy_fix import ProxyFix
# app.wsgi_app = ProxyFix(app.wsgi_app)
```
