# Documentación Técnica — Módulo `flask/app.py` (clase `Flask`)

## 1. Resumen ejecutivo

Este módulo define la clase `Flask`, la implementación WSGI concreta del framework (hereda de `App`, la capa *sansio*). Centraliza el ciclo de vida completo de una petición HTTP: creación del contexto, enrutamiento, despacho de la vista, normalización del valor de retorno a un objeto `Response`, manejo de errores HTTP/no controlados y ejecución de los *teardown handlers*.

Adicionalmente expone utilidades de infraestructura: construcción del entorno Jinja, generación de URLs (`url_for()`), acceso a recursos del paquete/instancia, servidor de desarrollo (`run()`), clientes de prueba y soporte para vistas `async` vía `asgiref`.

El módulo incluye también un mecanismo de compatibilidad retroactiva (`__init_subclass__()`, `remove_ctx()`, `add_ctx()`) que detecta subclases que sobrescriben métodos con la firma antigua (sin el parámetro `ctx: AppContext`) y las adapta emitiendo un `DeprecationWarning`.

---

## 2. Especificación de funciones y métodos

### 2.0 Elementos de módulo (contexto)

| Elemento | Tipo | Descripción |
|---|---|---|
| `T_shell_context_processor` | `TypeVar` | Acotado a `ft.ShellContextProcessorCallable`. |
| `T_teardown` | `TypeVar` | Acotado a `ft.TeardownCallable`. |
| `T_template_filter` | `TypeVar` | Acotado a `ft.TemplateFilterCallable`. |
| `T_template_global` | `TypeVar` | Acotado a `ft.TemplateGlobalCallable`. |
| `T_template_test` | `TypeVar` | Acotado a `ft.TemplateTestCallable`. |
| `F` | `TypeVar` | Acotado a `t.Callable[..., t.Any]`; usado por los decoradores de compatibilidad. |

Atributos de clase relevantes de `Flask`: `default_config` (`ImmutableDict`), `request_class` (`type[Request]`), `response_class` (`type[Response]`), `session_interface` (`SecureCookieSessionInterface()`), `cli` (`cli.AppGroup`, creado en `__init__`).

---

### 2.1 Funciones de nivel de módulo

#### `_make_timedelta()`

```python
def _make_timedelta(value: timedelta | int | None) -> timedelta | None:
    """Normaliza un valor de duración a `timedelta`.

    Args:
        value: `None`, un `timedelta` ya construido, o un número entero
            interpretado como segundos.

    Returns:
        `None` si la entrada es `None`; el mismo `timedelta` si ya lo era;
        en caso contrario `timedelta(seconds=value)`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `value` | `timedelta \| int \| None` | Sí | Duración a normalizar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `timedelta \| None` | Duración normalizada o `None`. |

| Raises | Condición |
|---|---|
| — | No lanza excepciones propias. |

> **Nota:** función privada (prefijo `_`), de uso interno del módulo.

---

#### `remove_ctx()`

Decorador de compatibilidad. Envuelve un método **sobrescrito por el usuario con la firma antigua** para descartar el argumento `ctx: AppContext` que la nueva implementación de Flask le pasa.

```python
def remove_ctx(f: F) -> F:
    """Elimina el argumento `ctx` inicial antes de invocar `f`.

    Args:
        f: Método de instancia con firma heredada (sin `ctx`).

    Returns:
        El método envuelto, con metadatos copiados vía `update_wrapper`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método a envolver. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `F` | Wrapper con `__name__`, `__doc__`, etc. de `f`. |

##### Función anidada `wrapper()` (dentro de `remove_ctx()`)

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `t.Any` | No | Argumentos posicionales; si `args[0]` es `AppContext` se descarta. |
| `**kwargs` | `t.Any` | No | Argumentos por nombre, reenviados sin alterar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `t.Any` | Resultado de `f(self, *args, **kwargs)`. |

| Raises | Condición |
|---|---|
| (propagadas) | Cualquier excepción lanzada por `f`. |

---

#### `add_ctx()`

Decorador de compatibilidad inverso. Envuelve el **método base de `Flask`** para que, cuando una subclase llame a `super().metodo(...)` sin `ctx`, se inyecte el contexto de aplicación activo.

```python
def add_ctx(f: F) -> F:
    """Inyecta el `AppContext` activo como primer argumento de `f`.

    Args:
        f: Método base de `Flask` que espera `ctx` como primer parámetro.

    Returns:
        El método envuelto, con metadatos copiados vía `update_wrapper`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `f` | `F` (`Callable[..., Any]`) | Sí | Método base a envolver. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `F` | Wrapper que garantiza la presencia de `ctx`. |

##### Función anidada `wrapper()` (dentro de `add_ctx()`)

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `Flask` | Sí | Instancia de la aplicación. |
| `*args` | `t.Any` | No | Si está vacío o `args[0]` no es `AppContext`, se prepende `app_ctx._get_current_object()`. |
| `**kwargs` | `t.Any` | No | Argumentos por nombre, reenviados sin alterar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `t.Any` | Resultado de `f(self, *args, **kwargs)`. |

| Raises | Condición |
|---|---|
| `RuntimeError` | Al resolver `app_ctx._get_current_object()` sin contexto de aplicación activo. |
| (propagadas) | Cualquier excepción lanzada por `f`. |

---

### 2.2 Métodos de la clase `Flask`

#### `__init_subclass__()`

```python
def __init_subclass__(cls, **kwargs: t.Any) -> None:
    """Detecta subclases con firmas de método obsoletas y las adapta.

    Recorre un conjunto fijo de métodos del ciclo de petición. Si la
    subclase los sobrescribe y el segundo parámetro no se llama `ctx`
    ni está anotado como `AppContext`, emite `DeprecationWarning` y
    aplica `remove_ctx()` al método de la subclase y `add_ctx()` al
    método base de `Flask`.

    Args:
        **kwargs: Argumentos de creación de clase, reenviados por el
            protocolo de `__init_subclass__`.
    """
```

Métodos inspeccionados: `handle_http_exception`, `handle_user_exception`, `handle_exception`, `log_exception`, `dispatch_request`, `full_dispatch_request`, `finalize_request`, `make_default_options_response`, `preprocess_request`, `process_response`, `do_teardown_request`, `do_teardown_appcontext`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `cls` | `type[Flask]` | Sí (implícito) | Subclase recién definida. |
| `**kwargs` | `t.Any` | No | Argumentos adicionales de definición de clase. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `None` | Efecto colateral: reemplaza métodos vía `setattr`. |

| Raises / Warns | Condición |
|---|---|
| `DeprecationWarning` (warning) | La subclase sobrescribe un método con la firma antigua. |
| `StopIteration` | Caso límite: el método sobrescrito no declara ni el parámetro `self`. |

---

#### `__init__()`

```python
def __init__(self, import_name, static_url_path=None, static_folder="static",
             static_host=None, host_matching=False, subdomain_matching=False,
             template_folder="templates", instance_path=None,
             instance_relative_config=False, root_path=None):
    """Inicializa la aplicación WSGI.

    Delega en `App.__init__`, crea el grupo de comandos Click
    (`self.cli`) y registra la ruta estática cuando existe
    `static_folder`, usando una `weakref` a la app para evitar ciclos
    de referencia.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `import_name` | `str` | Sí | — | Nombre del paquete/módulo de la aplicación. |
| `static_url_path` | `str \| None` | No | `None` | Ruta web de los archivos estáticos. |
| `static_folder` | `str \| os.PathLike[str] \| None` | No | `"static"` | Carpeta de archivos estáticos. |
| `static_host` | `str \| None` | No | `None` | Host de la ruta estática; obligatorio con `host_matching=True`. |
| `host_matching` | `bool` | No | `False` | Activa `url_map.host_matching`. |
| `subdomain_matching` | `bool` | No | `False` | Considera el subdominio relativo a `SERVER_NAME`. |
| `template_folder` | `str \| os.PathLike[str] \| None` | No | `"templates"` | Carpeta de plantillas. |
| `instance_path` | `str \| None` | No | `None` | Ruta alternativa de la carpeta *instance*. |
| `instance_relative_config` | `bool` | No | `False` | Resuelve rutas de configuración respecto a `instance_path`. |
| `root_path` | `str \| None` | No | `None` | Raíz de los archivos de la aplicación. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `None` | Constructor. |

| Raises | Condición |
|---|---|
| `AssertionError` | `bool(static_host) != host_matching` ("Invalid static_host/host_matching combination"). |

##### Callback anónimo (`lambda **kw`) registrado en `add_url_rule`

Función local sin nombre asignada como `view_func` del endpoint `"static"`.

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kw` | `t.Any` | No | Variables de la regla (`filename`), reenviadas a `send_static_file()`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Response` | Resultado de `self_ref().send_static_file(**kw)`. |

---

#### `get_send_file_max_age()`

```python
def get_send_file_max_age(self, filename: str | None) -> int | None:
    """Determina el valor de caché `max_age` para un archivo servido.

    Args:
        filename: Ruta del archivo a servir (puede ser `None`).

    Returns:
        Segundos de caché derivados de `SEND_FILE_MAX_AGE_DEFAULT`, o
        `None` para forzar peticiones condicionales.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str \| None` | Sí | Nombre/ruta del archivo. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `int \| None` | `int(value.total_seconds())` si la config es `timedelta`; el valor tal cual si es `int`; `None` si no está configurado. |

| Raises | Condición |
|---|---|
| — | No lanza excepciones propias. |

---

#### `send_static_file()`

```python
def send_static_file(self, filename: str) -> Response:
    """Vista registrada automáticamente para servir `static_folder`.

    Args:
        filename: Ruta relativa dentro de `static_folder`.

    Returns:
        Respuesta generada por `send_from_directory`.

    Raises:
        RuntimeError: Si `static_folder` no está configurado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `filename` | `str` | Sí | Ruta relativa del archivo estático. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Response` | Respuesta de archivo con `max_age` calculado por `get_send_file_max_age()`. |

| Raises | Condición |
|---|---|
| `RuntimeError` | `self.has_static_folder` es falso. |
| (propagadas) | Errores emitidos por `send_from_directory`. |

---

#### `open_resource()`

```python
def open_resource(self, resource, mode="rb", encoding=None) -> t.IO[t.AnyStr]:
    """Abre un recurso relativo a `root_path` en modo lectura.

    Raises:
        ValueError: Si `mode` no es `"r"`, `"rt"` o `"rb"`.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `resource` | `str` | Sí | — | Ruta relativa a `root_path`. |
| `mode` | `str` | No | `"rb"` | Solo lectura: `"r"`, `"rt"` o `"rb"`. |
| `encoding` | `str \| None` | No | `None` | Codificación en modo texto; ignorada en binario. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `t.IO[t.AnyStr]` | Descriptor de archivo abierto. |

| Raises | Condición |
|---|---|
| `ValueError` | Modo no permitido (escritura). |
| `OSError` / `FileNotFoundError` | El archivo no existe o no es accesible. |

---

#### `open_instance_resource()`

```python
def open_instance_resource(self, resource, mode="rb", encoding="utf-8") -> t.IO[t.AnyStr]:
    """Abre un recurso relativo a `instance_path`.

    A diferencia de `open_resource()`, admite modos de escritura.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `resource` | `str` | Sí | — | Ruta relativa a `instance_path`. |
| `mode` | `str` | No | `"rb"` | Cualquier modo válido de `open()`. |
| `encoding` | `str \| None` | No | `"utf-8"` | Codificación en modo texto; ignorada si `"b"` está en `mode`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `t.IO[t.AnyStr]` | Descriptor de archivo abierto. |

| Raises | Condición |
|---|---|
| `OSError` / `FileNotFoundError` | Ruta inexistente o sin permisos. |
| `ValueError` | Modo inválido reportado por `open()`. |

---

#### `create_jinja_environment()`

```python
def create_jinja_environment(self) -> Environment:
    """Construye el entorno Jinja a partir de `jinja_options`.

    Aplica `select_jinja_autoescape` y `auto_reload` (derivado de
    `TEMPLATES_AUTO_RELOAD` o de `debug`), e inyecta los globales
    `url_for`, `get_flashed_messages`, `config`, `request`, `session`
    y `g`, además de la política `json.dumps_function`.

    Returns:
        Instancia de `Environment` lista para renderizar.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Solo recibe `self`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Environment` | Entorno Jinja configurado. |

| Raises | Condición |
|---|---|
| — | No lanza excepciones propias. |

---

#### `create_url_adapter()`

```python
def create_url_adapter(self, request: Request | None) -> MapAdapter | None:
    """Crea un `MapAdapter` para una petición o para el contexto de app.

    Args:
        request: Petición activa, o `None` para construir el adaptador
            a partir de `SERVER_NAME`, `APPLICATION_ROOT` y
            `PREFERRED_URL_SCHEME`.

    Returns:
        El adaptador construido, o `None` si no hay petición ni
        `SERVER_NAME` configurado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request \| None` | Sí | Petición a enlazar; `None` fuera de petición. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `MapAdapter \| None` | Adaptador de rutas o `None`. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores de `get_host`/`bind_to_environ` (p. ej. host no confiable). |

---

#### `raise_routing_exception()`

```python
def raise_routing_exception(self, request: Request) -> t.NoReturn:
    """Relanza la excepción de enrutamiento de la petición.

    En modo debug sustituye los redirects que descartarían el cuerpo
    (distintos de 307/308 y en métodos con cuerpo) por
    `FormDataRoutingRedirect`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request` | `Request` | Sí | Petición cuyo `routing_exception` se relanza. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `t.NoReturn` | Nunca retorna. |

| Raises | Condición |
|---|---|
| `request.routing_exception` | Fuera de debug, o códigos 307/308, o métodos `GET`/`HEAD`/`OPTIONS`. |
| `FormDataRoutingRedirect` | En debug, con redirect que descartaría el cuerpo del formulario. |

---

#### `update_template_context()`

```python
def update_template_context(self, ctx: AppContext, context: dict[str, t.Any]) -> None:
    """Inyecta variables comunes y procesadores de contexto.

    Args:
        ctx: Contexto de aplicación activo (usado para obtener los
            blueprints de la petición, si hay petición).
        context: Diccionario de contexto modificado in-place. Sus
            valores originales se reaplican al final y tienen prioridad.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `context` | `dict[str, t.Any]` | Sí | Contexto de plantilla actualizado in-place. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `None` | Mutación in-place de `context`. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores de los *context processors* registrados. |

---

#### `make_shell_context()`

```python
def make_shell_context(self) -> dict[str, t.Any]:
    """Construye el namespace del shell interactivo.

    Returns:
        Diccionario con `app`, `g` y el resultado de todos los
        `shell_context_processors` registrados.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Solo recibe `self`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `dict[str, t.Any]` | Namespace del shell. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores de los procesadores de contexto de shell. |

---

#### `run()`

```python
def run(self, host=None, port=None, debug=None, load_dotenv=True, **options) -> None:
    """Arranca el servidor de desarrollo de Werkzeug.

    No apto para producción. Ignora la llamada (con aviso en consola)
    si se detecta `FLASK_RUN_FROM_CLI=true`. Resuelve host/puerto desde
    `SERVER_NAME` cuando no se indican y restaura
    `_got_first_request = False` al finalizar.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `host` | `str \| None` | No | `None` | Host de escucha; fallback a `SERVER_NAME` o `127.0.0.1`. |
| `port` | `int \| None` | No | `None` | Puerto; fallback a `SERVER_NAME` o `5000`. |
| `debug` | `bool \| None` | No | `None` | Fuerza el modo debug (prioridad máxima). |
| `load_dotenv` | `bool` | No | `True` | Carga `.env` / `.flaskenv`. |
| `**options` | `t.Any` | No | — | Reenviados a `werkzeug.serving.run_simple` (`use_reloader`, `use_debugger`, `threaded` con defaults). |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `None` | Bloquea hasta la parada del servidor. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores de `run_simple` (p. ej. `OSError` por puerto ocupado). |

---

#### `test_client()`

```python
def test_client(self, use_cookies: bool = True, **kwargs: t.Any) -> FlaskClient:
    """Crea un cliente de pruebas WSGI.

    Returns:
        Instancia de `test_client_class` o, si no está definida, de
        `flask.testing.FlaskClient`.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `use_cookies` | `bool` | No | `True` | Mantiene cookies entre peticiones. |
| `**kwargs` | `t.Any` | No | — | Reenviados al constructor de `test_client_class`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `FlaskClient` | Cliente de pruebas. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores del constructor del cliente personalizado. |

---

#### `test_cli_runner()`

```python
def test_cli_runner(self, **kwargs: t.Any) -> FlaskCliRunner:
    """Crea un runner para probar comandos CLI.

    Returns:
        Instancia de `test_cli_runner_class` o de
        `flask.testing.FlaskCliRunner` por defecto, con la app como
        primer argumento.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `**kwargs` | `t.Any` | No | Reenviados al constructor del runner. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `FlaskCliRunner` | Runner de CLI. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores del constructor del runner. |

---

#### `handle_http_exception()`

```python
def handle_http_exception(self, ctx, e) -> HTTPException | ft.ResponseReturnValue:
    """Resuelve una `HTTPException` con el manejador registrado.

    Devuelve la excepción sin cambios si no tiene código (excepciones
    proxy) o si es una `RoutingException`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (aporta `ctx.request.blueprints`). |
| `e` | `HTTPException` | Sí | Excepción HTTP a manejar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `HTTPException \| ft.ResponseReturnValue` | La excepción misma o el valor devuelto por el *error handler*. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores lanzados por el manejador de errores. |

---

#### `handle_user_exception()`

```python
def handle_user_exception(self, ctx, e) -> HTTPException | ft.ResponseReturnValue:
    """Resuelve cualquier excepción con manejador registrado.

    Delega en `handle_http_exception()` para `HTTPException` no
    atrapadas. Activa `show_exception` en `BadRequestKeyError` bajo
    debug o `TRAP_BAD_REQUEST_ERRORS`.

    Raises:
        Exception: Relanza la excepción activa si no hay manejador.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción a manejar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `HTTPException \| ft.ResponseReturnValue` | Valor de respuesta o excepción HTTP. |

| Raises | Condición |
|---|---|
| (re-raise `bare raise`) | No existe manejador registrado para `e`. |

---

#### `handle_exception()`

```python
def handle_exception(self, ctx: AppContext, e: Exception) -> Response:
    """Convierte una excepción no manejada en un error 500.

    Envía siempre `got_request_exception`. Si `PROPAGATE_EXCEPTIONS`
    (o `testing`/`debug`) está activo, relanza. En caso contrario
    registra el error y finaliza la petición con un
    `InternalServerError` que expone `original_exception`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `e` | `Exception` | Sí | Excepción no controlada. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Response` | Respuesta final (`finalize_request(..., from_error_handler=True)`). |

| Raises | Condición |
|---|---|
| `Exception` (`e` o la activa) | `PROPAGATE_EXCEPTIONS` resuelto a verdadero. |

---

#### `log_exception()`

```python
def log_exception(self, ctx, exc_info) -> None:
    """Registra la excepción como `error` en `self.logger`."""
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo (aporta `path` y `method`). |
| `exc_info` | `tuple[type, BaseException, TracebackType] \| tuple[None, None, None]` | Sí | Información de excepción estilo `sys.exc_info()`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `None` | Efecto colateral de logging. |

| Raises | Condición |
|---|---|
| — | No lanza excepciones propias. |

---

#### `dispatch_request()`

```python
def dispatch_request(self, ctx: AppContext) -> ft.ResponseReturnValue:
    """Empareja la URL e invoca la vista correspondiente.

    Responde automáticamente a `OPTIONS` cuando la regla tiene
    `provide_automatic_options`. No realiza manejo de errores.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con la petición enrutada. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `ft.ResponseReturnValue` | Valor crudo de la vista (no necesariamente `Response`). |

| Raises | Condición |
|---|---|
| `RoutingException` / `FormDataRoutingRedirect` | Vía `raise_routing_exception()` si `req.routing_exception` no es `None`. |
| (propagadas) | Excepciones de la función de vista. |

---

#### `full_dispatch_request()`

```python
def full_dispatch_request(self, ctx: AppContext) -> Response:
    """Ejecuta el ciclo completo: pre-proceso, despacho y finalización.

    Envía `request_started`, ejecuta `preprocess_request()` y
    `dispatch_request()`, captura excepciones con
    `handle_user_exception()` y finaliza con `finalize_request()`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo ya empujado. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Response` | Respuesta completamente procesada. |

| Raises / Warns | Condición |
|---|---|
| `DeprecationWarning` (warning) | Primera petición con `should_ignore_error` definido. |
| (propagadas) | Excepciones no capturadas por `handle_user_exception()` o surgidas en `finalize_request()`. |

---

#### `finalize_request()`

```python
def finalize_request(self, ctx, rv, from_error_handler=False) -> Response:
    """Convierte el valor de la vista en respuesta y post-procesa.

    Llama a `make_response()`, `process_response()` y envía
    `request_finished`. Con `from_error_handler=True`, los fallos de
    post-procesado se registran y se ignoran.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `ctx` | `AppContext` | Sí | — | Contexto activo. |
| `rv` | `ft.ResponseReturnValue \| HTTPException` | Sí | — | Valor devuelto por la vista o el *error handler*. |
| `from_error_handler` | `bool` | No | `False` | Activa el modo seguro ante errores de finalización. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Response` | Respuesta final. |

| Raises | Condición |
|---|---|
| `Exception` | Error en `process_response()`/señal con `from_error_handler=False`. |
| `TypeError` | Propagado desde `make_response()` ante un valor de retorno inválido. |

---

#### `make_default_options_response()`

```python
def make_default_options_response(self, ctx: AppContext) -> Response:
    """Crea la respuesta por defecto para peticiones `OPTIONS`.

    Returns:
        Instancia de `response_class` con el header `Allow` poblado a
        partir de `ctx.url_adapter.allowed_methods()`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto con `url_adapter` disponible. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Response` | Respuesta `OPTIONS` con métodos permitidos. |

| Raises | Condición |
|---|---|
| `AttributeError` | `ctx.url_adapter` es `None` (caso no esperado durante una petición). |

---

#### `ensure_sync()`

```python
def ensure_sync(self, func: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Garantiza que un callable sea ejecutable de forma síncrona.

    Args:
        func: Función de vista, hook o manejador.

    Returns:
        `func` sin cambios si es síncrona; el resultado de
        `async_to_sync()` si es una corrutina.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `t.Callable[..., t.Any]` | Sí | Callable a normalizar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `t.Callable[..., t.Any]` | Callable síncrono. |

| Raises | Condición |
|---|---|
| `RuntimeError` | Propagado de `async_to_sync()` si falta el extra `async`. |

---

#### `async_to_sync()`

```python
def async_to_sync(self, func) -> t.Callable[..., t.Any]:
    """Envuelve una función corrutina para invocarla síncronamente.

    Raises:
        RuntimeError: Si `asgiref` no está instalado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `func` | `t.Callable[..., t.Coroutine[t.Any, t.Any, t.Any]]` | Sí | Función `async def`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `t.Callable[..., t.Any]` | Wrapper síncrono de `asgiref.sync.async_to_sync`. |

| Raises | Condición |
|---|---|
| `RuntimeError` | `ImportError` de `asgiref.sync` ("Install Flask with the 'async' extra..."). |

---

#### `url_for()`

```python
def url_for(self, /, endpoint, *, _anchor=None, _method=None, _scheme=None,
            _external=None, **values) -> str:
    """Construye la URL de un endpoint.

    Resuelve endpoints relativos (`.nombre`) con el blueprint actual,
    aplica `inject_url_defaults()` y delega en `MapAdapter.build`. Los
    errores de construcción se derivan a `handle_url_build_error()`.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `endpoint` | `str` | Sí | — | Nombre del endpoint (posicional-only por `/`). |
| `_anchor` | `str \| None` | No | `None` | Fragmento `#anchor` (escapado con `urllib.parse.quote`). |
| `_method` | `str \| None` | No | `None` | Método HTTP asociado a la regla. |
| `_scheme` | `str \| None` | No | `None` | Esquema para URLs externas. |
| `_external` | `bool \| None` | No | `None` | Fuerza URL absoluta/relativa; por defecto `True` fuera de petición. |
| `**values` | `t.Any` | No | — | Variables de la regla; las desconocidas se añaden como query string. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `str` | URL construida (con anchor si se indicó). |

| Raises | Condición |
|---|---|
| `ValueError` | `_scheme` indicado con `_external=False`. |
| `RuntimeError` | Sin petición activa y sin `SERVER_NAME` (adaptador `None`). |
| `BuildError` | Si `handle_url_build_error()` no devuelve una cadena alternativa. |

---

#### `make_response()`

```python
def make_response(self, rv: ft.ResponseReturnValue) -> Response:
    """Normaliza el valor de retorno de una vista a `response_class`.

    Acepta `str`, `bytes`, `dict`, `list`, generadores/iteradores,
    tuplas `(body, status, headers)` / `(body, status)` /
    `(body, headers)`, instancias de `Response`, otras subclases de
    `BaseResponse` y callables WSGI.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `rv` | `ft.ResponseReturnValue` | Sí | Valor devuelto por la vista. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Response` | Instancia de `response_class` con status y headers aplicados. |

| Raises | Condición |
|---|---|
| `TypeError` | Tupla de tamaño distinto de 2 o 3. |
| `TypeError` | `rv is None` (la vista no devolvió nada). |
| `TypeError` | `force_type()` falla al coercionar un callable/`BaseResponse`. |
| `TypeError` | Tipo de retorno no soportado. |

---

#### `preprocess_request()`

```python
def preprocess_request(self, ctx: AppContext) -> ft.ResponseReturnValue | None:
    """Ejecuta los hooks previos al despacho.

    Invoca `url_value_preprocessors` y luego `before_request_funcs` de
    la app y los blueprints implicados.

    Returns:
        El primer valor no-`None` devuelto por un `before_request`
        (cortocircuita el despacho), o `None`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `ft.ResponseReturnValue \| None` | Respuesta anticipada o `None`. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores de los preprocesadores o de los hooks `before_request`. |

---

#### `process_response()`

```python
def process_response(self, ctx: AppContext, response: Response) -> Response:
    """Aplica los hooks posteriores y guarda la sesión.

    Ejecuta `ctx._after_request_functions`, los `after_request_funcs`
    de blueprints y app (en orden inverso de registro) y persiste la
    sesión si no es una *null session*.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `ctx` | `AppContext` | Sí | Contexto activo. |
| `response` | `Response` | Sí | Respuesta a post-procesar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `Response` | Respuesta resultante (misma instancia o una nueva). |

| Raises | Condición |
|---|---|
| (propagadas) | Errores de los hooks `after_request` o de `save_session`. |

---

#### `do_teardown_request()`

```python
def do_teardown_request(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta todos los `teardown_request` y la señal asociada.

    Usa `_CollectErrors` para invocar todos los callbacks aunque
    alguno falle, y relanza los errores agrupados al final.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `ctx` | `AppContext` | Sí | — | Contexto de la petición. |
| `exc` | `BaseException \| None` | No | `None` | Excepción no manejada, pasada a cada callback. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `None` | Efecto colateral; envía `request_tearing_down`. |

| Raises | Condición |
|---|---|
| (agrupadas por `collect_errors.raise_any`) | Uno o más callbacks/receptores fallaron ("Errors during request teardown"). |

---

#### `do_teardown_appcontext()`

```python
def do_teardown_appcontext(self, ctx: AppContext, exc: BaseException | None = None) -> None:
    """Ejecuta todos los `teardown_appcontext` y la señal asociada.

    Recolecta errores con `_CollectErrors` y los relanza agrupados.
    """
```

| Parámetro | Tipo | Requerido | Default | Descripción |
|---|---|---|---|---|
| `ctx` | `AppContext` | Sí | — | Contexto de aplicación en cierre. |
| `exc` | `BaseException \| None` | No | `None` | Excepción no manejada, pasada a cada callback. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `None` | Efecto colateral; envía `appcontext_tearing_down`. |

| Raises | Condición |
|---|---|
| (agrupadas por `collect_errors.raise_any`) | Uno o más callbacks/receptores fallaron ("Errors during app teardown"). |

---

#### `app_context()`

```python
def app_context(self) -> AppContext:
    """Crea un `AppContext` para usar como gestor de contexto.

    Returns:
        Un `AppContext(self)` no empujado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | Solo recibe `self`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `AppContext` | Contexto de aplicación. |

| Raises | Condición |
|---|---|
| — | No lanza excepciones propias. |

---

#### `request_context()`

```python
def request_context(self, environ: WSGIEnvironment) -> AppContext:
    """Crea un `AppContext` con información de petición desde un environ WSGI.

    Args:
        environ: Entorno WSGI válido.

    Returns:
        `AppContext.from_environ(self, environ)`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `AppContext` | Contexto con petición asociada. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores de `AppContext.from_environ` ante un environ inválido. |

---

#### `test_request_context()`

```python
def test_request_context(self, *args: t.Any, **kwargs: t.Any) -> AppContext:
    """Crea un `AppContext` con petición sintética para pruebas.

    Construye el environ con `flask.testing.EnvironBuilder` (cerrado
    siempre en el bloque `finally`) y delega en `request_context()`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `*args` | `t.Any` | No | Posicionales para `EnvironBuilder` (`path`, `base_url`, ...). |
| `**kwargs` | `t.Any` | No | Nombrados para `EnvironBuilder` (`subdomain`, `url_scheme`, `data`, `json`, ...). |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `AppContext` | Contexto de petición listo para `with`. |

| Raises | Condición |
|---|---|
| (propagadas) | Errores de construcción del `EnvironBuilder` (argumentos inválidos). |

---

#### `wsgi_app()`

```python
def wsgi_app(self, environ, start_response) -> cabc.Iterable[bytes]:
    """Implementación real de la aplicación WSGI.

    Empuja el contexto, despacha, maneja excepciones con
    `handle_exception()` y garantiza el `ctx.pop(error)` en `finally`.
    Soporta `werkzeug.debug.preserve_context` y el filtrado opcional
    mediante `should_ignore_error`.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI de la petición. |
| `start_response` | `StartResponse` | Sí | Callable WSGI para iniciar la respuesta. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `cabc.Iterable[bytes]` | Iterable del cuerpo de la respuesta. |

| Raises | Condición |
|---|---|
| `BaseException` | Excepciones que no heredan de `Exception` (p. ej. `KeyboardInterrupt`, `SystemExit`) se relanzan tras registrarse en `error`. |
| `Exception` | Relanzada por `handle_exception()` si `PROPAGATE_EXCEPTIONS` está activo. |

---

#### `__call__()`

```python
def __call__(self, environ, start_response) -> cabc.Iterable[bytes]:
    """Punto de entrada WSGI; delega en `wsgi_app()`."""
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `environ` | `WSGIEnvironment` | Sí | Entorno WSGI. |
| `start_response` | `StartResponse` | Sí | Callable WSGI de inicio de respuesta. |

| Retorno | Tipo | Descripción |
|---|---|---|
| — | `cabc.Iterable[bytes]` | Resultado de `self.wsgi_app(environ, start_response)`. |

| Raises | Condición |
|---|---|
| (propagadas) | Todas las de `wsgi_app()`. |

---

## 3. Ejemplo de uso

```python
"""Ejemplo integral: creación de la app, vistas, hooks, errores,
contextos y pruebas usando la API documentada arriba."""

from datetime import timedelta

from flask import Flask, g, request

# --- 1. Construcción de la aplicación (Flask.__init__) ---------------------
app = Flask(
    __name__,
    static_folder="static",
    static_url_path="/assets",
    template_folder="templates",
    instance_relative_config=True,
)
app.config.update(
    SERVER_NAME="example.com",
    PREFERRED_URL_SCHEME="https",
    SEND_FILE_MAX_AGE_DEFAULT=timedelta(hours=1),  # get_send_file_max_age()
)


# --- 2. Vistas y hooks del ciclo de petición -------------------------------
@app.route("/")
def index() -> str:
    # dispatch_request() -> make_response() convierte el str en Response
    return "Hola"


@app.route("/api/users")
def users():
    # make_response() convierte list/dict en respuesta JSON
    return [{"id": 1, "name": "Ada"}], 200, {"X-Total-Count": "1"}


@app.before_request
def attach_request_id() -> None:
    # Ejecutado por preprocess_request()
    g.request_id = request.headers.get("X-Request-Id", "local")


@app.after_request
def add_request_id(response):
    # Ejecutado por process_response()
    response.headers["X-Request-Id"] = g.get("request_id", "unknown")
    return response


@app.teardown_request
def close_resources(exc: BaseException | None) -> None:
    # Ejecutado por do_teardown_request()
    if exc is not None:
        app.logger.warning("Petición finalizada con error: %r", exc)


@app.teardown_appcontext
def close_db(exc: BaseException | None) -> None:
    # Ejecutado por do_teardown_appcontext()
    db = g.pop("db", None)
    if db is not None:
        db.close()


@app.shell_context_processor
def shell_namespace() -> dict:
    # Consumido por make_shell_context()
    return {"app": app}


@app.errorhandler(404)
def not_found(e):
    # Consumido por handle_http_exception() / handle_user_exception()
    return {"error": "not found"}, 404


# --- 3. Recursos, URLs y contextos -----------------------------------------
with app.app_context():                      # app_context()
    with app.open_resource("schema.sql", mode="r", encoding="utf-8") as f:
        schema = f.read()                    # open_resource()

    # url_for() fuera de petición: externa por defecto (requiere SERVER_NAME)
    print(app.url_for("users", _anchor="top"))
    # -> https://example.com/api/users#top

    print(app.make_shell_context().keys())   # make_shell_context()

with app.test_request_context("/?q=flask"):  # test_request_context()
    assert request.args["q"] == "flask"
    print(app.url_for("index"))              # -> /  (relativa dentro de petición)
    env = app.create_jinja_environment()     # create_jinja_environment()
    ctx_vars: dict = {}
    from flask.globals import app_ctx
    app.update_template_context(app_ctx._get_current_object(), ctx_vars)


# --- 4. Pruebas -------------------------------------------------------------
app.testing = True                           # propaga excepciones al cliente

with app.test_client() as client:            # test_client()
    rv = client.get("/api/users")
    assert rv.status_code == 200
    assert rv.headers["X-Total-Count"] == "1"
    assert client.get("/no-existe").status_code == 404

runner = app.test_cli_runner()               # test_cli_runner()
result = runner.invoke(args=["routes"])
print(result.output)


# --- 5. Middleware WSGI y servidor de desarrollo ---------------------------
from werkzeug.middleware.proxy_fix import ProxyFix

# Se envuelve wsgi_app, no la app, para conservar la referencia al objeto.
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)

if __name__ == "__main__":
    # run() solo para desarrollo; ignorado si se usa `flask run`.
    app.run(host="127.0.0.1", port=5000, debug=True, use_reloader=False)
```

### Ejemplo complementario: vistas asíncronas y subclase con firma moderna

```python
import typing as t

from flask import Flask
from flask.ctx import AppContext


class AuditedFlask(Flask):
    """Subclase con la firma NUEVA (recibe `ctx`), sin DeprecationWarning."""

    def log_exception(
        self,
        ctx: AppContext,
        exc_info: tuple[type, BaseException, t.Any] | tuple[None, None, None],
    ) -> None:
        self.logger.error("AUDIT %s", ctx.request.path, exc_info=exc_info)
        super().log_exception(ctx, exc_info)

    def ensure_sync(self, func):
        # Punto de extensión para cambiar la ejecución de vistas async.
        return super().ensure_sync(func)


app = AuditedFlask(__name__)


@app.route("/async")
async def async_view() -> str:
    # ensure_sync() -> async_to_sync(); requiere `pip install "flask[async]"`
    return "resultado async"
```