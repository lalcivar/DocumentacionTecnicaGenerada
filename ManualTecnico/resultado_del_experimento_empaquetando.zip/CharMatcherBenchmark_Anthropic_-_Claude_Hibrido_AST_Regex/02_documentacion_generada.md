# Documentación Técnica — `com.google.common.base.CharMatcherBenchmark`

---

## 1. Resumen ejecutivo

`CharMatcherBenchmark` es un *harness* de micro-benchmarking (basado en anotaciones de Caliper) cuyo propósito es medir el rendimiento de las operaciones de la clase `CharMatcher` de Guava, concretamente `trimAndCollapseFrom(...)` y `matches(char)`. La clase construye de forma determinista cadenas sintéticas de entrada parametrizadas por longitud, porcentaje de caracteres coincidentes, configuración de matcher (`SampleMatcherConfig`), precomputación y tamaño de la representación interna (`SmallCharMatcher` vs. matcher por defecto).

Adicionalmente contiene la clase anidada estática `CharSamples`, un generador de *code points* Unicode que sigue una distribución acumulada empírica derivada de contenido web, almacenada en dos tablas estáticas (`prob` y `chars`) que se inicializan en cuatro fases debido a la limitación del tamaño del pool de constantes/método en Java.

**Dependencias del código fuente provisto:** `com.google.caliper.{BeforeExperiment, Benchmark, Param}`, `BenchmarkHelpers.SampleMatcherConfig`, `CharMatcher`, `SmallCharMatcher`, `java.util.{ArrayList, BitSet, Collections, List, Random}`, `org.jspecify.annotations.NullUnmarked`.

---

## 2. Especificación de la clase

| Elemento | Valor |
|---|---|
| Nombre completo | `com.google.common.base.CharMatcherBenchmark` |
| Modificadores | `public`, anotada con `@NullUnmarked` |
| `@author` | David Beaumont, Kevin Bourrillion, David Richter |
| Tipos anidados | `enum Size`, `static class CharSamples` |
| Constructor | Implícito `public CharMatcherBenchmark()` (no declarado en el fuente) |

### 2.1 Estado / campos inyectados por Caliper

| Campo | Tipo | Visibilidad | Anotación | Descripción |
|---|---|---|---|---|
| `config` | `SampleMatcherConfig` | package-private | `@Param` | Configuración global: expone `config.matcher` (el `CharMatcher` bajo prueba) y `config.matchingChars` (alfabeto de caracteres que el matcher acepta). |
| `length` | `int` | package-private | `@Param({"64","1024"})` | Longitud de la cadena de entrada generada. |
| `percent` | `int` | package-private | `@Param({"0","10","50","100"})` | Porcentaje objetivo de caracteres coincidentes en la cadena. |
| `precomputed` | `boolean` | package-private | `@Param("true")` | Si `true`, se usa `config.matcher.precomputed()`. |
| `size` | `Size` | package-private | `@Param` | `DEFAULT` o `SMALL`; `SMALL` fuerza el uso de `SmallCharMatcher`. |
| `forceSlow` | `boolean` | package-private | `@Param("false")` | Fuerza un carácter coincidente en la posición 0 para activar el camino de *trimming*. |
| `web` | `boolean` | package-private | `@Param("false")` | Si `true`, la cadena se genera con el muestreador `CharSamples` (distribución web) ignorando `percent`/`matchingChars`. |
| `matcher` | `CharMatcher` | `private` | — | Matcher efectivo resuelto en `setUp()`. |
| `string` | `String` | `private` | — | Cadena de entrada generada en `setUp()`. |
| `NONMATCHING_CHARS` | `String` | `private static final` | — | Alfabeto `"abcdefghijklmnopqrstuvwxyz0123456789"` usado para posiciones *no* coincidentes. |

### 2.2 `enum Size`

| Constante | Semántica |
|---|---|
| `DEFAULT` | Se conserva el `CharMatcher` resuelto por `config`/`precomputed`. |
| `SMALL` | Se vuelca el matcher a un `BitSet` y se reconstruye vía `SmallCharMatcher.from(BitSet, String)`. |

---

## 3. Especificación de métodos y constructores

### 3.1 `CharMatcherBenchmark()` *(constructor implícito)*

```java
/**
 * Constructor por defecto generado por el compilador. Caliper instancia la clase
 * mediante este constructor sin argumentos e inyecta posteriormente los campos
 * anotados con {@code @Param}.
 */
public CharMatcherBenchmark()
```

| @param | Tipo | Requerido |
|---|---|---|
| *(ninguno)* | — | — |

| @return | @throws |
|---|---|
| Nueva instancia con `matcher` y `string` en `null`. | Ninguna. |

> **Nota de contrato:** invocar `trimAndCollapseFromString(int)` o `matches(int)` sin llamar previamente a `setUp()` produce `NullPointerException`.

---

### 3.2 `setUp()`

```java
/**
 * Prepara el estado del experimento: resuelve el {@link CharMatcher} efectivo
 * (precomputado y/o convertido a {@code SmallCharMatcher}) y genera la cadena de
 * entrada mediante {@code checkString(...)} con una instancia nueva de
 * {@link Random}.
 *
 * <p>Caliper invoca este método después de inyectar todos los parámetros.
 */
@BeforeExperiment
void setUp()
```

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| *(ninguno)* | — | — | Opera exclusivamente sobre los campos inyectados. |

| @return | Descripción |
|---|---|
| `void` | Efectos laterales: asigna `this.matcher` y `this.string`. |

| @throws | Condición |
|---|---|
| `NullPointerException` | Si `config`, `config.matcher`, `config.matchingChars` o `size` no han sido inyectados. |
| `NegativeArraySizeException` / `IllegalArgumentException` | Propagadas indirectamente si `length` es negativo (al construir el `StringBuilder`) o si `percent`/`matchingChars` producen alfabetos vacíos en `randomCharFrom`. |

**Flujo interno:**
1. `matcher = precomputed ? config.matcher.precomputed() : config.matcher`.
2. Si `size == Size.SMALL`: crea `BitSet tmp`, invoca `matcher.setBits(tmp)` y reemplaza `matcher` por `SmallCharMatcher.from(tmp, "")`.
3. `string = checkString(length, percent, config.matchingChars, new Random(), forceSlow, web)` — `Random` sin semilla fija: las cadenas no son reproducibles entre ejecuciones.

---

### 3.3 `trimAndCollapseFromString(int reps)`

```java
/**
 * Mide el coste de {@code CharMatcher.trimAndCollapseFrom(CharSequence, char)}
 * sobre la cadena precalculada, usando '!' como carácter de reemplazo.
 *
 * @param reps número de repeticiones solicitadas por el framework
 * @return acumulador de longitudes (valor "dummy" para evitar eliminación por JIT)
 */
@Benchmark
int trimAndCollapseFromString(int reps)
```

| @param | Tipo | Requerido | Descripción |
|---|---|---|---|
| `reps` | `int` | Sí