# Documentación Técnica - Clase `FuturesTest`

### 1. Información General

| Atributo | Valor |
| :--- | :--- |
| **Nombre de la Clase** | `FuturesTest` |
| **Paquete** | `com.google.common.util.concurrent` |
| **Archivo** | `FuturesTest.java` |
| **Herencia** | `extends junit.framework.TestCase` |
| **Autor** | Nishant Thakkar |
| **Licencia** | Apache License 2.0 |
| **Anotaciones** | `@NullMarked`, `@GwtCompatible` |
| **Dependencias Principales** | Guava, JUnit 3, Truth, `ListenableFuture`, `SettableFuture` |
| **Clase bajo prueba** | `com.google.common.util.concurrent.Futures` |

> **Nota Importante:** Esta clase **no es** la clase de utilidad `Futures`. Es la **suite de pruebas unitarias** para validar el comportamiento de `Futures`. Su objetivo es garantizar la correctitud, concurrencia y manejo de errores de todos los métodos de la API de Futures de Guava.

### 2. Descripción General

`FuturesTest` es una clase de pruebas unitarias exhaustiva que valida el comportamiento de la clase de utilidad `Futures` de Google Guava. Esta clase de utilidad proporciona métodos estáticos para trabajar con `ListenableFuture` y `Future` de forma asíncrona y no bloqueante.

La clase de test cubre más de 100 casos de prueba que verifican:

* Creación de futuros inmediatos exitosos, fallidos y cancelados.
* Transformaciones síncronas y asíncronas de futuros.
* Manejo y recuperación de errores con `catching` y `catchingAsync`.
* Combinación y agregación de múltiples futuros.
* Comportamiento ante cancelación, interrupción, timeout y `RejectedExecutionException`.
* Gestión de memoria, logging y propagación de excepciones `Error` vs `Exception`.

Utiliza el framework **JUnit 3** `TestCase`, aserciones de **Truth** `assertThat` y ejecutores de prueba controlados `directExecutor`, `newSingleThreadExecutor`.

### 3. Estructura de la Clase

#### 3.1 Atributos y Constantes

```java
private static final Logger aggregateFutureLogger
private final TestLogHandler aggregateFutureLogHandler
private static final String DATA1 = "data"
private static final String DATA2 = "more data"
private static final String DATA3 = "most data"
private static final Executor REJECTING_EXECUTOR
```

Se utilizan para verificar el logging de `AggregateFuture` y simular un `Executor` que rechaza tareas.

#### 3.2 Ciclo de Vida JUnit

| Método | Descripción |
| :--- | :--- |
| `setUp()` | Registra el `TestLogHandler` en el logger de `AggregateFuture` antes de cada test. |
| `tearDown()` | Limpia el estado de interrupción del hilo y remueve el handler del logger. |

#### 3.3 Clases Internas y Helpers

| Clase Helper | Propósito |
| :--- | :--- |
| `CallerClass1` / `CallerClass2` | Verificar que el `stack trace` de un `CancellationException` no filtre clases internas. |
| `ExecutorSpy` | Espía que verifica si un `Executor` fue realmente invocado. |
| `FunctionSpy` / `AsyncFunctionSpy` | Contadores para verificar cuántas veces se invoca una función de transformación. |
| `SingleCallListener` | `Runnable` que asegura que un listener se ejecute exactamente una vez. |
| `TestFuture` / `TestFutureBatch` | Conjunto de futuros de prueba: éxito, fallo, cancelado, `RuntimeException`, inmediatos y demorados. Usado para pruebas extensivas de `allAsList` y `successfulAsList`. |
| `Merger` | Interfaz para abstraer `allAsList` vs `successfulAsList` en pruebas parametrizadas. |
| `CancelPanickingFuture` | `AbstractFuture` que simula un fallo al intentar cancelar, para probar logging. |

### 4. Métodos Principales por Categoría

#### 4.1 Pruebas de Futuros Inmediatos
Verifican la creación de futuros ya completados.

* `testImmediateFuture()` - Valida `Futures.immediateFuture()` con valor exitoso.
* `testImmediateVoidFuture()` - Valida futuro con valor `null`.
* `testImmediateFailedFuture()` - Valida `immediateFailedFuture()` y que envuelva la excepción en `ExecutionException`.
* `testImmediateCancelledFutureBasic()` / `testImmediateCancelledFutureStack()` - Valida `immediateCancelledFuture()` y su estado `isCancelled()`.

#### 4.2 Pruebas de Transformación Síncrona `transform()`

* `testTransform_genericsNull()` / `testTransform_genericsHierarchy()` - Valida manejo de genéricos y nulabilidad.
* `testTransform_stackOverflow()` / `testTransform_listenerThrowsError()` - Valida robustez ante `StackOverflowError` y `Error` en listeners.
* `testTransform_errorAfterCancellation()` - Asegura que si la función cancela el futuro de salida, se respete la cancelación.
* `testTransform_rejectionPropagatesToOutput()` - Verifica que `RejectedExecutionException` del `Executor` se propague al futuro resultante.
* `testTransformValueRemainsMemoized()` / `testTransformExceptionRemainsMemoized()` - Verifica que el resultado de la transformación se memoize y no se re-ejecute.

#### 4.3 Pruebas de Transformación Asíncrona `transformAsync()` y `submitAsync()`

* `testTransformAsync_cancelPropagatesToInput()` / `testTransformAsync_interruptPropagatesToInput()` - Valida propagación de cancelación e interrupción hacia el futuro de entrada.
* `testTransformAsync_cancelPropagatesToAsyncOutput()` - Valida propagación hacia el futuro secundario retornado por la `AsyncFunction`.
* `testTransformAsync_asyncFunction_timeout()` / `testTransformAsync_asyncFunction_error()` - Valida timeout y manejo de errores lanzados por la función.
* `testSubmit()` / `testSubmitAsync()` / `testScheduleAsync()` - Prueban las variantes `Futures.submit()` y `Futures.scheduleAsync()` con `Callable`, `Runnable` y `AsyncCallable`.

#### 4.4 Pruebas de Manejo de Errores `catching()` y `catchingAsync()`

Equivalentes a bloques `try-catch` para futuros.

* `testCatching_inputDoesNotRaiseException()` / `testCatchingAsync_inputDoesNotRaiseException()` - Si no hay error, no se invoca el fallback.
* `testCatching_inputRaisesException()` / `testCatchingAsync_inputRaisesException()` - Si hay error, se invoca el fallback y retorna valor de recuperación.
* `testCatching_customTypeMatch()` / `testCatching_customTypeNoMatch()` - Valida filtrado por tipo de excepción `IOException` vs `Throwable`.
* `testCatching_fallbackGeneratesRuntimeException()` / `testCatchingAsync_fallbackGeneratesError()` - Valida que errores en el fallback se propaguen correctamente.
* `testCatching_rejectionPropagatesToOutput()` - Valida manejo de `RejectedExecutionException`.

#### 4.5 Pruebas de Agregación de Futuros

* `testAllAsList()` / `testAllAsList_emptyList()` / `testAllAsList_doneFutures()` - `Futures.allAsList()` combina múltiples futuros en `List<String>`. Falla si uno falla, se cancela si uno se cancela.
* `testAllAsList_failure()` / `testAllAsList_cancelled()` / `testAllAsList_resultCancelled()` - Valida propagación de fallo y cancelación a todos los futuros hijos.
* `testAllAsList_logging_*` - Verifica que solo se logueen errores y excepciones adicionales, evitando log duplicado para la misma causa.
* `testSuccessfulAsList()` / `testSuccessfulAsList_partialFailure()` - `Futures.successfulAsList()` nunca falla; reemplaza futuros fallidos/cancelados por `null`.
* `testWhenAllComplete()` / `testWhenAllSucceed()` - Prueban las APIs `Futures.whenAllComplete()` y `whenAllSucceed()` con `call()`, `callAsync()` y `run()`. `whenAllComplete` espera a todos aunque fallen, `whenAllSucceed` falla rápido.
* `testCompletionOrder()` / `testCompletionOrderExceptionThrown()` - `Futures.inCompletionOrder()` retorna una lista de futuros delegados que se completan en el orden en que terminan los originales, no en el orden de entrada.

#### 4.6 Pruebas de Utilidades Adicionales

* `testNonCancellationPropagating_*` - Valida `Futures.nonCancellationPropagating()` que crea un wrapper donde cancelar el wrapper no cancela el futuro delegado.
* `testLazyTransform()` - Valida `Futures.lazyTransform()` donde la función se aplica en cada `get()` y no se memoiza.
* `testFutures_nullChecks()` - Usa `ClassSanityTester` para verificar que todos los métodos públicos lancen `NullPointerException` ante parámetros nulos.

### 5. Dependencias Técnicas

* **Guava:** `ListenableFuture`, `SettableFuture`, `AbstractFuture`, `MoreExecutors.directExecutor`
* **Concurrencia Java:** `Executor`, `ExecutorService`, `ScheduledExecutorService`, `CountDownLatch`, `AtomicBoolean`
* **Testing:** `junit.framework.TestCase`, `com.google.common.truth.Truth`, `com.google.common.testing.GcFinalization` para pruebas de recolección de basura.

### 6. Conclusión

`FuturesTest` es una suite de pruebas crítica para garantizar la fiabilidad de la programación asíncrona en Guava. No aporta lógica de negocio, sino que actúa como **contrato de calidad** para la clase `Futures`, asegurando que las operaciones de transformación, combinación y recuperación de errores sean seguras ante condiciones de carrera, cancelación e interrupción de hilos.