# Documentación Técnica — `LongParameterResolver`

**Paquete:** `org.junit.jupiter.engine.execution.injection.sample`
**Tipo:** `public class`
**Implementa:** `org.junit.jupiter.api.extension.ParameterResolver`
**Desde (`@since`):** `5.0`
**Autor (`@author`):** No declarado en el código fuente. El encabezado de licencia atribuye la obra a *"the original author or authors"* (Eclipse Public License v2.0, 2015-2026). Se recomienda añadir explícitamente la etiqueta `@author` en el Javadoc de clase.

---

## 1. Resumen ejecutivo

`LongParameterResolver` es una implementación de ejemplo (clase *sample* de soporte para pruebas del motor JUnit Jupiter) de la SPI `ParameterResolver`, cuyo único cometido es inyectar el valor constante `42L` en cualquier parámetro de tipo `Long` declarado en métodos de prueba, constructores o callbacks del ciclo de vida.

Además de la coincidencia exacta de tipo (`Long.class`), la clase *intenta* resolver parámetros declarados mediante **variables de tipo genéricas** (por ejemplo `T`), siempre que dichas variables estén definidas a nivel de clase en la clase declarante del ejecutable (típicamente una superclase o interfaz genérica extendida/implementada por la clase de prueba) y su único límite superior (*bound*) sea una clase asignable desde `Long`.

Su naturaleza es puramente declarativa y sin estado: no mantiene campos de instancia, por lo que es intrínsecamente *thread-safe* y reutilizable entre contextos de extensión.

---

## 2. Especificación de métodos y constructores

### Inventario completo de miembros detectados

| # | Miembro | Modificadores | Origen |
|---|---------|---------------|--------|
| 1 | `LongParameterResolver()` | `public` (implícito) | Constructor por defecto generado por el compilador |
| 2 | `supportsParameter(ParameterContext, ExtensionContext)` | `public`, `@Override` | Implementación de `ParameterResolver` |
| 3 | `resolveParameter(ParameterContext, ExtensionContext)` | `public`, `@Override` | Implementación de `ParameterResolver` |

> No existen métodos `private`, `protected`, `static`, clases internas, clases anónimas ni expresiones lambda en el código fuente provisto.

---

### 2.1 Constructor `LongParameterResolver()`

Constructor por defecto **implícito**. No está escrito de forma explícita en el código fuente, pero el compilador lo genera al no declararse ningún otro constructor. Es el constructor invocado por el motor de JUnit Jupiter cuando la extensión se registra de forma declarativa mediante `@ExtendWith(LongParameterResolver.class)` o vía `ServiceLoader`, ya que ambos mecanismos requieren un constructor público sin argumentos.

```java
/**
 * Crea una nueva instancia sin estado del resolutor.
 *
 * <p>Constructor por defecto requerido por el registro declarativo de
 * extensiones de JUnit Jupiter.
 */
public LongParameterResolver() { }
```

**Parámetros de entrada (`@param`)**

| Nombre | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| — | — | — | No recibe parámetros. |

**Valor de retorno (`@return`)**

| Tipo | Descripción |
|------|-------------|
| `LongParameterResolver` | Nueva instancia inmutable y sin estado. |

**Excepciones (`@throws`)**

| Excepción | Condición |
|-----------|-----------|
| — | No lanza excepciones declaradas. |

---

### 2.2 Método `supportsParameter(ParameterContext, ExtensionContext)`

```java
/**
 * Determina si este resolutor puede proporcionar un valor para el parámetro
 * descrito por el {@link ParameterContext} suministrado.
 *
 * <p>Devuelve {@code true} en dos escenarios:
 * <ol>
 *   <li><strong>Coincidencia exacta:</strong> el tipo declarado del parámetro
 *       es exactamente {@link Long}.</li>
 *   <li><strong>Coincidencia por variable de tipo:</strong> el tipo
 *       parametrizado del parámetro coincide por nombre con una de las
 *       variables de tipo declaradas en la clase que declara el ejecutable,
 *       dicha variable posee exactamente un límite superior, ese límite es
 *       una {@link Class} y es asignable desde {@link Long}.</li>
 * </ol>
 *
 * @param parameterContext el contexto del parámetro a evaluar; requerido
 * @param extensionContext el contexto de extensión actual; no utilizado por
 *        esta implementación
 * @return {@code true} si el parámetro puede resolverse; {@code false} en
 *         caso contrario
 */
@Override
public boolean supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext)
```

**Parámetros de entrada (`@param`)**

| Nombre | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `parameterContext` | `org.junit.jupiter.api.extension.ParameterContext` | **Sí** | Contexto del parámetro bajo evaluación. Se consulta mediante `getParameter()` (tipo declarado y tipo parametrizado) y `getDeclaringExecutable()` (para obtener la clase declarante y sus variables de tipo). Un valor `null` provocaría `NullPointerException` al desreferenciarse. |
| `extensionContext` | `org.junit.jupiter.api.extension.ExtensionContext` | Sí (por contrato de la interfaz) | Contexto de ejecución actual proporcionado por el motor. **No se utiliza** en el cuerpo del método; admite `null` sin efectos secundarios desde el punto de vista de esta implementación. |

**Valor de retorno (`@return`)**

| Tipo | Descripción |
|------|-------------|
| `boolean` | `true` si (a) `parameterContext.getParameter().getType() == Long.class`, o (b) existe una `TypeVariable` en `parameterContext.getDeclaringExecutable().getDeclaringClass().getTypeParameters()` cuyo nombre coincide con `getParameterizedType().getTypeName()` y cuyo único *bound* es una `Class<?>` asignable desde `Long`. En cualquier otro caso, `false`. |

**Excepciones (`@throws`)**

| Excepción | Tipo | Condición de disparo |
|-----------|------|----------------------|
| `NullPointerException` | No declarada (runtime) | Si `parameterContext` es `null`, o si alguna de las llamadas en cadena (`getParameter()`, `getDeclaringExecutable()`, `getDeclaringClass()`) retornase `null`. |
| — | — | El método **no declara** ninguna excepción en su cláusula `throws`; en particular, no propaga `ParameterResolutionException` (a diferencia del contrato general de la interfaz, que la permite). |

**Detalle algorítmico**

1. **Comprobación de coincidencia exacta.** Se obtiene el tipo *borrado* del parámetro con `getParameter().getType()` y se compara por identidad referencial con `Long.class`. Nótese que al usarse `==` sobre `Class`, el tipo primitivo `long` **no** se considera soportado, ni tampoco subtipos (irrelevante por ser `Long` `final`).
2. **Obtención del tipo genérico.** `typeInMethod = parameterContext.getParameter().getParameterizedType()` captura la declaración genérica, que para un parámetro `T x` devuelve la `TypeVariable` `T`.
3. **Iteración sobre variables de tipo de la clase declarante.** Se recorre `getDeclaringExecutable().getDeclaringClass().getTypeParameters()`.
   - `namesMatch`: compara `typeInMethod.getTypeName()` con `typeVariable.getName()` (comparación textual del identificador, p. ej. `"T"`).
   - `typesAreCompatible`: exige que la variable declare exactamente **un** *bound* (`getBounds().length == 1`), que ese *bound* sea una `Class<?>` (*pattern matching* de `instanceof` con la variable `clazz`, característica de Java 16+) y que `clazz.isAssignableFrom(Long.class)` sea `true` (es decir, `Number`, `Comparable` no aplica por ser interfaz-`Class` sí válida, `Object`, `Long`, etc.).
   - Si ambas condiciones se cumplen, retorna `true` de forma anticipada.
4. **Resultado negativo por defecto:** `false`.

**Limitaciones conocidas**

- Solo inspecciona las variables de tipo de la **clase declarante** del ejecutable; no resuelve variables de tipo declaradas en el propio método (`<T> void test(T t)`) ni realiza resolución transitiva de argumentos de tipo reales en la jerarquía de herencia (de ahí el *"attempts"* del Javadoc de clase).
- Variables con *bounds* múltiples (`<T extends Number & Comparable<T>>`) quedan excluidas por la condición `length == 1`.
- *Bounds* que no sean `Class<?>` (p. ej. `ParameterizedType` como `Comparable<T>`) quedan excluidos.

---

### 2.3 Método `resolveParameter(ParameterContext, ExtensionContext)`

```java
/**
 * Resuelve el parámetro soportado devolviendo siempre la constante
 * {@code 42L}.
 *
 * <p>Este método únicamente es invocado por el motor de ejecución cuando
 * {@link #supportsParameter(ParameterContext, ExtensionContext)} ha
 * retornado previamente {@code true} para el mismo
 * {@link ParameterContext}.
 *
 * @param parameterContext el contexto del parámetro a resolver; no
 *        utilizado por esta implementación
 * @param extensionContext el contexto de extensión actual; no utilizado por
 *        esta implementación
 * @return el valor constante {@code 42L} como instancia de {@link Long}
 */
@Override
public Long resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext)
```

**Parámetros de entrada (`@param`)**

| Nombre | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `parameterContext` | `org.junit.jupiter.api.extension.ParameterContext` | Sí (por contrato de la interfaz) | Contexto del parámetro a resolver. **No se utiliza**: el método es constante. |
| `extensionContext` | `org.junit.jupiter.api.extension.ExtensionContext` | Sí (por contrato de