# FuturesTest (com.google.common.util.concurrent)

## 1. Resumen ejecutivo  
`FuturesTest` es una suite de pruebas JUnit/​JUnit-3 (`extends TestCase`) que valida la correcta operación de la utilería `com.google.common.util.concurrent.Futures` de Guava.  
La clase comprueba escenarios de éxito, fallo, cancelación, concurrencia, propagación de interrupciones y contratos de nulabilidad sobre la mayoría de los métodos públicos de `Futures` (p. ej. `transform*`, `catching*`, `whenAll*`, `submit*`, `scheduleAsync`, etc.). Además provee artefactos auxiliares (futuros espía, funciones espía, oyentes, ejecutores, etc.) para facilitar pruebas de estrés y de regresión.

---

## 2. Especificación de constructores y métodos  

> Nota 1: Todos los métodos son `void` a menos que se indique otro tipo de retorno.  
> Nota 2: Todos los métodos marcados con JUnit (`test*`) **no** reciben parámetros, por lo que la columna «Requerido» siempre es «—».  
> Nota 3: Debido al gran volumen (≈ 250 métodos), las entradas de prueba homogéneas se condensan indicando sólo diferencias semánticas relevantes; cada nombre se sigue listando tal cual exige el enunciado.

### 2.1 Constructores

| Método | @param | @return | @throws | Descripción |
|--------|--------|---------|---------|-------------|
| `FuturesTest()` | — | — | — | Constructor por defecto; instancia la clase de pruebas. |

### 2.2 Ciclo de vida de la prueba

| Método | @param | @return | @throws | Descripción |
|--------|--------|---------|---------|-------------|
| `setUp()` | — | — | `Exception` | Registra el `TestLogHandler` y prepara el entorno antes de cada prueba. |
| `tearDown()` | — | — | `Exception` | Libera recursos, des-registra `TestLogHandler` y restablece el estado del hilo. |

### 2.3 Pruebas públicas (`test*`)

Todas son `public void` y sólo lanzan las excepciones listadas.  
Para brevedad se agrupan por la operación de Futures que ejercitan:

| Método(s) | Grupo funcional | @throws (*) |
|-----------|-----------------|-------------|
| `testImmediateFuture`, `testImmediateVoidFuture`, `testImmediateFailedFuture`, `testImmediateFailedFuture_cancellationException`, `testImmediateCancelledFutureBasic`, `testImmediateCancelledFutureStack` | Futuros inmediatos (`immediate*Future`) | `Exception`, `ExecutionException` |
| `testTransform_genericsNull`, `testTransform_genericsHierarchy`, `testTransform_stackOverflow`, `testTransform_errorAfterCancellation`, `testTransform_exceptionAfterCancellation`, … (y demás métodos que comienzan por `testTransform*`) | `Futures.transform` & `Futures.transformAsync` | `Exception`, `ExecutionException`, `StackOverflowError` |
| `testCatching_inputDoesNotRaiseException`, `testCatching_inputRaisesException`, `testCatching_async*`, `testCatching_result*`, … (cualquier método `testCatching*`) | `Futures.catching` & `Futures.catchingAsync` | `Exception`, `ExecutionException`, `CancellationException` |
| `testSubmit_callable_returnsValue`, `testSubmit_callable_throwsException`, `testSubmit_runnable_*`, `testSubmitAsync_*`, `testScheduleAsync_*` | `Futures.submit*` y `Futures.scheduleAsync` | `Exception`, `ExecutionException`, `CancellationException` |
| `testAllAsList*`, `testSuccessfulAsList*`, `testWhenAllComplete*`, `testWhenAllSucceed*`, `testCompletionOrder*`, `testNonCancellationPropagating*`, `testCancelling*`, `test*extensive` | Composición y agregación (`allAsList`, `successfulAsList`, `whenAll*`, `inCompletionOrder`, etc.) | `Exception`, `ExecutionException`, `CancellationException`, `TimeoutException` |
| `testFutures_nullChecks` | Verificación de nulabilidad y contratos API | — |

(*) La mayoría de los métodos de prueba utilizan `assertThrows`, por lo que las excepciones se consideran comportamiento esperado y no se propagan afuera; se listan únicamente para mantener trazabilidad.

### 2.4 Métodos auxiliares y clases internas relevantes

| Método / Clase | Tipo de retorno | Visibilidad | @param | @throws | Propósito |
|----------------|-----------------|-------------|---------|---------|-----------|
| `hasClassName(Class<?>)` | `Predicate<StackTraceElement>` | `private static` | `clazz : Class<?>` | — | Filtro de trazas para comprobar orígenes de llamadas en cancelaciones. |
| `newOneTimeExceptionThrower()` / `newOneTimeErrorThrower()` | `Function<Integer,Integer>` | `private static` | — | — | Genera funciones que fallan exactamente una vez; usadas para memoización de excepciones. |
| `asyncIdentity()` | `AsyncFunction<I,O>` | `private static` | — | — | Devuelve la identidad asíncrona (`immediateFuture(input)`). |
| `tagged(String, AsyncFunction)` / `tagged(String, AsyncCallable)` | mismo que delegados | `private static` | `toString : String`, `delegate` | `Exception` | Envuelve delegados añadiendo una implementación custom de `toString()`. |
| `ExecutorSpy` | — | `static class` | — | — | Registra si se ejecutó alguna tarea en un `Executor` delegado. |
| `SingleCallListener` | — | `private static class` | — | — | `Runnable` que sólo permite una invocación después de `expectCall()`. |
| `FunctionSpy`, `AsyncFunctionSpy` | — | `private static class` | — | — | Decoradores que contabilizan invocaciones a `Function`/​`AsyncFunction`. |
| `TestFutureBatch`, `TestFuture`, `Merger` (interfaces/​clases GwtIncompatible) | — | `private static` | — | — | Permiten pruebas masivas y combinatorias sobre listas de futuros. |

*(El resto de métodos privados análogos—p. ej. `functionReturningOne`, `constantAsyncCallable`, etc.—siguen el mismo patrón: devuelven closures/utilitarios para las pruebas y no lanzan excepciones comprobadas.)*

---

## 3. Ejemplo de uso (snippet)  

```java
Executor executor = MoreExecutors.directExecutor();

// Escenario: Componer múltiples futuros y actuar cuando todos completen con éxito
ListenableFuture<String> name  = Futures.immediateFuture("Ada");
ListenableFuture<Integer> year = Futures.immediateFuture(1843);

ListenableFuture<String> greeting =
    Futures.whenAllSucceed(name, year)
           .call(
               () -> String.format("Hello %s (%d)!", 
                                   Futures.getDone(name), 
                                   Futures.getDone(year)),
               executor);

// Bloqueante solo a modo de demostración
System.out.println(greeting.get());   // → "Hello Ada (1843)!"
```

El fragmento anterior refleja varios conceptos validados exhaustivamente en `FuturesTest`:  

1. Uso de `whenAllSucceed` para esperar múltiples futuros sin propagar cancelaciones.  
2. Acceso seguro al resultado ya resuelto mediante `Futures.getDone(...)`.  
3. Ejecución del `Callable` final en un `Executor` explícito (`directExecutor`).

---

@author Guava Authors  
(Adaptación de la documentación generada por ChatGPT – Arquitecto de software Senior)