# Documentación Técnica — `requests.sessions`

---

## 1. Resumen ejecutivo

El módulo `requests.sessions` implementa el objeto `Session`, responsable de **persistir y fusionar configuración entre peticiones HTTP** (cookies, cabeceras, autenticación, proxies, hooks, verificación TLS y adaptadores de transporte). Además expone el mixin `SessionRedirectMixin`, que encapsula toda la lógica de resolución de redirecciones (reconstrucción de método, autenticación, proxies y cuerpo de la petición) conforme a RFC 7231/7235, y dos utilidades de fusión de ajustes (`merge_setting()`, `merge_hooks()`).

Arquitecturalmente, `Session` actúa como *fachada* de alto nivel: construye un `Request`, lo normaliza a un `PreparedRequest` mediante `prepare_request()`, selecciona el adaptador adecuado con `get_adapter()` y delega la transmisión en `send()`, gestionando el ciclo completo de redirecciones y la extracción de cookies.

### 1.1. Constantes y símbolos de módulo

| Símbolo | Tipo | Descripción |
|---|---|---|
| `preferred_clock` | `Callable[[], float]` | Reloj monotónico preferido para medir el tiempo transcurrido. Es `time.perf_counter` en `win32` y `time.time` en el resto de plataformas. |
| `DEFAULT_REDIRECT_LIMIT`, `REDIRECT_STATI`, `PreparedRequest`, `Request`, `Response` | re-exportados | Reexpuestos desde `.models` por compatibilidad retroactiva. |
| `should_bypass_proxies`, `default_headers`, `DEFAULT_PORTS`, … | re-exportados | Reexpuestos desde `.utils` para consumidores externos. |

> **Nota sobre funciones anidadas:** tras el análisis estático del código fuente provisto, **no existen funciones anidadas, callbacks internos, decoradores definidos localmente ni workers de hilos**. Los únicos bloques de ámbito interno son *comprehensions* (`none_keys`, `history`, `keys_to_move`, `state`), que no constituyen funciones nombradas. Se documentan en consecuencia dentro de sus métodos contenedores.

---

## 2. Especificación de funciones y métodos

### 2.1. Funciones de módulo

---

#### `merge_setting()`

```python
def merge_setting(
    request_setting: Any,
    session_setting: Any,
    dict_class: type = OrderedDict,
) -> Any
```

Determina el ajuste efectivo para una petición concreta, combinando el valor explícito de la petición con el valor de la sesión. Si ambos valores son mapeos (`Mapping`), se fusionan en una instancia de `dict_class`, dando **precedencia a los valores de la petición**; las claves cuyo valor final sea `None` se eliminan del resultado (mecanismo canónico para *desactivar* una cabecera heredada de la sesión).

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request_setting` | `Any` | Sí | Ajuste definido a nivel de petición. Tiene prioridad sobre el de la sesión. |
| `session_setting` | `Any` | Sí | Ajuste definido a nivel de `Session`. |
| `dict_class` | `type` | No (`OrderedDict`) | Clase contenedora del resultado cuando ambos ajustes son mapeos (p. ej. `CaseInsensitiveDict`). |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Any` | `request_setting` si `session_setting is None`; `session_setting` si `request_setting is None`; `request_setting` si alguno **no** es `Mapping`; en caso contrario, instancia de `dict_class` con la fusión y sin claves `None`. |

**Excepciones**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones propias. Puede propagar `TypeError` desde `to_key_val_list()` si se recibe un tipo no soportado. |

**Docstring (Google Style)**

```python
"""Resuelve el ajuste efectivo entre petición y sesión.

Args:
    request_setting (Any): Ajuste a nivel de petición (prioritario).
    session_setting (Any): Ajuste a nivel de sesión.
    dict_class (type): Clase contenedora del resultado fusionado.

Returns:
    Any: Valor único o mapeo fusionado sin claves con valor ``None``.
"""
```

---

#### `merge_hooks()`

```python
def merge_hooks(
    request_hooks: _t.HooksType,
    session_hooks: _t.HooksType,
    dict_class: type = OrderedDict,
) -> _t.HooksType
```

Fusiona los *hooks* de la petición con los de la sesión. Implementa una salvaguarda específica: si uno de los diccionarios contiene `{'response': []}` (valor por defecto vacío), se devuelve el otro sin fusionar, evitando que un conjunto vacío anule los hooks registrados en la sesión.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| `request_hooks` | `_t.HooksType` | Sí | Hooks de la petición. Puede ser `None` o `{'response': []}`. |
| `session_hooks` | `_t.HooksType` | Sí | Hooks de la sesión. Puede ser `None` o `{'response': []}`. |
| `dict_class` | `type` | No (`OrderedDict`) | Clase contenedora delegada a `merge_setting()`. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `_t.HooksType` | Diccionario de hooks resultante (`{nombre_evento: [callables]}`). |

**Excepciones**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones propias. |

---

#### `session()`

```python
def session() -> Session
```

Factoría de conveniencia que devuelve una nueva instancia de `Session`.

> **Deprecado desde 1.0.0.** Se conserva únicamente por compatibilidad retroactiva; el código nuevo debe instanciar `requests.sessions.Session` directamente.

**Parámetros**

| Nombre | Tipo | Requerido | Descripción |
|---|---|---|---|
| — | — | — | No recibe parámetros. |

**Retorno**

| Tipo | Descripción |
|---|---|
| `Session` | Instancia nueva, apta para uso como gestor de contexto. |

**Excepciones**

| Excepción | Condición |
|---|---|
| — | No lanza excepciones propias. |

---

### 2.2. Clase `SessionRedirectMixin`

Mixin que concentra la política de redirecciones. Declara como contrato los atributos `max_redirects: int`, `trust_env: bool` y `cookies: RequestsCookieJar`, que deben ser provistos por la clase concreta.

---

#### `SessionRedirectMixin.send()`

```python
def send(self, request: PreparedRequest, **kwargs: Any) -> Response: ...
```

**Declaración abstracta (stub)**. No contiene implementación (cuer