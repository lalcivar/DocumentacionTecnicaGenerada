# Documentación Técnica - `requests.models`

## 1. Resumen Ejecutivo

El módulo `requests.models` contiene los objetos primarios que potencian la librería `Requests`. Implementa las clases `Request`, `PreparedRequest` y `Response`, junto con los mixins `RequestEncodingMixin` y `RequestHooksMixin`, encargados de la codificación de parámetros, construcción de cuerpos `multipart/form-data`, gestión de hooks, preparación de URLs, cabeceras, autenticación y el consumo/streaming de respuestas HTTP. Es el núcleo de bajo nivel sobre el que `Session` construye y envía peticiones HTTP.

---

## 2. Especificación de Funciones y Métodos

### 2.1 Clase `RequestEncodingMixin`

Mixin responsable de la codificación de datos y archivos para la transmisión HTTP.

#### `RequestEncodingMixin.path_url()` - `property`

Construye la URL de tipo path (path + query string) a partir de `self.url`.

```python
@property
def path_url(self) -> str:
    """Build the path URL to use."""
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `self` | `RequestEncodingMixin` | Sí | Instancia que contiene el atributo `url`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `path_url` | `str` | Ruta y query string. Retorna `"/"` si el path está vacío. |

| Excepción | Condición |
|---|---|
| `AttributeError` / `TypeError` | Si `self.url` es `None` o no es parseable por `urlsplit`. |

---

#### `RequestEncodingMixin._encode_params()`

Codifica parámetros en un fragmento de datos. Soporta `dict` o lista de tuplas de 2 elementos, preservando el orden en este último caso.

```python
@staticmethod
def _encode_params(data: _t.EncodableDataType) -> str | bytes | _t.SupportsRead[str | bytes]:
    """Encode parameters in a piece of data.

    Will successfully encode parameters when passed as a dict or a list of
    2-tuples. Order is retained if data is a list of 2-tuples but arbitrary
    if parameters are supplied as a dict.

    Args:
        data: Datos a codificar. Puede ser str, bytes, objeto file-like con read(), dict o lista de tuplas.

    Returns:
        Datos codificados como string URL-encoded, bytes sin modificar o el mismo objeto file-like.

    Raises:
        TypeError: Si la estructura de datos no es iterable de forma esperada.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `data` | `str \| bytes \| SupportsRead[str\|bytes] \| KVDataType` | Sí | Datos a codificar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `encoded` | `str \| bytes \| SupportsRead[str\|bytes]` | `str`/`bytes` sin cambios si ya lo son, objeto original si tiene `read()`, o `str` URL-encoded (`urlencode(..., doseq=True)`). |

| Excepción | Condición |
|---|---|
| - | No lanza excepciones explícitas; delega errores de `urlencode` o `to_key_val_list`. |

> **Sobrecargas (`@overload`):** `str -> str`, `bytes -> bytes`, `SupportsRead -> SupportsRead`, `KVDataType -> str`.

---

#### `RequestEncodingMixin._encode_files()`

Construye el cuerpo para una petición `multipart/form-data`.

```python
@staticmethod
def _encode_files(files: _t.FilesType, data: _t.RawDataType | None) -> tuple[bytes, str]:
    """Build the body for a multipart/form-data request.

    Will successfully encode files when passed as a dict or a list of
    tuples. Order is retained if data is a list of tuples but arbitrary
    if parameters are supplied as a dict.
    The tuples may be 2-tuples (filename, fileobj), 3-tuples (filename, fileobj, contentype)
    or 4-tuples (filename, fileobj, contentype, custom_headers).

    Args:
        files: Diccionario o lista de tuplas con archivos.
        data: Datos de formulario adicionales.

    Returns:
        Tupla con (body, content_type).

    Raises:
        ValueError: Si files está vacío o si data es un string.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `files` | `_t.FilesType` | Sí | Archivos a codificar. Formato `dict` o `list[tuple]`. |
| `data` | `_t.RawDataType \| None` | No | Datos de formulario a incluir junto a los archivos. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `body, content_type` | `tuple[bytes, str]` | Cuerpo binario codificado y cabecera `Content-Type` con boundary. |

| Excepción | Condición |
|---|---|
| `ValueError` | Si `files` es falsy (`Files must be provided.`). |
| `ValueError` | Si `data` es `basestring` (`Data must not be a string.`). |

---

### 2.2 Clase `RequestHooksMixin`

Mixin para el sistema de eventos/hooks de Requests.

#### `RequestHooksMixin.register_hook()`

Registra correctamente un hook en un evento.

```python
def register_hook(self, event: str, hook: Iterable[_t.HookType] | _t.HookType) -> None:
    """Properly register a hook.

    Args:
        event: Nombre del evento (ej. 'response').
        hook: Callable o iterable de callables.

    Raises:
        ValueError: Si el evento no está soportado.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `event` | `str` | Sí | Nombre del evento registrado en `self.hooks`. |
| `hook` | `Iterable[HookType] \| HookType` | Sí | Función o lista de funciones `Callable`. |

| Retorno | Tipo | Descripción |
|---|---|---|
| - | `None` | No retorna valor. Modifica `self.hooks[event]` in-place. |

| Excepción | Condición |
|---|---|
| `ValueError` | Si `event not in self.hooks` (`Unsupported event specified`). |

---

#### `RequestHooksMixin.deregister_hook()`

Elimina un hook previamente registrado.

```python
def deregister_hook(self, event: str, hook: _t.HookType) -> bool:
    """Deregister a previously registered hook.
    Returns True if the hook existed, False if not.

    Args:
        event: Nombre del evento.
        hook: Callable a eliminar.

    Returns:
        True si el hook existía y fue eliminado, False en caso contrario.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `event` | `str` | Sí | Nombre del evento. |
| `hook` | `_t.HookType` | Sí | Callable a eliminar. |

| Retorno | Tipo | Descripción |
|---|---|---|
| `result` | `bool` | `True` si se eliminó, `False` si no se encontró (`ValueError` capturado). |

| Excepción | Condición |
|---|---|
| `KeyError` | Si `event` no existe en `self.hooks` (no capturado, se propaga). |

---

### 2.3 Clase `Request`

Objeto creado por el usuario para preparar una `PreparedRequest`.

#### `Request.__init__()`

```python
def __init__(self, method: str | None = None, url: _t.UriType | None = None, headers: _t.HeadersType = None, files: _t.FilesType = None, data: _t.DataType = None, params: _t.ParamsType = None, auth: _t.AuthType = None, cookies: RequestsCookieJar | CookieJar | dict[str, str] | None = None, hooks: _t.HooksInputType | None = None, json: _t.JsonType = None) -> None:
    """Inicializa una petición de usuario.

    Args:
        method: Método HTTP (GET, POST, etc.).
        url: URL a solicitar.
        headers: Diccionario de cabeceras.
        files: Diccionario {filename: fileobject} para multipart.
        data: Cuerpo de la petición (dict, lista de tuplas o bytes/str).
        params: Parámetros URL a anexar.
        auth: Handler de autenticación o tupla (user, pass).
        cookies: Diccionario o CookieJar.
        hooks: Diccionario de hooks de callback.
        json: Objeto serializable a JSON para el body.
    """
```

| Parámetro | Tipo | Requerido | Descripción |
|---|---|---|---|
| `method` | `str \| None` | No | Método HTTP. Default `None`. |
| `url` | `_t.UriType \| None` | No | URL destino. |
| `headers` | `_t.HeadersType` | No | Cabeceras. Default `{}`. |
| `files` | `_t.FilesType` | No | Archivos. Default `[]`. |
| `data` | `_t.DataType` | No | Body. Default `[]`. |
| `params` | `_t.ParamsType` | No | Query params. Default `{}`. |
| `hooks` | `_t.HooksInputType \| None` | No | Hooks. Default `{}`. |
| `json` | `_t.JsonType` | No | Payload JSON. Default `None`. |
| `auth` | `_t.AuthType` | No | Autenticación. |
| `cookies` | `RequestsCookieJar \| CookieJar \| dict[str,str] \| None` | No | Cookies. |

| Retorno | Tipo | Descripción |
|---|---|---|
| - | `None` | Inicializa atributos `method`, `url`, `headers`, `files`, `data`, `json`, `params`, `auth`, `cookies`, `hooks`. |

---

#### `Request.__repr__()`

```python
def __repr__(self) -> str:
    """Retorna representación <Request [METHOD]>."""
```

| Retorno | Tipo | Descripción |
|---|---|---|
| `repr` | `str` | Formato `"<Request [GET]>"`. |

---

#### `Request.prepare()`

Construye y retorna una `PreparedRequest` para transmisión.

```python
def prepare(self) -> PreparedRequest:
    """Constructs a PreparedRequest for transmission and returns it.

    Returns:
        Instancia de PreparedRequest completamente preparada.
    """
```

| Retorno | Tipo | Descripción |
|---|---|---|
| `p` | `PreparedRequest` | Petición preparada con todos los parámetros del `Request` actual. |

---

### 2.4 Clase `PreparedRequest`

Objeto totalmente mutable que contiene los bytes exactos que se enviarán al servidor. Hereda de `RequestEncodingMixin` y `RequestHooksMixin