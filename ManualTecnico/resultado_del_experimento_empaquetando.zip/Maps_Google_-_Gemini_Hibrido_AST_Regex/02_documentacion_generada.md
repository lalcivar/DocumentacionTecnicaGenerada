¡Excelente! Actuaré como un Arquitecto de Software Senior en Java y Redactor Técnico para documentar la clase `com.google.common.collect.Maps`. A continuación, presento la documentación técnica exhaustiva siguiendo la estructura y restricciones solicitadas.

---

### 1. Resumen ejecutivo

La clase `com.google.common.collect.Maps` es una clase de utilidad final que proporciona métodos estáticos para trabajar con instancias de `java.util.Map`. Ofrece una amplia gama de funcionalidades, incluyendo métodos de fábrica para crear implementaciones de `Map` mutables e inmutables (como `HashMap`, `TreeMap`, `EnumMap`), herramientas para comparar mapas (`difference`), y mecanismos para crear vistas transformadas (`transformValues`) o filtradas (`filterKeys