# Documentación técnica: `DiscoverySelectorResolver`

## Información general

| Atributo | Valor |
|---|---|
| **Paquete** | `org.junit.platform.suite.engine` |
| **Tipo** | Clase `final`, visibilidad *package-private* |
| **Disponible desde** | JUnit Platform 1.8 |
| **Colaboradores** | `SuiteEngineDescriptor`, `SuiteTestDescriptor`, `ClassSelectorResolver`, `IsSuiteClass`, `EngineDiscoveryRequestResolver`, `DiscoveryIssueReporter` |

## Descripción general

`DiscoverySelectorResolver` es la clase responsable de **la fase de descubrimiento (discovery) del motor de suites de JUnit Platform** (`junit-platform-suite-engine`).

Su cometido consiste en traducir los *selectores* y *filtros* contenidos en un `EngineDiscoveryRequest` (selectores de clase, de paquete, de classpath, de módulo, etc.) en una jerarquía de `TestDescriptor` colgada del descriptor raíz del motor (`SuiteEngineDescriptor`).

A diferencia de un motor de pruebas convencional, aquí el resultado del descubrimiento no son métodos de test, sino **clases anotadas con `@Suite`**. Cada una de ellas se representa mediante un `SuiteTestDescriptor`, que a su vez delega en el `Launcher` interno para descubrir de forma recursiva los tests que la suite declara (mediante `@SelectClasses`, `@SelectPackages`, etc.).

La clase está diseñada como un *helper* sin estado: encapsula un único resolvedor estático reutilizable y expone un solo método de instancia como punto de entrada.

## Estructura interna

### Campo estático `resolver`

```java
private static final EngineDiscoveryRequestResolver<SuiteEngineDescriptor> resolver
```

Resolvedor inmutable y compartido, construido una única vez mediante el *builder* de `EngineDiscoveryRequestResolver`. Se configura con dos componentes:

1. **`addClassContainerSelectorResolverWithContext(...)`**
   Registra un resolvedor para selectores "contenedores" de clases (paquetes, classpath roots, módulos). Utiliza el predicado `IsSuiteClass` para filtrar, de todas las clases encontradas en el contenedor, únicamente aquellas que son suites válidas (anotadas con `@Suite` y con la estructura correcta). El predicado recibe el `DiscoveryIssueReporter` del contexto para poder notificar problemas de configuración (por ejemplo, clases candidatas no válidas).

2. **`addSelectorResolver(...)`**
   Registra un `ClassSelectorResolver`, encargado de resolver selectores de clase y de identificadores únicos (`UniqueIdSelector`). Se le inyecta todo el contexto necesario para construir los descriptores de suite:
   - el filtro de nombres de clase (`getClassNameFilter()`),
   - el descriptor raíz del motor (`getEngineDescriptor()`),
   - los parámetros de configuración de la petición,
   - el creador de directorios de salida (`OutputDirectoryCreator`),
   - el `DiscoveryListener`,
   - el `DiscoveryIssueReporter`.

Al ser `static final`, el coste de construcción del resolvedor se paga una sola vez por carga de clase y se reutiliza en todas las ejecuciones de descubrimiento.

## Métodos principales

### `void resolveSelectors(EngineDiscoveryRequest request, SuiteEngineDescriptor engineDescriptor)`

Método público (a nivel de paquete) y **único punto de entrada** de la clase. Normalmente es invocado por `SuiteTestEngine#discover(...)`.

**Parámetros**

| Nombre | Descripción |
|---|---|
| `request` | Petición de descubrimiento emitida por el `Launcher`, con los selectores, filtros, parámetros de configuración y *listeners*. |
| `engineDescriptor` | Descriptor raíz del motor de suites, que actuará como padre de los descriptores generados. |

**Comportamiento**

1. **Creación del reportador de incidencias.** Construye un `DiscoveryIssueReporter` que:
   - *reenvía* (`forwarding`) las incidencias al `DiscoveryListener` de la petición, asociándolas al `UniqueId` del motor;
   - *deduplica* (`deduplicating`) las incidencias repetidas, de modo que un mismo problema detectado varias veces durante la resolución se notifique una sola vez.
2. **Resolución de selectores.** Delega en `resolver.resolve(request, engineDescriptor, issueReporter)`, lo que puebla el árbol con un `SuiteTestDescriptor` por cada clase de suite seleccionada.
3. **Descubrimiento anidado.** Invoca `discoverSuites(engineDescriptor)` para que cada suite resuelva sus propios tests.
4. **Poda del árbol.** Ejecuta `engineDescriptor.accept(TestDescriptor::prune)`, recorriendo el árbol y eliminando los contenedores que no contienen ningún test. Así se evita exponer suites vacías al `Launcher`.

**Valor de retorno:** ninguno; el resultado se refleja como efecto colateral sobre `engineDescriptor`.

### `private static void discoverSuites(SuiteEngineDescriptor engineDescriptor)`

Método auxiliar interno. Recorre los hijos directos del descriptor del motor, los convierte a `SuiteTestDescriptor` y llama a `discover()` sobre cada uno.

- Asume por diseño (*invariante*) que **todos** los hijos directos del `SuiteEngineDescriptor` son instancias de `SuiteTestDescriptor`; de lo contrario, el `cast` lanzaría `ClassCastException`.
- Separa deliberadamente la resolución de los selectores del motor (paso 2) del descubrimiento interno de cada suite (paso 3), ya que este último dispara ejecuciones anidadas del `Launcher` y debe realizarse cuando el árbol de primer nivel ya está completo.

## Flujo resumido

```
EngineDiscoveryRequest
        │
        ▼
resolveSelectors(...)
        │
        ├─► DiscoveryIssueReporter (forwarding + deduplicating)
        ├─► EngineDiscoveryRequestResolver.resolve(...)   → SuiteTestDescriptor por cada @Suite
        ├─► discoverSuites(...)                           → descubrimiento anidado de cada suite
        └─► TestDescriptor::prune                         → eliminación de contenedores vacíos
        │
        ▼
Árbol de TestDescriptor listo para ejecución
```

## Notas de diseño y uso

- **Clase de uso interno:** es *package-private* y `final`, por lo que no forma parte de la API pública de JUnit Platform ni está pensada para ser extendida o utilizada directamente por código cliente.
- **Sin constructor explícito:** se emplea el constructor por defecto; la clase no mantiene estado de instancia, por lo que `resolveSelectors` es seguro frente a reutilización (la seguridad frente a hilos depende de los colaboradores inyectados).
- **Idempotencia:** no está diseñada para invocarse dos veces sobre el mismo `SuiteEngineDescriptor`, ya que se producirían descriptores duplicados o nuevos descubrimientos anidados.
- Los comentarios `// @formatter:off` / `// @formatter:on` únicamente desactivan el formateador automático de código para preservar la legibilidad de las cadenas de llamadas; no tienen efecto funcional.