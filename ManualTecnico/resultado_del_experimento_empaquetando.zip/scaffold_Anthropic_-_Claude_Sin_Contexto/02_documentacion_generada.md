# Documentación técnica: `flask/sansio/scaffold.py`

## 1. Descripción general

Este módulo define la clase base **`Scaffold`**, que encapsula el **comportamiento común compartido entre `flask.Flask` (la aplicación) y `flask.blueprints.Blueprint` (los blueprints)**.

Forma parte del subpaquete `sansio` de Flask ("sans I/O"), lo que significa que contiene únicamente lógica de **registro y configuración**, sin realizar operaciones de entrada/salida ni depender del ciclo de petición/respuesta en tiempo de ejecución. Su responsabilidad es ofrecer:

1. **Resolución de rutas del sistema de archivos**: `root_path`, carpeta de archivos estáticos (`static_folder`), prefijo de URL estático (`static_url_path`) y carpeta de plantillas (`template_folder`) con su cargador Jinja asociado.
2. **Estructuras de datos de registro**: diccionarios donde se almacenan vistas, manejadores de error y *hooks* del ciclo de vida de la petición (`before_request`, `after_request`, `teardown_request`, procesadores de contexto, pre-procesadores de valores de URL y valores por defecto de URL).
3. **API de decoradores**: `route`, `get`, `post`, `put`, `delete`, `patch`, `query`, `endpoint`, `errorhandler`, etc., que son la interfaz pública con la que el desarrollador registra funcionalidad.
4. **Utilidades de descubrimiento de paquetes**: funciones auxiliares (`find_package`, `_find_package_path`) para localizar dónde está instalado/importado un paquete.

`Scaffold` es una **clase abstracta en la práctica**: métodos como `add_url_rule` y `_check_setup_finished` lanzan `NotImplementedError` y deben ser implementados por las subclases (`Flask` y `Blueprint`).

---

## 2. Dependencias

| Dependencia | Uso |
|---|---|
| `importlib.util`, `os`, `pathlib`, `sys` | Resolución de rutas y localización de paquetes/módulos. |
| `collections.defaultdict` | Construcción de los registros anidados por *scope*. |
| `functools.update_wrapper` | Preservación de metadatos en el decorador `setupmethod`. |
| `jinja2.BaseLoader`, `jinja2.FileSystemLoader` | Cargador de plantillas. |
| `werkzeug.exceptions.default_exceptions`, `HTTPException` | Mapeo de códigos HTTP a clases de excepción. |
| `werkzeug.utils.cached_property` | Cacheo del cargador Jinja. |
| `flask.typing` (`ft`) | Alias de tipos para *callables* y claves de registro. |
| `flask.helpers.get_root_path` | Descubrimiento automático de `root_path`. |
| `flask.templating._default_template_ctx_processor` | Procesador de contexto por defecto. |
| `click.Group` (solo `TYPE_CHECKING`) | Tipado del atributo `cli`. |

---

## 3. Componentes a nivel de módulo

### 3.1 `_sentinel`

```python
_sentinel = object()
```

Valor *singleton* centinela usado como valor por defecto de parámetros, para distinguir "no se pasó nada" de "se pasó `None`".

### 3.2 Variables de tipo (`TypeVar`)

Conjunto de variables genéricas que permiten que los decoradores **devuelvan exactamente el mismo tipo que reciben**, conservando así la firma de las funciones decoradas para los verificadores estáticos de tipos:

| TypeVar | Acotado a |
|---|---|
| `F` | `Callable[..., Any]` |
| `T_route` | `ft.RouteCallable` |
| `T_before_request` | `ft.BeforeRequestCallable` |
| `T_after_request` | `ft.AfterRequestCallable[Any]` |
| `T_teardown` | `ft.TeardownCallable` |
| `T_error_handler` | `ft.ErrorHandlerCallable` |
| `T_template_context_processor` | `ft.TemplateContextProcessorCallable` |
| `T_url_defaults` | `ft.URLDefaultCallable` |
| `T_url_value_preprocessor` | `ft.URLValuePreprocessorCallable` |

### 3.3 `setupmethod(f: F) -> F`

Decorador interno que envuelve los métodos de configuración de `Scaffold`. Antes de ejecutar el método original invoca `self._check_setup_finished(nombre_del_método)`, lo que permite a las subclases **impedir registros tardíos** (por ejemplo, añadir rutas después de que la aplicación ya ha atendido su primera petición o de que el blueprint ya fue registrado). Usa `update_wrapper` para preservar nombre, docstring y anotaciones.

---

## 4. Clase `Scaffold`

### 4.1 Constructor

```python
Scaffold(
    import_name: str,
    static_folder: str | os.PathLike[str] | None = None,
    static_url_path: str | None = None,
    template_folder: str | os.PathLike[str] | None = None,
    root_path: str | None = None,
)
```

**Parámetros**

- `import_name`: nombre de importación del módulo donde se define el objeto (normalmente `__name__`). Es la base para descubrir `root_path`.
- `static_folder`: ruta a la carpeta de archivos estáticos; si se define, se añadirá una ruta estática.
- `static_url_path`: prefijo de URL para la ruta estática.
- `template_folder`: carpeta con plantillas; si se define, se añade un cargador Jinja.
- `root_path`: ruta base para archivos estáticos, plantillas y recursos. Si es `None`, se deduce mediante `get_root_path(import_name)`.

### 4.2 Atributos de clase

| Atributo | Tipo | Descripción |
|---|---|---|
| `cli` | `click.Group` | Grupo de comandos CLI asociado. |
| `name` | `str` | Nombre del objeto (implementado por las subclases). |
| `_static_folder` | `str \| None` | Almacenamiento interno de la carpeta estática. |
| `_static_url_path` | `str \| None` | Almacenamiento interno del prefijo de URL estático. |

### 4.3 Atributos de instancia

| Atributo | Estructura | Propósito |
|---|---|---|
| `import_name` | `str` | Nombre del paquete/módulo propietario. No debe modificarse tras la construcción. |
| `template_folder` | `str \| PathLike \| None` | Carpeta de plantillas relativa a `root_path`. |
| `root_path` | `str` | Ruta absoluta del paquete en el sistema de archivos. |
| `view_functions` | `dict[str, RouteCallable]` | Mapea nombres de *endpoint* a funciones de vista. |
| `error_handler_spec` | `{scope: {code: {clase: handler}}}` | Manejadores de error. `scope` = nombre de blueprint o `None`; `code` = código HTTP o `None` para excepciones genéricas. |
| `before_request_funcs` | `{scope: [funcs]}` | Funciones ejecutadas al inicio de cada petición. |
| `after_request_funcs` | `{scope: [funcs]}` | Funciones ejecutadas al final de cada petición exitosa. |
| `teardown_request_funcs` | `{scope: [funcs]}` | Funciones ejecutadas al destruir el contexto de petición, incluso con excepciones. |
| `template_context_processors` | `{scope: [funcs]}` | Inyectan variables en el contexto de las plantillas. Inicializado con `_default_template_ctx_processor` en el *scope* `None`. |
| `url_value_preprocessors` | `{scope: [funcs]}` | Modifican los valores capturados de la URL antes de llegar a la vista. |
| `url_default_functions` | `{scope: [funcs]}` | Modifican los valores usados al construir URLs. |

> **Nota:** todas estas estructuras son **internas**; la documentación original advierte que no deben modificarse directamente y que su formato puede cambiar. Son `defaultdict`, por lo que acceder a un *scope* inexistente lo crea automáticamente.

### 4.4 Métodos especiales e internos

| Método | Descripción |
|---|---|
| `__repr__()` | Devuelve `<NombreClase 'name'>`. |
| `_check_setup_finished(f_name)` | **Abstracto** (`NotImplementedError`). Las subclases lo implementan para validar si todavía se permite configurar. |
| `_method_route(method, rule, options)` | Helper que delega en `route()` fijando `methods=[method]`. Lanza `TypeError` si se pasa `methods` explícitamente. |
| `_get_exc_class_and_code(exc_class_or_code)` | *staticmethod*. Normaliza un código HTTP entero o una clase de excepción a la tupla `(clase_excepción, código \| None)`. Valida que no sea una instancia y que sea subclase de `Exception`; traduce códigos vía `werkzeug.exceptions.default_exceptions`. |

### 4.5 Propiedades

| Propiedad | Tipo | Comportamiento |
|---|---|---|
| `static_folder` (get/set) | `str \| None` | *Getter*: devuelve la ruta **absoluta** (`root_path` + carpeta) o `None`. *Setter*: normaliza con `os.fspath` y elimina barras finales. |
| `has_static_folder` | `bool` | `True` si hay carpeta estática configurada. |
| `static_url_path` (get/set) | `str \| None` | *Getter*: devuelve el valor configurado o lo deriva del nombre base de `static_folder` (`/<basename>`). *Setter*: elimina la barra final. |
| `jinja_loader` | `BaseLoader \| None` | `cached_property`. Devuelve un `FileSystemLoader` apuntando a `root_path/template_folder`, o `None` si no hay `template_folder`. |

### 4.6 Métodos de registro de rutas

Todos están decorados con `@setupmethod`.

| Método | Descripción |
|---|---|
| `route(rule, **options)` | Decorador principal. Registra la función de vista en `rule` llamando a `add_url_rule`. El *endpoint* por defecto es el nombre de la función; `methods` por defecto es `["GET"]` (más `HEAD` y `OPTIONS` automáticos). |
| `get / post / put / delete / patch / query` | Atajos de `route` con un único método HTTP fijado. `query` corresponde al método HTTP `QUERY` (añadido en 3.2); el resto desde 2.0. |
| `add_url_rule(rule, endpoint=None, view_func=None, provide_automatic_options=None, **options)` | **Abstracto** (`NotImplementedError`). Punto de extensión real donde las subclases registran la regla de enrutamiento. |
| `endpoint(endpoint)` | Decorador que asocia una función de vista a un nombre de *endpoint* ya registrado s