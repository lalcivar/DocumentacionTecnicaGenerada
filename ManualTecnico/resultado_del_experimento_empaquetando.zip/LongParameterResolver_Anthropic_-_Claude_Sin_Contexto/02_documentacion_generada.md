# Documentación técnica: `LongParameterResolver`

**Paquete:** `org.junit.jupiter.engine.execution.injection.sample`
**Implementa:** `org.junit.jupiter.api.extension.ParameterResolver`
**Disponible desde:** JUnit Jupiter 5.0
**Licencia:** Eclipse Public License v2.0

---

## 1. Descripción general

`LongParameterResolver` es una implementación de ejemplo de la interfaz de extensión `ParameterResolver` del modelo de extensiones de JUnit Jupiter. Su propósito es demostrar (y servir como material de prueba interno del motor de ejecución de JUnit Jupiter) el mecanismo de **inyección de parámetros** en constructores y métodos de test.

El comportamiento del resolutor es deliberadamente trivial: **resuelve cualquier parámetro de tipo `Long` con el valor constante `42L`**.

Adicionalmente, el resolutor *intenta* dar soporte a **parámetros declarados mediante variables de tipo genéricas** (p. ej. `void test(N number)`), siempre que:

1. La variable de tipo esté declarada **a nivel de clase** (en la clase que declara el ejecutable, típicamente una superclase o interfaz genérica extendida/implementada por la clase de test), y
2. La variable de tipo posea **exactamente un límite superior (bound)**, que sea una `Class<?>` **asignable desde `Long`** (por ejemplo `Number`, `Comparable` no aplica por no ser compatible en este chequeo, `Object`, `Long`, etc.).

> **Nota de alcance:** se trata de una clase de *sample*/soporte de pruebas del motor de JUnit Jupiter, no de una API pública destinada a uso en producción.

---

## 2. Dependencias relevantes

| Tipo | Uso |
|------|-----|
| `java.lang.reflect.Type` | Representación del tipo parametrizado del parámetro. |
| `java.lang.reflect.TypeVariable` | Inspección de las variables de tipo declaradas por la clase. |
| `ParameterContext` | Acceso al parámetro a resolver y al ejecutable que lo declara. |
| `ExtensionContext` | Contexto de ejecución del test (no utilizado en esta implementación). |

---

## 3. Métodos principales

### 3.1 `boolean supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext)`

Determina si este resolutor es capaz de proporcionar un valor para el parámetro indicado.

**Parámetros**

| Nombre | Descripción |
|--------|-------------|
| `parameterContext` | Contexto del parámetro candidato; expone el `Parameter` reflectivo y el `Executable` (constructor o método) que lo declara. |
| `extensionContext` | Contexto de extensión actual. No se utiliza en esta implementación. |

**Valor de retorno:** `true` si el parámetro puede ser resuelto por este resolutor; `false` en caso contrario.

**Algoritmo**

1. **Coincidencia exacta.** Si `parameterContext.getParameter().getType() == Long.class`, devuelve `true` inmediatamente.
2. **Resolución de variables de tipo.** En caso contrario:
   - Obtiene el tipo parametrizado del parámetro (`getParameterizedType()`).
   - Itera sobre las variables de tipo declaradas por la clase que declara el ejecutable (`getDeclaringExecutable().getDeclaringClass().getTypeParameters()`).
   - Para cada variable de tipo evalúa dos condiciones:
     - `namesMatch`: el nombre del tipo del parámetro coincide con el nombre de la variable de tipo (comparación textual, p. ej. `"N"` == `"N"`).
     - `typesAreCompatible`: la variable de tipo tiene **un único** límite, dicho límite es una `Class<?>` (patrón `instanceof` con variable de patrón `clazz`, Java 16+) y `clazz.isAssignableFrom(Long.class)`.
   - Si ambas condiciones se cumplen, devuelve `true`.
3. Si ninguna variable de tipo satisface las condiciones, devuelve `false`.

**Consideraciones / limitaciones**

- La comparación de nombres es **puramente léxica**, no una resolución real de argumentos de tipo; por ello la documentación original indica que el soporte genérico es un *intento* (“attempts to support”).
- No se contemplan variables de tipo declaradas **a nivel de método** (`<T> void test(T t)`), ni límites múltiples (`<T extends A & B>`), ni límites que no sean clases crudas (p. ej. tipos parametrizados).
- Tipos primitivos `long` **no** son soportados por la comparación exacta (`long != Long.class`).

---

### 3.2 `Long resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext)`

Proporciona el valor efectivo que se inyectará en el parámetro.

**Parámetros:** idénticos a `supportsParameter`; ninguno de los dos es utilizado.

**Valor de retorno:** siempre la constante `42L` (autoboxing a `Long`).

**Precondición:** JUnit Jupiter invoca este método únicamente cuando `supportsParameter` ha devuelto `true` para el mismo `ParameterContext`.

**Nota de covarianza:** el tipo de retorno se estrecha de `Object` (declarado en la interfaz) a `Long`, aprovechando los tipos de retorno covariantes de Java.

---

## 4. Ejemplo de uso

```java
@ExtendWith(LongParameterResolver.class)
class MiTest {

    @Test
    void parametroDeTipoLong(Long numero) {
        assertEquals(42L, numero);   // inyectado por el resolutor
    }
}
```

Uso con una variable de tipo declarada en una clase base genérica:

```java
abstract class BaseTest<N extends Number> {

    @Test
    void parametroGenerico(N numero) {
        assertEquals(42L, numero);   // "N" coincide y Number es asignable desde Long
    }
}

@ExtendWith(LongParameterResolver.class)
class MiTestConcreto extends BaseTest<Long> {
}
```

---

## 5. Ciclo de vida y seguridad en hilos

- La clase **no mantiene estado** (sin campos de instancia), por lo que es **inmutable y segura para uso concurrente**.
- Puede registrarse declarativamente mediante `@ExtendWith` o programáticamente mediante `@RegisterExtension`; JUnit Jupiter requiere un constructor público sin argumentos, provisto implícitamente.