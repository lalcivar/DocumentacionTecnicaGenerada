# Documentación Técnica: `CharMatcherBenchmark`

**Paquete:** `com.google.common.base`  
**Clase:** `public class CharMatcherBenchmark`  
**Clase Interna:** `static class CharSamples`  
**Anotaciones de Clase:** `@NullUnmarked`  
**Autores:** `@author David Beaumont`, `@author Kevin Bourrillion`, `@author David Richter` (clase principal), `@author Christopher Swenson` (clase interna `CharSamples`)

---

### 1. Resumen Ejecutivo

`CharMatcherBenchmark` es una clase de micro-benchmarking basada en Caliper diseñada para medir el rendimiento de la clase `com.google.common.base.CharMatcher` de Guava. Evalúa operaciones críticas como `trimAndCollapseFrom()` y `matches()` bajo diferentes configuraciones parametrizadas de longitud de cadena, porcentaje de coincidencia y tipo de matcher. Incluye la clase interna `CharSamples` que proporciona un generador de puntos de código con distribución estadística derivada de datos reales de la web para pruebas realistas.

### 2. Especificación de Métodos y Constructores

#### 2.1 Clase `CharMatcherBenchmark`

##### Constructor por Defecto `CharMatcherBenchmark()`

Constructor implícito por defecto generado por el compilador. No declarado explícitamente en el código fuente.

```java
/**
 * Construye una nueva instancia de CharMatcherBenchmark.
 * Caliper inyecta los parámetros anotados con @Param después de la construcción.
 *
 * @author David Beaumont
 * @author Kevin Bourrillion
 * @author David Richter
 */
public CharMatcherBenchmark()
```

| Atributo | Valor |
| :--- | :--- |
| **Visibilidad** | `public` (implícito) |
| **Tipo** | Constructor |
| **@return** | Instancia de `CharMatcherBenchmark` |
| **@throws** | Ninguna |

---

##### Método `setUp()`

```java
/**
 * Inicializa el estado del benchmark después de la inyección de parámetros de Caliper.
 * Configura el CharMatcher (precomputado o no) y genera la cadena de prueba.
 *
 * @author David Beaumont
 */
@BeforeExperiment
void setUp()
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | Método sin parámetros. Utiliza los campos inyectados `config`, `length`, `percent`, `precomputed`, `size`, `forceSlow` y `web`. |

| @return | Descripción |
| :--- | :--- |
| `void` | No retorna valor. Inicializa los campos de instancia `matcher` y `string`. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | Puede propagar excepciones no verificadas si `config` es nulo o `SmallCharMatcher.from()` falla. |

**Lógica interna:** Si `precomputed == true` usa `config.matcher.precomputed()`, de lo contrario `config.matcher`. Si `size == Size.SMALL`, crea un `BitSet` y lo convierte vía `SmallCharMatcher.from(tmp, "")`. Finalmente invoca a `checkString()` para generar `string`.

---

##### Método `trimAndCollapseFromString()`

```java
/**
 * Benchmark para {@link CharMatcher#trimAndCollapseFrom(CharSequence, char)}.
 * Mide el rendimiento de recortar y colapsar caracteres coincidentes.
 *
 * @param reps número de repeticiones que Caliper solicita ejecutar
 * @return valor dummy acumulado para evitar optimización DCE (Dead Code Elimination)
 * @author David Beaumont
 */
@Benchmark
int trimAndCollapseFromString(int reps)
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `reps` | `int` | Sí | Número de iteraciones a ejecutar. Inyectado por Caliper. |

| @return | Descripción |
| :--- | :--- |
| `int` | Suma acumulada de `matcher.trimAndCollapseFrom(string, '!').length()` en `reps` iteraciones. Se retorna para que el JIT no elimine el código. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | - |

---

##### Método `matches()`

```java
/**
 * Benchmark para {@link CharMatcher#matches(char)}.
 * Mide el rendimiento de la verificación de coincidencia carácter por carácter.
 *
 * @param reps número de repeticiones que Caliper solicita ejecutar
 * @return conteo dummy de coincidencias para evitar optimización DCE
 * @author David Beaumont
 */
@Benchmark
int matches(int reps)
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `reps` | `int` | Sí | Número de iteraciones a ejecutar. Inyectado por Caliper. |

| @return | Descripción |
| :--- | :--- |
| `int` | Contador acumulado. Incrementa en 1 por cada `matcher.matches(string.charAt(i % string.length())) == true`. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | `StringIndexOutOfBoundsException` implícita si `string` es nulo o vacío (no controlado). |

---

##### Método `checkString()`

```java
/**
 * Genera una cadena de prueba controlada para el benchmark.
 * Si web es true, usa distribución web vía CharSamples; si no, genera una cadena
 * con un porcentaje exacto de caracteres coincidentes.
 *
 * @param length longitud deseada de la cadena a generar
 * @param percent porcentaje (0-100) de caracteres que deben coincidir con el matcher
 * @param matchingChars cadena que contiene el conjunto de caracteres considerados como coincidentes
 * @param rand generador aleatorio para barajar y seleccionar caracteres
 * @param forceSlow si es true, fuerza un carácter coincidente en la posición 0 para ejercitar la rama lenta de trim
 * @param web si es true, ignora los demás parámetros y genera la cadena usando CharSamples
 * @return cadena generada de longitud {@code length} lista para el benchmark
 */
private static String checkString(int length, int percent, String matchingChars, Random rand, boolean forceSlow, boolean web)
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `length` | `int` | Sí | Longitud de la cadena a construir. Valores parametrizados: `64`, `1024`. |
| `percent` | `int` | Sí | Porcentaje de caracteres coincidentes. Valores: `0`, `10`, `50`, `100`. |
| `matchingChars` | `String` | Sí | Conjunto de caracteres que el `CharMatcher` considera coincidentes. Proviene de `config.matchingChars`. |
| `rand` | `Random` | Sí | Instancia de `Random` para aleatorización. |
| `forceSlow` | `boolean` | Sí | Si `true`, coloca el índice `0` al inicio de la lista barajada para forzar coincidencia inicial. |
| `web` | `boolean` | Sí | Si `true`, genera puntos de código vía `CharSamples` en lugar de la lógica de porcentaje. |

| @return | Descripción |
| :--- | :--- |
| `String` | Cadena de longitud `length` con distribución controlada de caracteres coincidentes/no coincidentes. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | `IllegalArgumentException` implícita si `matchingChars` o `NONMATCHING_CHARS` están vacíos al invocar `randomCharFrom`. |

---

##### Método `randomCharFrom()`

```java
/**
 * Selecciona un carácter aleatorio de una cadena dada.
 *
 * @param s cadena fuente de donde extraer el carácter
 * @param rand generador aleatorio
 * @return un carácter aleatorio contenido en {@code s}
 */
private static char randomCharFrom(String s, Random rand)
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `s` | `String` | Sí | Cadena fuente. No debe ser nula ni vacía. |
| `rand` | `Random` | Sí | Generador aleatorio. |

| @return | Descripción |
| :--- | :--- |
| `char` | Carácter en la posición `rand.nextInt(s.length())` de `s`. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | `IllegalArgumentException` si `s.length() == 0` (vía `Random.nextInt(0)`). |

---

#### 2.2 Clase Interna `CharSamples`

Clase estática anidada `static class CharSamples` que provee muestreo con distribución derivada de la web.

##### Bloque Estático de Inicialización

```java
static {
  populateProb1();
  populateProb2();
  populateChars1();
  populateChars2();
}
```
Inicializa los arreglos estáticos `prob` (10003 elementos) y `chars` (10002 elementos) al cargar la clase. No es un método documentable con Javadoc pero es parte crítica del ciclo de vida.

---

##### Constructor `CharSamples()`

```java
/**
 * Construye un generador de muestras de caracteres con distribución web.
 *
 * @param random generador aleatorio subyacente para el muestreo
 * @author Christopher Swenson
 */
public CharSamples(Random random)
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `random` | `Random` | Sí | Instancia de `Random` utilizada para generar el `needle` en `nextCodePoint()`. |

| @return | Descripción |
| :--- | :--- |
| `CharSamples` | Nueva instancia configurada. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | - |

---

##### Método `nextCodePoint()`

```java
/**
 * Retorna el siguiente punto de código muestreado según la distribución de probabilidad web.
 * Realiza una búsqueda binaria sobre el arreglo {@code prob} para mapear un entero aleatorio
 * a un punto de código en {@code chars}.
 *
 * @return punto de código Unicode (int) muestreado
 * @author Christopher Swenson
 */
public int nextCodePoint()
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | Usa el campo de instancia `random` y los campos estáticos `prob`, `chars`, `sum`. |

| @return | Descripción |
| :--- | :--- |
| `int` | Punto de código Unicode muestreado. Valor entre `0` y `Character.MAX_CODE_POINT`. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | `ArrayIndexOutOfBoundsException` implícita si `prob` o `chars` no están inicializados. Bucle infinito teórico si `prob` no está ordenado. |

---

##### Método `populateProb1()`

```java
/**
 * Inicializa la primera mitad del arreglo de probabilidades acumuladas {@code prob}.
 * Crea un arreglo de 10003 enteros y copia los valores iniciales mediante System.arraycopy.
 *
 * @author Christopher Swenson
 */
private static void populateProb1()
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | - |

| @return | Descripción |
| :--- | :--- |
| `void` | Inicializa el campo estático `prob` con los primeros ~5000 valores de probabilidad acumulada. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | - |

---

##### Método `populateProb2()`

```java
/**
 * Completa la segunda mitad del arreglo de probabilidades acumuladas {@code prob}.
 * Copia los valores restantes al final del arreglo {@code prob} ya inicializado por populateProb1().
 *
 * @author Christopher Swenson
 */
private static void populateProb2()
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | - |

| @return | Descripción |
| :--- | :--- |
| `void` | Completa `prob` copiando el segundo bloque de valores vía `System.arraycopy(temp, 0, prob, prob.length - temp.length, temp.length)`. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | - |

---

##### Método `populateChars1()`

```java
/**
 * Inicializa la primera mitad del arreglo de puntos de código {@code chars}.
 * Crea un arreglo de 10002 enteros y copia los puntos de código iniciales.
 *
 * @author Christopher Swenson
 */
private static void populateChars1()
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | - |

| @return | Descripción |
| :--- | :--- |
| `void` | Inicializa el campo estático `chars` con los primeros ~5000 puntos de código. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | - |

---

##### Método `populateChars2()`

```java
/**
 * Completa la segunda mitad del arreglo de puntos de código {@code chars}.
 * Copia los puntos de código restantes al final del arreglo {@code chars}.
 *
 * @author Christopher Swenson
 */
private static void populateChars2()
```

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| *Ninguno* | - | - | - |

| @return | Descripción |
| :--- | :--- |
| `void` | Completa `chars` copiando el segundo bloque vía `System.arraycopy(temp, 0, chars, chars.length - temp.length, temp.length)`. |

| @throws | Condición |
| :--- | :--- |
| Ninguna declarada | - |

---

### 3. Ejemplo de Uso

El siguiente ejemplo muestra un uso real y manual de `CharMatcherBenchmark` fuera del runner de Caliper, y el uso directo de `CharSamples` para generar texto con distribución web.

```java
package com.google.common.base;

import com.google.common.base.BenchmarkHelpers.SampleMatcherConfig;
import java.util.Random;

public class EjemploCharMatcherBenchmark {

    public static void main(String[] args) {
        // 1. Configuración manual del benchmark (normalmente inyectada por Caliper)
        CharMatcherBenchmark benchmark = new CharMatcherBenchmark();
        
        // Simulación de inyección de parámetros @Param
        benchmark.config = SampleMatcherConfig.WHITESPACE; // Ejemplo de config
        benchmark.length = 1024;
        benchmark.percent = 50;
        benchmark.precomputed = true;
        benchmark.size = CharMatcherBenchmark.Size.DEFAULT;
        benchmark.forceSlow = false;
        benchmark.web = false;

        // 2. Inicialización (equivalente a