Claro, aquí tienes la documentación técnica para la clase `com.google.common.collect.Maps` de la librería Guava.

---

### Documentación Técnica: Clase `com.google.common.collect.Maps`

### Descripción General

La clase `Maps` de la librería Guava de Google es una clase de utilidad final (`final`) que proporciona métodos estáticos para trabajar con instancias de `java.util.Map` y sus subtipos, como `SortedMap`, `NavigableMap` y `BiMap`. Al ser una clase de utilidad, no puede ser instanciada (su constructor es privado) y todos sus métodos son estáticos.

El propósito principal de esta clase es ofrecer funcionalidades que no están presentes en el JDK estándar o simplificar tareas comunes relacionadas con los mapas. Estas funcionalidades incluyen la creación de diferentes tipos de mapas, la obtención de vistas transformadas o filtradas, el cálculo de diferencias entre mapas y otras operaciones de conveniencia.

Es el equivalente para mapas de otras clases de utilidad de Guava como `Lists`, `Sets` y `Queues`.

### Métodos Principales

A continuación, se describen algunos de los métodos más importantes y utilizados de la clase `Maps`.

---

#### 1. Métodos de Creación (Factories)

Estos métodos facilitan la creación de instancias mutables de diferentes implementaciones de `Map`.

*   **`newHashMap()`**
    *   **Descripción:** Crea una instancia mutable y vacía de `HashMap`.
    *   **Nota:** Con la introducción del "operador diamante" (`<>`) en Java 7, este método es menos necesario. Se puede usar directamente `new HashMap<>()`.

*   **`newLinkedHashMap()`**
    *   **Descripción:** Crea una instancia mutable y vacía de `LinkedHashMap`, que mantiene el orden de inserción.
    *   **Nota:** Al igual que `newHashMap`, su uso ha sido reemplazado en gran medida por `new LinkedHashMap<>()`.

*   **`newTreeMap()`**
    *   **Descripción:** Crea una instancia mutable y vacía de `TreeMap`, que ordena las claves según su orden natural o un comparador proporcionado.

*   **`newConcurrentMap()`**
    *   **Descripción:** Crea una instancia mutable y vacía de `ConcurrentHashMap`, ideal para entornos concurrentes.

---

#### 2. Métodos de Indexación y Conversión

Estos métodos permiten crear mapas a partir de otras colecciones de una manera declarativa.

*   **`uniqueIndex(Iterable<V> values, Function<? super V, K> keyFunction)`**
    *   **Descripción:** Crea un `ImmutableMap` a partir de un `Iterable` de valores. Para cada valor, se aplica la `keyFunction` para obtener su clave correspondiente en el mapa. El mapa resultante asocia cada clave generada con su valor original.
    *   **Uso:** Es muy útil para crear un "índice" de objetos, permitiendo búsquedas rápidas por un atributo específico.
    *   **Excepción:** Lanza una `IllegalArgumentException` si la `keyFunction` produce la misma clave para más de un valor.
    *   **Nota moderna:** En Java 8 y superior, una funcionalidad similar se puede lograr con `Stream.collect(Collectors.toImmutableMap(keyFunction, v -> v))`.

*   **`toMap(Iterable<K> keys, Function<? super K, V> valueFunction)`**
    *   **Descripción:** Crea un `ImmutableMap` a partir de un `Iterable` de claves. Para cada clave, se aplica la `valueFunction` para calcular su valor correspondiente.
    *   **Uso:** Útil cuando tienes una colección de identificadores y necesitas generar un mapa donde los valores se calculan a partir de esos identificadores.

---

#### 3. Métodos de Comparación

*   **`difference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right)`**
    *   **Descripción:** Calcula la diferencia entre dos mapas y devuelve un objeto `MapDifference`. Este objeto proporciona una vista detallada de las diferencias, incluyendo:
        *   Entradas que solo existen en el mapa de la izquierda (`entriesOnlyOnLeft()`).
        *   Entradas que solo existen en el mapa de la derecha (`entriesOnlyOnRight()`).
        *   Entradas que existen en ambos mapas con el mismo valor (`entriesInCommon()`).
        *   Entradas con claves comunes pero valores diferentes (`entriesDiffering()`).
    *   **Importante:** El resultado es una **instantánea inmutable** del estado de los mapas en el momento de la llamada.

---

#### 4. Métodos de Transformación y Vistas (Views)

Estos métodos devuelven una **vista** del mapa original, lo que significa que los cambios en el mapa original se reflejan en la vista y viceversa. La transformación se aplica de forma "perezosa" (lazy).

*   **`transformValues(Map<K, V1> fromMap, Function<? super V1, V2> function)`**
    *   **Descripción:** Devuelve una vista del mapa donde cada valor es el resultado de aplicar la `function` al valor original. Las claves permanecen intactas.
    *   **Ejemplo:** Se puede usar para transformar un `Map<String, Integer>` en un `Map<String, String>` aplicando `String::valueOf` a cada valor entero.

*   **`transformEntries(Map<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)`**
    *   **Descripción:** Similar a `transformValues`, pero la función de transformación (`EntryTransformer`) recibe tanto la clave como el valor de cada entrada, lo que permite transformaciones más complejas.

---

#### 5. Métodos de Filtrado

Al igual que los métodos de transformación, estos devuelven una **vista** filtrada del mapa original.

*   **`filterKeys(Map<K, V> unfiltered, Predicate<? super K> keyPredicate)`**
    *   **Descripción:** Devuelve una vista del mapa que solo contiene las entradas cuyas claves satisfacen el predicado (`keyPredicate`).
    *   **Comportamiento:** Intentar añadir una entrada con una clave que no cumple el predicado lanzará una `IllegalArgumentException`.

*   **`filterValues(Map<K, V> unfiltered, Predicate<? super V> valuePredicate)`**
    *   **Descripción:** Devuelve una vista del mapa que solo contiene las entradas cuyos valores satisfacen el predicado (`valuePredicate`).

*   **`filterEntries(Map<K, V> unfiltered, Predicate<? super Entry<K, V>> entryPredicate)`**
    *   **Descripción:** La forma más general de filtrado. Devuelve una vista del mapa que contiene solo las entradas que satisfacen el predicado de entrada (`entryPredicate`).

---

#### 6. Otros Métodos de Utilidad

*   **`asMap(Set<K> set, Function<? super K, V> function)`**
    *   **Descripción:** Devuelve una vista de un `Set` como si fuera un `Map`. Las claves del mapa son los elementos del `Set`, y los valores se calculan dinámicamente aplicando la `function` a cada clave cuando se solicita un valor.
    *   **Nota:** El mapa resultante no admite operaciones de escritura como `put` o `putAll`.