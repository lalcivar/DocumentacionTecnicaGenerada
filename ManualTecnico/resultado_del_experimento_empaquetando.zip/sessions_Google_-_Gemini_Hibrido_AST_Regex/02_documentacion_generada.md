Claro, aquí tienes la documentación técnica exhaustiva del código `requests.sessions`, siguiendo el estándar de Docstrings de Google y las especificaciones solicitadas.

***

## Documentación Técnica: Módulo `requests.sessions`

### 1. Resumen ejecutivo

Este módulo proporciona el objeto `Session`, un componente central de la librería `requests`. Su propósito es gestionar y persistir configuraciones a través de múltiples peticiones HTTP, como cookies, cabeceras, autenticación y proxies, además de implementar la lógica de seguimiento de redirecciones y la reutilización de conexiones (connection-pooling).

### 2. Especificación de funciones y métodos

A continuación se detalla cada función y método presente en el módulo.

---

#### `merge_setting(request_setting, session_setting, dict_class)`

Combina una configuración específica de una petición con la configuración global de la sesión. Si ambas configuraciones son diccionarios, se fusionan. La configuración de la petición tiene prioridad sobre la de la sesión.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request_setting` | `Any` | Sí | El valor de configuración proporcionado en la petición individual. |
| `session_setting` | `Any` | Sí | El valor de configuración predeterminado en el objeto `Session`. |
| `dict_class` | `type` | No | La clase de diccionario a usar para la fusión (por defecto `OrderedDict`). |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `merged_setting` | `Any` | La configuración resultante después de la fusión. |

---

#### `merge_hooks(request_hooks, session_hooks, dict_class)`

Fusiona correctamente los hooks de una petición y los de una sesión. Esta función es necesaria para manejar casos especiales donde una lista de hooks vacía en la petición podría anular incorrectamente los hooks de la sesión.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `request_hooks` | `_t.HooksType` | Sí | Diccionario de hooks definido en la petición. |
| `session_hooks` | `_t.HooksType` | Sí | Diccionario de hooks definido en la sesión. |
| `dict_class` | `type` | No | La clase de diccionario a usar para la fusión (por defecto `OrderedDict`). |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `merged_hooks` | `_t.HooksType` | El diccionario de hooks resultante de la fusión. |

---

### Clase `SessionRedirectMixin`

Un mixin que encapsula la lógica para manejar las redirecciones HTTP.

#### `get_redirect_target(self, resp)`

Extrae la URL de redirección desde una respuesta HTTP.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `resp` | `Response` | Sí | El objeto de respuesta que puede contener una cabecera `Location`. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `location` | `str \| None` | La URL de redirección si la respuesta es una redirección; de lo contrario, `None`. |

---

#### `should_strip_auth(self, old_url, new_url)`

Determina si la cabecera `Authorization` debe ser eliminada al seguir una redirección. La autenticación se elimina si el hostname, el puerto o el esquema cambian, con excepciones específicas para redirecciones de HTTP a HTTPS en puertos estándar.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `old_url` | `str` | Sí | La URL original de la petición. |
| `new_url` | `str` | Sí | La nueva URL a la que se está redirigiendo. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `should_strip` | `bool` | `True` si la cabecera de autorización debe ser eliminada, `False` en caso contrario. |

---

#### `resolve_redirects(self, resp, req, stream, timeout, verify, cert, proxies, yield_requests, **adapter_kwargs)`

Gestiona el proceso de seguimiento de redirecciones. Es una función generadora que produce una secuencia de respuestas (`Response`) a medida que sigue cada redirección.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `resp` | `Response` | Sí | La respuesta inicial que desencadenó la redirección. |
| `req` | `PreparedRequest` | Sí | La petición preparada original. |
| `stream` | `bool` | No | Si la respuesta debe ser transmitida en streaming. |
| `timeout` | `_t.TimeoutType` | No | Timeout para las peticiones de redirección. |
| `verify` | `_t.VerifyType` | No | Configuración de verificación SSL. |
| `cert` | `_t.CertType` | No | Certificado de cliente SSL. |
| `proxies` | `dict[str, str] \| None` | No | Diccionario de configuración de proxies. |
| `yield_requests` | `bool` | No | Si es `True`, el generador produce objetos `PreparedRequest` en lugar de `Response`. |
| `**adapter_kwargs` | `Any` | No | Argumentos adicionales para el adaptador. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `generator` | `Generator[Response, None, None]` | Un generador que produce objetos `Response` para cada paso de la redirección. |

| Raises | Tipo | Descripción |
| :--- | :--- | :--- |
| `TooManyRedirects` | `TooManyRedirects` | Se lanza si se excede el número máximo de redirecciones (`max_redirects`). |

---

#### `rebuild_auth(self, prepared_request, response)`

Reconstruye la información de autenticación para una petición redirigida. Elimina la cabecera `Authorization` si es necesario (usando `should_strip_auth`) y busca nuevas credenciales en el archivo `.netrc` si `trust_env` está activado.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `prepared_request` | `PreparedRequest` | Sí | La nueva petición preparada para la redirección. |
| `response` | `Response` | Sí | La respuesta que causó la redirección. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Este método modifica `prepared_request` in-place. |

---

#### `rebuild_proxies(self, prepared_request, proxies)`

Re-evalúa y reconstruye la configuración de proxy para una petición redirigida. Considera las variables de entorno (`NO_PROXY`) y reconstruye la cabecera `Proxy-Authorization` si es necesario.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `prepared_request` | `PreparedRequest` | Sí | La nueva petición preparada para la redirección. |
| `proxies` | `dict[str, str] \| None` | Sí | La configuración de proxy actual. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `new_proxies` | `dict[str, str]` | El diccionario de proxies actualizado para la petición redirigida. |

---

#### `rebuild_method(self, prepared_request, response)`

Ajusta el método HTTP de una petición redirigida según los estándares y el comportamiento común de los navegadores. Por ejemplo, cambia a `GET` para redirecciones 301, 302 y 303 (excepto para `HEAD`).

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `prepared_request` | `PreparedRequest` | Sí | La nueva petición preparada para la redirección. |
| `response` | `Response` | Sí | La respuesta que causó la redirección. |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | Este método modifica `prepared_request.method` in-place. |

---

### Clase `Session`

Objeto principal que gestiona y persiste el estado a través de múltiples peticiones.

#### `__init__(self)`

Inicializa una nueva instancia de `Session`, configurando los valores predeterminados para cabeceras, cookies, proxies, y otros atributos de la sesión.

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | El constructor no retorna ningún valor. |

---

#### `__enter__(self)`

Implementa el protocolo de gestor de contexto, permitiendo el uso de `with requests.Session() as s:`.

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `self` | `Session` | Retorna la propia instancia de la sesión. |

---

#### `__exit__(self, *args)`

Cierra la sesión y sus recursos (como los adaptadores de conexión) al salir del bloque `with`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `*args` | `Any` | Sí | Argumentos de excepción (no utilizados directamente). |

| Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `None` | `None` | No retorna ningún valor. |

---

#### `prepare_request(self, request)`

Construye un objeto `PreparedRequest` fusionando la configuración de la sesión con la