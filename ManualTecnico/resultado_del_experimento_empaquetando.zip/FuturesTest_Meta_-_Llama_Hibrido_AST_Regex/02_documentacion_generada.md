# Documentación Técnica - `com.google.common.util.concurrent.FuturesTest`

> **Paquete:** `com.google.common.util.concurrent`  
> **Clase:** `public class FuturesTest extends TestCase`  
> **Anotaciones:** `@NullMarked`, `@GwtCompatible`  
> **Autor:** `@author Nishant Thakkar`  
> **Dependencia bajo prueba:** `com.google.common.util.concurrent.Futures`  
> **Framework:** JUnit 3 (`junit.framework.TestCase`) + Truth + Guava

---

## 1. Resumen Ejecutivo

`FuturesTest` es la suite de pruebas unitarias exhaustiva para la clase de utilidad `Futures` de Guava. Valida el comportamiento correcto de fábricas de futuros inmediatos (`immediateFuture`, `immediateFailedFuture`, `immediateCancelledFuture`), transformaciones síncronas/asíncronas (`transform`, `transformAsync`, `lazyTransform`), manejo de errores (`catching`, `catchingAsync`), composición (`allAsList`, `successfulAsList`, `whenAllComplete`, `whenAllSucceed`, `inCompletionOrder`), utilidades de ejecución (`submit`, `submitAsync`, `scheduleAsync`, `nonCancellationPropagating`) y garantías de propagación de cancelación, logging y recolección de basura.

La clase extiende `TestCase` y contiene más de 130 métodos de prueba, clases internas, spies y fixtures para cubrir casos de éxito, fallo, cancelación, interrupción, `RejectedExecutionException`, `StackOverflowError` y condiciones de carrera.

---

## 2. Especificación de Métodos y Constructores

### 2.1 Ciclo de Vida JUnit y Estado Interno

| Campo | Tipo | Descripción |
