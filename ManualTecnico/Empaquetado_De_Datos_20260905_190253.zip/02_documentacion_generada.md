# Documentación de APIs - `flask.globals` / `flask.ctx` (Proxies de Contexto)

### 1. Resumen Ejecutivo

Este módulo implementa el sistema de proxies de contexto de Flask basado en `ContextVar` y `werkzeug.local.LocalProxy`. Expone los objetos globales `current_app`, `g`, `request`, `session` y `app_ctx` que resuelven dinámicamente al contexto de aplicación o de petición activo, permitiendo un acceso seguro y aislado por contexto de ejecución sin necesidad de pasar objetos explícitamente. Incluye además un mecanismo de compatibilidad para el acceso deprecado a `request_ctx`.

### 2. Especificación de Funciones

Se han detectado **2 definiciones de funciones/métodos** en el código fuente. No existen funciones anidadas, callbacks ni workers adicionales.

#### 2.1. `ProxyMixin._get_current_object()`

Método de protocolo definido exclusivamente para tipado estático dentro del bloque `if t.TYPE_CHECKING`. Define la interfaz que todos los proxies (`FlaskProxy`, `AppContextProxy`, etc.) exponen para obtener el objeto subyacente.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `ProxyMixin[T]` | Sí | Instancia del proxy. Implícito. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| Objeto subyacente | `T` (covariante) | Retorna la instancia real a la que apunta el `LocalProxy` (`Flask`, `AppContext`, `Request`, etc.). |

| Manejo de Errores | Condición |
| :--- | :--- |
| `RuntimeError` | Lanzado por `LocalProxy` cuando se invoca fuera de un contexto. Mensaje `_no_app_msg` si el proxy depende de `app_ctx` (`current_app`, `g`, `app_ctx`) o `_no_req_msg` si depende de `request` (`request`, `session`). |

> **Clases de Proxy asociadas:** `FlaskProxy`, `AppContextProxy`, `_AppCtxGlobalsProxy`, `RequestProxy`, `SessionMixinProxy`. Todas heredan de `ProxyMixin[T]` y de su tipo proxificado correspondiente. No definen métodos propios; su comportamiento es delegado íntegramente a `LocalProxy`.

#### 2.2. `__getattr__(name: str) -> t.Any`

Función a nivel de módulo que implementa el protocolo [PEP 562](https://peps.python.org/pep-0562/). Intercepta accesos a atributos no encontrados en el módulo para proveer compatibilidad hacia atrás.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `name` | `str` | Sí | Nombre del atributo que se intenta importar desde el módulo. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `app_ctx` | `AppContextProxy` (`LocalProxy[AppContext]`) | Si `name == "request_ctx"`, retorna el proxy `app_ctx` como alias de compatibilidad. |

| Manejo de Errores / Efectos Secundarios | Condición | Descripción |
| :--- | :--- | :--- |
| `DeprecationWarning` | `name == "request_ctx"` | Emite advertencia: `"'request_ctx' has merged with 'app_ctx', and will be removed in Flask 4.0. Use 'app_ctx' instead."` con `stacklevel=2`. |
| `AttributeError` | `name != "request_ctx"` | Lanzado para cualquier otro atributo no existente. Mensaje: `name`. |

**Objetos Globales Expuestos por el Módulo (no son funciones, pero son la API principal):**

| Variable | Tipo Real | ContextVar Base | Mensaje si está desvinculado |
| :--- | :--- | :--- | :--- |
| `app_ctx` | `AppContextProxy` | `_cv_app` | `_no_app_msg` |
| `current_app` | `FlaskProxy` | `_cv_app` -> `app` | `_no_app_msg` |
| `g` | `_AppCtxGlobalsProxy` | `_cv_app` -> `g` | `_no_app_msg` |
| `request` | `RequestProxy` | `_cv_app` -> `request` | `_no_req_msg` |
| `session` | `SessionMixinProxy` | `_cv_app` -> `session` | `_no_req_msg` |

Todos son instancias de `werkzeug.local.LocalProxy` vinculadas a `_cv_app: ContextVar[AppContext]`.

### 3. Ejemplo de Uso

```python
from flask import Flask, current_app, g, request, session, app_ctx

app = Flask(__name__)
app.secret_key = 'secret'

# 1. Uso dentro de contexto de aplicación
with app.app_context():
    # current_app y g resuelven correctamente
    print(f"App activa: {current_app.name}")
    g.usuario_actual = "admin"
    print(f"Usuario en g: {g.usuario_actual}")
    
    # Acceso explícito al objeto subyacente si es necesario
    app_obj = current_app._get_current_object()
    print(type(app_obj)) # <class 'flask.app.Flask'>

# 2. Uso dentro de contexto de petición
with app.test_request_context('/?name=Flask', method='GET'):
    print(f"Path: {request.path}")
    print(f"Args: {request.args.get('name')}")
    session['user_id'] = 123

# 3. Fuera de contexto -> RuntimeError
try:
    print(current_app.name)
except RuntimeError as e:
    print(e) # Working outside of application context...

# 4. Compatibilidad deprecada (emite DeprecationWarning)
import flask.globals
ctx = flask.globals.request_ctx # Equivalente a flask.globals.app_ctx
print(ctx is app_ctx) # True
```