# Manual de Usuario (Alto Nivel) - Módulo `flask.globals`

## 1. Resumen Ejecutivo

Este módulo implementa el sistema de proxies globales y sensibles al contexto de Flask mediante `ContextVar` y `werkzeug.local.LocalProxy`. Expone los objetos `current_app`, `g`, `request`, `session` y `app_ctx` que resuelven dinámicamente al contexto de aplicación o de petición activo, permitiendo acceder al estado de la aplicación sin pasar referencias explícitas. Incluye además compatibilidad tipada para analizadores estáticos y un mecanismo de deprecación para el acceso al antiguo `request_ctx`.

## 2. Especificación de Funciones

El análisis estático del código fuente detecta **1 función a nivel de módulo** en tiempo de ejecución y **1 método de protocolo** definido exclusivamente para tipado estático dentro del bloque `if t.TYPE_CHECKING`. No se detectaron funciones anidadas, callbacks ni workers internos adicionales.

### 2.1. `__getattr__()`

Función a nivel de módulo que implementa el protocolo **PEP 562** para la resolución dinámica de atributos del módulo. Actúa como interceptor para accesos a atributos no definidos explícitamente en el módulo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `name` | `str` | Sí | Nombre del atributo solicitado al módulo mediante `import flask.globals; flask.globals.<name>` o `from flask.globals import <name>`. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `return` | `t.Any` | Si `name == "request_ctx"`, retorna el objeto proxy `app_ctx` (`AppContextProxy`). |

| Manejo de Errores | Tipo de Excepción / Advertencia | Condición Disparadora |
| :--- | :--- | :--- |
| Advertencia de deprecación | `DeprecationWarning` | Se emite cuando `name == "request_ctx"`. Mensaje: `'request_ctx' has merged with 'app_ctx', and will be removed in Flask 4.0. Use 'app_ctx' instead.` con `stacklevel=2`. |
| Atributo no encontrado | `AttributeError` | Se lanza `AttributeError(name)` para cualquier valor de `name` distinto de `"request_ctx"`. |

> **Nota:** Esta es la única función ejecutable en tiempo de ejecución del módulo. Los objetos `app_ctx`, `current_app`, `g`, `request` y `session` no son funciones, sino instancias de `LocalProxy` vinculadas a la variable de contexto `_cv_app`.

### 2.2. `ProxyMixin._get_current_object()`

Método definido dentro del protocolo `ProxyMixin` bajo la guarda `if t.TYPE_CHECKING`. No se ejecuta en tiempo de ejecución; su propósito es informar a los verificadores de tipos (mypy, pyright) que los proxies exponen el método de resolución del objeto subyacente.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `ProxyMixin[T]` | Sí (implícito) | Instancia del proxy. |

| Valor de Retorno | Tipo | Descripción |
| :--- | :--- | :--- |
| `return` | `T` | Retorna la instancia real del objeto proxificado (`Flask`, `AppContext`, `_AppCtxGlobals`, `Request` o `SessionMixin` según el proxy concreto). El tipo es covariante. |

| Manejo de Errores | Condición |
| :--- | :--- |
| `RuntimeError` (en tiempo de ejecución vía `LocalProxy`) | Si se invoca fuera de un contexto válido, `LocalProxy` lanza `RuntimeError` con el mensaje `_no_app_msg` ("Working outside of application context...") para `current_app`, `g`, `app_ctx`, o `_no_req_msg` ("Working outside of request context...") para `request` y `session`. Este comportamiento es heredado de `werkzeug.local.LocalProxy`, no implementado directamente en este método. |

#### Clases de Tipado Asociadas que heredan `ProxyMixin._get_current_object()`

Estas clases no definen métodos adicionales y existen únicamente para tipado estático. Todas heredan `ProxyMixin._get_current_object()` sin reimplementación:

*   `FlaskProxy(ProxyMixin[Flask], Flask)`
*   `AppContextProxy(ProxyMixin[AppContext], AppContext)`
*   `_AppCtxGlobalsProxy(ProxyMixin[_AppCtxGlobals], _AppCtxGlobals)`
*   `RequestProxy(ProxyMixin[Request], Request)`
*   `SessionMixinProxy(ProxyMixin[SessionMixin], SessionMixin)`

**Cobertura total:** No se detectaron funciones anidadas, locales, lambdas, callbacks o métodos auxiliares adicionales dentro de `__getattr__()` o en el resto del módulo.

## 3. Ejemplo de Uso

Caso real que demuestra el acceso a los proxies dentro y fuera de contexto, y el comportamiento de `__getattr__()` para el atributo deprecado:

```python
from flask import Flask, current_app, g, request, session, app_ctx
import warnings

app = Flask(__name__)
app.secret_key = 'dev-key'

# 1. Acceso dentro del contexto de aplicación
with app.app_context():
    # current_app resuelve a la instancia 'app' vía _cv_app
    print(f"App en contexto: {current_app.name}")
    print(f"app_ctx es válido: {app_ctx.app == current_app}")

    # 'g' es un namespace global por contexto
    g.usuario_actual = "admin"
    print(f"Usuario en g: {g.usuario_actual}")

    # Acceso directo al objeto subyacente si es necesario
    app_real = current_app._get_current_object()
    print(f"Objeto real: {type(app_real)}")

# 2. Acceso dentro del contexto de petición
with app.test_request_context('/?q=flask', method='GET'):
    print(f"Path del request: {request.path}")
    print(f"Args: {request.args.get('q')}")
    session['visitas'] = 1
    print(f"Sesión: {session['visitas']}")

# 3. Error fuera de contexto
try:
    print(current_app.name)
except RuntimeError as e:
    print(f"Error esperado: {e}") # Working outside of application context.

# 4. Acceso deprecado interceptado por __getattr__()
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter("always")
    from flask import globals as flask_globals
    ctx_deprecado = flask_globals.request_ctx # Invoca a __getattr__("request_ctx")
    print(f"Advertencia: {w[0].category.__name__}: {w[0].message}")
    print(f"request_ctx es app_ctx: {ctx_deprecado is app_ctx}")
```