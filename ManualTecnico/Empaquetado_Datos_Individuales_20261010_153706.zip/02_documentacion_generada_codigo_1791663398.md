# Docstrings de funciones - Módulo `Config`

## 1. Resumen ejecutivo

Este código implementa el sistema de configuración de Flask. La clase `Config` extiende `dict` para almacenar la configuración de la aplicación y proporciona múltiples métodos para cargarla desde archivos Python, objetos, mapeos, ficheros genéricos y variables de entorno. La clase descriptor `ConfigAttribute` permite exponer claves de configuración como atributos de la instancia `App` con conversión opcional de tipos.

## 2. Especificación de funciones

### `ConfigAttribute.__init__()`

Inicializa un descriptor que redirige el acceso a un atributo hacia `app.config`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `name` | `str` | Sí | Nombre de la clave en `app.config` a la que se vincula el atributo. |
| `get_converter` | `Callable[[Any], T] \| None` | No | Función opcional para convertir el valor obtenido de la configuración. Por defecto `None`. |

**Valor de retorno:** `None`

**Manejo de errores:** No lanza errores propios.

---

### `ConfigAttribute.__get__()`

Implementa el protocolo descriptor para la lectura del atributo. Si se accede desde la clase, retorna el propio descriptor; si se accede desde una instancia de `App`, retorna el valor de configuración.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `App \| None` | Sí | Instancia de la aplicación. `None` si el acceso es a nivel de clase. |
| `owner` | `type[App] \| None` | No | Clase propietaria del descriptor. Por defecto `None`. |

**Valor de retorno:** `T | Self` - Retorna `Self` si `obj is None`. En caso contrario retorna el valor `T` almacenado en `obj.config[name]`, convertido por `get_converter` si está definido.

**Manejo de errores:**
*   `KeyError`: Si la clave `self.__name__` no existe en `obj.config`.

> **Nota sobre sobrecargas:** El método posee dos sobrecargas tipadas con `@t.overload` para el chequeo estático: `__get__(obj: None, owner: None) -> Self` y `__get__(obj: App, owner: type[App]) -> T`.

---

### `ConfigAttribute.__set__()`

Implementa el protocolo descriptor para la escritura del atributo, delegando la asignación al diccionario de configuración.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `App` | Sí | Instancia de la aplicación donde se establecerá el valor. |
| `value` | `Any` | Sí | Valor a asignar en `obj.config[self.__name__]`. |

**Valor de retorno:** `None`

**Manejo de errores:** No lanza errores propios.

---

### `Config.__init__()`

Inicializa el diccionario de configuración.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `root_path` | `str \| os.PathLike[str]` | Sí | Ruta base respecto a la cual se resuelven los ficheros de configuración relativos. Normalmente `Flask.root_path`. |
| `defaults` | `dict[str, Any] \| None` | No | Diccionario opcional de valores por defecto. Por defecto `None`. |

**Valor de retorno:** `None`

**Manejo de errores:** No lanza errores propios.

---

### `Config.from_envvar()`

Carga configuración desde un fichero cuya ruta está definida en una variable de entorno.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `variable_name` | `str` | Sí | Nombre de la variable de entorno que contiene la ruta al fichero. |
| `silent` | `bool` | No | Si es `True`, no lanza error si la variable no existe o el fichero no se encuentra. Por defecto `False`. |

**Valor de retorno:** `bool` - `True` si el fichero se cargó correctamente, `False` si `silent=True` y la variable no está definida.

**Manejo de errores:**
*   `RuntimeError`: Si la variable de entorno no está definida o está vacía y `silent` es `False`.
*   Propaga `OSError` proveniente de `from_pyfile` si el fichero no puede cargarse y `silent` es `False`.

---

### `Config.from_prefixed_env()`

Carga variables de entorno que comienzan con un prefijo determinado, convirtiendo sus valores y soportando claves anidadas mediante `__`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `prefix` | `str` | No | Prefijo a filtrar. Se le añade `_` automáticamente. Por defecto `"FLASK"`. |
| `loads` | `Callable[[str], Any]` | No | Función para deserializar cada valor string. Por defecto `json.loads`. Es *keyword-only*. |

**Valor de retorno:** `bool` - Siempre retorna `True`.

**Manejo de errores:**
*   Ignora silenciosamente cualquier `Exception` lanzada por `loads` y mantiene el valor como `str`.
*   Si una clave contiene `__`, crea diccionarios intermedios vacíos si no existen.

---

### `Config.from_pyfile()`

Actualiza la configuración ejecutando un fichero Python y cargando sus variables en mayúsculas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| os.PathLike[str]` | Sí | Ruta del fichero. Puede ser absoluta o relativa a `root_path`. |
| `silent` | `bool` | No | Si es `True`, retorna `False` en lugar de lanzar error si el fichero no existe. Por defecto `False`. |

**Valor de retorno:** `bool` - `True` si el fichero se cargó correctamente, `False` si `silent=True` y el fichero no existe.

**Manejo de errores:**
*   `OSError`: Si el fichero no puede abrirse/leerse y `silent` es `False` o el `errno` no es `ENOENT`, `EISDIR` o `ENOTDIR`. Modifica `e.strerror` a `"Unable to load configuration file (...)"` antes de relanzar.

---

### `Config.from_object()`

Carga configuración desde un objeto, módulo o string de importación, considerando solo atributos en mayúsculas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `object \| str` | Sí | Objeto de configuración o string de importación (ej. `'myapp.config'`). |

**Valor de retorno:** `None`

**Manejo de errores:**
*   `ImportError` / `ModuleNotFoundError`: Si `obj` es un string y `import_string` no puede importarlo.
*   No valida que `obj` sea un `dict`; los `dict` no funcionarán porque sus claves no son atributos.

---

### `Config.from_file()`

Carga configuración desde un fichero arbitrario utilizando una función `load` personalizada y delega en `from_mapping`.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| os.PathLike[str]` | Sí | Ruta del fichero, absoluta o relativa a `root_path`. |
| `load` | `Callable[[IO[Any]], Mapping[str, Any]]` | Sí | Callable que recibe un handle de fichero y retorna un `Mapping` con los datos. |
| `silent` | `bool` | No | Si es `True`, ignora el error si el fichero no existe. Por defecto `False`. |
| `text` | `bool` | No | Si es `True` abre el fichero en modo texto `"r"`, si es `False` en modo binario `"rb"`. Por defecto `True`. |

**Valor de retorno:** `bool` - `True` si el fichero se cargó y `from_mapping` se ejecutó correctamente, `False` si `silent=True` y el fichero no existe.

**Manejo de errores:**
*   `OSError`: Si el fichero no puede abrirse y `silent` es `False` o el `errno` no es `ENOENT` o `EISDIR`. Modifica `e.strerror` antes de relanzar.
*   Propaga cualquier excepción lanzada por la función `load`.

---

### `Config.from_mapping()`

Actualiza la configuración a partir de un mapeo y/o `kwargs`, ignorando claves que no estén en mayúsculas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `mapping` | `Mapping[str, Any] \| None` | No | Mapeo con valores de configuración. Por defecto `None`. |
| `**kwargs` | `Any` | No | Pares clave-valor adicionales. Tienen prioridad sobre `mapping`. |

**Valor de retorno:** `bool` - Siempre retorna `True`.

**Manejo de errores:** No lanza errores. Filtra silenciosamente cualquier clave donde `key.isupper()` sea `False`.

---

### `Config.get_namespace()`

Retorna un sub-diccionario con las opciones que coinciden con un prefijo/namespace.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `namespace` | `str` | Sí | Prefijo a filtrar (ej. `'IMAGE_STORE_'`). |
| `lowercase` | `bool` | No | Si es `True`, convierte las claves resultantes a minúsculas. Por defecto `True`. |
| `trim_namespace` | `bool` | No | Si es `True`, elimina el prefijo de las claves resultantes. Por defecto `True`. |

**Valor de retorno:** `dict[str, Any]` - Diccionario filtrado y transformado según los flags.

**Manejo de errores:** No lanza errores. Retorna diccionario vacío si no hay coincidencias.

---

### `Config.__repr__()`

Retorna la representación oficial del objeto.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Config` | Sí | Instancia de la configuración. |

**Valor de retorno:** `str` - Cadena con formato `"<Config {contenido_del_dict}>"`.

**Manejo de errores:** No lanza errores.

## 3. Ejemplo de uso

```python
import json
import os
from flask import Flask

# 1. Inicialización y carga desde objeto
class DefaultConfig:
    DEBUG = False
    SECRET_KEY = 'dev-key'
    IMAGE_STORE_TYPE = 'fs'
    IMAGE_STORE_PATH = '/var/app/images'
    lowercase_key = 'este valor será ignorado'

app = Flask(__name__)
app.config.from_object(DefaultConfig)
app.config.from_mapping(ENV='production', DEBUG=True)

# 2. Carga desde fichero Python y desde variable de entorno
# app.config.from_pyfile('config.cfg', silent=True)
# os.environ['MYAPP_SETTINGS'] = '/path/to/config.cfg'
# app.config.from_envvar('MYAPP_SETTINGS', silent=False)

# 3. Carga desde variables de entorno con prefijo y anidamiento
os.environ['FLASK_CACHE__REDIS__HOST'] = '"localhost"'
os.environ['FLASK_CACHE__REDIS__PORT'] = '6379'
app.config.from_prefixed_env(prefix='FLASK', loads=json.loads)
# Resultado: app.config['CACHE'] == {'REDIS': {'HOST': 'localhost', 'PORT': 6379}}

# 4. Carga desde fichero JSON genérico
# app.config.from_file('config.json', load=json.load, text=True)

# 5. Uso de get_namespace para extraer un subconjunto
image_store_config = app.config.get_namespace('IMAGE_STORE_')
print(image_store_config)
# {'type': 'fs', 'path': '/var/app/images'}

# 6. Uso de ConfigAttribute en una App personalizada
from flask.config import ConfigAttribute

class MyApp(Flask):
    debug_mode = ConfigAttribute('DEBUG', get_converter=bool)

print(app.config)  # <Config {'DEBUG': True, 'SECRET_KEY': 'dev-key', ...}>
```
