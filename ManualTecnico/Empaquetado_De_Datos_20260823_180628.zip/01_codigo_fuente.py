import os
import requests
import customtkinter as ctk
from tkinter import filedialog, messagebox
from dotenv import load_dotenv

# 1. Cargar la API Key desde el archivo .env
load_dotenv()
API_KEY = os.getenv("OPENROUTER_API_KEY")

# Configurar el aspecto visual (Modo Oscuro)
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# Diccionario que conecta lo que ve el usuario con los IDs oficiales de OpenRouter
MODELOS_OPENROUTER = {
    "Anthropic - Claude 3.5 Sonnet": "anthropic/claude-3.5-sonnet",
    "OpenAI - ChatGPT (GPT-4o)": "openai/gpt-4o",
    "Google - Gemini 1.5 Pro": "google/gemini-pro-1.5",
    "Meta - Llama 3.3 70B Instruct": "meta-llama/llama-3.3-70b-instruct"
}

class AplicacionDocumentador(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Configuración de la ventana principal
        self.title("GENERADOR CIENTÍFICO DE DOCUMENTACIÓN CON LLMS")
        self.geometry("1000x700")

        # Variables para guardar datos en memoria
        self.contenido_codigo = ""

        # --- 1. PANEL DE CONFIGURACIÓN (SUPERIOR) ---
        self.frame_config = ctk.CTkFrame(self)
        self.frame_config.pack(padx=15, pady=(15, 5), fill="x")

        # Título del panel
        self.lbl_config = ctk.CTkLabel(self.frame_config, text="1. PANEL DE CONFIGURACIÓN", font=("Arial", 12, "bold"))
        self.lbl_config.pack(anchor="w", padx=10, pady=(5, 0))

        # Sub-contenedor para controles de configuración
        self.subframe_config = ctk.CTkFrame(self.frame_config, fg_color="transparent")
        self.subframe_config.pack(fill="x", padx=10, pady=5)

        self.lbl_modelo = ctk.CTkLabel(self.subframe_config, text="MODELO LLM:")
        self.lbl_modelo.pack(side="left", padx=(0, 5))

        self.combo_modelos = ctk.CTkOptionMenu(
            self.subframe_config, 
            values=list(MODELOS_OPENROUTER.keys()),
            width=280
        )
        self.combo_modelos.pack(side="left", padx=5)

        # Estado de seguridad de la API Key
        self.lbl_sec_status = ctk.CTkLabel(
            self.subframe_config, 
            text="🔒 API Key Cargada (.env)" if API_KEY else "⚠️ Sin API Key",
            text_color="#34d399" if API_KEY else "#f87171"
        )
        self.lbl_sec_status.pack(side="right", padx=10)

        # --- 2. PANEL DE ARCHIVO Y ARTEFACTO ---
        self.frame_archivo = ctk.CTkFrame(self)
        self.frame_archivo.pack(padx=15, pady=5, fill="x")

        self.lbl_panel_archivo = ctk.CTkLabel(self.frame_archivo, text="2. PANEL DE ARCHIVO Y ARTEFACTO", font=("Arial", 12, "bold"))
        self.lbl_panel_archivo.pack(anchor="w", padx=10, pady=(5, 0))

        self.subframe_archivo = ctk.CTkFrame(self.frame_archivo, fg_color="transparent")
        self.subframe_archivo.pack(fill="x", padx=10, pady=5)

        self.btn_generar.pack(padx=15, pady=10, fill="x")

        # --- 3 y 4. PANELS DE CÓDIGO Y RESULTADO (LADO A LADO) ---
        self.frame_editores = ctk.CTkFrame(self, fg_color="transparent")
        self.frame_editores.pack(padx=15, pady=5, fill="both", expand=True)

        # Lado Izquierdo: Entrada de Código
        self.frame_izq = ctk.CTkFrame(self.frame_editores)
        self.frame_izq.pack(side="left", fill="both", expand=True, padx=(0, 5))

        self.lbl_izq = ctk.CTkLabel(self.frame_izq, text="3. ENTRADA DE CÓDIGO FUENTE", font=("Arial", 11, "bold"))
        self.lbl_izq.pack(anchor="w", padx=10, pady=5)

        self.txt_codigo = ctk.CTkTextbox(self.frame_izq, font=("Consolas", 12))
        self.txt_codigo.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        # Lado Derecho: Documentación Generada
        self.frame_der = ctk.CTkFrame(self.frame_editores)
        self.frame_der.pack(side="right", fill="both", expand=True, padx=(5, 0))

        self.lbl_der = ctk.CTkLabel(self.frame_der, text="4. RESULTADO DE DOCUMENTACIÓN GENERADA", font=("Arial", 11, "bold"))
        self.lbl_der.pack(anchor="w", padx=10, pady=5)

        self.txt_resultado = ctk.CTkTextbox(self.frame_der, font=("Arial", 12))
        self.txt_resultado.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        # --- BANDA INFERIOR DE ESTADO ---
        self.frame_status = ctk.CTkFrame(self, height=35)
        self.frame_status.pack(padx=15, pady=(5, 15), fill="x")

        self.lbl_estado = ctk.CTkLabel(self.frame_status, text="Estado: Listo para procesar", text_color="#38bdf8")
        self.lbl_estado.pack(side="left", padx=10, pady=5)

    # --- FUNCIONALIDADES ---
    def cargar_archivo(self):
        """Abre una ventana para elegir un archivo de código"""
        ruta_archivo = filedialog.askopenfilename(
            filetypes=[("Archivos Java", "*.java"),("Archivos Python", "*.py"),("Todos los archivos", "*.*")]
        )
        if ruta_archivo:
            nombre_archivo = os.path.basename(ruta_archivo)
            self.lbl_archivo_cargado.configure(text=f"Cargado: {nombre_archivo}", text_color="#34d399")
            
            # Leer el archivo y mostrarlo en la caja de código
            with open(ruta_archivo, "r", encoding="utf-8") as f:
                self.contenido_codigo = f.read()
                
            self.txt_codigo.delete("1.0", "end")
            self.txt_codigo.insert("1.0", self.contenido_codigo)

    def generar_documentacion(self):
        """Envía la solicitud a OpenRouter"""
        if not API_KEY:
            messagebox.showerror("Error de Configuración", "No se encontró la OPENROUTER_API_KEY en el archivo .env")
            return

        codigo = self.txt_codigo.get("1.0", "end-str").strip()
        if not codigo:
            messagebox.showwarning("Advertencia", "Por favor carga un archivo o escribe código antes de generar.")
            return

        # Actualizar estado a "Procesando..."
        self.lbl_estado.configure(text="Estado: ⏳ Generando documentación con OpenRouter...", text_color="#facc15")
        self.update() # Actualiza la ventana inmediatamente

        modelo_nombre = self.combo_modelos.get()
        modelo_id = MODELOS_OPENROUTER[modelo_nombre]
        tipo_artefacto = self.combo_artefacto.get()

        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": modelo_id,
            "messages": [
                {
                    "role": "system", 
                    "content": f"Eres un experto en documentación de código. Genera un/a '{tipo_artefacto}' bien estructurado en Markdown."
                },
                {
                    "role": "user", 
                    "content": f"Documenta el siguiente código:\n\n```\n{codigo}\n```"
                }
            ],
            "temperature": 0.2  # Baja temperatura para evitar alucinaciones
        }

        try:
            response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload)
            if response.status_code == 200:
                resultado = response.json()['choices'][0]['message']['content']
                self.txt_resultado.delete("1.0", "end")
                self.txt_resultado.insert("1.0", resultado)
                self.lbl_estado.configure(text="Estado: ✅ Generación completada con éxito", text_color="#34d399")
            else:
                messagebox.showerror("Error API", f"Error {response.status_code}: {response.text}")
                self.lbl_estado.configure(text="Estado: ❌ Error en la llamada API", text_color="#f87171")
        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error inesperado: {str(e)}")
            self.lbl_estado.configure(text="Estado: ❌ Error de conexión", text_color="#f87171")

# Ejecutar la aplicación
if __name__ == "__main__":
    app = AplicacionDocumentador()
    app.mainloop()