Claro, aquí tienes el manual de usuario de alto nivel para el código proporcionado.

***

# Manual de Usuario: Módulo de Carga de Archivos

## 1. Resumen Ejecutivo

Este módulo proporciona funcionalidades para cargar archivos de código fuente (`.py`, `.java`) a través de un diálogo de selección de archivos. Incluye un método para el procesamiento avanzado que separa el código de su documentación (Docstrings/Javadoc) y otro método para una carga simple que lee el contenido completo del archivo sin modificaciones. Ambas funciones están diseñadas para operar dentro de una interfaz gráfica de usuario, actualizando los componentes visuales correspondientes.

## 2. Especificación de Funciones

### `cargar_archivo_codigo(self)`

Esta función abre un diálogo para que el usuario seleccione un archivo de código Python o Java. Una vez seleccionado, procesa el archivo para separar el código ejecutable de los comentarios de documentación (Docstrings o Javadoc), que se consideran el "Ground Truth". El código limpio se muestra en la interfaz y el Ground Truth se almacena internamente.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| (Ninguno) | N/A | N/A | La función no recibe parámetros de entrada directos del usuario. |

**Valor de Retorno**

- **Tipo:** `None`
- **Descripción:** La función no retorna ningún valor. Sus resultados son efectos secundarios: actualiza un campo de texto en la GUI con el código limpio y almacena el Ground Truth en una variable de instancia (`self.ground_truth_extraido`).

**Manejo de Errores**

- Si el usuario cancela el diálogo de selección de archivo, la función termina su ejecución silenciosamente.
- Si ocurre cualquier excepción durante la lectura o el procesamiento del archivo (ej. `procesar_archivo_codigo` falla), se mostrará una ventana emergente (`messagebox.showerror`) con el detalle del error.
- Si el archivo no contiene documentación extraíble, se muestra una advertencia (`messagebox.showwarning`) pero el código limpio se carga igualmente.

---

### `cargar_archivo(self)`

Esta función abre un diálogo para que el usuario seleccione un archivo de código. Lee el contenido completo del archivo seleccionado y lo inserta directamente en un área de texto de la interfaz, sin realizar ningún tipo de procesamiento o separación.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| (Ninguno) | N/A | N/A | La función no recibe parámetros de entrada directos del usuario. |

**Valor de Retorno**

- **Tipo:** `None`
- **Descripción:** La función no retorna ningún valor. Su resultado es un efecto secundario: actualiza un campo de texto en la GUI (`self.txt_codigo`) con el contenido íntegro del archivo.

**Manejo de Errores**

- Si el usuario cancela el diálogo de selección de archivo, la función termina su ejecución silenciosamente.
- El código no implementa un manejo de errores explícito con ventanas emergentes para esta función. Se basa en el manejo de excepciones estándar de las operaciones de E/S de archivos en Python (ej. `with open(...)`).

## 3. Ejemplo de Uso

El siguiente código demuestra cómo integrar estas funciones en una aplicación simple de Tkinter. Se asume que las funciones son métodos de una clase que gestiona la interfaz gráfica.

```python
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import os

# --- Bloque de Simulación ---
# Dado que 'procesar_archivo_codigo' no se proporciona, lo simulamos para el ejemplo.
def procesar_archivo_codigo(ruta_archivo):
    """
    Función simulada que separa código de 'docstrings'.
    """
    codigo_limpio = ""
    ground_truth = ""
    with open(ruta_archivo, 'r', encoding='utf-8') as f:
        contenido = f.read()
    
    # Lógica simple de ejemplo: Asumimos que el docstring está al inicio
    if '"""' in contenido:
        partes = contenido.split('"""', 2)
        if len(partes) == 3:
            ground_truth = partes[1].strip()
            codigo_limpio = (partes[0] + partes[2]).strip()
        else:
            codigo_limpio = contenido
    else:
        codigo_limpio = contenido
        
    return codigo_limpio, ground_truth
# --- Fin del Bloque de Simulación ---


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Demo de Carga de Archivos")
        self.geometry("800x600")

        # Variables internas
        self.ground_truth_extraido = ""
        self.contenido_codigo = ""

        # --- Widgets para cargar_archivo_codigo ---
        frame1 = tk.LabelFrame(self, text="Carga con Procesamiento Avanzado")
        frame1.pack(padx=10, pady=10, fill="x")
        
        btn_cargar_procesado = tk.Button(frame1, text="Cargar y Procesar Archivo", command=self.cargar_archivo_codigo)
        btn_cargar_procesado.pack(pady=5)
        
        self.txt_codigo_entrada = scrolledtext.ScrolledText(frame1, height=10)
        self.txt_codigo_entrada.pack(padx=5, pady=5, fill="both", expand=True)

        # --- Widgets para cargar_archivo ---
        frame2 = tk.LabelFrame(self, text="Carga Simple de Archivo")
        frame2.pack(padx=10, pady=10, fill="x")

        self.lbl_archivo_cargado = tk.Label(frame2, text="Ningún archivo cargado")
        self.lbl_archivo_cargado.pack(pady=5)
        
        btn_cargar_simple = tk.Button(frame2, text="Cargar Archivo Completo", command=self.cargar_archivo)
        btn_cargar_simple.pack(pady=5)
        
        self.txt_codigo = scrolledtext.ScrolledText(frame2, height=10)
        self.txt_codigo.pack(padx=5, pady=5, fill="both", expand=True)

    # --- Métodos a documentar ---
    def cargar_archivo_codigo(self):
        ruta = filedialog.askopenfilename(
            title="Seleccionar archivo de código",
            filetypes=[("Código Python y Java", "*.py *.java"), ("Python", "*.py"), ("Java", "*.java")]
        )
        if not ruta:
            return

        try:
            codigo_limpio, ground_truth = procesar_archivo_codigo(ruta)
            
            if not ground_truth:
                messagebox.showwarning("Aviso", "El archivo cargado no contiene Docstrings o Javadoc para usar como Ground Truth.")

            self.txt_codigo_entrada.delete("1.0", "end")
            self.txt_codigo_entrada.insert("1.0", codigo_limpio)
            self.ground_truth_extraido = ground_truth

            messagebox.showinfo("Éxito", "Archivo cargado y procesado.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo procesar el archivo: {e}")
            
    def cargar_archivo(self):
        ruta_archivo = filedialog.askopenfilename(
            filetypes=[("Archivos Java", "*.java"),("Archivos Python", "*.py"),("Todos los archivos", "*.*")]
        )
        if ruta_archivo:
            nombre_archivo = os.path.basename(ruta_archivo)
            self.lbl_archivo_cargado.configure(text=f"Cargado: {nombre_archivo}", foreground="#34d399")
            
            with open(ruta_archivo, "r", encoding="utf-8") as f:
                self.contenido_codigo = f.read()
                
            self.txt_codigo.delete("1.0", "end")
            self.txt_codigo.insert("1.0", self.contenido_codigo)

if __name__ == "__main__":
    app = App()
    app.mainloop()
```