def cargar_archivo_codigo(self):
    ruta = filedialog.askopenfilename(
        title="Seleccionar archivo de código",
        filetypes=[("Código Python y Java", "*.py *.java"), ("Python", "*.py"), ("Java", "*.java")]
    )
    if not ruta:
        return

    try:
        # Extraer automáticamente código limpio y Ground Truth
        codigo_limpio, ground_truth = procesar_archivo_codigo(ruta)
        
        if not ground_truth:
            messagebox.showwarning("Aviso", "El archivo cargado no contiene Docstrings o Javadoc para usar como Ground Truth.")

        # 1. Insertar SOLO el código limpio en el área de texto principal
        self.txt_codigo_entrada.delete("1.0", "end")
        self.txt_codigo_entrada.insert("1.0", codigo_limpio)

        # 2. Guardar el Ground Truth extraído en la variable interna
        self.ground_truth_extraido = ground_truth

        messagebox.showinfo("Éxito", "Archivo cargado correctamente.\nEl código fue separado de la documentación de referencia (Ground Truth).")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo procesar el archivo: {e}")
        
        def cargar_archivo(self):
        """Abre una ventana para elegir un archivo de código"""
        ruta_archivo = filedialog.askopenfilename(
            filetypes=[("Archivos Java", "*.java"),("Archivos Python", "*.py"),("Todos los archivos", "*.*")]
        )
        if ruta_archivo:
            nombre_archivo = os.path.basename(ruta_archivo)
            self.lbl_archivo_cargado.configure(text=f"Cargado: {nombre_archivo}", text_color="#34d399")
            
            # Leer el archivo y mostrarlo en la caja de código
            with open(ruta_archivo, "r", encoding="utf-8") as f:
                self.contenido_codigo = f.read()
                
            self.txt_codigo.delete("1.0", "end")
            self.txt_codigo.insert("1.0", self.contenido_codigo)