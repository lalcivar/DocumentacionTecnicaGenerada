# Manual de Usuario (Alto Nivel) - Módulo `Config`

## 1. Resumen Ejecutivo

Este código implementa el sistema de gestión de configuración de Flask. La clase `Config` extiende `dict` para almacenar parámetros de configuración de la aplicación y provee múltiples métodos para cargarlos desde archivos Python, objetos, diccionarios, archivos genéricos y variables de entorno. La clase `ConfigAttribute` es un descriptor que permite exponer claves de la configuración como atributos tipados de la instancia `App`.

## 2. Especificación de Funciones

### 2.1 Clase `ConfigAttribute`

Descriptor genérico `ConfigAttribute[T]` que redirige el acceso a un atributo hacia `app.config`.

#### `ConfigAttribute.__init__()`

Constructor del descriptor.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `name` | `str` | Sí | Nombre de la clave en `app.config` a la que se hará forward. |
| `get_converter` | `Callable[[Any], T] \| None` | No | Función opcional para convertir el valor obtenido de la configuración. Por defecto `None`. |

**Valor de retorno:** `None`

**Manejo de errores:** No genera errores propios.

#### `ConfigAttribute.__get__()`

Implementa el protocolo descriptor para la lectura del atributo. Presenta dos sobrecargas tipadas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `App \| None` | Sí | Instancia de la aplicación. Si es `None`, se accede desde la clase. |
| `owner` | `type[App] \| None` | No | Clase propietaria del descriptor. Por defecto `None`. |

**Valor de retorno:** 
* Si `obj is None` -> retorna `te.Self` (el propio descriptor).
* Si `obj is not None` -> retorna `T`, el valor de `obj.config[name]` opcionalmente convertido por `get_converter`.

**Manejo de errores:** Lanza `KeyError` si `self.__name__` no existe en `obj.config`.

#### `ConfigAttribute.__set__()`

Implementa el protocolo descriptor para la escritura del atributo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `App` | Sí | Instancia de la aplicación donde se escribirá la configuración. |
| `value` | `Any` | Sí | Valor a asignar en `obj.config[self.__name__]`. |

**Valor de retorno:** `None`

**Manejo de errores:** No genera errores propios.

---

### 2.2 Clase `Config`

Clase que hereda de `dict` y centraliza toda la lógica de carga de configuración.

#### `Config.__init__()`

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `root_path` | `str \| os.PathLike[str]` | Sí | Ruta base contra la cual se resuelven los nombres de archivo relativos. Normalmente `Flask.root_path`. |
| `defaults` | `dict[str, Any] \| None` | No | Diccionario de valores por defecto para inicializar la configuración. Por defecto `None` (dict vacío). |

**Valor de retorno:** `None`

**Manejo de errores:** No genera errores propios.

#### `Config.from_envvar()`

Carga configuración desde un archivo Python cuya ruta está definida en una variable de entorno.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `variable_name` | `str` | Sí | Nombre de la variable de entorno que contiene la ruta al archivo. |
| `silent` | `bool` | No | Si es `True`, no falla si la variable o el archivo no existen. Por defecto `False`. |

**Valor de retorno:** `bool` - `True` si el archivo se cargó correctamente, `False` si `silent=True` y no se encontró.

**Manejo de errores:** 
* Lanza `RuntimeError` si la variable de entorno no está definida o está vacía y `silent` es `False`.
* Delega en `from_pyfile()` para errores de lectura del archivo.

#### `Config.from_prefixed_env()`

Carga variables de entorno que comienzan con un prefijo determinado y las convierte a tipos Python.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `prefix` | `str` | No | Prefijo a filtrar. Por defecto `"FLASK"`. Se busca `f"{prefix}_"`. |
| `loads` | `Callable[[str], Any]` | No | Función para deserializar valores string. Por defecto `json.loads`. Es *keyword-only*. |

**Valor de retorno:** `bool` - Siempre retorna `True`.

**Manejo de errores:** 
* No lanza errores. Si `loads(value)` falla (cualquier `Exception`), se ignora el error y se conserva el valor como `str`.
* Soporta claves anidadas separadas por `__` (ej: `FLASK_CACHE__REDIS__HOST`). Si una clave intermedia no existe, se crea un `dict` vacío automáticamente. Las claves se procesan en orden `sorted(os.environ)`.

#### `Config.from_pyfile()`

Actualiza la configuración ejecutando un archivo Python como código.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| os.PathLike[str]` | Sí | Nombre del archivo. Puede ser absoluto o relativo a `root_path`. |
| `silent` | `bool` | No | Si es `True`, ignora silenciosamente si el archivo no existe. Por defecto `False`. |

**Valor de retorno:** `bool` - `True` si se cargó, `False` si `silent=True` y el archivo no existe.

**Manejo de errores:** 
* Captura `OSError`. Si `silent` es `True` y `e.errno` es `ENOENT`, `EISDIR` o `ENOTDIR`, retorna `False`.
* En caso contrario, modifica `e.strerror` a `"Unable to load configuration file (...)"` y relanza la excepción.
* Internamente crea un `types.ModuleType("config")` y ejecuta `exec(compile(...))`, luego delega en `from_object()`.

#### `Config.from_object()`

Carga solo los atributos en mayúsculas de un objeto o módulo.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `obj` | `object \| str` | Sí | Objeto de configuración o string de importación (ej: `'myapp.config'`). |

**Valor de retorno:** `None`

**Manejo de errores:** 
* Si `obj` es `str`, utiliza `werkzeug.utils.import_string` y puede lanzar `ImportError` si el módulo no existe.
* No valida que el objeto sea `dict`; un `dict` no funcionará porque sus claves no son atributos.

#### `Config.from_file()`

Carga configuración desde un archivo arbitrario usando una función de carga inyectada.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `filename` | `str \| os.PathLike[str]` | Sí | Ruta al archivo, absoluta o relativa a `root_path`. |
| `load` | `Callable[[IO[Any]], Mapping[str, Any]]` | Sí | Callable que recibe un file handle y retorna un `Mapping`. Ej: `json.load`, `tomllib.load`. |
| `silent` | `bool` | No | Si es `True`, ignora si el archivo no existe. Por defecto `False`. |
| `text` | `bool` | No | Si es `True` abre en modo texto `"r"`, si es `False` en binario `"rb"`. Por defecto `True`. |

**Valor de retorno:** `bool` - Resultado de `from_mapping()`, `True` si se cargó, `False` si `silent=True` y no existe.

**Manejo de errores:** 
* Captura `OSError`. Si `silent` es `True` y `e.errno` es `ENOENT` o `EISDIR`, retorna `False`.
* En caso contrario, modifica `e.strerror` y relanza la excepción.

#### `Config.from_mapping()`

Actualiza la configuración desde un mapping o kwargs, filtrando solo claves en mayúsculas.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `mapping` | `Mapping[str, Any] \| None` | No | Diccionario o mapping con valores de configuración. Por defecto `None`. |
| `**kwargs` | `Any` | No | Pares clave-valor adicionales. Tienen prioridad sobre `mapping`. |

**Valor de retorno:** `bool` - Siempre retorna `True`.

**Manejo de errores:** No genera errores. Ignora silenciosamente cualquier clave que no sea `key.isupper()`.

#### `Config.get_namespace()`

Retorna un subconjunto de la configuración filtrado por un prefijo/namespace.

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `namespace` | `str` | Sí | Prefijo a filtrar (ej: `'IMAGE_STORE_'`). |
| `lowercase` | `bool` | No | Si es `True`, convierte las claves resultantes a minúsculas. Por defecto `True`. |
| `trim_namespace` | `bool` | No | Si es `True`, elimina el prefijo de las claves resultantes. Por defecto `True`. |

**Valor de retorno:** `dict[str, Any]` - Diccionario filtrado y transformado.

**Manejo de errores:** No genera errores. Retorna `dict` vacío si no hay coincidencias.

#### `Config.__repr__()`

| Parámetro | Tipo | Requerido | Descripción |
| :--- | :--- | :--- | :--- |
| `self` | `Config` | Sí | Instancia implícita. |

**Valor de retorno:** `str` - Representación con formato `<Config {dict}>`.

**Manejo de errores:** No genera errores.

> **Nota sobre funciones anidadas:** Tras el análisis exhaustivo del código fuente provisto, no se detectaron funciones anidadas, locales, callbacks ni workers de hilos definidos dentro de los métodos. El 100% de las funciones y métodos existentes han sido documentados arriba.

## 3. Ejemplo de Uso

```python
import os
import json
from flask import Flask

# 1. Inicialización y carga desde objeto (defaults)
class DefaultConfig:
    DEBUG = False
    SECRET_KEY = 'default-key'
    IMAGE_STORE_TYPE = 'fs'
    IMAGE_STORE_PATH = '/tmp/images'

app = Flask(__name__)
app.config.from_object(DefaultConfig)

# 2. Carga desde archivo Python relativo a root_path
# app.config.from_pyfile('config/production.cfg', silent=False)

# 3. Carga desde variable de entorno
# export MYAPP_SETTINGS='/path/to/settings.cfg'
# app.config.from_envvar('MYAPP_SETTINGS', silent=True)

# 4. Carga desde variables de entorno con prefijo FLASK_
os.environ['FLASK_CACHE__REDIS__HOST'] = '"localhost"'
os.environ['FLASK_CACHE__REDIS__PORT'] = '6379'
os.environ['FLASK_DEBUG'] = 'true'
app.config.from_prefixed_env(prefix="FLASK", loads=json.loads)
# Resultado: app.config['CACHE'] = {'REDIS': {'HOST': 'localhost', 'PORT': 6379}}
#            app.config['DEBUG'] = True (convertido desde JSON)

# 5. Carga desde archivo JSON genérico
# app.config.from_file("config.json", load=json.load, text=True)

# 6. Carga directa desde mapping (solo claves en mayúsculas)
app.config.from_mapping(
    {'DEBUG': True, 'TESTING': True, 'lowercase_key': 'ignorado'},
    SECRET_KEY='clave-super-secreta'
)

# 7. Uso de get_namespace para extraer configuración por prefijo
app.config['IMAGE_STORE_BASE_URL'] = 'http://img.example.com'
image_store_config = app.config.get_namespace('IMAGE_STORE_')
print(image_store_config)
# {'type': 'fs', 'path': '/tmp/images', 'base_url': 'http://img.example.com'}

# 8. Uso de ConfigAttribute (ej. app.debug hace forward a app.config['DEBUG'])
print(app.debug)  # Accede vía descriptor ConfigAttribute
app.debug = False # Escribe vía ConfigAttribute.__set__
```